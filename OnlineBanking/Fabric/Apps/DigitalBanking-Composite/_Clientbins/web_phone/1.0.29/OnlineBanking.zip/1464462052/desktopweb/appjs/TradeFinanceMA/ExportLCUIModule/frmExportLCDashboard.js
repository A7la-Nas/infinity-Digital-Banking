define("TradeFinanceMA/ExportLCUIModule/frmExportLCDashboard", function() {
    return function(controller) {
        function addWidgetsfrmExportLCDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmExportLCDashboard"] && appConfig.componentMetadata["ResourcesMA"]["frmExportLCDashboard"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.ImportLC.ExportLC";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "TradeFinance";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "Exports";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxCreateNewDrawingPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxCreateNewDrawingPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1500
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateNewDrawingPopup.setDefaultUnit(kony.flex.DP);
            var flxCreateNewDrawingContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxCreateNewDrawingContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "width": "600dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateNewDrawingContainer.setDefaultUnit(kony.flex.DP);
            var CreateNewDrawing = new com.InfinityOLB.TradeFinance.LGCopyDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CreateNewDrawing",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCreateNewDrawingContainer.add(CreateNewDrawing);
            flxCreateNewDrawingPopup.add(flxCreateNewDrawingContainer);
            formTemplate12.flxContentPopup.add(flxCreateNewDrawingPopup);
            var flxExportLCSummary = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "430dp",
                "id": "flxExportLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportLCSummary.setDefaultUnit(kony.flex.DP);
            var flxExportOverview = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "410dp",
                "id": "flxExportOverview",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0",
                "width": "66.25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportOverview.setDefaultUnit(kony.flex.DP);
            var flxExportOverviewHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxExportOverviewHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportOverviewHeader.setDefaultUnit(kony.flex.DP);
            var lblExportOverviewHeading = new kony.ui.Label({
                "id": "lblExportOverviewHeading",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.exportOverview\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCurrencyFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxCurrencyFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "18%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyFilter.setDefaultUnit(kony.flex.DP);
            var flxCurrencyFilterDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxCurrencyFilterDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyFilterDropdown.setDefaultUnit(kony.flex.DP);
            var lblCurrencyFilterDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCurrencyFilterDropdownIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedCurrencyFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectedCurrencyFilter",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "USD-$",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrencyFilterDropdown.add(lblCurrencyFilterDropdownIcon, lblSelectedCurrencyFilter);
            var flxCurrencyFilterList = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxCurrencyFilterList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "40dp",
                "verticalScrollIndicator": true,
                "width": "46.40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyFilterList.setDefaultUnit(kony.flex.DP);
            var segCurrencyFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segCurrencyFilter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrencyFilterList.add(segCurrencyFilter);
            flxCurrencyFilter.add(flxCurrencyFilterDropdown, flxCurrencyFilterList);
            var flxDurationFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDurationFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDurationFilter.setDefaultUnit(kony.flex.DP);
            var flxDurationFilterDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxDurationFilterDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDurationFilterDropdown.setDefaultUnit(kony.flex.DP);
            var lblDurationFilterDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblDurationFilterDropdownIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedDurationFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectedDurationFilter",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "1 Month",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDurationFilterDropdown.add(lblDurationFilterDropdownIcon, lblSelectedDurationFilter);
            var flxDurationFilterList = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxDurationFilterList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "40dp",
                "verticalScrollIndicator": true,
                "width": "46.40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxDurationFilterList.setDefaultUnit(kony.flex.DP);
            var segDurationFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segDurationFilter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDurationFilterList.add(segDurationFilter);
            flxDurationFilter.add(flxDurationFilterDropdown, flxDurationFilterList);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            flxExportOverviewHeader.add(lblExportOverviewHeading, flxCurrencyFilter, flxDurationFilter, flxSeparator1);
            var flxExportSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "78dp",
                "id": "flxExportSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportSummary.setDefaultUnit(kony.flex.DP);
            var flxSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary1.setDefaultUnit(kony.flex.DP);
            var lblSummary1 = new kony.ui.Label({
                "id": "lblSummary1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.dashboard.pendingRequests\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCount1 = new kony.ui.Label({
                "id": "lblCount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblFF000020px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount1 = new kony.ui.Label({
                "id": "lblAmount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSummary1.add(lblSummary1, lblCount1, lblAmount1);
            var flxHorizontalSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "32dp",
                "id": "flxHorizontalSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator1.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator1.add();
            var flxSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary2.setDefaultUnit(kony.flex.DP);
            var lblSummary2 = new kony.ui.Label({
                "id": "lblSummary2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCount2 = new kony.ui.Label({
                "id": "lblCount2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblffa500SSPReg20px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount2 = new kony.ui.Label({
                "id": "lblAmount2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSummary2.add(lblSummary2, lblCount2, lblAmount2);
            var flxHorizontalSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "32dp",
                "id": "flxHorizontalSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator2.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator2.add();
            var flxSummary3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSummary3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary3.setDefaultUnit(kony.flex.DP);
            var lblSummary3 = new kony.ui.Label({
                "id": "lblSummary3",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.settled\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCount3 = new kony.ui.Label({
                "id": "lblCount3",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl00849520px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount3 = new kony.ui.Label({
                "id": "lblAmount3",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSummary3.add(lblSummary3, lblCount3, lblAmount3);
            var flxHorizontalSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "32dp",
                "id": "flxHorizontalSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator3.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator3.add();
            var flxSummary4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSummary4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary4.setDefaultUnit(kony.flex.DP);
            var lblSummary4 = new kony.ui.Label({
                "id": "lblSummary4",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Rejected\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCount4 = new kony.ui.Label({
                "id": "lblCount4",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount4 = new kony.ui.Label({
                "id": "lblAmount4",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSummary4.add(lblSummary4, lblCount4, lblAmount4);
            flxExportSummary.add(flxSummary1, flxHorizontalSeparator1, flxSummary2, flxHorizontalSeparator2, flxSummary3, flxHorizontalSeparator3, flxSummary4);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxBarGraphContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "202dp",
                "id": "flxBarGraphContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.20%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "87.60%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBarGraphContainer.setDefaultUnit(kony.flex.DP);
            var flxBarGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBarGraph",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBarGraph.setDefaultUnit(kony.flex.DP);
            flxBarGraph.add();
            var flxLegends = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "61dp",
                "id": "flxLegends",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "80dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegends.setDefaultUnit(kony.flex.DP);
            var flxLegend1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLegend1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegend1.setDefaultUnit(kony.flex.DP);
            var flxLegendIcon1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLegendIcon1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxbdbdbdOpacity50",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendIcon1.setDefaultUnit(kony.flex.DP);
            flxLegendIcon1.add();
            var lblLegendValue1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLegendValue1",
                "isVisible": true,
                "left": "7dp",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.available\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegend1.add(flxLegendIcon1, lblLegendValue1);
            var flxLegend2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLegend2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegend2.setDefaultUnit(kony.flex.DP);
            var flxLegendIcon2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLegendIcon2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxbdbdbdNoBorder",
                "top": "0dp",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendIcon2.setDefaultUnit(kony.flex.DP);
            flxLegendIcon2.add();
            var lblLegendValue2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLegendValue2",
                "isVisible": true,
                "left": "7dp",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.utilized\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegend2.add(flxLegendIcon2, lblLegendValue2);
            flxLegends.add(flxLegend1, flxLegend2);
            flxBarGraphContainer.add(flxBarGraph, flxLegends);
            flxExportOverview.add(flxExportOverviewHeader, flxExportSummary, flxSeparator2, flxBarGraphContainer);
            var flxQuickLinksAndRecentLC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxQuickLinksAndRecentLC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "32.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksAndRecentLC.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLink1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxQuickLink1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxffffffBottomBorder",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLink1.setDefaultUnit(kony.flex.DP);
            var btnQL1 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnQL1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.CreateNewDrawing\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLink1.add(btnQL1);
            var flxQuickLink2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxQuickLink2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLink2.setDefaultUnit(kony.flex.DP);
            var btnQL2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnQL2",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.newlyReceivedExportLc\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLink2.add(btnQL2);
            flxQuickLinks.add(flxQuickLink1, flxQuickLink2);
            var flxRecentLC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "290dp",
                "id": "flxRecentLC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentLC.setDefaultUnit(kony.flex.DP);
            var flxRecentLCHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxRecentLCHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentLCHeader.setDefaultUnit(kony.flex.DP);
            var lblRecentLCHeading = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRecentLCHeading",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.recentExportLC\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            flxRecentLCHeader.add(lblRecentLCHeading, flxSeparator4);
            var flxRecentLCRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "240dp",
                "id": "flxRecentLCRecords",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentLCRecords.setDefaultUnit(kony.flex.DP);
            var segRecentLC = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "height": "100%",
                "id": "segRecentLC",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxRecentLC"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRecentLCRecords.add(segRecentLC);
            flxRecentLC.add(flxRecentLCHeader, flxRecentLCRecords);
            flxQuickLinksAndRecentLC.add(flxQuickLinks, flxRecentLC);
            var flxQuickLinksTablet = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxQuickLinksTablet",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksTablet.setDefaultUnit(kony.flex.DP);
            var flxQuickLinkTablet1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxQuickLinkTablet1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinkTablet1.setDefaultUnit(kony.flex.DP);
            var btnQLTablet1 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnQLTablet1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.CreateNewDrawing\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLinkTablet1.add(btnQLTablet1);
            var flxQuickLinkTablet2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxQuickLinkTablet2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinkTablet2.setDefaultUnit(kony.flex.DP);
            var btnQLTablet2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnQLTablet2",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.newlyReceivedExportLc\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLinkTablet2.add(btnQLTablet2);
            flxQuickLinksTablet.add(flxQuickLinkTablet1, flxQuickLinkTablet2);
            flxExportLCSummary.add(flxExportOverview, flxQuickLinksAndRecentLC, flxQuickLinksTablet);
            var flxList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxList.setDefaultUnit(kony.flex.DP);
            var flxLetterOfCredit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLetterOfCredit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetterOfCredit.setDefaultUnit(kony.flex.DP);
            var flxLCList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCList.setDefaultUnit(kony.flex.DP);
            var flxLCListHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCListHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCListHeader.setDefaultUnit(kony.flex.DP);
            var btnTab1 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab1",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknBtnAccountSummarySelected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LetterofCredits\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [20, 0, 20, 0],
                "paddingInPixel": true
            }, {});
            var btnTab2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBtnAccountSummaryUnselected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Amendments\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [20, 0, 20, 0],
                "paddingInPixel": true
            }, {});
            var btnTab3 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab3",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBtnAccountSummaryUnselected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Drawings\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [20, 0, 20, 0],
                "paddingInPixel": true
            }, {});
            flxLCListHeader.add(btnTab1, btnTab2, btnTab3);
            var flxSearchAndFilter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSearchAndFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchAndFilter.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.60%",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "60%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var lblSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "25dp",
                "id": "lblSearchIcon",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "25dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "40dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingsSearchPlaceholder\")",
                "right": "40dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 10, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var flxSearchClear = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSearchClear",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "16dp",
                "top": "0dp",
                "width": "18dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchClear.setDefaultUnit(kony.flex.DP);
            var lblClearIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "17dp",
                "id": "lblClearIcon",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "width": "17dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchClear.add(lblClearIcon);
            flxSearch.add(lblSearchIcon, tbxSearch, flxSearchClear);
            var flxDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "6.60%",
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "29%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var lblView = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblView",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl949494SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFilterText = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFilterText",
                "isVisible": true,
                "left": "62dp",
                "skin": "ICSknLbl42424215PX",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDropdownFilterIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Accounts"
                },
                "centerY": "50%",
                "id": "lblDropdownFilterIcon",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(lblView, lblFilterText, lblDropdownFilterIcon);
            var flxVerticalEllipsis = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsis",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1.60%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "3.30%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsis.setDefaultUnit(kony.flex.DP);
            var lblVerticalEllipsis = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblVerticalEllipsis",
                "isVisible": true,
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsis.add(lblVerticalEllipsis);
            flxSearchAndFilter.add(flxSearch, flxDropDown, flxVerticalEllipsis);
            var LcListBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "LcListBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            LcListBody.setDefaultUnit(kony.flex.DP);
            var flxListHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxListHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxbgf7f7f7op100Bordere3e3e3radius2pxTopBottom",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListHeader.setDefaultUnit(kony.flex.DP);
            var flxLCHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLCHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCHeader.setDefaultUnit(kony.flex.DP);
            var flxColumn1Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn1Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn1Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn1Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn1Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn1Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "13dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn1Tab1.add(lblColumn1Tab1, imgColumn1Tab1);
            var flxColumn2Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn2Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn2Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn2Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCReference\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn2Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn2Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "13dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn2Tab1.add(lblColumn2Tab1, imgColumn2Tab1);
            var flxColumn3Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn3Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn3Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn3Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn3Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn3Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn3Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "13dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn3Tab1.add(lblColumn3Tab1, imgColumn3Tab1);
            var flxColumn4Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn4Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "10.5%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn4Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn4Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn4Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.updatedOn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn4Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn4Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "13dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn4Tab1.add(lblColumn4Tab1, imgColumn4Tab1);
            var flxColumn5Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn5Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn5Tab1.setDefaultUnit(kony.flex.DP);
            var imgColumn5Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn5Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "13dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColumn5Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn5Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn5Tab1.add(imgColumn5Tab1, lblColumn5Tab1);
            var flxColumn6Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn6Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "14%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn6Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn6Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn6Tab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn6Tab1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn6Tab1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "14dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn6Tab1.add(lblColumn6Tab1, imgColumn6Tab1);
            var flxColumn7Tab1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn7Tab1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn7Tab1.setDefaultUnit(kony.flex.DP);
            var lblColumn7Tab1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn7Tab1",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn7Tab1.add(lblColumn7Tab1);
            flxLCHeader.add(flxColumn1Tab1, flxColumn2Tab1, flxColumn3Tab1, flxColumn4Tab1, flxColumn5Tab1, flxColumn6Tab1, flxColumn7Tab1);
            var flxAmendmentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAmendmentHeader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentHeader.setDefaultUnit(kony.flex.DP);
            var flxColumn1Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn1Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn1Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn1Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn1Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn1Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn1Tab3.add(lblColumn1Tab3, imgColumn1Tab3);
            var flxColumn2Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn2Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "17%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn2Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn2Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCReference\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn2Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn2Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn2Tab3.add(lblColumn2Tab3, imgColumn2Tab3);
            var flxColumn3Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn3Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "16.50%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn3Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn3Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn3Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn3Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn3Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn3Tab3.add(lblColumn3Tab3, imgColumn3Tab3);
            var flxColumn4Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn4Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn4Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn4Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn4Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReceivedOn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn4Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn4Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn4Tab3.add(lblColumn4Tab3, imgColumn4Tab3);
            var flxColumn5Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn5Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn5Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn5Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn5Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmendmentNoWithDot\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn5Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn5Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn5Tab3.add(lblColumn5Tab3, imgColumn5Tab3);
            var flxColumn6Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn6Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "14%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn6Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn6Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn6Tab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn6Tab3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn6Tab3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn6Tab3.add(lblColumn6Tab3, imgColumn6Tab3);
            var flxColumn7Tab3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn7Tab3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "8%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn7Tab3.setDefaultUnit(kony.flex.DP);
            var lblColumn7Tab3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn7Tab3",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn7Tab3.add(lblColumn7Tab3);
            flxAmendmentHeader.add(flxColumn1Tab3, flxColumn2Tab3, flxColumn3Tab3, flxColumn4Tab3, flxColumn5Tab3, flxColumn6Tab3, flxColumn7Tab3);
            var flxDrawingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDrawingHeader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingHeader.setDefaultUnit(kony.flex.DP);
            var flxColumn1Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn1Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn1Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn1Tab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn1Tab2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn1Tab2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn1Tab2.add(lblColumn1Tab2, imgColumn1Tab2);
            var flxColumn2Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn2Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn2Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn2Tab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingReference\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn2Tab2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn2Tab2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn2Tab2.add(lblColumn2Tab2, imgColumn2Tab2);
            var flxColumn3Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn3Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn3Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn3Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn3Tab2",
                "isVisible": true,
                "right": "18dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn3Tab2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn3Tab2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn3Tab2.add(lblColumn3Tab2, imgColumn3Tab2);
            var flxColumn4Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn4Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn4Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn4Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn4Tab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Date\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn4Tab2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn4Tab2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn4Tab2.add(lblColumn4Tab2, imgColumn4Tab2);
            var flxColumn5Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn5Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn5Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn5Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn5Tab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgColumn5Tab2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgColumn5Tab2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn5Tab2.add(lblColumn5Tab2, imgColumn5Tab2);
            var flxColumn6Tab2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxColumn6Tab2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn6Tab2.setDefaultUnit(kony.flex.DP);
            var lblColumn6Tab2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblColumn6Tab2",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn6Tab2.add(lblColumn6Tab2);
            flxDrawingHeader.add(flxColumn1Tab2, flxColumn2Tab2, flxColumn3Tab2, flxColumn4Tab2, flxColumn5Tab2, flxColumn6Tab2);
            flxListHeader.add(flxLCHeader, flxAmendmentHeader, flxDrawingHeader);
            var flxTransactionList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "5dp",
                "clipBounds": false,
                "id": "flxTransactionList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionList.setDefaultUnit(kony.flex.DP);
            var segList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segList",
                "isVisible": true,
                "left": "-1dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentHistorySelected"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": true,
                "top": "40dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100.20%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionList.add(segList);
            var flxNoTransactions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactions.setDefaultUnit(kony.flex.DP);
            var imgNoTransaction = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgNoTransaction",
                "isVisible": true,
                "left": "67dp",
                "src": "info_large.png",
                "top": "37dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoTransaction = new kony.ui.Label({
                "id": "lblNoTransaction",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.NoRecordErrMsg\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoTransactions.add(imgNoTransaction, lblNoTransaction);
            LcListBody.add(flxListHeader, flxTransactionList, flxNoTransactions);
            flxLCList.add(flxLCListHeader, flxSearchAndFilter, LcListBody);
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPagination",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var flxPageEnd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPageEnd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPageEnd.setDefaultUnit(kony.flex.DP);
            var lblPageEndIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblPageEndIcon",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "b",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPageEnd.add(lblPageEndIcon);
            var flxPageNext = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPageNext",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPageNext.setDefaultUnit(kony.flex.DP);
            var lblPageNextIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblPageNextIcon",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": ".",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPageNext.add(lblPageNextIcon);
            var lblPageText = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPageText",
                "isVisible": true,
                "minWidth": "66dp",
                "right": "10dp",
                "skin": "sknlbl42424215px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPagePrevious = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPagePrevious",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagePrevious.setDefaultUnit(kony.flex.DP);
            var lblPagePreviousIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblPagePreviousIcon",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "-",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPagePrevious.add(lblPagePreviousIcon);
            var flxPageStart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPageStart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPageStart.setDefaultUnit(kony.flex.DP);
            var lblPageStartIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblPageStartIcon",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "[",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPageStart.add(lblPageStartIcon);
            flxPagination.add(flxPageEnd, flxPageNext, lblPageText, flxPagePrevious, flxPageStart);
            flxLetterOfCredit.add(flxLCList, flxPagination);
            var flxListDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "maxHeight": "580dp",
                "minHeight": "100dp",
                "isModalContainer": false,
                "right": "6.60%",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "110dp",
                "width": "29%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListDropdown.setDefaultUnit(kony.flex.DP);
            var flxFilters = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "maxHeight": "500dp",
                "minHeight": "100dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFilters.setDefaultUnit(kony.flex.DP);
            var segFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segFilter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxTempExportLCFilter1"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxGuaranteeReceivedDetailsHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilters.add(segFilter);
            var flxFilterActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxFilterActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterActions.setDefaultUnit(kony.flex.DP);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var btnCancel = new kony.ui.Button({
                "bottom": "10dp",
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "5%",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                "top": "10dp",
                "width": "43%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnApply = new kony.ui.Button({
                "bottom": "10dp",
                "centerY": "50%",
                "height": "40dp",
                "id": "btnApply",
                "isVisible": true,
                "right": "5%",
                "skin": "ICSknbtnEnabed003e7536px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.datePicker.apply\")",
                "top": "20dp",
                "width": "43%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterActions.add(flxBottomSeparator, btnCancel, btnApply);
            flxListDropdown.add(flxFilters, flxFilterActions);
            var flxEllipsisDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "42dp",
                "id": "flxEllipsisDropDown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3.20%",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "110dp",
                "width": "20%",
                "zIndex": 15,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEllipsisDropDown.setDefaultUnit(kony.flex.DP);
            var segEllipsisDropDownValues = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblListValue": ""
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segEllipsisDropDownValues",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxListDropdown": "flxListDropdown",
                    "lblListValue": "lblListValue"
                },
                "width": "100%",
                "zIndex": 15,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEllipsisDropDown.add(segEllipsisDropDownValues);
            flxList.add(flxLetterOfCredit, flxListDropdown, flxEllipsisDropDown);
            var flxActions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var btnBackToDashboard = new kony.ui.Button({
                "height": "40dp",
                "id": "btnBackToDashboard",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.backToLcDashboard\")",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back to LC Dashboard"
            });
            flxActions.add(btnBackToDashboard);
            formTemplate12.flxContentTCCenter.add(flxExportLCSummary, flxList, flxActions);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxCreateNewDrawingPopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "lblSelectedCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterDropdown"]
                    },
                    "flxCurrencyFilterList": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter"]
                    },
                    "segCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterList"]
                    },
                    "lblSelectedDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterDropdown"]
                    },
                    "flxDurationFilterList": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter"]
                    },
                    "segDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterList"]
                    },
                    "flxSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader"]
                    },
                    "flxExportSummary": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview"]
                    },
                    "lblSummary1": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary2": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary3": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary3"]
                    },
                    "flxHorizontalSeparator3": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary4": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary4"]
                    },
                    "flxSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview"]
                    },
                    "flxBarGraphContainer": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview"]
                    },
                    "flxBarGraph": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxBarGraphContainer"]
                    },
                    "flxSeparator4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxQuickLinksAndRecentLC", "flxRecentLC", "flxRecentLCHeader"]
                    },
                    "flxLetterOfCredit": {
                        "skin": "ICSknFlxF8F7F8",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxLCList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit"]
                    },
                    "flxSearchAndFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "tbxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxSearch"]
                    },
                    "flxDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "lblView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblFilterText": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblDropdownFilterIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "LcListBody": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "segList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxTransactionList"]
                    },
                    "flxNoTransactions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody"]
                    },
                    "lblNoTransaction": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxNoTransactions"]
                    },
                    "flxPagination": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit"]
                    },
                    "flxListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 5106,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "segFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilters"]
                    },
                    "flxFilterActions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "flxBottomSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilterActions"]
                    },
                    "flxActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknFlxBordere3e3e3Radius3Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "btnBackToDashboard": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxActions"]
                    }
                },
                "1024": {
                    "flxCreateNewDrawingPopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "flxExportLCSummary": {
                        "height": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxExportOverview": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary"]
                    },
                    "lblSelectedCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterDropdown"]
                    },
                    "flxCurrencyFilterList": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter"]
                    },
                    "segCurrencyFilter": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterList"]
                    },
                    "lblSelectedDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterDropdown"]
                    },
                    "flxDurationFilterList": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter"]
                    },
                    "segDurationFilter": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterList"]
                    },
                    "flxSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader"]
                    },
                    "lblSummary1": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary2": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary3": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary3"]
                    },
                    "lblCount3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary3"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary4": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary4"]
                    },
                    "flxSeparator2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview"]
                    },
                    "flxBarGraph": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxBarGraphContainer"]
                    },
                    "flxQuickLinksAndRecentLC": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary"]
                    },
                    "flxSeparator4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxQuickLinksAndRecentLC", "flxRecentLC", "flxRecentLCHeader"]
                    },
                    "flxQuickLinksTablet": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary"]
                    },
                    "flxQuickLinkTablet1": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxQuickLinksTablet"]
                    },
                    "flxQuickLinkTablet2": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxQuickLinksTablet"]
                    },
                    "flxLCList": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit"]
                    },
                    "flxLCListHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxSearchAndFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "47%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "tbxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxSearch"]
                    },
                    "flxDropDown": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "lblView": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblFilterText": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblDropdownFilterIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "flxVerticalEllipsis": {
                        "right": {
                            "type": "string",
                            "value": "1.10%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "flxColumn1Tab1": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn2Tab1": {
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn3Tab1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn4Tab1": {
                        "width": {
                            "type": "string",
                            "value": "19%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn5Tab1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn6Tab1": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxColumn7Tab1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "11.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxAmendmentHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader"]
                    },
                    "flxColumn1Tab3": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn2Tab3": {
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn3Tab3": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn4Tab3": {
                        "width": {
                            "type": "string",
                            "value": "19%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn5Tab3": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn6Tab3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxColumn7Tab3": {
                        "width": {
                            "type": "string",
                            "value": "11.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxDrawingHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader"]
                    },
                    "flxColumn1Tab2": {
                        "width": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "flxColumn2Tab2": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "flxColumn3Tab2": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "flxColumn4Tab2": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "24%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "flxColumn5Tab2": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "flxColumn6Tab2": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "segList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxTransactionList"]
                    },
                    "flxNoTransactions": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody"]
                    },
                    "imgNoTransaction": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxNoTransactions"]
                    },
                    "lblNoTransaction": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxNoTransactions"]
                    },
                    "flxListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxFilters": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "segFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilters"]
                    },
                    "flxFilterActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "flxBottomSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilterActions"]
                    },
                    "flxEllipsisDropDown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxActions": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "btnBackToDashboard": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxActions"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxCreateNewDrawingPopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "lblSelectedCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterDropdown"]
                    },
                    "flxCurrencyFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter"]
                    },
                    "segCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterList"]
                    },
                    "lblSelectedDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterDropdown"]
                    },
                    "flxDurationFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter"]
                    },
                    "segDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterList"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "flxBarGraph": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxBarGraphContainer"]
                    },
                    "flxLetterOfCredit": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxLCList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit"]
                    },
                    "flxLCListHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxSearchAndFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxSearch": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "tbxSearch": {
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxSearch"]
                    },
                    "flxDropDown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter"]
                    },
                    "lblView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblFilterText": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "lblDropdownFilterIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "flxSearchAndFilter", "flxDropDown"]
                    },
                    "LcListBody": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList"]
                    },
                    "flxListHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody"]
                    },
                    "flxLCHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader"]
                    },
                    "flxColumn1Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn1Tab1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn1Tab1"]
                    },
                    "flxColumn2Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn2Tab1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn2Tab1"]
                    },
                    "flxColumn3Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn3Tab1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn3Tab1"]
                    },
                    "flxColumn4Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn4Tab1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn4Tab1"]
                    },
                    "flxColumn5Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn5Tab1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn5Tab1"]
                    },
                    "flxColumn6Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "imgColumn6Tab1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader", "flxColumn6Tab1"]
                    },
                    "flxColumn7Tab1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxLCHeader"]
                    },
                    "flxAmendmentHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader"]
                    },
                    "flxColumn1Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn1Tab3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn1Tab3"]
                    },
                    "flxColumn2Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn2Tab3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn2Tab3"]
                    },
                    "flxColumn3Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn3Tab3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn3Tab3"]
                    },
                    "flxColumn4Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn4Tab3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn4Tab3"]
                    },
                    "flxColumn5Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn5Tab3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn5Tab3"]
                    },
                    "flxColumn6Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "imgColumn6Tab3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader", "flxColumn6Tab3"]
                    },
                    "flxColumn7Tab3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxAmendmentHeader"]
                    },
                    "flxDrawingHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader"]
                    },
                    "flxColumn1Tab2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "imgColumn1Tab2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader", "flxColumn1Tab2"]
                    },
                    "flxColumn2Tab2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "imgColumn2Tab2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader", "flxColumn2Tab2"]
                    },
                    "flxColumn3Tab2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "imgColumn3Tab2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader", "flxColumn3Tab2"]
                    },
                    "flxColumn4Tab2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "imgColumn4Tab2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader", "flxColumn4Tab2"]
                    },
                    "flxColumn5Tab2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "imgColumn5Tab2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader", "flxColumn5Tab2"]
                    },
                    "flxColumn6Tab2": {
                        "width": {
                            "type": "string",
                            "value": "11.70%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxListHeader", "flxDrawingHeader"]
                    },
                    "segList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxTransactionList"]
                    },
                    "flxNoTransactions": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody"]
                    },
                    "imgNoTransaction": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxNoTransactions"]
                    },
                    "lblNoTransaction": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxLetterOfCredit", "flxLCList", "LcListBody", "flxNoTransactions"]
                    },
                    "flxListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isCustomLayout": false,
                        "zIndex": 500,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxFilters": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 500,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "segFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilters"]
                    },
                    "flxFilterActions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown"]
                    },
                    "flxBottomSeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilterActions"]
                    },
                    "btnCancel": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilterActions"]
                    },
                    "btnApply": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList", "flxListDropdown", "flxFilterActions"]
                    },
                    "flxEllipsisDropDown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxList"]
                    },
                    "flxActions": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    }
                },
                "1380": {
                    "flxCreateNewDrawingPopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "lblSelectedCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterDropdown"]
                    },
                    "flxCurrencyFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter"]
                    },
                    "segCurrencyFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxCurrencyFilter", "flxCurrencyFilterList"]
                    },
                    "lblSelectedDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterDropdown"]
                    },
                    "flxDurationFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter"]
                    },
                    "segDurationFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportOverviewHeader", "flxDurationFilter", "flxDurationFilterList"]
                    },
                    "lblSummary1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary3"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary"]
                    },
                    "lblSummary4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxExportSummary", "flxSummary4"]
                    },
                    "flxBarGraph": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxBarGraphContainer"]
                    },
                    "flxLegends": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxExportLCSummary", "flxExportOverview", "flxBarGraphContainer"]
                    },
                    "btnBackToDashboard": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxActions"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCDashboard,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCDashboard",
            "init": controller.AS_Form_f3543ac5f7b94ae5aabbbb73fc2f8f95,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});