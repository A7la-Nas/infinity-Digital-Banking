define("TradeFinanceMA/ExportLCUIModule/frmExportAmendmentViewDetails", function() {
    return function(controller) {
        function addWidgetsfrmExportAmendmentViewDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgeImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAcknowledgeImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgeImage.setDefaultUnit(kony.flex.DP);
            var imgSuccessAcknowledge = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSuccessAcknowledge",
                "isVisible": true,
                "left": "0",
                "src": "confirmation_tick.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgeImage.add(imgSuccessAcknowledge);
            var flxAcknowlegementMessage = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "32dp",
                "id": "flxAcknowlegementMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "100dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowlegementMessage.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgementMsg = new kony.ui.Label({
                "id": "lblAcknowledgementMsg",
                "isVisible": true,
                "left": "0",
                "skin": "defLabel",
                "text": "Self consent on amendment request has been submitted successfully.",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowlegementMessage.add(lblAcknowledgementMsg);
            var flxAcknowledgeClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "29dp",
                "id": "flxAcknowledgeClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "21dp",
                "skin": "slFbox",
                "top": "0",
                "width": "29dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgeClose.setDefaultUnit(kony.flex.DP);
            var imgAcknowledgeClose = new kony.ui.Image2({
                "height": "29dp",
                "id": "imgAcknowledgeClose",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "29dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgeClose.add(imgAcknowledgeClose);
            flxAcknowledgement.add(flxAcknowledgeImage, flxAcknowlegementMessage, flxAcknowledgeClose);
            var flxAmendDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAmendDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "88%",
                "zIndex": 4,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblExportAmendDetailsHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExportAmendDetailsHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "text": "Export Amendment - AM56798749056 - Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisBodyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "5.80%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBodyContent.setDefaultUnit(kony.flex.DP);
            var flxVerticalEllipsisBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "55dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "6.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBody.setDefaultUnit(kony.flex.DP);
            var lblVerticalEllipsis = new kony.ui.Label({
                "centerX": "50%",
                "height": "100%",
                "id": "lblVerticalEllipsis",
                "isVisible": true,
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerticalEllipsisDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "-10dp",
                "skin": "slfBoxffffffB1R5",
                "top": "35dp",
                "width": "250dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.setDefaultUnit(kony.flex.DP);
            var segVerticalDropdownEllipsis = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segVerticalDropdownEllipsis",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCTypeOfAccountsList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListRow": "flxAccountListRow",
                    "flxLCAccountType": "flxLCAccountType",
                    "flxLCType": "flxLCType",
                    "flxLCTypeOfAccountsList": "flxLCTypeOfAccountsList",
                    "imgLCCheckbox": "imgLCCheckbox",
                    "lblLCAccountType": "lblLCAccountType",
                    "lblLCCheckbox": "lblLCCheckbox"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.add(segVerticalDropdownEllipsis);
            flxVerticalEllipsisBody.add(lblVerticalEllipsis, flxVerticalEllipsisDropdown);
            flxVerticalEllipsisBodyContent.add(flxVerticalEllipsisBody);
            flxAmendDetailsHeader.add(lblExportAmendDetailsHeader, flxVerticalEllipsisBodyContent);
            var flxLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummary.setDefaultUnit(kony.flex.DP);
            var flxSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryLbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummaryLbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryLbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "LC Summary",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLCViewDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCViewDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "12%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCViewDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewLCDetails",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View LC Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCViewDetails.add(lblViewLCDetails);
            flxLCSummaryLbl.add(lblLCSummary, flxLCViewDetails);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var flxLCSummaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": false,
                "id": "flxLCSummaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryDetails.setDefaultUnit(kony.flex.DP);
            var flxRow1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow1.setDefaultUnit(kony.flex.DP);
            var flxBeneficiary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiary.setDefaultUnit(kony.flex.DP);
            var flxBeneficiaryLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "80dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryLabel.setDefaultUnit(kony.flex.DP);
            var lblBeneficiary = new kony.ui.Label({
                "id": "lblBeneficiary",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Beneficiary:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeneficiaryLabel.add(lblBeneficiary);
            var flxBeneficiaryValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryValue.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblBeneficiaryValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Katie Flyod",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeneficiaryValue.add(lblBeneficiaryValue);
            flxBeneficiary.add(flxBeneficiaryLabel, flxBeneficiaryValue);
            var flxLCRefNo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCRefNo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCRefNo.setDefaultUnit(kony.flex.DP);
            var flxLCRefNoKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCRefNoKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "66dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCRefNoKey.setDefaultUnit(kony.flex.DP);
            var lblLCRefNo = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCRefNoKey.add(lblLCRefNo);
            var flxLCRefNoValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCRefNoValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCRefNoValue.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoValue01 = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCRefNoValue01",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "1039023921",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCRefNoValue.add(lblLCRefNoValue01);
            flxLCRefNo.add(flxLCRefNoKey, flxLCRefNoValue);
            var flxLCType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCType.setDefaultUnit(kony.flex.DP);
            var flxLCTypeLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCTypeLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCTypeLabel.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCTypeLabel.add(lblLCType);
            var flxLCTypeValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCTypeValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCTypeValue.setDefaultUnit(kony.flex.DP);
            var lblLCTypeValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Sight",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCTypeValue.add(lblLCTypeValue);
            flxLCType.add(flxLCTypeLabel, flxLCTypeValue);
            flxRow1.add(flxBeneficiary, flxLCRefNo, flxLCType);
            var flxRow2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow2.setDefaultUnit(kony.flex.DP);
            var flxLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmount.setDefaultUnit(kony.flex.DP);
            var flxLCAmountLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmountLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "80dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmountLabel.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmountLabel.add(lblLCAmount);
            var flxLCAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmountValue.setDefaultUnit(kony.flex.DP);
            var lblLCAmountValue1 = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCAmountValue1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmountValue.add(lblLCAmountValue1);
            flxLCAmount.add(flxLCAmountLabel, flxLCAmountValue);
            var flxIssueDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDate.setDefaultUnit(kony.flex.DP);
            var flxIssueDateLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDateLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDateLabel.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssueDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Issue Date: ",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssueDateLabel.add(lblIssueDate);
            var flxIssueDateValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDateValue.setDefaultUnit(kony.flex.DP);
            var lblIssueDateValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssueDateValue.add(lblIssueDateValue);
            flxIssueDate.add(flxIssueDateLabel, flxIssueDateValue);
            var flxExpiryDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExpiryDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDate.setDefaultUnit(kony.flex.DP);
            var flxExpiryDateLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxExpiryDateLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "78dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDateLabel.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDateLabel.add(lblExpiryDate);
            var flxExpiryDateValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxExpiryDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDateValue.setDefaultUnit(kony.flex.DP);
            var lblExpiryDateValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "12/31/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDateValue.add(lblExpiryDateValue);
            flxExpiryDate.add(flxExpiryDateLabel, flxExpiryDateValue);
            flxRow2.add(flxLCAmount, flxIssueDate, flxExpiryDate);
            var flxRow3 = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow3.setDefaultUnit(kony.flex.DP);
            var flxPaymentTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentTerms.setDefaultUnit(kony.flex.DP);
            var flxPaymentTermsLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxPaymentTermsLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "104dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentTermsLabel.setDefaultUnit(kony.flex.DP);
            var lblPaymentTerms = new kony.ui.Label({
                "id": "lblPaymentTerms",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Payment Terms:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentTermsLabel.add(lblPaymentTerms);
            var flxPaymentTermsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxPaymentTermsValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentTermsValue.setDefaultUnit(kony.flex.DP);
            var lblPaymentTermsValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPaymentTermsValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "By Payment",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentTermsValue.add(lblPaymentTermsValue);
            flxPaymentTerms.add(flxPaymentTermsLabel, flxPaymentTermsValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var flxCustomerNameLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxCustomerNameLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "110dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameLabel.setDefaultUnit(kony.flex.DP);
            var lblCustomerName = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerName",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Customer Name : ",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameLabel.add(lblCustomerName);
            var flxCustomerNameValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxCustomerNameValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Temenos UK",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.add(lblCustomerNameValue);
            flxCustomerName.add(flxCustomerNameLabel, flxCustomerNameValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var flxCustomerIDLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxCustomerIDLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerIDLabel.setDefaultUnit(kony.flex.DP);
            var lblCustomerID = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerID",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Customer ID :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerIDLabel.add(lblCustomerID);
            var flxCustomerIDValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxCustomerIDValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerIDValue.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "3142344",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerIDValue.add(lblCustomerIDValue);
            flxCustomerID.add(flxCustomerIDLabel, flxCustomerIDValue);
            flxRow3.add(flxPaymentTerms, flxCustomerName, flxCustomerID);
            flxLCSummaryDetails.add(flxRow1, flxRow2, flxRow3);
            flxSummaryHeader.add(flxLCSummaryLbl, flxBottomSeparator, flxLCSummaryDetails);
            flxLCSummary.add(flxSummaryHeader);
            var flxAmendDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "16dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxAmendmentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendmentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentDetails.setDefaultUnit(kony.flex.DP);
            var flxAmendmentDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAmendmentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblAmendmentDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmendmentDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Amendment Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendmentDetailsHeader.add(lblAmendmentDetails);
            var flxAmendmentDetailsHeaderSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAmendmentDetailsHeaderSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "14dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentDetailsHeaderSep.setDefaultUnit(kony.flex.DP);
            flxAmendmentDetailsHeaderSep.add();
            var flxSegAmendmentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegAmendmentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegAmendmentDetails.setDefaultUnit(kony.flex.DP);
            var segAmendmentDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblReview": "Amendment Reference :",
                    "lblReviewValue1": "AM56798749056"
                }, {
                    "lblReview": "Amendment Number :",
                    "lblReviewValue1": "02"
                }, {
                    "lblReview": "Received On :",
                    "lblReviewValue1": "01/25/2021"
                }, {
                    "lblReview": "Amendment Status:",
                    "lblReviewValue1": "Accepted"
                }, {
                    "lblReview": "Acceptance/Rejection Date :",
                    "lblReviewValue1": "02/13/2022"
                }, {
                    "lblReview": "Self Acceptance :",
                    "lblReviewValue1": "Approved"
                }],
                "groupCells": false,
                "id": "segAmendmentDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxAmendRowTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAmendRowTemplate": "flxAmendRowTemplate",
                    "flxReviewRight": "flxReviewRight",
                    "flxReviewValues": "flxReviewValues",
                    "flxreviewRows": "flxreviewRows",
                    "lblReview": "lblReview",
                    "lblReviewValue1": "lblReviewValue1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegAmendmentDetails.add(segAmendmentDetails);
            var flxAmendmentBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAmendmentBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxAmendmentBottomSeparator.add();
            flxAmendmentDetails.add(flxAmendmentDetailsHeader, flxAmendmentDetailsHeaderSep, flxSegAmendmentDetails, flxAmendmentBottomSeparator);
            var flxAmendmentsRequested = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendmentsRequested",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentsRequested.setDefaultUnit(kony.flex.DP);
            var flxAmendmentsReqHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAmendmentsReqHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentsReqHeader.setDefaultUnit(kony.flex.DP);
            var lblAmendmentsReqHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmendmentsReqHeader",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Amendments Requested",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendmentsReqHeader.add(lblAmendmentsReqHeader);
            var flxAmendmentsReqSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAmendmentsReqSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "14dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentsReqSeparator.setDefaultUnit(kony.flex.DP);
            flxAmendmentsReqSeparator.add();
            var flxAmendmentsReqDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendmentsReqDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentsReqDetails.setDefaultUnit(kony.flex.DP);
            var flxSegAmendmentReq = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegAmendmentReq",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegAmendmentReq.setDefaultUnit(kony.flex.DP);
            var segAmendmentsRequested = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblReview": "Amendment Reference:",
                    "lblReviewValue1": "12345678"
                }, {
                    "lblReview": "Amendment Reference:",
                    "lblReviewValue1": "12345678"
                }, {
                    "lblReview": "Amendment Reference:",
                    "lblReviewValue1": "12345678"
                }],
                "groupCells": false,
                "id": "segAmendmentsRequested",
                "isVisible": true,
                "left": 0,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxAmendRowTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAmendRowTemplate": "flxAmendRowTemplate",
                    "flxReviewRight": "flxReviewRight",
                    "flxReviewValues": "flxReviewValues",
                    "flxreviewRows": "flxreviewRows",
                    "lblReview": "lblReview",
                    "lblReviewValue1": "lblReviewValue1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegAmendmentReq.add(segAmendmentsRequested);
            var flxAmendmentLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAmendmentLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "98%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentLCAmount.setDefaultUnit(kony.flex.DP);
            var flxAmendLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "15%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendLCAmount.setDefaultUnit(kony.flex.DP);
            var lblAmendLCAmount = new kony.ui.Label({
                "id": "lblAmendLCAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendLCAmount.add(lblAmendLCAmount);
            var flxAmendLCAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendLCAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "254dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendLCAmountValue.setDefaultUnit(kony.flex.DP);
            var lblAmednLCAmountValue = new kony.ui.Label({
                "id": "lblAmednLCAmountValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 22,783.00",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmendLCAmountDiffValue = new kony.ui.Label({
                "id": "lblAmendLCAmountDiffValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "LC amount is increased by $ 230.67",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendLCAmountValue.add(lblAmednLCAmountValue, lblAmendLCAmountDiffValue);
            flxAmendmentLCAmount.add(flxAmendLCAmount, flxAmendLCAmountValue);
            var flxOtherAmendments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOtherAmendments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOtherAmendments.setDefaultUnit(kony.flex.DP);
            var flxOtherAmendmentsLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOtherAmendmentsLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "17%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOtherAmendmentsLabel.setDefaultUnit(kony.flex.DP);
            var lblOtherAmendments = new kony.ui.Label({
                "id": "lblOtherAmendments",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Other Amendments:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOtherAmendmentsLabel.add(lblOtherAmendments);
            var flxOtherAmendmentsDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOtherAmendmentsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "254dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "281dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOtherAmendmentsDetails.setDefaultUnit(kony.flex.DP);
            var lblOtherAmendmentsDetails = new kony.ui.Label({
                "id": "lblOtherAmendmentsDetails",
                "isVisible": true,
                "left": "0",
                "skin": "ICSKNLbl42424215PxWordBreak",
                "text": "Label",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOtherAmendmentsDetails.add(lblOtherAmendmentsDetails);
            flxOtherAmendments.add(flxOtherAmendmentsLabel, flxOtherAmendmentsDetails);
            flxAmendmentsReqDetails.add(flxSegAmendmentReq, flxAmendmentLCAmount, flxOtherAmendments);
            var flxAmendmentsReqBottomSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAmendmentsReqBottomSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentsReqBottomSep.setDefaultUnit(kony.flex.DP);
            flxAmendmentsReqBottomSep.add();
            flxAmendmentsRequested.add(flxAmendmentsReqHeader, flxAmendmentsReqSeparator, flxAmendmentsReqDetails, flxAmendmentsReqBottomSep);
            var flxAmendmentCharges = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmendmentCharges",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentCharges.setDefaultUnit(kony.flex.DP);
            var flxAmendmentChargesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAmendmentChargesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentChargesHeader.setDefaultUnit(kony.flex.DP);
            var lblAmendmentsCharges = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmendmentsCharges",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Amendment Charges",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendmentChargesHeader.add(lblAmendmentsCharges);
            var flxAmendmentChargesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAmendmentChargesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "14dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendmentChargesSeparator.setDefaultUnit(kony.flex.DP);
            flxAmendmentChargesSeparator.add();
            var flxSegAmendmentCharges = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegAmendmentCharges",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegAmendmentCharges.setDefaultUnit(kony.flex.DP);
            var segAmendmentCharges = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblReview": "Charges will be paid by:",
                    "lblReviewValue1": "Beneficiary (Me)"
                }, {
                    "lblReview": "Charges Debit Account:",
                    "lblReviewValue1": "Checking Account…6886"
                }],
                "groupCells": false,
                "id": "segAmendmentCharges",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxAmendRowTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAmendRowTemplate": "flxAmendRowTemplate",
                    "flxReviewRight": "flxReviewRight",
                    "flxReviewValues": "flxReviewValues",
                    "flxreviewRows": "flxreviewRows",
                    "lblReview": "lblReview",
                    "lblReviewValue1": "lblReviewValue1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegAmendmentCharges.add(segAmendmentCharges);
            var flxAmendChargesBottomSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAmendChargesBottomSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendChargesBottomSep.setDefaultUnit(kony.flex.DP);
            flxAmendChargesBottomSep.add();
            flxAmendmentCharges.add(flxAmendmentChargesHeader, flxAmendmentChargesSeparator, flxSegAmendmentCharges, flxAmendChargesBottomSep);
            flxAmendDetailsContent.add(flxAmendmentDetails, flxAmendmentsRequested, flxAmendmentCharges);
            var flxSelfAcceptance = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelfAcceptance",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "16dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelfAcceptance.setDefaultUnit(kony.flex.DP);
            var flxSelfAcceptanceHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSelfAcceptanceHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelfAcceptanceHeader.setDefaultUnit(kony.flex.DP);
            var lblSelfAcceptanaceHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelfAcceptanaceHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Self Acceptance",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelfAcceptanceHeader.add(lblSelfAcceptanaceHeader);
            var flxSelfAcceptanceSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSelfAcceptanceSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "14dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelfAcceptanceSeparator.setDefaultUnit(kony.flex.DP);
            flxSelfAcceptanceSeparator.add();
            var flxSelfAcceptanceContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxSelfAcceptanceContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelfAcceptanceContent.setDefaultUnit(kony.flex.DP);
            var flxAmendRaised = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAmendRaised",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmendRaised.setDefaultUnit(kony.flex.DP);
            var lblAmendmentRaised = new kony.ui.Label({
                "id": "lblAmendmentRaised",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Your acceptance on the amendment raised",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmendRaised.add(lblAmendmentRaised);
            var flxSelfAcceptanceActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelfAcceptanceActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelfAcceptanceActions.setDefaultUnit(kony.flex.DP);
            var flxAcceptContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAcceptContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "85dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcceptContainer.setDefaultUnit(kony.flex.DP);
            var flxAcceptRadioImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAcceptRadioImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcceptRadioImg.setDefaultUnit(kony.flex.DP);
            var imgRadioAccept = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadioAccept",
                "isVisible": true,
                "left": "0",
                "src": "radiobtn_active.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcceptRadioImg.add(imgRadioAccept);
            var flxAccept = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAccept",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccept.setDefaultUnit(kony.flex.DP);
            var lblAccept = new kony.ui.Label({
                "id": "lblAccept",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Accept",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccept.add(lblAccept);
            flxAcceptContainer.add(flxAcceptRadioImg, flxAccept);
            var flxRejectSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRejectSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectSection.setDefaultUnit(kony.flex.DP);
            var flxRejecttRadioImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRejecttRadioImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejecttRadioImg.setDefaultUnit(kony.flex.DP);
            var imgRadioReject = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadioReject",
                "isVisible": true,
                "left": "0",
                "src": "radio_btn_inactive.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejecttRadioImg.add(imgRadioReject);
            var flxReject = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxReject",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReject.setDefaultUnit(kony.flex.DP);
            var lblReject = new kony.ui.Label({
                "id": "lblReject",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Reject",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReject.add(lblReject);
            flxRejectSection.add(flxRejecttRadioImg, flxReject);
            flxSelfAcceptanceActions.add(flxAcceptContainer, flxRejectSection);
            flxSelfAcceptanceContent.add(flxAmendRaised, flxSelfAcceptanceActions);
            var flxRejectReasons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "95dp",
                "id": "flxRejectReasons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectReasons.setDefaultUnit(kony.flex.DP);
            var flxRejectReasonLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRejectReasonLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectReasonLabel.setDefaultUnit(kony.flex.DP);
            var lblRejectReasons = new kony.ui.Label({
                "id": "lblRejectReasons",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Enter reason for self rejection",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejectReasonLabel.add(lblRejectReasons);
            var flxRejectReasonTextBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRejectReasonTextBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "367dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectReasonTextBox.setDefaultUnit(kony.flex.DP);
            var txtAreaRejectReason = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtAreaRejectReason",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Enter Text Here",
                "skin": "sknlblTextareaBordere3e3e3SSP42424215px",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTextAreaPlaceholder727272SSPR36px"
            });
            flxRejectReasonTextBox.add(txtAreaRejectReason);
            flxRejectReasons.add(flxRejectReasonLabel, flxRejectReasonTextBox);
            flxSelfAcceptance.add(flxSelfAcceptanceHeader, flxSelfAcceptanceSeparator, flxSelfAcceptanceContent, flxRejectReasons);
            var flxButtonsActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxButtonsActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonsActions.setDefaultUnit(kony.flex.DP);
            var flxSubmitButtonActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubmitButtonActions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmitButtonActions.setDefaultUnit(kony.flex.DP);
            var btnSubmitConsent = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSubmitConsent",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "Submit Consent",
                "top": "0",
                "width": "12.20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnConsentBack = new kony.ui.Button({
                "height": "50dp",
                "id": "btnConsentBack",
                "isVisible": true,
                "right": "167dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Back",
                "top": "0",
                "width": "12.20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSubmitButtonActions.add(btnSubmitConsent, btnConsentBack);
            var flxBackButtonActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBackButtonActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackButtonActions.setDefaultUnit(kony.flex.DP);
            var btnBack = new kony.ui.Button({
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "text": "Back",
                "top": "0",
                "width": "11.50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackButtonActions.add(btnBack);
            flxButtonsActions.add(flxSubmitButtonActions, flxBackButtonActions);
            flxMain.add(flxAcknowledgement, flxAmendDetailsHeader, flxLCSummary, flxAmendDetailsContent, flxSelfAcceptance, flxButtonsActions);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268dp",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "44.30%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "height": "268dp",
                        "width": "44.30%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxLCDetailsPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLCDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1500
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLCDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "73%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblLCDetailsHeading = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLCDetailsHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.ExportLC\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLCPopupClose = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnLCPopupClose",
                "isVisible": true,
                "right": "0%",
                "skin": "btnClose",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.add(lblLCDetailsHeading, btnLCPopupClose);
            var flxLCDetailsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLCDetailsBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsBody.setDefaultUnit(kony.flex.DP);
            var ExportLCDetails = new com.InfinityOLB.TradeFinance.ExportLCDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ExportLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLCDetailsBody.add(ExportLCDetails);
            flxLCDetailsContainer.add(flxLCDetailsHeader, flxLCDetailsBody);
            var flxBottomGap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBottomGap",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "700dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomGap.setDefaultUnit(kony.flex.DP);
            flxBottomGap.add();
            flxLCDetailsPopup.add(flxLCDetailsContainer, flxBottomGap);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsBody": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowlegementMessage": {
                        "height": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementMsg": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknLbl424242SSPRWordBreak24Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAmendDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxVerticalEllipsisBodyContent": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.07%"
                        },
                        "segmentProps": []
                    },
                    "flxVerticalEllipsisBody": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVerticalEllipsisDropdown": {
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryDetails": {
                        "segmentProps": []
                    },
                    "flxRow1": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiary": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLCRefNo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCRefNoValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLCType": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRow2": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDateValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDateValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxRow3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentTerms": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentTermsValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIDValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxAmendDetailsContent": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "segAmendmentDetails": {
                        "data": [{
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxAmendRowTemplateTablet"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmendRowTemplateTablet": "flxAmendRowTemplateTablet",
                            "flxReviewRight": "flxReviewRight",
                            "flxReviewValues": "flxReviewValues",
                            "flxreviewRows": "flxreviewRows",
                            "lblReview": "lblReview",
                            "lblReviewValue1": "lblReviewValue1"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "segAmendmentsRequested": {
                        "data": [{
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxAmendRowTemplateTablet"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmendRowTemplateTablet": "flxAmendRowTemplateTablet",
                            "flxReviewRight": "flxReviewRight",
                            "flxReviewValues": "flxReviewValues",
                            "flxreviewRows": "flxreviewRows",
                            "lblReview": "lblReview",
                            "lblReviewValue1": "lblReviewValue1"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "segAmendmentCharges": {
                        "data": [{
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Amendment Reference:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12345678"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxAmendRowTemplateTablet"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmendRowTemplateTablet": "flxAmendRowTemplateTablet",
                            "flxReviewRight": "flxReviewRight",
                            "flxReviewValues": "flxReviewValues",
                            "flxreviewRows": "flxreviewRows",
                            "lblReview": "lblReview",
                            "lblReviewValue1": "lblReviewValue1"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxSelfAcceptance": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsActions": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitButtonActions": {
                        "segmentProps": []
                    },
                    "btnSubmitConsent": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnConsentBack": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "22%"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsContainer": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsBody": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxAmendDetailsHeader": {
                        "segmentProps": []
                    },
                    "lblExportAmendDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryLabel": {
                        "segmentProps": []
                    },
                    "lblBeneficiaryValue": {
                        "segmentProps": []
                    },
                    "flxLCRefNoKey": {
                        "segmentProps": []
                    },
                    "flxLCTypeLabel": {
                        "segmentProps": []
                    },
                    "flxLCTypeValue": {
                        "segmentProps": []
                    },
                    "flxLCAmountValue": {
                        "segmentProps": []
                    },
                    "flxPaymentTermsValue": {
                        "segmentProps": []
                    },
                    "flxCustomerIDLabel": {
                        "segmentProps": []
                    },
                    "flxCustomerIDValue": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsBody": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxLCSummary": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsBody": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "CustomPopup": {
                    "centerX": "50%",
                    "height": "268dp",
                    "width": "44.30%"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxLCDetailsPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmExportAmendmentViewDetails,
            "enabledForIdleTimeout": true,
            "id": "frmExportAmendmentViewDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_bc4c12be1ed64b8da42242e8e17d5da7,
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});