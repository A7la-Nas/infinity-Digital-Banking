define("ManageProfileMA/SettingsNewUIModule/frmProfileEmail", function() {
    return function(controller) {
        function addWidgetsfrmProfileEmail() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "We could not find an exact match. Please enter your payee information as it appears on your bill."
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Dropdown"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    },
                    "profileMenu": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxProfile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxProfile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfile.setDefaultUnit(kony.flex.DP);
            var flxEmailWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmailWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailWrapper.setDefaultUnit(kony.flex.DP);
            var flxEmails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmails",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmails.setDefaultUnit(kony.flex.DP);
            var flxEmailHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxEmailHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailHeader.setDefaultUnit(kony.flex.DP);
            var flxEmailSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEmailSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailSeparator.setDefaultUnit(kony.flex.DP);
            flxEmailSeparator.add();
            var lblEmailHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "49%",
                "id": "lblEmailHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EmailId\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewEmail = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Add New Email"
                },
                "centerY": "50%",
                "id": "btnAddNewEmail",
                "isVisible": true,
                "right": "2.18%",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxEmailHeader.add(flxEmailSeparator, lblEmailHeading, btnAddNewEmail);
            var flxEmailContents = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxEmailContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "285dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailContents.setDefaultUnit(kony.flex.DP);
            var flxErrorContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert"
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxErrorContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 20,
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorContainer.setDefaultUnit(kony.flex.DP);
            var lblImageError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblImageError",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "We couldn't upload your profile picture, as your file does not match with image uplaod criteria, please check again and upload.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgErr = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErr",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorContainer.add(lblImageError, imgErr);
            var flxEmailBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxEmailBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFBorderE9E9E9Radius4px",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailBody.setDefaultUnit(kony.flex.DP);
            var segEmailIds = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segEmailIds",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementEmail"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnEdit": "btnEdit",
                    "flxDeleteAction": "flxDeleteAction",
                    "flxEdit": "flxEdit",
                    "flxEmail": "flxEmail",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementEmail": "flxProfileManagementEmail",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblEmail": "lblEmail",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "widgetSkin": "sknSegDefault",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewEmailMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Add New Email"
                },
                "bottom": 20,
                "height": "40dp",
                "id": "btnAddNewEmailMobile",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxEmailBody.add(segEmailIds, btnAddNewEmailMobile);
            flxEmailContents.add(flxErrorContainer, flxEmailBody);
            var flxNoInfoWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxNoInfoWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarning.setDefaultUnit(kony.flex.DP);
            var flxNoInfoWarningWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxNoInfoWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblNoInfoWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoInfoWarning",
                "isVisible": true,
                "left": "112dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.noAddress\")",
                "top": "23dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoInfoWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNoInfoWarningImage",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "15px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.add(lblNoInfoWarning, lblNoInfoWarningImage);
            flxNoInfoWarning.add(flxNoInfoWarningWrapper);
            flxEmails.add(flxEmailHeader, flxEmailContents, flxNoInfoWarning);
            var flxCombinedEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCombinedEmail",
                "isVisible": false,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCombinedEmail.setDefaultUnit(kony.flex.DP);
            var flxPersonalEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalEmail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalEmail.setDefaultUnit(kony.flex.DP);
            var flxPersonalEmailHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxPersonalEmailHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalEmailHeader.setDefaultUnit(kony.flex.DP);
            var flxPersonalEmailSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonalEmailSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalEmailSeparator.setDefaultUnit(kony.flex.DP);
            flxPersonalEmailSeparator.add();
            var lblPersonalEmailHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "49%",
                "id": "lblPersonalEmailHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalBankingEmail\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewPersonalEmail = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Add New Email"
                },
                "centerY": "50%",
                "id": "btnAddNewPersonalEmail",
                "isVisible": true,
                "right": "2.18%",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxPersonalEmailHeader.add(flxPersonalEmailSeparator, lblPersonalEmailHeading, btnAddNewPersonalEmail);
            var flxPersonalEmailBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalEmailBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalEmailBody.setDefaultUnit(kony.flex.DP);
            var segPersonalEmailIds = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segPersonalEmailIds",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementEmail"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnEdit": "btnEdit",
                    "flxDeleteAction": "flxDeleteAction",
                    "flxEdit": "flxEdit",
                    "flxEmail": "flxEmail",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementEmail": "flxProfileManagementEmail",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblEmail": "lblEmail",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "widgetSkin": "Copyseg0j1ef31990dd644",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPersonalEmailBody.add(segPersonalEmailIds);
            flxPersonalEmail.add(flxPersonalEmailHeader, flxPersonalEmailBody);
            var flxEmailTypeSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEmailTypeSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailTypeSeparator.setDefaultUnit(kony.flex.DP);
            flxEmailTypeSeparator.add();
            var flxBusinessEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessEmail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessEmail.setDefaultUnit(kony.flex.DP);
            var flxBusinessEmailHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxBusinessEmailHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessEmailHeader.setDefaultUnit(kony.flex.DP);
            var flxBusinessEmailSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBusinessEmailSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessEmailSeparator.setDefaultUnit(kony.flex.DP);
            flxBusinessEmailSeparator.add();
            var lblBusinessEmailHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblBusinessEmailHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BusinessBankingEmail\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewBusinessEmail = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Add New Email"
                },
                "centerY": "50%",
                "id": "btnAddNewBusinessEmail",
                "isVisible": false,
                "right": "2.18%",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxBusinessEmailHeader.add(flxBusinessEmailSeparator, lblBusinessEmailHeading, btnAddNewBusinessEmail);
            var flxBusinessEmailBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessEmailBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessEmailBody.setDefaultUnit(kony.flex.DP);
            var segBusinessEmailIds = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segBusinessEmailIds",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementEmail"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnEdit": "btnEdit",
                    "flxDeleteAction": "flxDeleteAction",
                    "flxEdit": "flxEdit",
                    "flxEmail": "flxEmail",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementEmail": "flxProfileManagementEmail",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblEmail": "lblEmail",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "widgetSkin": "Copyseg0j1ef31990dd644",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBusinessEmailBody.add(segBusinessEmailIds);
            flxBusinessEmail.add(flxBusinessEmailHeader, flxBusinessEmailBody);
            flxCombinedEmail.add(flxPersonalEmail, flxEmailTypeSeparator, flxBusinessEmail);
            flxEmailWrapper.add(flxEmails, flxCombinedEmail);
            var ProfileInfo = new com.InfinityOLB.WireTransfer.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ProfileInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "WireTransferMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profileManagement.profileImageInfo\")",
                        "isVisible": true
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxProfile.add(flxEmailWrapper, ProfileInfo);
            flxRight.add(flxProfile);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxDeletePopUp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxDelete = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "268dp",
                "id": "flxDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var flxDeleteHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteClose.setDefaultUnit(kony.flex.DP);
            var CopyimgDeleteClose0ee315396d8944f = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "CopyimgDeleteClose0ee315396d8944f",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": true,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteClose.add(CopyimgDeleteClose0ee315396d8944f, lblcross);
            flxDeleteHeader.add(lblDeleteHeader, flxDeleteClose);
            var flxDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator.add();
            var flxDeleteContents = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "105dp",
                "id": "flxDeleteContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteContents.setDefaultUnit(kony.flex.DP);
            var lblConfirmDelete = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblConfirmDelete",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.deleteEmail\")",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteContents.add(lblConfirmDelete);
            var flxDeleteSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator2.add();
            var flxDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "80px",
                "id": "flxDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeleteYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Yes"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeleteYes",
                "isVisible": true,
                "left": "51.58%",
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeleteNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "No"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeleteNo",
                "isVisible": true,
                "left": "3.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxDeleteButtons.add(btnDeleteYes, btnDeleteNo);
            flxDelete.add(flxDeleteHeader, flxDeleteSeperator, flxDeleteContents, flxDeleteSeperator2, flxDeleteButtons);
            flxDeletePopUp.add(flxDelete);
            flxDialogs.add(flxLogout, flxDeletePopUp);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmProfileEmail": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxEmails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "btnAddNewEmail": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxEmailContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknlblff000011px",
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgErr": {
                        "left": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "flxEmailBody": {
                        "height": {
                            "type": "string",
                            "value": "870px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewEmailMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "ProfileInfo.RichTextInfo": {
                        "isVisible": true,
                        "text": "Add supported image formats like JPEG and PNG.",
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteHeader": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblDeleteHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "62px"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblEmailHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "btnAddNewEmail": {
                        "right": {
                            "type": "string",
                            "value": "2.18%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "btnAddNewEmailMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxEmails": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "btnAddNewEmail": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "flxEmailBody": {
                        "height": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewEmailMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "text": "K",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxCombinedEmail": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "segPersonalEmailIds": {
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "i18n_text": "i18n.ProfileManagement.deleteEmail",
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "bottom": {
                            "type": "number",
                            "value": "30"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmProfileEmail": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxEmails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblEmailHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "btnAddNewEmail": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "btnAddNewEmailMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "skin": "sknlbl4a90e230OLBFontIconsPx",
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteHeader": {
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "profileMenu": {
                    "centerX": "",
                    "width": "100%"
                },
                "ProfileInfo": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "ProfileInfo.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "ProfileInfo.imgToolTip": {
                    "src": "tool_tip.png"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmProfileEmail,
            "enabledForIdleTimeout": true,
            "id": "frmProfileEmail",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_bc57e9aaae2543839acf891ec2634dcf(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Email Settings",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});