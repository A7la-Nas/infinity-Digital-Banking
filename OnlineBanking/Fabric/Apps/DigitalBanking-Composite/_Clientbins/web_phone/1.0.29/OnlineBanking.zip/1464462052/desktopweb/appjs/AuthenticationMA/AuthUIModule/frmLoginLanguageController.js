/**
 * Login form controller which will handle all login page UI changes
 * @module frmLoginController
 */
define("AuthenticationMA/AuthUIModule/userfrmLoginLanguageController", ['FormControllerUtility', 'Deeplinking', 'ViewConstants', 'CommonUtilities', 'OLBConstants'], function(FormControllerUtility, Deeplinking, ViewConstants, CommonUtilities, OLBConstants) {
    return {
        postShow: function() {
            var config = applicationManager.getConfigurationManager();
            kony.i18n.setCurrentLocaleAsync(config.configurations.getItem("LOCALE"), function() {
                var previousForm = kony.application.getPreviousForm();
                var currentForm = kony.application.getCurrentForm();
                var OLBLogoutStatus = kony.store.getItem('OLBLogoutStatus');
                //var isUserLoggedin = kony.store.getItem('UserLoginStatus');
                if (previousForm && previousForm.id == "frmProfileManagement") applicationManager.getNavigationManager().navigateTo("frmProfileManagement");
                else if (OLBLogoutStatus && OLBLogoutStatus.isUserLoggedoutSuccessfully || (currentForm && currentForm.id == "frmLogout")) {
                    if (OLBLogoutStatus) {
                        // kony.store.setItem('UserLoginStatus',false);
                        OLBLogoutStatus.isUserLoggedoutSuccessfully = false;
                        applicationManager.getStorageManager().setStoredItem('OLBLogoutStatus', OLBLogoutStatus);
                    }
                    applicationManager.getNavigationManager().navigateTo("frmLogout");
                } else if (previousForm && previousForm.id === "frmProfileLanguage") {
                    if (config.configurations.getItem("LOCALE") === "ar_AE") {
                        kony.application.setApplicationBehaviors({
                            'rtlMirroringInWidgetPropertySetter': true
                        });
                    } else {
                        kony.application.setApplicationBehaviors({
                            'rtlMirroringInWidgetPropertySetter': false
                        });
                    }
                    kony.application.destroyForm({
                        "appName": "ManageProfileMA",
                        "friendlyName": "frmProfileLanguage"
                    });
                    applicationManager.getNavigationManager().navigateTo({
                        "appName": "ManageProfileMA",
                        "friendlyName": "frmProfileLanguage"
                    });
                } else {
                    var scaType = CommonUtilities.getSCAType();
                    if (scaType == 1) {
                        kony.application.destroyForm("frmLoginHID");
                        applicationManager.getNavigationManager().navigateTo("frmLoginHID");
                    } else if (scaType == 2) {
                        kony.application.destroyForm("frmLoginUniken");
                        applicationManager.getNavigationManager().navigateTo("frmLoginUniken");
                    } else {
                        kony.application.destroyForm("frmLogin");
                        applicationManager.getNavigationManager().navigateTo("frmLogin");
                    }
                }
            }, function() {});
        }
    };
});
define("AuthenticationMA/AuthUIModule/frmLoginLanguageControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmLoginLanguage **/
    AS_Form_a778a02a21204ce9b531ebf73c46144e: function AS_Form_a778a02a21204ce9b531ebf73c46144e(eventobject) {
        var self = this;
        //this.onPreShow();
    },
    /** onTouchEnd defined for frmLoginLanguage **/
    AS_Form_i79b7965a6bc45f7aae63f59dd688b08: function AS_Form_i79b7965a6bc45f7aae63f59dd688b08(eventobject, x, y) {
        var self = this;
        //hidePopups();
    },
    /** postShow defined for frmLoginLanguage **/
    AS_Form_ib2c7270983345e9bd9ee39a89b71007: function AS_Form_ib2c7270983345e9bd9ee39a89b71007(eventobject) {
        var self = this;
        this.postShow();
    },
    /** onDeviceBack defined for frmLoginLanguage **/
    AS_Form_jce8c301abad400688ca23e71a3aab00: function AS_Form_jce8c301abad400688ca23e71a3aab00(eventobject) {
        var self = this;
        kony.print("User pressed back button");
    }
});
define("AuthenticationMA/AuthUIModule/frmLoginLanguageController", ["AuthenticationMA/AuthUIModule/userfrmLoginLanguageController", "AuthenticationMA/AuthUIModule/frmLoginLanguageControllerActions"], function() {
    var controller = require("AuthenticationMA/AuthUIModule/userfrmLoginLanguageController");
    var controllerActions = ["AuthenticationMA/AuthUIModule/frmLoginLanguageControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
