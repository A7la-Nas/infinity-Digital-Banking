define("SelfServiceEnrolmentMA/EnrollUIModule/frmEnrollBusiness", function() {
    return function(controller) {
        function addWidgetsfrmEnrollBusiness() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "FlexContainer0e2898aa93bca45": {
                        "left": "6%",
                        "width": "88%"
                    },
                    "customhamburger.imgCollapseAccounts": {
                        "src": "arrow_down.png"
                    },
                    "customhamburger.imgKony": {
                        "src": "kony_logo_white.png"
                    },
                    "customhamburger.imgLogout": {
                        "src": "menu_logout.png"
                    },
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu": {
                        "isVisible": false
                    },
                    "headermenu.btnLogout": {
                        "isVisible": false
                    },
                    "headermenu.flxMessages": {
                        "isVisible": false
                    },
                    "headermenu.flxResetUserImg": {
                        "isVisible": false
                    },
                    "headermenu.flxUserId": {
                        "isVisible": false
                    },
                    "headermenu.flxVerticalSeperator1": {
                        "isVisible": false
                    },
                    "headermenu.flxVerticalSeperator2": {
                        "isVisible": false
                    },
                    "headermenu.imgDropdown": {
                        "src": "profile_dropdown_arrow.png"
                    },
                    "headermenu.imgLogout": {
                        "isVisible": false,
                        "src": "logout.png"
                    },
                    "headermenu.imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "headermenu.imgUserBoundary": {
                        "src": "verify_user.png"
                    },
                    "headermenu.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "headermenu.imgheaderdefault": {
                        "src": "default_username.png"
                    },
                    "imgKony": {
                        "left": "0dp",
                        "src": "kony_logo.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedback": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "isVisible": false,
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.flxSeperator1": {
                        "isVisible": false
                    },
                    "topmenu.flxTransfersAndPay": {
                        "isVisible": false
                    },
                    "topmenu.flxaccounts": {
                        "left": "0%",
                        "width": "11.50%"
                    },
                    "topmenu.lblAccounts": {
                        "centerX": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.BusinessEnrollementHeader\")",
                        "left": "10dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxMainWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "minHeight": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent_2.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow_2.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent_2.png",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey_2.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCloseDownTimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCloseDownTimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning, lblCloseDownTimeWarning);
            flxMainWrapper.add(flxDowntimeWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": 0,
                "width": "88%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "74dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.CreateAUser\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewCompany = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "41dp",
                "id": "btnAddNewCompany",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.addNewCompany\")",
                "width": "17.75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSecondaryFocusSSP3343a815PxHover"
            });
            flxContentHeader.add(lblContentHeader, btnAddNewCompany);
            var flxSuccessMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxSuccessMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuccessMsg.setDefaultUnit(kony.flex.DP);
            var imgSuccessMsg = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "14dp",
                "height": "50dp",
                "id": "imgSuccessMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "success_green.png",
                "top": "15dp",
                "width": "50dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSuccessMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSuccessMsg",
                "isVisible": true,
                "left": "89dp",
                "skin": "sknlbl424242SSPRegular24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.accountAddedMsg\")",
                "top": "28dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxCloseMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "50dp",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseMsg.setDefaultUnit(kony.flex.DP);
            var imgCloseMsg = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseMsg",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseMsg.add(imgCloseMsg);
            flxSuccessMsg.add(imgSuccessMsg, lblSuccessMsg, flxCloseMsg);
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDetailsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65dp",
                "id": "flxDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDetailsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "height": "20dp",
                "id": "lblDetailsHeader",
                "isVisible": true,
                "left": 0,
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.CreateAUser\")",
                "top": "15px",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDetailsHeaderSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "lblDetailsHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "15px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            lblDetailsHeaderSeparator.setDefaultUnit(kony.flex.DP);
            lblDetailsHeaderSeparator.add();
            flxDetailsHeader.add(lblDetailsHeader, lblDetailsHeaderSeparator);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.48%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow_2.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShowErrorMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50.00%",
                "height": "50%",
                "id": "lblShowErrorMessage",
                "isVisible": true,
                "left": "3.14%",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblShowErrorMessage);
            var flxPersonalDetailsWithCIF = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalDetailsWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0px",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalDetailsWithCIF.setDefaultUnit(kony.flex.DP);
            var flxNameDetailsWithCIF = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNameDetailsWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameDetailsWithCIF.setDefaultUnit(kony.flex.DP);
            var lblFirstNameWithCIF = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFirstNameWithCIF",
                "isVisible": true,
                "left": "2.10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.FirstName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFirstNameWithCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFirstNameWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": 31,
                "width": "23%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFirstNameWithCIF.setDefaultUnit(kony.flex.DP);
            var tbxFirstNameWithCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "inline",
                        "aria-labelledby": "lblFirstNameWithCIF",
                        "aria-required": true,
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxFirstNameWithCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.tbxName\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 10, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "given-name",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxFirstNameWithCIF.add(tbxFirstNameWithCIF);
            var lblLastNameWithCIF = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLastNameWithCIF",
                "isVisible": true,
                "left": "28.10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Lastname\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLastNameWithCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxLastNameWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLastNameWithCIF.setDefaultUnit(kony.flex.DP);
            var tbxLastNameWithCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "inline",
                        "aria-labelledby": "lblLastNameWithCIF",
                        "aria-required": true,
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50.00%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxLastNameWithCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0.00%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterLastNameBB\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 10, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "family-name",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxLastNameWithCIF.add(tbxLastNameWithCIF);
            flxNameDetailsWithCIF.add(lblFirstNameWithCIF, flxFirstNameWithCIF, lblLastNameWithCIF, flxLastNameWithCIF);
            var lblDOBWithCIF = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDOBWithCIF",
                "isVisible": true,
                "left": "2.10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.DOB\")",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCustomDateWithCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxCustomDateWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomDateWithCIF.setDefaultUnit(kony.flex.DP);
            var CustomDateWithCIFOld = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomDate({
                "height": "100%",
                "id": "CustomDateWithCIFOld",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomDate": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "isVisible": false,
                        "maxWidth": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxWrapper": {
                        "clipBounds": false,
                        "width": "100%"
                    },
                    "lblLine": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CustomDateWithCIF = new com.InfinityOLB.SelfServiceEnrolmentMA.DateInputContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "40dp",
                "id": "CustomDateWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "DateInputContainer": {
                        "left": "2%",
                        "width": "96%"
                    },
                    "flxSeparator": {
                        "isVisible": false
                    },
                    "lblDatePlaceholderKA": {
                        "text": "MM/DD/YYYY"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomDateWithCIF.add(CustomDateWithCIFOld, CustomDateWithCIF);
            var lblSSNWithCIF = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSSNWithCIF",
                "isVisible": true,
                "left": "2.10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.SSN\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSSNWithCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "150dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSSNWithCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSSNWithCIF.setDefaultUnit(kony.flex.DP);
            var tbxSSNWithCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblSSNWithCIF",
                        "aria-required": true,
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxSSNWithCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.userMgmt.ssn\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 10, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxSSNWithCIF.add(tbxSSNWithCIF);
            flxPersonalDetailsWithCIF.add(flxNameDetailsWithCIF, lblDOBWithCIF, flxCustomDateWithCIF, lblSSNWithCIF, flxSSNWithCIF);
            var flxCompanyAndBusinessContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCompanyAndBusinessContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyAndBusinessContainer.setDefaultUnit(kony.flex.DP);
            var lblBusinessCompanyName = new kony.ui.Label({
                "id": "lblBusinessCompanyName",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.companyName\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBusinessCompanyName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBusinessCompanyName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessCompanyName.setDefaultUnit(kony.flex.DP);
            var tbxBusinessCompanyName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter the company name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxBusinessCompanyName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxBusinessCompanyName.add(tbxBusinessCompanyName);
            var lblTypeOfOrganisation = new kony.ui.Label({
                "id": "lblTypeOfOrganisation",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.typeofOrganisation\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "165dp",
                "isModalContainer": false,
                "skin": "slFboxE3E3E3RC",
                "top": "-20dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoOrganization = new kony.ui.Image2({
                "height": "100%",
                "id": "imgInfoOrganization",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "info_grey_2.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfoOrganization);
            var flxTypeOfOrganisation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0px",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTypeOfOrganisation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeOfOrganisation.setDefaultUnit(kony.flex.DP);
            var lstbTypeOfOrganisation = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yLabel": "Select the type of organisation"
                },
                "bottom": "0px",
                "focusSkin": "sknLbxBorder003e751px",
                "height": "100%",
                "id": "lstbTypeOfOrganisation",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select here"]
                ],
                "skin": "sknzerobordergreyfont",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            flxTypeOfOrganisation.add(lstbTypeOfOrganisation);
            var lblYourRoleinCompany = new kony.ui.Label({
                "id": "lblYourRoleinCompany",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "text": "Your Role in Company",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxYourRoleinCompany = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxYourRoleinCompany",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYourRoleinCompany.setDefaultUnit(kony.flex.DP);
            var lstbYourRoleinCompany = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yLabel": "Select your role in company"
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "100%",
                "id": "lstbYourRoleinCompany",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select here"]
                ],
                "skin": "sknzerobordergreyfont",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            flxYourRoleinCompany.add(lstbYourRoleinCompany);
            var lblEmailAddress = new kony.ui.Label({
                "id": "lblEmailAddress",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.manageUser.EmailID\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmailAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEmailAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailAddress.setDefaultUnit(kony.flex.DP);
            var tbxEmailAddress = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter email address"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxEmailAddress",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxEmailAddress.add(tbxEmailAddress);
            var lblTelephoneNumber = new kony.ui.Label({
                "id": "lblTelephoneNumber",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.telephoneNumber\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTelephoneNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTelephoneNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTelephoneNumber.setDefaultUnit(kony.flex.DP);
            var tbxTelephoneNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Telephone Number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxTelephoneNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxTelephoneNumber.add(tbxTelephoneNumber);
            var lblCompanyTaxId = new kony.ui.Label({
                "id": "lblCompanyTaxId",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.taxId\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCompanyTaxId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCompanyTaxId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyTaxId.setDefaultUnit(kony.flex.DP);
            var tbxCompanyTaxId = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Tax ID"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCompanyTaxId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxCompanyTaxId.add(tbxCompanyTaxId);
            var lblFax = new kony.ui.Label({
                "id": "lblFax",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.faxoptional\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxfax = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxfax",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxfax.setDefaultUnit(kony.flex.DP);
            var tbxfax = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Fax (Optional)"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxfax",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxfax.add(tbxfax);
            var flxCompanyAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCompanyAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyAddress.setDefaultUnit(kony.flex.DP);
            var lblCompanyAddress = new kony.ui.Label({
                "id": "lblCompanyAddress",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.companyAddress\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddressLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAddressLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressLine1.setDefaultUnit(kony.flex.DP);
            var tbxAddressLine1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Address Line 1"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxAddressLine1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxAddressLine1.add(tbxAddressLine1);
            var flxAddressLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAddressLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "91dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressLine2.setDefaultUnit(kony.flex.DP);
            var tbxAddressLine2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Address Line 2"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxAddressLine2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxAddressLine2.add(tbxAddressLine2);
            var lblCountry = new kony.ui.Label({
                "id": "lblCountry",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Country\")",
                "top": "148dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCountry = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCountry",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "171dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCountry.setDefaultUnit(kony.flex.DP);
            var tbxCountry = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Country"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCountry",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Country\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var flxNoResultsFound = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoResultsFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "39dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFound.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFound = new kony.ui.Label({
                "id": "lblNoResultsFound",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "text": "No Results Found",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFound.add(lblNoResultsFound);
            var segSearchCountry = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100dp",
                "id": "segSearchCountry",
                "isVisible": false,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxSearchAdressList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": "41dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSearchAdressList": "flxSearchAdressList",
                    "lblAddressCountry": "lblAddressCountry"
                },
                "width": "100%",
                "zIndex": 10,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCountry.add(tbxCountry, flxNoResultsFound, segSearchCountry);
            var lblState = new kony.ui.Label({
                "id": "lblState",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.state\")",
                "top": "228dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxState = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxState",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "251dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxState.setDefaultUnit(kony.flex.DP);
            var tbxState = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter State"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxState",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.state\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var segSearchState = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100dp",
                "id": "segSearchState",
                "isVisible": false,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxSearchAdressList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": 41,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSearchAdressList": "flxSearchAdressList",
                    "lblAddressCountry": "lblAddressCountry"
                },
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoResultsFoundState = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoResultsFoundState",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "39dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFoundState.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFoundState = new kony.ui.Label({
                "id": "lblNoResultsFoundState",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "text": "No Results Found",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFoundState.add(lblNoResultsFoundState);
            flxState.add(tbxState, segSearchState, flxNoResultsFoundState);
            var lblCity = new kony.ui.Label({
                "id": "lblCity",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.city\")",
                "top": "308dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCity",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "331dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCity.setDefaultUnit(kony.flex.DP);
            var tbxCity = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter City"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCity",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.city\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var segSearchCity = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100dp",
                "id": "segSearchCity",
                "isVisible": false,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxSearchAdressList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": "41dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSearchAdressList": "flxSearchAdressList",
                    "lblAddressCountry": "lblAddressCountry"
                },
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoResultsFoundCity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoResultsFoundCity",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "39dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFoundCity.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFoundCity = new kony.ui.Label({
                "id": "lblNoResultsFoundCity",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "text": "No Results Found",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFoundCity.add(lblNoResultsFoundCity);
            flxCity.add(tbxCity, segSearchCity, flxNoResultsFoundCity);
            var lblZipCode = new kony.ui.Label({
                "id": "lblZipCode",
                "isVisible": true,
                "left": "37.20%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.zipcode\")",
                "top": "308dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxZipCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxZipCode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "37%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "331dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZipCode.setDefaultUnit(kony.flex.DP);
            var tbxZipCode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Zip Code"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxZipCode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.zipcode\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxZipCode.add(tbxZipCode);
            flxCompanyAddress.add(lblCompanyAddress, flxAddressLine1, flxAddressLine2, lblCountry, flxCountry, lblState, flxState, lblCity, flxCity, lblZipCode, flxZipCode);
            flxCompanyAndBusinessContainer.add(lblBusinessCompanyName, flxBusinessCompanyName, lblTypeOfOrganisation, flxInfo, flxTypeOfOrganisation, lblYourRoleinCompany, flxYourRoleinCompany, lblEmailAddress, flxEmailAddress, lblTelephoneNumber, flxTelephoneNumber, lblCompanyTaxId, flxCompanyTaxId, lblFax, flxfax, flxCompanyAddress);
            var flxDomainDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDomainDetailsContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDomainDetailsContainer.setDefaultUnit(kony.flex.DP);
            var lblDomainName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblDomainName",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.ContractName\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDomainName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": 40,
                "id": "flxDomainName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "18.30%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDomainName.setDefaultUnit(kony.flex.DP);
            var tbxDomainName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblDomainName",
                        "aria-required": true
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxDomainName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 2, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxDomainName.add(tbxDomainName);
            var lblTypeOfDomain = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblTypeOfDomain",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.Service\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeOfDomain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTypeOfDomain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeOfDomain.setDefaultUnit(kony.flex.DP);
            var lstbTypeOfDomain = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Select type Of Domain"
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "100%",
                "id": "lstbTypeOfDomain",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select here"]
                ],
                "skin": "sknzerobordergreyfont",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 0, 1],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            flxTypeOfDomain.add(lstbTypeOfDomain);
            var lblYourRoleInTheDomain = new kony.ui.Label({
                "id": "lblYourRoleInTheDomain",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.DefaultRole\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxYourRoleInTheDomain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "150dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxYourRoleInTheDomain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYourRoleInTheDomain.setDefaultUnit(kony.flex.DP);
            var lstbYourRoleInTheDomain = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Select your role in this domain"
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "100%",
                "id": "lstbYourRoleInTheDomain",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select here"]
                ],
                "skin": "sknzerobordergreyfont",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 1, 0, 1],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            flxYourRoleInTheDomain.add(lstbYourRoleInTheDomain);
            flxDomainDetailsContainer.add(lblDomainName, flxDomainName, lblTypeOfDomain, flxTypeOfDomain, lblYourRoleInTheDomain, flxYourRoleInTheDomain);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "10%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": 0,
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlblUserName",
                "text": "Your application for business enrollement is submitted successfully & we will notify you with further process after verification",
                "top": 0,
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRightContainerInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRightContainerInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.setDefaultUnit(kony.flex.DP);
            var lblReferenceHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "35%",
                "id": "lblReferenceHeader",
                "isVisible": true,
                "left": "332dp",
                "right": "10%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ReferenceNumber\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "centerY": "65%",
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "480dp",
                "right": "10%",
                "skin": "sknlblUserName",
                "text": "Label",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.add(lblReferenceHeader, lblReferenceNumber);
            flxAcknowledgement.add(flxImgContainer, lblSuccessMessage, flxRightContainerInfo);
            var flxVerifyDetials = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerifyDetials",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyDetials.setDefaultUnit(kony.flex.DP);
            var flxVerifyDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxVerifyDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblverifyDetailsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblverifyDetailsHeader",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.UserDetails\")",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditUserDetails = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Edit User Details"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnEditUserDetails",
                "isVisible": true,
                "right": "3%",
                "skin": "bbSknBtnFont455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerifyDetailsHeader.add(lblverifyDetailsHeader, btnEditUserDetails);
            var flxUserDetailHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxUserDetailHeader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetailHeader.setDefaultUnit(kony.flex.DP);
            var lblUserDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUserDetails",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.UserDetails\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserDetailHeader.add(lblUserDetails);
            var flxSeparator9 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator9",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator9.setDefaultUnit(kony.flex.DP);
            flxSeparator9.add();
            var flxUserDetailsSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUserDetailsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetailsSegment.setDefaultUnit(kony.flex.DP);
            var segUserDetails = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUserDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxEnrollBussinessUserDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEnrollBussinessUserDetails": "flxEnrollBussinessUserDetails",
                    "lblLeftSideContent": "lblLeftSideContent",
                    "lblRIghtSideContent": "lblRIghtSideContent"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserDetailsSegment.add(segUserDetails);
            var flxSeparator7 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator7.setDefaultUnit(kony.flex.DP);
            flxSeparator7.add();
            var flxCompanyDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxCompanyDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblCompanyDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblCompanyDetails",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Auth.CompanyDetails\")",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditCompanyDetails = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Edit Company Details"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnEditCompanyDetails",
                "isVisible": true,
                "right": "3%",
                "skin": "bbSknBtnFont455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCompanyDetailsHeader.add(lblCompanyDetails, btnEditCompanyDetails);
            var flxSeparator8 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator8",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator8.setDefaultUnit(kony.flex.DP);
            flxSeparator8.add();
            var flxCompanyDetailsSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCompanyDetailsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyDetailsSegment.setDefaultUnit(kony.flex.DP);
            var TabBodyCompanyDetails = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyCompanyDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "segTemplates": {
                        "bottom": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeparatorCompanyDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorCompanyDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorCompanyDetails.setDefaultUnit(kony.flex.DP);
            flxSeparatorCompanyDetails.add();
            flxCompanyDetailsSegment.add(TabBodyCompanyDetails, flxSeparatorCompanyDetails);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var flxDomainDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDomainDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDomainDetails.setDefaultUnit(kony.flex.DP);
            var lblDomainDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblDomainDetails",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.contractDetails\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditDomainDetails = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Edit Domain Details"
                },
                "centerY": "50%",
                "id": "btnEditDomainDetails",
                "isVisible": true,
                "right": "3%",
                "skin": "bbSknBtnFont455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDomainDetails.add(lblDomainDetails, btnEditDomainDetails);
            var flxSeparator10 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator10",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator10.setDefaultUnit(kony.flex.DP);
            flxSeparator10.add();
            var flxDomainDetailsSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDomainDetailsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDomainDetailsSegment.setDefaultUnit(kony.flex.DP);
            var segDomainDetails = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segDomainDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxEnrollBussinessUserDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEnrollBussinessUserDetails": "flxEnrollBussinessUserDetails",
                    "lblLeftSideContent": "lblLeftSideContent",
                    "lblRIghtSideContent": "lblRIghtSideContent"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDomainDetailsSegment.add(segDomainDetails);
            var flxSeparator11 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator11",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator11.setDefaultUnit(kony.flex.DP);
            flxSeparator11.add();
            var flxSelectedServicesHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxSelectedServicesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedServicesHeader.setDefaultUnit(kony.flex.DP);
            var lblSelectedServices = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblSelectedServices",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.selectedServices\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSelectedServicesEdit = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Edit selected services"
                },
                "centerY": "50%",
                "id": "btnSelectedServicesEdit",
                "isVisible": true,
                "right": "3%",
                "skin": "bbSknBtnFont455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectedServicesHeader.add(lblSelectedServices, btnSelectedServicesEdit);
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxSelectedServicesSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSelectedServicesSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedServicesSegment.setDefaultUnit(kony.flex.DP);
            var segSelectedServices = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segSelectedServices",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxEnrollBusinessSelectedServices"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEnrollBusinessSelectedServices": "flxEnrollBusinessSelectedServices",
                    "lblActiveSelection1": "lblActiveSelection1",
                    "lblName": "lblName",
                    "lblSeparator": "lblSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDataUnavailable = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxDataUnavailable",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDataUnavailable.setDefaultUnit(kony.flex.DP);
            var imgWarningInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "36dp",
                "id": "imgWarningInfoIcon",
                "isVisible": true,
                "left": "2.51%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0",
                "width": "36dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblWarning",
                "isVisible": true,
                "left": "88dp",
                "maxWidth": "80%",
                "minWidth": "50%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.noAvailablefeatures\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblUserName"
            });
            flxDataUnavailable.add(imgWarningInfoIcon, lblWarning);
            flxSelectedServicesSegment.add(segSelectedServices, flxDataUnavailable);
            var flxSeparator6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator6.setDefaultUnit(kony.flex.DP);
            flxSeparator6.add();
            var flxTermsConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": 50,
                "id": "flxTermsConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsConditions.setDefaultUnit(kony.flex.DP);
            var lblTermsConditions = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTermsConditions",
                "isVisible": false,
                "left": "2%",
                "skin": "bbSknLbl424242SSPS15Px",
                "text": "Terms And Conditions",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTermsConditions.add(lblTermsConditions);
            var flxTermsConditionsDetials = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "170dp",
                "id": "flxTermsConditionsDetials",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxe3e3e31px",
                "top": "20dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsConditionsDetials.setDefaultUnit(kony.flex.DP);
            var flxImgContainerTermsConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20%",
                "id": "flxImgContainerTermsConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20%",
                "width": "4%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainerTermsConditions.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainerTermsConditions.add(imgInfo);
            var flxTermsData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": 120,
                "id": "flxTermsData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "7%",
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox",
                "top": "20%",
                "width": "90%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsData.setDefaultUnit(kony.flex.DP);
            var lblTermsConditionsHeader = new kony.ui.Label({
                "height": "20dp",
                "id": "lblTermsConditionsHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP17pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.TermsAndConditions\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTandCData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxTandCData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTandCData.setDefaultUnit(kony.flex.DP);
            var lblTermsConditionsData = new kony.ui.Label({
                "id": "lblTermsConditionsData",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.TAndCPoint1\")",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTandC2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTandC2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTandC2.setDefaultUnit(kony.flex.DP);
            var lblTermsConditionsData2 = new kony.ui.Label({
                "id": "lblTermsConditionsData2",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.TAndCPoint2\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTermsAndConditions = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "id": "btnTermsAndConditions",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTandC2.add(lblTermsConditionsData2, btnTermsAndConditions);
            flxTandCData.add(lblTermsConditionsData, flxTandC2);
            flxTermsData.add(lblTermsConditionsHeader, flxTandCData);
            flxTermsConditionsDetials.add(flxImgContainerTermsConditions, flxTermsData);
            flxVerifyDetials.add(flxVerifyDetailsHeader, flxUserDetailHeader, flxSeparator9, flxUserDetailsSegment, flxSeparator7, flxCompanyDetailsHeader, flxSeparator8, flxCompanyDetailsSegment, flxSeparator5, flxDomainDetails, flxSeparator10, flxDomainDetailsSegment, flxSeparator11, flxSelectedServicesHeader, flxSeparator3, flxSelectedServicesSegment, flxSeparator6, flxTermsConditions, flxTermsConditionsDetials);
            var flxEnrollmentMethod = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEnrollmentMethod",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollmentMethod.setDefaultUnit(kony.flex.DP);
            var flxMethod1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMethod1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethod1.setDefaultUnit(kony.flex.DP);
            var lblMethod1Header = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerX": "50%",
                "id": "lblMethod1Header",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.method01\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCIFNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblCIFNumber",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Auth.CIFNumber\")",
                "top": "20dp",
                "width": "64%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCIFNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCIFNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "64%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCIFNumber.setDefaultUnit(kony.flex.DP);
            var tbxCIFNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblCIFNumber",
                        "aria-required": true
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCIFNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.EnterCIFNumberhere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxCIFNumber.add(tbxCIFNumber);
            flxMethod1.add(lblMethod1Header, lblCIFNumber, flxCIFNumber);
            var flxMethodSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "clipBounds": false,
                "height": "400dp",
                "id": "flxMethodSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "1dp",
                "zIndex": 3,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethodSeparator.setDefaultUnit(kony.flex.DP);
            var imgOr = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "imgOr",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "or_circle.png",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 20
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxOr = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxOr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOr.setDefaultUnit(kony.flex.DP);
            var lblOr = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOr",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.or\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOr.add(lblOr);
            flxMethodSeparator.add(imgOr, flxOr);
            var flxMethod2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMethod2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethod2.setDefaultUnit(kony.flex.DP);
            var lblMethod2Header = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerX": "50%",
                "id": "lblMethod2Header",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.method02\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCompanyName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblCompanyName",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Auth.RegisteredCompanyName\")",
                "top": "20dp",
                "width": "64%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCompanyName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCompanyName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "64%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyName.setDefaultUnit(kony.flex.DP);
            var tbxCompanyName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "inline",
                        "aria-labelledby": "lblCompanyName",
                        "aria-required": true
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCompanyName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "organization",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxCompanyName.add(tbxCompanyName);
            var lblTaxId = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblTaxId",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Auth.TaxIdNumber\")",
                "top": "20dp",
                "width": "64%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTaxId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTaxId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "64%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTaxId.setDefaultUnit(kony.flex.DP);
            var tbxTaxId = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblTaxId",
                        "aria-required": true
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxTaxId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxTaxId.add(tbxTaxId);
            flxMethod2.add(lblMethod2Header, lblCompanyName, flxCompanyName, lblTaxId, flxTaxId);
            flxEnrollmentMethod.add(flxMethod1, flxMethodSeparator, flxMethod2);
            var flxVerifyCompanyDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerifyCompanyDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyCompanyDetails.setDefaultUnit(kony.flex.DP);
            var flxDetailsCompanyName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDetailsCompanyName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsCompanyName.setDefaultUnit(kony.flex.DP);
            var lblDetailsCompanyName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsCompanyName",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.companyName\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDetailsCompanyNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsCompanyNameValue",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSP15Px",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsCompanyName.add(lblDetailsCompanyName, lblDetailsCompanyNameValue);
            var flxDetailsTaxId = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDetailsTaxId",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsTaxId.setDefaultUnit(kony.flex.DP);
            var lblDetailsTaxId = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsTaxId",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.taxId\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDetailsTaxIdValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsTaxIdValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsTaxId.add(lblDetailsTaxId, lblDetailsTaxIdValue);
            var flxDetailsCIFNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDetailsCIFNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsCIFNumber.setDefaultUnit(kony.flex.DP);
            var lblDetailsCIFNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsCIFNumber",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.customerIdNumber\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDetailsCIFNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDetailsCIFNumberValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsCIFNumber.add(lblDetailsCIFNumber, lblDetailsCIFNumberValue);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxVerifyCompanyDetails.add(flxDetailsCompanyName, flxDetailsTaxId, flxDetailsCIFNumber, flxSeparator);
            var flxVerifyBusinessAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxVerifyBusinessAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyBusinessAccounts.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "60dp",
                "id": "flxAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.setDefaultUnit(kony.flex.DP);
            var lblAccountsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "height": "20dp",
                "id": "lblAccountsHeader",
                "isVisible": true,
                "left": 0,
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.businessAccounts\")",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.add(lblAccountsHeader);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeparator.add();
            var flxAccountsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSegment.setDefaultUnit(kony.flex.DP);
            var TabBodyAccountsDetails = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyAccountsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "segTemplates": {
                        "bottom": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountsSegment.add(TabBodyAccountsDetails);
            flxVerifyBusinessAccounts.add(flxAccountsHeader, flxHeaderSeparator, flxAccountsSegment);
            var flxAboutYouContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAboutYouContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAboutYouContainer.setDefaultUnit(kony.flex.DP);
            var flxNameDetailsWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNameDetailsWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameDetailsWithOutCIF.setDefaultUnit(kony.flex.DP);
            var lblFirstNameWithOutCIF = new kony.ui.Label({
                "id": "lblFirstNameWithOutCIF",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.FirstName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMiddleNameWithOutCIF = new kony.ui.Label({
                "id": "lblMiddleNameWithOutCIF",
                "isVisible": true,
                "left": "30%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.MiddleName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLastnameWithOutCIF = new kony.ui.Label({
                "id": "lblLastnameWithOutCIF",
                "isVisible": true,
                "left": "57.30%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Lastname\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNameWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxNameWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "24dp",
                "width": "23%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxNameWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter First Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxNameWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.tbxName\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxNameWithOutCIF.add(tbxNameWithOutCIF);
            var flxMiddleNameWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMiddleNameWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleNameWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxMiddleNameWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Middle Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxMiddleNameWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxMiddleNameWithOutCIF.add(tbxMiddleNameWithOutCIF);
            var flxLastNameWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxLastNameWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "57.30%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLastNameWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxLastNameWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Last Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50.00%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxLastNameWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0.00%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterLastNameBB\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxLastNameWithOutCIF.add(tbxLastNameWithOutCIF);
            flxNameDetailsWithOutCIF.add(lblFirstNameWithOutCIF, lblMiddleNameWithOutCIF, lblLastnameWithOutCIF, flxNameWithOutCIF, flxMiddleNameWithOutCIF, flxLastNameWithOutCIF);
            var lblDOBWithOutCIF = new kony.ui.Label({
                "id": "lblDOBWithOutCIF",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.DOB\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDOBWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxDOBWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDOBWithOutCIF.setDefaultUnit(kony.flex.DP);
            var customDateWithOutCIFOld = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomDate({
                "height": "100%",
                "id": "customDateWithOutCIFOld",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomDate": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "isVisible": false,
                        "maxWidth": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxWrapper": {
                        "clipBounds": false,
                        "width": "100%"
                    },
                    "lblLine": {
                        "isVisible": false
                    },
                    "txt1": {
                        "placeholder": "M"
                    },
                    "txt2": {
                        "placeholder": "M"
                    },
                    "txt3": {
                        "placeholder": "D"
                    },
                    "txt4": {
                        "placeholder": "D"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customDateWithOutCIF = new com.InfinityOLB.SelfServiceEnrolmentMA.DateInputContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "40dp",
                "id": "customDateWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "DateInputContainer": {
                        "left": "3%",
                        "width": "96%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDOBWithOutCIF.add(customDateWithOutCIFOld, customDateWithOutCIF);
            var lblEmailWithOutCIF = new kony.ui.Label({
                "id": "lblEmailWithOutCIF",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EmailId\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmailWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEmailWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxEmailWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter your work email address"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxEmailWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.tbxEmailID\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxEmailWithOutCIF.add(tbxEmailWithOutCIF);
            var lblPhoneNumWithOutCIF = new kony.ui.Label({
                "id": "lblPhoneNumWithOutCIF",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.MobilePhone\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPhoneNumWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPhoneNumWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxPhoneNumWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Your Phone Number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxPhoneNumWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Enroll.PhoneNumberBB\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxPhoneNumWithOutCIF.add(tbxPhoneNumWithOutCIF);
            var lblSSNWithOutCIF = new kony.ui.Label({
                "id": "lblSSNWithOutCIF",
                "isVisible": true,
                "left": "2.51%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.SSNBB\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSSNWithOutCIF = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "115dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSSNWithOutCIF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSSNWithOutCIF.setDefaultUnit(kony.flex.DP);
            var tbxSSNWithOutCIF = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Social Security Number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxSSNWithOutCIF",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.userMgmt.ssn\")",
                "right": "0%",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxSSNWithOutCIF.add(tbxSSNWithOutCIF);
            flxAboutYouContainer.add(flxNameDetailsWithOutCIF, lblDOBWithOutCIF, flxDOBWithOutCIF, lblEmailWithOutCIF, flxEmailWithOutCIF, lblPhoneNumWithOutCIF, flxPhoneNumWithOutCIF, lblSSNWithOutCIF, flxSSNWithOutCIF);
            var flxBusinessAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessAccounts.setDefaultUnit(kony.flex.DP);
            var flxAddAccountsManually = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "138px",
                "id": "flxAddAccountsManually",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.51%",
                "isModalContainer": false,
                "right": "2.51%",
                "skin": "sknFlxe3e3e31px",
                "top": "20dp",
                "width": "95%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddAccountsManually.setDefaultUnit(kony.flex.DP);
            var lblAccountDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addAccountsManually\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetails.setDefaultUnit(kony.flex.DP);
            var lblAccHolderName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccHolderName",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.accountHolderName\")",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccNumber",
                "isVisible": true,
                "left": "28%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumber\")",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccType",
                "isVisible": false,
                "left": "53.30%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfers.SelectAccounttype\")",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccHolderName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccHolderName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccHolderName.setDefaultUnit(kony.flex.DP);
            var tbAccHolderName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Account Holder Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbAccHolderName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter here",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxAccHolderName.add(tbAccHolderName);
            var flxAccNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNumber.setDefaultUnit(kony.flex.DP);
            var tbAccNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Account Number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbAccNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter here",
                "secureTextEntry": false,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            flxAccNumber.add(tbAccNumber);
            var flxAccType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccType",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "53.30%",
                "isModalContainer": false,
                "right": 20,
                "skin": "skne3e3e3br3pxradius",
                "top": "31dp",
                "width": "23%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccType.setDefaultUnit(kony.flex.DP);
            var lbAccountType = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "100%",
                "id": "lbAccountType",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknzerobordergreyfont",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            flxAccType.add(lbAccountType);
            var bntAddAccount = new kony.ui.Button({
                "bottom": "20dp",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "bntAddAccount",
                "isVisible": true,
                "left": "79.80%",
                "right": "0%",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addAccount\")",
                "top": "31dp",
                "width": "17.60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountDetails.add(lblAccHolderName, lblAccNumber, lblAccType, flxAccHolderName, flxAccNumber, flxAccType, bntAddAccount);
            flxAddAccountsManually.add(lblAccountDescription, flxAccountDetails);
            var flxAccountsDataSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAccountsDataSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsDataSeparator.setDefaultUnit(kony.flex.DP);
            flxAccountsDataSeparator.add();
            var lblAddedAccountsDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAddedAccountsDesc",
                "isVisible": true,
                "left": "26dp",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addedAccounts\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddedAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddedAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddedAccounts.setDefaultUnit(kony.flex.DP);
            var flxTabletAccountsSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTabletAccountsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabletAccountsSeparator.setDefaultUnit(kony.flex.DP);
            flxTabletAccountsSeparator.add();
            var TabBodyNew = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "id": "TabBodyNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "bottom": "0dp",
                        "isVisible": true
                    },
                    "segTemplates": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxEmptyAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxEmptyAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmptyAccounts.setDefaultUnit(kony.flex.DP);
            var imgWarningIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "36px",
                "id": "imgWarningIcon",
                "isVisible": true,
                "left": "2.51%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0",
                "width": "36px"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountsInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountsInfo",
                "isVisible": true,
                "left": "88dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.noAccountsAdded\")",
                "top": "6dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmptyAccounts.add(imgWarningIcon, lblAccountsInfo);
            flxAddedAccounts.add(flxTabletAccountsSeparator, TabBodyNew, flxEmptyAccounts);
            var flxAccountsSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAccountsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSeparator.setDefaultUnit(kony.flex.DP);
            flxAccountsSeparator.add();
            flxBusinessAccounts.add(flxAddAccountsManually, flxAccountsDataSeparator, lblAddedAccountsDesc, flxAddedAccounts, flxAccountsSeparator);
            var flxFeatureContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFeatureContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureContainer.setDefaultUnit(kony.flex.DP);
            var flxAvailableFeatures = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAvailableFeatures",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableFeatures.setDefaultUnit(kony.flex.DP);
            var flxSelectAvailableFeatures = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSelectAvailableFeatures",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAvailableFeatures.setDefaultUnit(kony.flex.DP);
            var lblCheckFeature = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Check Feature"
                },
                "centerY": "50%",
                "height": "32dp",
                "id": "lblCheckFeature",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlblOLBFonts0273E420pxOlbFontIcons",
                "text": "C",
                "width": "32dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFeatureName",
                "isVisible": true,
                "left": "2%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.AvailableServices\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectAvailableFeatures.add(lblCheckFeature, lblFeatureName);
            var segAvailableFeatures = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segAvailableFeatures",
                "isVisible": false,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxFeatureContainer"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFeatureContainer": "flxFeatureContainer",
                    "flxFeatureRow": "flxFeatureRow",
                    "lblCheckFeature": "lblCheckFeature",
                    "lblFeatureName": "lblFeatureName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAvailableFeatures = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxNoAvailableFeatures",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAvailableFeatures.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "36px",
                "id": "imgWarning",
                "isVisible": true,
                "left": "2.51%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0",
                "width": "36px"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoFeatures = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoFeatures",
                "isVisible": true,
                "left": "88dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.noAvailablefeatures\")",
                "top": "6dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAvailableFeatures.add(imgWarning, lblNoFeatures);
            flxAvailableFeatures.add(flxSelectAvailableFeatures, segAvailableFeatures, flxNoAvailableFeatures);
            var flxDefaultFeatures = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDefaultFeatures",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDefaultFeatures.setDefaultUnit(kony.flex.DP);
            var flxDefaultFeaturesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDefaultFeaturesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "0dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDefaultFeaturesHeader.setDefaultUnit(kony.flex.DP);
            var lblDefaultFeatures = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDefaultFeatures",
                "isVisible": true,
                "left": "2%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.DefaultServices\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDefaultFeaturesHeader.add(lblDefaultFeatures);
            var segDefaultFeatures = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segDefaultFeatures",
                "isVisible": true,
                "left": "2%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxFeatureContainer"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFeatureContainer": "flxFeatureContainer",
                    "flxFeatureRow": "flxFeatureRow",
                    "lblCheckFeature": "lblCheckFeature",
                    "lblFeatureName": "lblFeatureName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDefaultFeatures.add(flxDefaultFeaturesHeader, segDefaultFeatures);
            var lblFeatureNote = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "50dp",
                "id": "lblFeatureNote",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.businessEnroll.featuresNote\")",
                "top": "65dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeatureContainer.add(flxAvailableFeatures, flxDefaultFeatures, lblFeatureNote);
            var flxOTP = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOTP",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTP.setDefaultUnit(kony.flex.DP);
            var OTPPostLogin = new com.InfinityOLB.Resources.mfa.OTPPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared"
                    },
                    "btnProceed": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared"
                    },
                    "btnResendCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.ResendOtp\")",
                        "isVisible": true,
                        "left": "65dp"
                    },
                    "flxActions": {
                        "clipBounds": true,
                        "isVisible": false
                    },
                    "flxDescription": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "width": "100%"
                    },
                    "flxEnterOTP": {
                        "isVisible": true
                    },
                    "flxEnterOTPCode": {
                        "isVisible": true,
                        "left": "100dp",
                        "top": "30px"
                    },
                    "flxEnterSecureAccessCode": {
                        "isVisible": false
                    },
                    "flxExtendedNotes": {
                        "bottom": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxImgTxt": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "width": "90%"
                    },
                    "flxOTPHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "width": "90%"
                    },
                    "flxSeparator2": {
                        "isVisible": false,
                        "top": "20dp"
                    },
                    "imgViewOTPCode": {
                        "src": "view.png"
                    },
                    "lblHeader": {
                        "left": "10dp",
                        "text": "Select any one or both mode of contact to get a secure  code",
                        "width": "90%"
                    },
                    "lblHeaderOTP": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "lblNote": {
                        "bottom": "viz.val_cleared",
                        "height": "70dp",
                        "left": "100dp",
                        "top": "30dp"
                    },
                    "lblPhoneOTP": {
                        "left": "0dp"
                    },
                    "lblRegisteredEmail": {
                        "left": "108dp"
                    },
                    "lblRegisteredPhone": {
                        "left": "108dp",
                        "top": "20dp"
                    },
                    "lblResendMessage": {
                        "bottom": "viz.val_cleared",
                        "top": "10dp",
                        "width": "90%"
                    },
                    "lblSecureAccessCodeNotes": {
                        "left": "30dp"
                    },
                    "lblWrongOTP": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "3%"
                    },
                    "lbxEmail": {
                        "left": "108dp"
                    },
                    "lbxPhone": {
                        "left": "108dp"
                    },
                    "rtxHeaderOTP": {
                        "top": "8dp",
                        "width": "85%"
                    },
                    "tbxEnterOTPCode": {
                        "secureTextEntry": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxOTP.add(OTPPostLogin);
            var flxActionsSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxActionsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActionsSeparator.setDefaultUnit(kony.flex.DP);
            flxActionsSeparator.add();
            var formActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "111dp",
                "id": "formActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "20dp"
                    },
                    "btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "14.14%"
                    },
                    "btnNext": {
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "width": "14.14%"
                    },
                    "btnOption": {
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "width": "14.14%"
                    },
                    "flxMain": {
                        "reverseLayoutDirection": false,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxContent.add(flxDetailsHeader, flxErrorMessage, flxPersonalDetailsWithCIF, flxCompanyAndBusinessContainer, flxDomainDetailsContainer, flxAcknowledgement, flxVerifyDetials, flxEnrollmentMethod, flxVerifyCompanyDetails, flxVerifyBusinessAccounts, flxAboutYouContainer, flxBusinessAccounts, flxFeatureContainer, flxOTP, flxActionsSeparator, formActionsNew);
            flxContentContainer.add(flxContentHeader, flxSuccessMsg, flxContent);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "0%",
                        "width": "100%"
                    },
                    "imgFooterIconOne": {
                        "src": "footer_logo_1.png"
                    },
                    "imgFooterIconThree": {
                        "src": "footer_logo_3.png"
                    },
                    "imgFooterIconTwo": {
                        "src": "footer_logo_2.png"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "0%",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxleftcontainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxleftcontainer.setDefaultUnit(kony.flex.DP);
            flxleftcontainer.add();
            var flxrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "75%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxrightcontainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxrightcontainer.setDefaultUnit(kony.flex.DP);
            flxrightcontainer.add();
            flxFooter.add(customfooter, flxleftcontainer, flxrightcontainer);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "icon_close_grey.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox4",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox4",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading_2.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "450%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "670dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this Popup"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey_2.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "10dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCCheckBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblIAccept",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "CopysknBtnffffffBorder4",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "50dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxCancelPopup = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 10000
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var PopupHeaderUM = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomFeedbackPopup({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog"
                    }
                },
                "height": "260px",
                "id": "PopupHeaderUM",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomFeedbackPopup": {
                        "isVisible": false
                    },
                    "btnNo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")"
                    },
                    "btnYes": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userMgmt.CancelUserCreation\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            PopupHeaderUM.btnNo.onClick = controller.AS_Button_i806e35651e04b1cbdbad15322d6e745;
            PopupHeaderUM.btnYes.onClick = controller.AS_Button_e6227a89fd5e4389bab3617b7c421105;
            flxCancelPopup.add(PopupHeaderUM);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Create User",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDetailsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblDetailsHeaderSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFirstNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "31"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblLastNameWithCIF": {
                        "left": {
                            "type": "string",
                            "value": "42.78%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblDOBWithCIF": {
                        "segmentProps": []
                    },
                    "flxCustomDateWithCIF": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomDateWithCIF.lblDatePlaceholderKA": {
                        "text": "DD/MM/YYYY",
                        "segmentProps": []
                    },
                    "CustomDateWithCIF.tbxDateInputKA": {
                        "text": "",
                        "segmentProps": []
                    },
                    "lblSSNWithCIF": {
                        "segmentProps": []
                    },
                    "flxSSNWithCIF": {
                        "segmentProps": []
                    },
                    "lblBusinessCompanyName": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBusinessCompanyName": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTypeOfOrganisation": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "flxTypeOfOrganisation": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lstbTypeOfOrganisation": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourRoleinCompany": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxYourRoleinCompany": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lstbYourRoleinCompany": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailAddress": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailAddress": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTelephoneNumber": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxTelephoneNumber": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblCompanyTaxId": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCompanyTaxId": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFax": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxfax": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddressLine1": {
                        "segmentProps": []
                    },
                    "flxAddressLine2": {
                        "segmentProps": []
                    },
                    "flxCountry": {
                        "segmentProps": []
                    },
                    "flxState": {
                        "segmentProps": []
                    },
                    "flxCity": {
                        "segmentProps": []
                    },
                    "flxZipCode": {
                        "segmentProps": []
                    },
                    "lblDomainName": {
                        "segmentProps": []
                    },
                    "flxDomainName": {
                        "segmentProps": []
                    },
                    "lblTypeOfDomain": {
                        "segmentProps": []
                    },
                    "flxTypeOfDomain": {
                        "segmentProps": []
                    },
                    "lstbTypeOfDomain": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourRoleInTheDomain": {
                        "segmentProps": []
                    },
                    "flxYourRoleInTheDomain": {
                        "segmentProps": []
                    },
                    "lstbYourRoleInTheDomain": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "segmentProps": []
                    },
                    "flxVerifyDetailsHeader": {
                        "segmentProps": []
                    },
                    "btnEditUserDetails": {
                        "segmentProps": []
                    },
                    "flxUserDetailHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblUserDetails": {
                        "skin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxSeparator9": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segUserDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator7": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxCompanyDetailsHeader": {
                        "segmentProps": []
                    },
                    "btnEditCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator8": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeparatorCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDomainDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDomainDetails": {
                        "segmentProps": []
                    },
                    "btnEditDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator10": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator11": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSelectedServicesHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedServices": {
                        "segmentProps": []
                    },
                    "btnSelectedServicesEdit": {
                        "segmentProps": []
                    },
                    "flxSeparator3": {
                        "segmentProps": []
                    },
                    "segSelectedServices": {
                        "segmentProps": []
                    },
                    "flxSeparator6": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "segmentProps": []
                    },
                    "lblTermsConditions": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsHeader": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsData": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsData2": {
                        "segmentProps": []
                    },
                    "flxCIFNumber": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMethodSeparator": {
                        "isCustomLayout": true,
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "imgOr": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxOr": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isCustomLayout": true,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "retainFlexPositionProperties": true,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "s1593e510a4744528aad5fa763c61ed2",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "lblOr": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "i18n_text": "i18n.enrollNow.or",
                        "isCustomLayout": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "retainContentAlignment": true,
                        "retainFlexPositionProperties": true,
                        "skin": "sknOr",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMethod2": {
                        "segmentProps": []
                    },
                    "flxCompanyName": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxTaxId": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDetailsCompanyName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCompanyName": {
                        "segmentProps": []
                    },
                    "lblDetailsCompanyNameValue": {
                        "segmentProps": []
                    },
                    "flxDetailsTaxId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsTaxId": {
                        "segmentProps": []
                    },
                    "lblDetailsTaxIdValue": {
                        "segmentProps": []
                    },
                    "flxDetailsCIFNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumber": {
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumberValue": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHeaderSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblMiddleNameWithOutCIF": {
                        "segmentProps": []
                    },
                    "lblLastnameWithOutCIF": {
                        "segmentProps": []
                    },
                    "flxNameWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "flxMiddleNameWithOutCIF": {
                        "segmentProps": []
                    },
                    "flxLastNameWithOutCIF": {
                        "segmentProps": []
                    },
                    "lblDOBWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDOBWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblSSNWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSSNWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsDataSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAccountsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProfileSettings": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnResendCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterOTPCode": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxExtendedNotes": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxImgTxt": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxOTPHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxSeparator2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblHeader": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblNote": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredPhone": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblResendMessage": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblWrongOTP": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.tbxEnterOTPCode": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxleftcontainer": {
                        "segmentProps": []
                    },
                    "flxrightcontainer": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "77%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsHeader": {
                        "segmentProps": []
                    },
                    "lblDetailsHeaderSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblShowErrorMessage": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNameDetailsWithCIF": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblFirstNameWithCIF": {
                        "segmentProps": []
                    },
                    "flxFirstNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "tbxFirstNameWithCIF": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblLastNameWithCIF": {
                        "left": {
                            "type": "string",
                            "value": "2.55%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "tbxLastNameWithCIF": {
                        "centerY": {
                            "type": "string",
                            "value": "49.17%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "segmentProps": []
                    },
                    "lblDOBWithCIF": {
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomDateWithCIF": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "lblSSNWithCIF": {
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": []
                    },
                    "flxSSNWithCIF": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "tbxSSNWithCIF": {
                        "segmentProps": []
                    },
                    "lblBusinessCompanyName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBusinessCompanyName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTypeOfOrganisation": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "flxTypeOfOrganisation": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lstbTypeOfOrganisation": {
                        "segmentProps": []
                    },
                    "lblYourRoleinCompany": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxYourRoleinCompany": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lstbYourRoleinCompany": {
                        "segmentProps": []
                    },
                    "lblEmailAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTelephoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxTelephoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblCompanyTaxId": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCompanyTaxId": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFax": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxfax": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxCompanyAddress": {
                        "segmentProps": []
                    },
                    "lblCompanyAddress": {
                        "segmentProps": []
                    },
                    "flxAddressLine1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblCountry": {
                        "segmentProps": []
                    },
                    "flxCountry": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoResultsFound": {
                        "segmentProps": []
                    },
                    "lblState": {
                        "segmentProps": []
                    },
                    "flxState": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoResultsFoundState": {
                        "segmentProps": []
                    },
                    "lblCity": {
                        "segmentProps": []
                    },
                    "flxCity": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoResultsFoundCity": {
                        "segmentProps": []
                    },
                    "lblZipCode": {
                        "left": {
                            "type": "string",
                            "value": "2.51%"
                        },
                        "top": {
                            "type": "string",
                            "value": "388dp"
                        },
                        "segmentProps": []
                    },
                    "flxZipCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "411dp"
                        },
                        "segmentProps": []
                    },
                    "lblDomainName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDomainName": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblTypeOfDomain": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxTypeOfDomain": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lstbTypeOfDomain": {
                        "segmentProps": []
                    },
                    "lblYourRoleInTheDomain": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxYourRoleInTheDomain": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lstbYourRoleInTheDomain": {
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlbl424242SSPReg17px",
                        "text": "23467686990",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxVerifyDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblverifyDetailsHeader": {
                        "segmentProps": []
                    },
                    "btnEditUserDetails": {
                        "segmentProps": []
                    },
                    "flxUserDetailHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblUserDetails": {
                        "skin": "bbSknLbl424242SSPS15Px",
                        "segmentProps": []
                    },
                    "flxSeparator9": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segUserDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator7": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxCompanyDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCompanyDetails": {
                        "segmentProps": []
                    },
                    "btnEditCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator8": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeparatorCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDomainDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDomainDetails": {
                        "segmentProps": []
                    },
                    "btnEditDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator10": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSeparator11": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSelectedServicesHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedServices": {
                        "segmentProps": []
                    },
                    "btnSelectedServicesEdit": {
                        "segmentProps": []
                    },
                    "flxSeparator3": {
                        "segmentProps": []
                    },
                    "segSelectedServices": {
                        "segmentProps": []
                    },
                    "flxSeparator6": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "segmentProps": []
                    },
                    "lblTermsConditions": {
                        "segmentProps": []
                    },
                    "flxImgContainerTermsConditions": {
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsHeader": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsData": {
                        "segmentProps": []
                    },
                    "flxTandC2": {
                        "height": {
                            "type": "string",
                            "value": "40%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblTermsConditionsData2": {
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMethod1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMethod1Header": {
                        "segmentProps": []
                    },
                    "lblCIFNumber": {
                        "segmentProps": []
                    },
                    "flxCIFNumber": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMethodSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "imgOr": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMethod2": {
                        "segmentProps": []
                    },
                    "lblMethod2Header": {
                        "segmentProps": []
                    },
                    "lblCompanyName": {
                        "segmentProps": []
                    },
                    "flxCompanyName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTaxId": {
                        "segmentProps": []
                    },
                    "flxTaxId": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDetailsCompanyName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCompanyName": {
                        "segmentProps": []
                    },
                    "lblDetailsCompanyNameValue": {
                        "segmentProps": []
                    },
                    "flxDetailsTaxId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsTaxId": {
                        "segmentProps": []
                    },
                    "lblDetailsTaxIdValue": {
                        "segmentProps": []
                    },
                    "flxDetailsCIFNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumber": {
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumberValue": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountsHeader": {
                        "segmentProps": []
                    },
                    "flxHeaderSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNameDetailsWithOutCIF": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblFirstNameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMiddleNameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "segmentProps": []
                    },
                    "lblLastnameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "182dp"
                        },
                        "segmentProps": []
                    },
                    "flxNameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "20"
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxMiddleNameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "212dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "lblDOBWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDOBWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Email",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblSSNWithOutCIF": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSSNWithOutCIF": {
                        "bottom": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxBusinessAccounts": {
                        "segmentProps": []
                    },
                    "lblAccNumber": {
                        "left": {
                            "type": "string",
                            "value": "45.57%"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccType": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccHolderName": {
                        "width": {
                            "type": "string",
                            "value": "25.08%"
                        },
                        "segmentProps": []
                    },
                    "flxAccNumber": {
                        "left": {
                            "type": "string",
                            "value": "45.57%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25.08%"
                        },
                        "segmentProps": []
                    },
                    "flxAccType": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "117dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29.49%"
                        },
                        "segmentProps": []
                    },
                    "bntAddAccount": {
                        "left": {
                            "type": "string",
                            "value": "45.57%"
                        },
                        "top": {
                            "type": "string",
                            "value": "117dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25.08%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsDataSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TabBodyNew": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "TabBodyNew"
                    },
                    "flxAccountsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.tbxEnterOTPCode": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "formActionsNew.btnBack": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "formActionsNew.btnCancel": {
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnOption": {
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblAccounts": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "padding": [1, 1, 1, 1],
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "segmentProps": []
                    },
                    "flxDetailsHeader": {
                        "segmentProps": []
                    },
                    "lblShowErrorMessage": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFirstNameWithCIF": {
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "right": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "tbxFirstNameWithCIF": {
                        "segmentProps": []
                    },
                    "flxLastNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "28.10%"
                        },
                        "right": {
                            "type": "string",
                            "value": "49.10%"
                        },
                        "segmentProps": []
                    },
                    "tbxLastNameWithCIF": {
                        "segmentProps": []
                    },
                    "tbxSSNWithCIF": {
                        "segmentProps": []
                    },
                    "lstbTypeOfOrganisation": {
                        "segmentProps": []
                    },
                    "lstbYourRoleinCompany": {
                        "segmentProps": []
                    },
                    "lblDomainName": {
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "tbxDomainName": {
                        "padding": [2, 1, 0, 1],
                        "segmentProps": []
                    },
                    "lstbTypeOfDomain": {
                        "segmentProps": []
                    },
                    "lstbYourRoleInTheDomain": {
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "23467686990",
                        "segmentProps": []
                    },
                    "flxVerifyDetailsHeader": {
                        "segmentProps": []
                    },
                    "btnEditUserDetails": {
                        "segmentProps": []
                    },
                    "flxUserDetailHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblUserDetails": {
                        "segmentProps": []
                    },
                    "segUserDetails": {
                        "segmentProps": []
                    },
                    "flxCompanyDetailsHeader": {
                        "segmentProps": []
                    },
                    "btnEditCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxDomainDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDomainDetails": {
                        "segmentProps": []
                    },
                    "btnEditDomainDetails": {
                        "segmentProps": []
                    },
                    "segDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSelectedServicesHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedServices": {
                        "segmentProps": []
                    },
                    "btnSelectedServicesEdit": {
                        "segmentProps": []
                    },
                    "segSelectedServices": {
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblTermsConditions": {
                        "segmentProps": []
                    },
                    "flxImgContainerTermsConditions": {
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsHeader": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsData": {
                        "segmentProps": []
                    },
                    "flxTandC2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTermsConditionsData2": {
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "lblMethod1Header": {
                        "i18n_text": "i18n.userManagement.method01",
                        "text": "",
                        "segmentProps": []
                    },
                    "imgOr": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblMethod2Header": {
                        "i18n_text": "i18n.userManagement.method02",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDetailsCompanyName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCompanyName": {
                        "segmentProps": []
                    },
                    "lblDetailsCompanyNameValue": {
                        "segmentProps": []
                    },
                    "flxDetailsTaxId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsTaxId": {
                        "segmentProps": []
                    },
                    "lblDetailsTaxIdValue": {
                        "segmentProps": []
                    },
                    "flxDetailsCIFNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumber": {
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumberValue": {
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "segmentProps": []
                    },
                    "flxMiddleNameWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "bntAddAccount": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "12.86%"
                        },
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.tbxEnterOTPCode": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxleftcontainer": {
                        "segmentProps": []
                    },
                    "flxrightcontainer": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.headermenu.flxMessages": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblFirstNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.08%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "flxFirstNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.01%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "lblLastNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "28.00%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithCIF": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "28.01%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "tbxLastNameWithCIF": {
                        "centerY": {
                            "type": "string",
                            "value": "49.17%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0.48%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lstbTypeOfOrganisation": {
                        "segmentProps": []
                    },
                    "lstbYourRoleinCompany": {
                        "segmentProps": []
                    },
                    "lstbTypeOfDomain": {
                        "segmentProps": []
                    },
                    "lstbYourRoleInTheDomain": {
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green_2.png",
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "text": "43331575819",
                        "segmentProps": []
                    },
                    "btnEditUserDetails": {
                        "segmentProps": []
                    },
                    "flxUserDetailHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblUserDetails": {
                        "skin": "sknLblSSP46464615pxbold",
                        "segmentProps": []
                    },
                    "segUserDetails": {
                        "segmentProps": []
                    },
                    "lblCompanyDetails": {
                        "i18n_text": "i18n.konybb.Auth.CompanyDetails",
                        "text": "",
                        "segmentProps": []
                    },
                    "btnEditCompanyDetails": {
                        "segmentProps": []
                    },
                    "flxDomainDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDomainDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.userManagement.contractDetails",
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "btnEditDomainDetails": {
                        "segmentProps": []
                    },
                    "segDomainDetails": {
                        "segmentProps": []
                    },
                    "flxSelectedServicesHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedServices": {
                        "i18n_text": "i18n.userManagement.selectedServices",
                        "text": "",
                        "segmentProps": []
                    },
                    "btnSelectedServicesEdit": {
                        "segmentProps": []
                    },
                    "segSelectedServices": {
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblTermsConditions": {
                        "segmentProps": []
                    },
                    "flxImgContainerTermsConditions": {
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsHeader": {
                        "i18n_text": "i18n.ProfileManagement.TermsAndConditions",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblTermsConditionsData": {
                        "segmentProps": []
                    },
                    "lblTermsConditionsData2": {
                        "segmentProps": []
                    },
                    "imgOr": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDetailsCompanyName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCompanyName": {
                        "i18n_text": "i18n.common.companyName",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblDetailsCompanyNameValue": {
                        "segmentProps": []
                    },
                    "flxDetailsTaxId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsTaxId": {
                        "i18n_text": "i18n.common.taxId",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblDetailsTaxIdValue": {
                        "segmentProps": []
                    },
                    "flxDetailsCIFNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumber": {
                        "i18n_text": "i18n.userManagement.customerIdNumber",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblDetailsCIFNumberValue": {
                        "segmentProps": []
                    },
                    "flxMiddleNameWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxLastNameWithOutCIF": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "bntAddAccount": {
                        "width": {
                            "type": "string",
                            "value": "12.86%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.tbxEnterOTPCode": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTCContentsCheckbox": {
                        "segmentProps": []
                    },
                    "lblTCContentsCheckBox": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblHeading": {
                        "text": "",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupMessage": {
                        "text": "",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.FlexContainer0e2898aa93bca45": {
                    "left": "6%",
                    "width": "88%"
                },
                "customheader.customhamburger.imgCollapseAccounts": {
                    "src": "arrow_down.png"
                },
                "customheader.customhamburger.imgKony": {
                    "src": "kony_logo_white.png"
                },
                "customheader.customhamburger.imgLogout": {
                    "src": "menu_logout.png"
                },
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.headermenu.imgDropdown": {
                    "src": "profile_dropdown_arrow.png"
                },
                "customheader.headermenu.imgLogout": {
                    "src": "logout.png"
                },
                "customheader.headermenu.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheader.headermenu.imgUserBoundary": {
                    "src": "verify_user.png"
                },
                "customheader.headermenu.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customheader.headermenu.imgheaderdefault": {
                    "src": "default_username.png"
                },
                "customheader.imgKony": {
                    "left": "0dp",
                    "src": "kony_logo.png"
                },
                "customheader.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.flxaccounts": {
                    "left": "0%",
                    "width": "11.50%"
                },
                "customheader.topmenu.lblAccounts": {
                    "centerX": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "10dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "CustomDateWithCIFOld": {
                    "centerX": "",
                    "height": "100%",
                    "maxWidth": "",
                    "width": "100%"
                },
                "CustomDateWithCIFOld.flxWrapper": {
                    "width": "100%"
                },
                "CustomDateWithCIF": {
                    "left": "2%",
                    "width": "96%"
                },
                "CustomDateWithCIF.lblDatePlaceholderKA": {
                    "text": "MM/DD/YYYY"
                },
                "TabBodyCompanyDetails": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "TabBodyCompanyDetails.segTemplates": {
                    "bottom": ""
                },
                "TabBodyAccountsDetails": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "TabBodyAccountsDetails.segTemplates": {
                    "bottom": ""
                },
                "customDateWithOutCIFOld": {
                    "centerX": "",
                    "height": "100%",
                    "maxWidth": "",
                    "width": "100%"
                },
                "customDateWithOutCIFOld.flxWrapper": {
                    "width": "100%"
                },
                "customDateWithOutCIF": {
                    "left": "3%",
                    "width": "96%"
                },
                "TabBodyNew": {
                    "bottom": "0dp"
                },
                "OTPPostLogin.btnCancel": {
                    "centerX": "50%",
                    "centerY": ""
                },
                "OTPPostLogin.btnProceed": {
                    "centerX": "50%",
                    "centerY": ""
                },
                "OTPPostLogin.btnResendCode": {
                    "left": "65dp"
                },
                "OTPPostLogin.flxDescription": {
                    "width": "100%"
                },
                "OTPPostLogin.flxEnterOTPCode": {
                    "left": "100dp",
                    "top": "30px"
                },
                "OTPPostLogin.flxExtendedNotes": {
                    "bottom": "",
                    "left": "0dp",
                    "top": "0dp"
                },
                "OTPPostLogin.flxImgTxt": {
                    "width": "90%"
                },
                "OTPPostLogin.flxOTPHeader": {
                    "width": "90%"
                },
                "OTPPostLogin.flxSeparator2": {
                    "top": "20dp"
                },
                "OTPPostLogin.imgViewOTPCode": {
                    "src": "view.png"
                },
                "OTPPostLogin.lblHeader": {
                    "left": "10dp",
                    "text": "Select any one or both mode of contact to get a secure  code",
                    "width": "90%"
                },
                "OTPPostLogin.lblHeaderOTP": {
                    "width": "100%"
                },
                "OTPPostLogin.lblNote": {
                    "bottom": "",
                    "height": "70dp",
                    "left": "100dp",
                    "top": "30dp"
                },
                "OTPPostLogin.lblPhoneOTP": {
                    "left": "0dp"
                },
                "OTPPostLogin.lblRegisteredEmail": {
                    "left": "108dp"
                },
                "OTPPostLogin.lblRegisteredPhone": {
                    "left": "108dp",
                    "top": "20dp"
                },
                "OTPPostLogin.lblResendMessage": {
                    "bottom": "",
                    "top": "10dp",
                    "width": "90%"
                },
                "OTPPostLogin.lblSecureAccessCodeNotes": {
                    "left": "30dp"
                },
                "OTPPostLogin.lblWrongOTP": {
                    "centerX": "",
                    "left": "3%"
                },
                "OTPPostLogin.lbxEmail": {
                    "left": "108dp"
                },
                "OTPPostLogin.lbxPhone": {
                    "left": "108dp"
                },
                "OTPPostLogin.rtxHeaderOTP": {
                    "top": "8dp",
                    "width": "85%"
                },
                "formActionsNew.btnBack": {
                    "left": "",
                    "right": "20dp"
                },
                "formActionsNew.btnCancel": {
                    "left": "",
                    "right": "20dp",
                    "width": "14.14%"
                },
                "formActionsNew.btnNext": {
                    "left": "",
                    "right": "20px",
                    "width": "14.14%"
                },
                "formActionsNew.btnOption": {
                    "left": "",
                    "right": "20px",
                    "width": "14.14%"
                },
                "formActionsNew.flxMain": {
                    "reverseLayoutDirection": false,
                    "layoutType": kony.flex.FREE_FORM
                },
                "formActionsNew": {
                    "top": "0dp"
                },
                "customfooter": {
                    "centerX": "50%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "0%",
                    "width": "100%"
                },
                "customfooter.imgFooterIconOne": {
                    "src": "footer_logo_1.png"
                },
                "customfooter.imgFooterIconThree": {
                    "src": "footer_logo_3.png"
                },
                "customfooter.imgFooterIconTwo": {
                    "src": "footer_logo_2.png"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "0%",
                    "width": "100%"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "icon_close_grey.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxLoading, flxTermsAndConditions, flxCancelPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmEnrollBusiness,
            "enabledForIdleTimeout": true,
            "id": "frmEnrollBusiness",
            "init": controller.AS_Form_c3edd1d8b97942a2b8aff4ddb5102ee0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_d11489da236d436eb49117357b28928a,
            "postShow": controller.AS_Form_cd0629d79c9640289a9106da94be0e80,
            "preShow": function(eventobject) {
                controller.AS_Form_f08124bb5c17467cadf8be4c900593bd(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_g94abbcb919545d88db8f2d6aba35fa8,
            "appName": "SelfServiceEnrolmentMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});