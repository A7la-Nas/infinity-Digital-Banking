define("ACHMA/ACHUIModule/frmACHDashboard", function() {
    return function(controller) {
        function addWidgetsfrmACHDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "100%",
                        "zIndex": 900
                    },
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared",
                        "text": "Help"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.ACHTransactions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDownloadAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgDownloadAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "2%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.setDefaultUnit(kony.flex.DP);
            var imgDownloadAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgDownloadAchTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.add(imgDownloadAchTransaction);
            var flxImgPrintAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgPrintAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "3%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.setDefaultUnit(kony.flex.DP);
            var imgPrintAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgPrintAchTransaction",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "bbprint.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.add(imgPrintAchTransaction);
            flxContentHeader.add(lblContentHeader, flxImgDownloadAch, flxImgPrintAch);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxContentDashBoard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentDashBoard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentDashBoard.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "58.19%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxTabPaneContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTabPaneContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabPaneContainer.setDefaultUnit(kony.flex.DP);
            var TabPaneNew = new com.InfinityOLB.Resources.TabPaneNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabPaneNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "MobileCustomDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": false,
                        "zIndex": 1
                    },
                    "MobileCustomDropdown.flxDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": true
                    },
                    "MobileCustomDropdown.flxImage": {
                        "left": "91%"
                    },
                    "MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "4%"
                    },
                    "MobileCustomDropdown.imgDropdown": {
                        "src": "listboxarw.png"
                    },
                    "MobileCustomDropdown.lblView": {
                        "width": "100%"
                    },
                    "MobileCustomDropdown.lblViewType": {
                        "left": "0%",
                        "width": "85%"
                    },
                    "MobileCustomDropdown.segCurrency": {
                        "data": [
                            [{
                                    "lblHedaerContent": "Single Transaction"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ],
                            [{
                                    "lblHedaerContent": "Bulk Transaction"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ],
                            [{
                                    "lblHedaerContent": "Other Requests"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ]
                        ]
                    },
                    "MobileCustomDropdown.segProcessingType": {
                        "data": [{
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }]
                    },
                    "MobileCustomDropdown.segTimePeriod": {
                        "data": [{
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }]
                    },
                    "MobileCustomDropdown.segTypeOfAccounts": {
                        "data": [{
                            "imgCheckBox": "D",
                            "imgCheckBox2": "D",
                            "lblAccountType1": "Savings",
                            "lblAccountType2": "Savings"
                        }]
                    },
                    "MobileCustomDropdown.segViewTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "zIndex": 15
                    },
                    "PaginationContainer.flxPagination": {
                        "reverseLayoutDirection": true
                    },
                    "PaginationContainer.imgPaginationFirst": {
                        "src": "pagination_inactive.png"
                    },
                    "PaginationContainer.imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "PaginationContainer.imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "TabBodyNew": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "TabBodyNew.segTemplates": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "TabSearchBarNew": {
                        "centerY": "viz.val_cleared",
                        "clipBounds": false,
                        "isVisible": true,
                        "zIndex": 1,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "TabSearchBarNew.MobileCustomDropdown": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "height": "80dp",
                        "isVisible": false,
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "isVisible": false,
                        "left": "4%",
                        "top": "60dp",
                        "width": "92%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxFilter": {
                        "centerX": "viz.val_cleared",
                        "left": "0%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxImage": {
                        "centerX": "viz.val_cleared",
                        "clipBounds": false,
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "width": "20%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "left": "4%",
                        "minWidth": "viz.val_cleared",
                        "top": "20dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "20dp",
                        "src": "dropdown_expand.png",
                        "width": "20dp"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "centerX": "viz.val_cleared",
                        "left": "8dp",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "20%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "left": "48dp",
                        "right": "40%",
                        "top": "0%",
                        "width": "50%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.segCurrency": {
                        "data": [
                            [{
                                    "lblHedaerContent": "Single Transaction"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ],
                            [{
                                    "lblHedaerContent": "Bulk Transaction"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }, {
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ],
                            [{
                                    "lblHedaerContent": "Other Requests"
                                },
                                [{
                                    "lblCheckFeature": "L",
                                    "lblFeatureName": "Label"
                                }]
                            ]
                        ]
                    },
                    "TabSearchBarNew.MobileCustomDropdown.segProcessingType": {
                        "data": [{
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }]
                    },
                    "TabSearchBarNew.MobileCustomDropdown.segTimePeriod": {
                        "data": [{
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }, {
                            "lblCheckFeature": "L",
                            "lblFeatureName": "Label"
                        }]
                    },
                    "TabSearchBarNew.MobileCustomDropdown.segTypeOfAccounts": {
                        "data": [{
                            "imgCheckBox": "D",
                            "imgCheckBox2": "D",
                            "lblAccountType1": "Savings",
                            "lblAccountType2": "Savings"
                        }]
                    },
                    "TabSearchBarNew.flxBoxSearch": {
                        "centerY": "47.50%",
                        "height": "40dp",
                        "left": "0%",
                        "top": "viz.val_cleared",
                        "width": "95%"
                    },
                    "TabSearchBarNew.flxDropDown": {
                        "centerY": "47.50%",
                        "height": "50dp",
                        "isVisible": true,
                        "left": "68%",
                        "top": "viz.val_cleared",
                        "width": "30%",
                        "zIndex": 1
                    },
                    "TabSearchBarNew.flxOptions": {
                        "height": "100%",
                        "isVisible": false
                    },
                    "TabSearchBarNew.flxSearch": {
                        "isVisible": true,
                        "left": "20dp",
                        "width": "68%"
                    },
                    "TabSearchBarNew.lblView": {
                        "isVisible": true
                    },
                    "TabSearchBarNew.listBoxViewType": {
                        "isVisible": true,
                        "right": "10dp",
                        "width": "67.74%"
                    },
                    "TabSearchBarNew.tbxSearch": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                    },
                    "TabsHeaderNew": {
                        "isVisible": true
                    },
                    "TabsHeaderNew.btnTab4": {
                        "isVisible": false
                    },
                    "TabsHeaderNew.btnTab5": {
                        "isVisible": false
                    },
                    "TabsHeaderNew.btnTab6": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTabPaneContainer.add(TabPaneNew);
            var flxCreateUI = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxCreateUI",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "Copysknflxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUI.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.FillTheDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblTitle);
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            flxTopSeparator.add();
            var NonEditableDetails = new com.InfinityOLB.ApprovalRequestMA.NonEditableDetailsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "98%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "NonEditableDetailsNew": {
                        "isVisible": false,
                        "left": "1%",
                        "top": "0dp",
                        "width": "98%"
                    },
                    "btnEdit": {
                        "isVisible": true
                    },
                    "flxBtmSeperator": {
                        "isVisible": true
                    },
                    "flxTitle": {
                        "isVisible": true
                    },
                    "flxTopSepartor": {
                        "isVisible": true
                    },
                    "lblACHTitleText": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCreateDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCreateDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDetails.setDefaultUnit(kony.flex.DP);
            var flxTemplate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTemplate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplate.setDefaultUnit(kony.flex.DP);
            var lblName = new kony.ui.Label({
                "id": "lblName",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateName\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateNAme = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateNAme",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateNAme.setDefaultUnit(kony.flex.DP);
            var tbxTemplateName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "100%",
                "id": "tbxTemplateName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "34dp",
                "placeholder": "Template Name",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxTemplateNAme.add(tbxTemplateName);
            var lblDescription = new kony.ui.Label({
                "id": "lblDescription",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateDescription\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateDescription = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateDescription",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateDescription.setDefaultUnit(kony.flex.DP);
            var tbxTemplateDescription = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "100%",
                "id": "tbxTemplateDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "34dp",
                "placeholder": "Template Description",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxTemplateDescription.add(tbxTemplateDescription);
            flxTemplate.add(lblName, flxTemplateNAme, lblDescription, flxTemplateDescription);
            var lblType = new kony.ui.Label({
                "id": "lblType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxType.setDefaultUnit(kony.flex.DP);
            var lstbTemplateType = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbTemplateType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLstb000D19",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxType.add(lstbTemplateType);
            var tblRequestType = new kony.ui.Label({
                "id": "tblRequestType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.RequestType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRequestType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxRequestType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestType.setDefaultUnit(kony.flex.DP);
            var lstbRequestType = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbRequestType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLstb000D19",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxRequestType.add(lstbRequestType);
            flxCreateDetails.add(flxTemplate, lblType, flxType, tblRequestType, flxRequestType);
            var lblCompany = new kony.ui.Label({
                "id": "lblCompany",
                "isVisible": false,
                "left": "2.52%",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Company Name/ID",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCompanyID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxCompanyID",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "right": 425,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyID.setDefaultUnit(kony.flex.DP);
            var lstbCompanyName = new kony.ui.ListBox({
                "focusSkin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "height": "100%",
                "id": "lstbCompanyName",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select"],
                    ["lblPheonix", "Pheoinx Solutions - 007619340"]
                ],
                "selectedKey": "lblSelect",
                "skin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "top": "0dp",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxCompanyID.add(lstbCompanyName);
            var lblPaymentType = new kony.ui.Label({
                "id": "lblPaymentType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.DebitAccount\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxPaymentType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentType.setDefaultUnit(kony.flex.DP);
            var lstbAccount = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbAccount",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select"],
                    ["lblx7690", "Progress Business Checking - X7690"],
                    ["lblx4710", "Pro Business Checking - X4710"]
                ],
                "selectedKey": "lblSelect",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxPaymentType.add(lstbAccount);
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "30dp",
                "width": "94%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transfer From"
                },
                "centerY": "50%",
                "id": "lblSelectAccount",
                "isVisible": false,
                "left": "40dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Pay From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "20dp",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblTypeIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTypeIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "g",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeIcon.add(lblTypeIcon);
            var lblFromAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transfer From"
                },
                "centerY": "50%",
                "id": "lblFromAmount",
                "isVisible": false,
                "right": "59dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Transfer From",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTransferFrom = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Search by account name or number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "tbxPlaceholderskna0a0a015px",
                "height": "100%",
                "id": "txtTransferFrom",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            var flxCancelFilterFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxCancelFilterFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxCancelFilterFrom.setDefaultUnit(kony.flex.DP);
            var imgCancelFilterFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancelFilterFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "search_close.png",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxCancelFilterFrom.add(imgCancelFilterFrom);
            var flxLoadingContainerFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingContainerFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 10,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingContainerFrom.setDefaultUnit(kony.flex.DP);
            var flxLoadingIndicatorFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorFrom.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Remove"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            flxLoadingIndicatorFrom.add(imgLoadingIndicatorFrom);
            flxLoadingContainerFrom.add(flxLoadingIndicatorFrom);
            flxFrom.add(lblSelectAccount, flxTypeIcon, lblFromAmount, txtTransferFrom, flxCancelFilterFrom, flxLoadingContainerFrom);
            var flxFromSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "5dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "300dp",
                "horizontalScrollIndicator": true,
                "id": "flxFromSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxscrollffffffShadowCustom",
                "top": "70dp",
                "verticalScrollIndicator": true,
                "width": "94%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxFromSegment.setDefaultUnit(kony.flex.DP);
            var segTransferFrom = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segTransferFrom",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxFromAccountsList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListItem": "flxAccountListItem",
                    "flxAmount": "flxAmount",
                    "flxBankIcon": "flxBankIcon",
                    "flxDropDown": "flxDropDown",
                    "flxFromAccountsList": "flxFromAccountsList",
                    "flxIcons": "flxIcons",
                    "flxTransfersFromListHeader": "flxTransfersFromListHeader",
                    "imgBankIcon": "imgBankIcon",
                    "imgDropDown": "imgDropDown",
                    "imgIcon": "imgIcon",
                    "lblAccType": "lblAccType",
                    "lblAccountName": "lblAccountName",
                    "lblAmount": "lblAmount",
                    "lblCurSym": "lblCurSym",
                    "lblSeparator": "lblSeparator",
                    "lblTopSeparator": "lblTopSeparator",
                    "lblTransactionHeader": "lblTransactionHeader"
                },
                "zIndex": 5,
                "appName": "ACHMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAccountsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "172dp",
                "id": "flxNoAccountsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFFFFFF",
                "top": "0dp",
                "width": "94%",
                "zIndex": 10,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoAccountsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "There are no accounts to transfer from. Add a bank account to get started"
                },
                "centerX": "50%",
                "height": "24dp",
                "id": "lblNoAccountsFrom",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.add(lblNoAccountsFrom);
            var flxNoResultsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoResultsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "No results found"
                },
                "centerX": "50%",
                "id": "lblNoResultsFrom",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.add(lblNoResultsFrom);
            flxFromSegment.add(segTransferFrom, flxNoAccountsFrom, flxNoResultsFrom);
            var lblMaxAmt = new kony.ui.Label({
                "id": "lblMaxAmt",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.MaximumTransferAmount\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMaxAmt = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxMaxAmt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaxAmt.setDefaultUnit(kony.flex.DP);
            var lblCurrSymbol = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrSymbol",
                "isVisible": true,
                "left": "4%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.currencySymbol\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxMaxAmt = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "40dp",
                "id": "tbxMaxAmt",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "8%",
                "placeholder": "0.00",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": 0,
                "width": "91%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknTextBoxSSP42424215PxNoBor",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxMaxAmt.add(lblCurrSymbol, tbxMaxAmt);
            var lblEffectiveDate = new kony.ui.Label({
                "id": "lblEffectiveDate",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.EffectiveDate\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "88.68%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var flxEffectiveDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxEffectiveDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectiveDate.setDefaultUnit(kony.flex.DP);
            var calEffectiveDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calEffectiveDate",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxEffectiveDate.add(calEffectiveDate);
            var lblNotTodayMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayMsg",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknLato72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(flxEffectiveDate, lblNotTodayMsg);
            var flxBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "18dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeperator.setDefaultUnit(kony.flex.DP);
            flxBottomSeperator.add();
            var createFlowFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "81dp",
                "id": "createFlowFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "viz.val_cleared",
                        "right": "23%",
                        "width": "18%"
                    },
                    "btnNext": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Proceed\")",
                        "left": "77.35%",
                        "width": "18.99%"
                    },
                    "btnOption": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "43.50%",
                        "width": "18%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCreateUI.add(flxHeader, flxTopSeparator, NonEditableDetails, flxCreateDetails, lblCompany, flxCompanyID, lblPaymentType, flxPaymentType, flxFrom, flxFromSegment, lblMaxAmt, flxMaxAmt, lblEffectiveDate, flxDate, flxBottomSeperator, createFlowFormActionsNew);
            var flxACHFilesUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxACHFilesUpload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesUpload.setDefaultUnit(kony.flex.DP);
            var flxACHFilesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxACHFilesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesHeader.setDefaultUnit(kony.flex.DP);
            var lblUploadFilesHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUploadFilesHeader",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.SelectTheFormatAndUpload\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxACHFilesHeader.add(lblUploadFilesHeader);
            var flxACHFilesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxACHFilesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesSeparator.setDefaultUnit(kony.flex.DP);
            flxACHFilesSeparator.add();
            var flxErrorFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxErrorFlow",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "94.97%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorFlow.setDefaultUnit(kony.flex.DP);
            var flxErrorUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorUpload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorUpload.setDefaultUnit(kony.flex.DP);
            var imgUploadFileError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgUploadFileError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadFailMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "You have already added all the accounts you have with us."
                },
                "centerY": "50%",
                "id": "lblUploadFailMessage",
                "isVisible": true,
                "left": "70dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.ACHFileErrorMessage\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorUpload.add(imgUploadFileError, lblUploadFailMessage);
            flxErrorFlow.add(flxErrorUpload);
            var lblFormatType = new kony.ui.Label({
                "id": "lblFormatType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.FormatType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFormatType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxFormatType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormatType.setDefaultUnit(kony.flex.DP);
            var lstbFormatType = new kony.ui.ListBox({
                "focusSkin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "height": "100%",
                "id": "lstbFormatType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFormatType.add(lstbFormatType);
            var lblUploadFile = new kony.ui.Label({
                "id": "lblUploadFile",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.UploadFile\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadFile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "105dp",
                "id": "flxUploadFile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "bbsknUploadflxf5f5f5",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFile.setDefaultUnit(kony.flex.DP);
            var imgPlusSign = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "35%",
                "height": "40dp",
                "id": "imgPlusSign",
                "isVisible": true,
                "skin": "slImage",
                "src": "bb_addicon.png",
                "top": "7dp",
                "width": "32dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblClickUpload = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "60%",
                "id": "lblClickUpload",
                "isVisible": true,
                "skin": "bbsknA0A0A015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.ClicktoUpload\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFile.add(imgPlusSign, lblClickUpload);
            var flxUploadedFileDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUploadedFileDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileDetails.setDefaultUnit(kony.flex.DP);
            var flxUploadedFile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "50dp",
                "id": "flxUploadedFile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": 330,
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFile.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.setDefaultUnit(kony.flex.DP);
            var imgFileType = new kony.ui.Image2({
                "height": "100%",
                "id": "imgFileType",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_image.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.add(imgFileType);
            var lblFIleName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFIleName",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknBBLato0273e315px",
                "text": "FileName.Nacha",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgdownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgdownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgdownload.setDefaultUnit(kony.flex.DP);
            var imgDownloadFIle = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgDownloadFIle",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgdownload.add(imgDownloadFIle);
            flxUploadedFile.add(flxFileTypeImage, lblFIleName, flxImgdownload);
            var btnRemoveFile = new kony.ui.Button({
                "height": "50dp",
                "id": "btnRemoveFile",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBBtn273e3NoBorder15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.payAPersonDeregister\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFileDetails.add(flxUploadedFile, btnRemoveFile);
            var flxACHFilesSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxACHFilesSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 90,
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesSeparator2.setDefaultUnit(kony.flex.DP);
            flxACHFilesSeparator2.add();
            var flxFilesACHActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFilesACHActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilesACHActions.setDefaultUnit(kony.flex.DP);
            var ACHFilesActions = new com.InfinityOLB.ApprovalRequestMA.formActions({
                "centerX": "50%",
                "height": "111dp",
                "id": "ACHFilesActions",
                "isVisible": false,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "viewType": "ACHFilesActions",
                "overrides": {
                    "formActions": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var ACHFilesActions_data = (appConfig.componentMetadata && appConfig.componentMetadata["ApprovalRequestMA"] && appConfig.componentMetadata["ApprovalRequestMA"]["frmACHDashboard"] && appConfig.componentMetadata["ApprovalRequestMA"]["frmACHDashboard"]["ACHFilesActions"]) || {};
            var filesFormActionsNew = new com.InfinityOLB.Resources.formActionsTemplate({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "80dp",
                "id": "filesFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFilesACHActions.add(ACHFilesActions, filesFormActionsNew);
            flxACHFilesUpload.add(flxACHFilesHeader, flxACHFilesSeparator, flxErrorFlow, lblFormatType, flxFormatType, lblUploadFile, flxUploadFile, flxUploadedFileDetails, flxACHFilesSeparator2, flxFilesACHActions);
            flxDashboard.add(flxTabPaneContainer, flxCreateUI, flxACHFilesUpload);
            var dbRightContainerNew = new com.InfinityOLB.Resources.dbRightContainerNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "dbRightContainerNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "28.68%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "dbRightContainerNew": {
                        "top": "0dp",
                        "width": "28.68%"
                    },
                    "imgBanner": {
                        "src": "nuo_banner_1.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxContentDashBoard.add(flxDashboard, dbRightContainerNew);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "110dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmACHDashboard"] && appConfig.componentMetadata["ResourcesMA"]["frmACHDashboard"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "115dp"
                    },
                    "flxAcknowledgementNew": {
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "isVisible": false
                    },
                    "flxTickImage": {
                        "height": "50dp"
                    },
                    "imgDownload": {
                        "src": "bbdownloadicon.png"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "imgTick": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    }
                }
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "focusSkin": "slfBoxffffffB1R5",
                "id": "flxTransactionDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var flxACHFileUploadDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "200dp",
                "id": "flxACHFileUploadDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFileUploadDetails.setDefaultUnit(kony.flex.DP);
            var lblACHfileDetails = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblACHfileDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.YourACHFileDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var flxTopSepartor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSepartor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSepartor.setDefaultUnit(kony.flex.DP);
            var imgTopSeparatorEmpty = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgTopSeparatorEmpty",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopSepartor.add(imgTopSeparatorEmpty);
            var flxFomatType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFomatType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": 20,
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFomatType.setDefaultUnit(kony.flex.DP);
            var lblFomatTypeAck = new kony.ui.Label({
                "id": "lblFomatTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.FormatTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblFormatTypeValue = new kony.ui.Label({
                "id": "lblFormatTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Nacha",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl455574SSP15Px"
            });
            flxFomatType.add(lblFomatTypeAck, lblFormatTypeValue);
            var flxFileUploadRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFileUploadRequest",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadRequest.setDefaultUnit(kony.flex.DP);
            var lblRequestTypeAck = new kony.ui.Label({
                "id": "lblRequestTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.RequestTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblRequestTypeValue = new kony.ui.Label({
                "id": "lblRequestTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "PPD",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl455574SSP15Px"
            });
            flxFileUploadRequest.add(lblRequestTypeAck, lblRequestTypeValue);
            var flxFileUploadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFileUploadAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadAck.setDefaultUnit(kony.flex.DP);
            var lblUploadedFile = new kony.ui.Label({
                "id": "lblUploadedFile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.UploadedFileColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxUploadedFileAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "50dp",
                "id": "flxUploadedFileAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "270dp",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": 330,
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileAck.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImageAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImageAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImageAck.setDefaultUnit(kony.flex.DP);
            var imgFileTypeAck = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHint": "File Type Image",
                    "a11yLabel": "File Type Image",
                    "a11yValue": "File Type Image"
                },
                "height": "100%",
                "id": "imgFileTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_image.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "File Type Image"
            });
            flxFileTypeImageAck.add(imgFileTypeAck);
            var lblFileNameAck = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFileNameAck",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknBBLato0273e315px",
                "text": "FileName.Nacha",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgdownloadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgdownloadAck",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.setDefaultUnit(kony.flex.DP);
            var imgDownloadFIleAck = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgDownloadFIleAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.add(imgDownloadFIleAck);
            flxUploadedFileAck.add(flxFileTypeImageAck, lblFileNameAck, flxImgdownloadAck);
            flxFileUploadAck.add(lblUploadedFile, flxUploadedFileAck);
            flxACHFileUploadDetails.add(lblACHfileDetails, flxTopSepartor, flxFomatType, flxFileUploadRequest, flxFileUploadAck);
            var NonEditableDetailsNew = new com.InfinityOLB.ApprovalRequestMA.NonEditableDetailsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableDetailsNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "5dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "flxBtmSeperator": {
                        "centerX": "50%",
                        "isVisible": true,
                        "top": "13dp",
                        "width": "96.67%"
                    },
                    "flxSupportingDocuments": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxTopSepartor": {
                        "centerX": "50%",
                        "width": "96.67%"
                    },
                    "lblACHTitleText": {
                        "centerY": "27dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.template.ACH\")",
                        "top": "viz.val_cleared"
                    },
                    "segDetails": {
                        "centerX": "viz.val_cleared",
                        "top": "13dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDateContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "122dp",
                "id": "flxDateContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateContainer.setDefaultUnit(kony.flex.DP);
            var flxEffectiveDateSelect = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "31.27%",
                "clipBounds": false,
                "height": "74dp",
                "id": "flxEffectiveDateSelect",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "59.26%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectiveDateSelect.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "height": "30dp",
                "id": "lblDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.EffectiveDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "88.68%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate1.setDefaultUnit(kony.flex.DP);
            var flxEffectDate1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxEffectDate1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectDate1.setDefaultUnit(kony.flex.DP);
            var calEffectiveDate1 = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calEffectiveDate1",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/MM/yyyy",
                "skin": "sknBBSSP455574cal15px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxEffectDate1.add(calEffectiveDate1);
            var lblNotTodayDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayDate",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknLato72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate1.add(flxEffectDate1, lblNotTodayDate);
            flxEffectiveDateSelect.add(lblDate, flxDate1);
            var flxDateBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxDateBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "120dp",
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateBottomSeperator.setDefaultUnit(kony.flex.DP);
            var lblSample1 = new kony.ui.Label({
                "id": "lblSample1",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDateBottomSeperator.add(lblSample1);
            flxDateContainer.add(flxEffectiveDateSelect, flxDateBottomSeperator);
            var flxPaymentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "96dp",
                "id": "flxPaymentInstruction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentInstruction.setDefaultUnit(kony.flex.DP);
            var lblPayemntInstruction = new kony.ui.Label({
                "id": "lblPayemntInstruction",
                "isVisible": true,
                "left": "1.66%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.SetPaymentInstruction\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxPaymentOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.58%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentOptions.setDefaultUnit(kony.flex.DP);
            var imgRadiobtn1 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadiobtn1",
                "isVisible": true,
                "left": 6,
                "skin": "slImage",
                "src": "radioactivebb.png",
                "top": 18,
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOption1 = new kony.ui.Label({
                "id": "lblOption1",
                "isVisible": true,
                "left": 33,
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Do not process details with amounts of $0.00",
                "top": 19,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadiobtn2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadiobtn2",
                "isVisible": true,
                "left": 6,
                "skin": "slImage",
                "src": "radioinactivebb.png",
                "top": 44,
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOption2 = new kony.ui.Label({
                "id": "lblOption2",
                "isVisible": true,
                "left": 33,
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Send details with amounts of $0.00 as payments",
                "top": 45,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentOptions.add(imgRadiobtn1, lblOption1, imgRadiobtn2, lblOption2);
            flxPaymentInstruction.add(lblPayemntInstruction, flxPaymentOptions);
            var flxAckPaymentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "52dp",
                "id": "flxAckPaymentInstruction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckPaymentInstruction.setDefaultUnit(kony.flex.DP);
            var lblAckPayemntInstruction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAckPayemntInstruction",
                "isVisible": true,
                "left": "1.66%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.PaymentInstruction\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblAckPaymentInstructionValue = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblAckPaymentInstructionValue",
                "isVisible": true,
                "left": "22.58%",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Do not process details with amounts of $0.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            flxAckPaymentInstruction.add(lblAckPayemntInstruction, lblAckPaymentInstructionValue);
            var flxSeperator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 0,
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator4.setDefaultUnit(kony.flex.DP);
            var lblSample = new kony.ui.Label({
                "id": "lblSample",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperator4.add(lblSample);
            var flxTemplateRecordHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "115dp",
                "id": "flxTemplateRecordHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordHeader.setDefaultUnit(kony.flex.DP);
            var lblRecordHeader1 = new kony.ui.Label({
                "id": "lblRecordHeader1",
                "isVisible": true,
                "left": "1.66%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CreditorDestinationAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblRecordHeader2 = new kony.ui.Label({
                "id": "lblRecordHeader2",
                "isVisible": true,
                "left": "1.66%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.accountInfo\")",
                "top": "70dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxSeperatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 50,
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.setDefaultUnit(kony.flex.DP);
            var lblsampleHeader = new kony.ui.Label({
                "id": "lblsampleHeader",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.add(lblsampleHeader);
            flxTemplateRecordHeader.add(lblRecordHeader1, lblRecordHeader2, flxSeperatorHeader);
            var flxTemplateRecordsErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxTemplateRecordsErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgTemplateRecordsError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgTemplateRecordsError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTemplateRecordsError = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50%",
                "id": "lblTemplateRecordsError",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateRecordsErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTemplateRecordsErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxTemplateRecordsErrorSeperator.add();
            flxTemplateRecordsErrorMessage.add(imgTemplateRecordsError, lblTemplateRecordsError, flxTemplateRecordsErrorSeperator);
            var TemplateRecordsNew = new com.InfinityOLB.ApprovalRequestMA.TemplateRecordsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TemplateRecordsNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "TabBodyNew.segTemplates": {
                        "left": "0dp"
                    },
                    "btnAddAdditionalDetailsRow": {
                        "isVisible": false
                    },
                    "btnUpdate": {
                        "centerY": "50%",
                        "left": "0.93%",
                        "right": "3%",
                        "top": "viz.val_cleared"
                    },
                    "flxSeparator": {
                        "width": "100%"
                    },
                    "flxTotalAmount": {
                        "left": "79%"
                    },
                    "lblAmountColon": {
                        "centerY": "54%"
                    },
                    "lblCurrSymbol": {
                        "left": "7%"
                    },
                    "lblTotalAmount": {
                        "left": "viz.val_cleared"
                    },
                    "lblTotalAmountCreate": {
                        "left": "13%"
                    },
                    "tbxTotalAmount": {
                        "left": "77%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxApprovalsHistoryInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalsHistoryInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryInformation.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxApprovalsHistoryErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgApprovalHistoryError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgApprovalHistoryError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalHistoryError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApprovalHistoryError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxErrorSeperator.add();
            flxApprovalsHistoryErrorMessage.add(imgApprovalHistoryError, lblApprovalHistoryError, flxErrorSeperator);
            var flxApprovalHistoryContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalHistoryContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalHistoryInformation = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalHistoryInformation",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Approval History Information",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxApprovalStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "25dp",
                "clipBounds": true,
                "id": "flxApprovalStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.setDefaultUnit(kony.flex.DP);
            var flxApprovalStatusGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalStatusGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatusGroup.setDefaultUnit(kony.flex.DP);
            var flxApprovalDetailsStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalDetailsStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "60%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsStatus.setDefaultUnit(kony.flex.DP);
            var lblApprovalStatus = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatus",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ApprovalStatus\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var lblApprovalStatusValue = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatusValue",
                "isVisible": true,
                "left": "150dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            flxApprovalDetailsStatus.add(lblApprovalStatus, lblApprovalStatusValue);
            var flxApprovedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovedCountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblApproveCount = new kony.ui.Label({
                "id": "lblApproveCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "text": "Approved:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApproveCountVal = new kony.ui.Label({
                "id": "lblApproveCountVal",
                "isVisible": true,
                "left": "185dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "2",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.add(lblApproveCount, lblApproveCountVal);
            var flxRejectedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRejectedCountDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblRejectCount = new kony.ui.Label({
                "id": "lblRejectCount",
                "isVisible": true,
                "left": 20,
                "skin": "sknlbla0a0a015px",
                "text": "Rejected:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRejectCountVal = new kony.ui.Label({
                "id": "lblRejectCountVal",
                "isVisible": true,
                "left": "190dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.add(lblRejectCount, lblRejectCountVal);
            flxApprovalStatusGroup.add(flxApprovalDetailsStatus, flxApprovedCountDetails, flxRejectedCountDetails);
            var btnPendingAprrovers = new kony.ui.Button({
                "height": "40dp",
                "id": "btnPendingAprrovers",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "text": "Pending Approvers",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.add(flxApprovalStatusGroup, btnPendingAprrovers);
            var flxSeparatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom.add();
            var segApprovalDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segApprovalDetails",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsRowTemplate"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsACKHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxApprovalDetailsACKHeader": "flxApprovalDetailsACKHeader",
                    "flxApprovalDetailsRowTemplate": "flxApprovalDetailsRowTemplate",
                    "flxApproveDetails": "flxApproveDetails",
                    "flxHeaderValues": "flxHeaderValues",
                    "flxNoRecords": "flxNoRecords",
                    "flxTopSeperator": "flxTopSeperator",
                    "flxTopSeperator2": "flxTopSeperator2",
                    "imgFlxTopSeparator": "imgFlxTopSeparator",
                    "imgFlxTopSeparator2": "imgFlxTopSeparator2",
                    "lblAction": "lblAction",
                    "lblActionKey": "lblActionKey",
                    "lblComments": "lblComments",
                    "lblCommentsKey": "lblCommentsKey",
                    "lblDateAndTime": "lblDateAndTime",
                    "lblDateAndTimeKey": "lblDateAndTimeKey",
                    "lblNoRecords": "lblNoRecords",
                    "lblSignatoryGroup": "lblSignatoryGroup",
                    "lblSignatoryGroupKey": "lblSignatoryGroupKey",
                    "lblUserID": "lblUserID",
                    "lblUserIDKey": "lblUserIDKey"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.add(lblApprovalHistoryInformation, flxTopSeperator, flxApprovalStatus, flxSeparatorBottom, segApprovalDetails);
            flxApprovalsHistoryInformation.add(flxApprovalsHistoryErrorMessage, flxApprovalHistoryContent);
            var CommonFormActionsNew = new com.InfinityOLB.Resources.formActionsTemplate({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "80dp",
                "id": "CommonFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransactionDetails.add(flxErrorMessage, flxACHFileUploadDetails, NonEditableDetailsNew, flxDateContainer, flxPaymentInstruction, flxAckPaymentInstruction, flxSeperator4, flxTemplateRecordHeader, flxTemplateRecordsErrorMessage, TemplateRecordsNew, flxApprovalsHistoryInformation, CommonFormActionsNew);
            var flxAuthenticator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "4dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthenticator.setDefaultUnit(kony.flex.DP);
            var OTPAuthenticator = new com.InfinityOLB.ApprovalRequestMA.OTPAuthenticator({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadowBlur8Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "OTPCode.imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "OTPCode.imgWarning": {
                        "src": "error_yellow.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAuthenticator.add(OTPAuthenticator);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxContentHeader, flxDisplayErrorMessage, flxContentDashBoard, flxAcknowledgementContainer, flxTransactionDetails, flxAuthenticator, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "100dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "100dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "top": "26.60%",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "23dp",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "22dp",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder3343a81pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSave = new kony.ui.Button({
                "bottom": 20,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "13dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "icon_close_grey.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 6000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxClose": {
                        "isVisible": true,
                        "right": "0dp"
                    },
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "280dp"
                    },
                    "flxPopupNew": {
                        "isVisible": false,
                        "zIndex": 6000
                    },
                    "formActionsNew.btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "formActionsNew.btnNext": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "imgClose": {
                        "right": "20dp",
                        "src": "bbcloseicon.png"
                    },
                    "trComments": {
                        "left": "30dp",
                        "right": "viz.val_cleared",
                        "top": "12dp",
                        "width": "88.70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxOverlay = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxOverlay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverlay.setDefaultUnit(kony.flex.DP);
            flxOverlay.add();
            var flxPendingApprovers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50.04%",
                "clipBounds": true,
                "height": "700dp",
                "id": "flxPendingApprovers",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "ICsknFlxffffff",
                "width": "50%",
                "zIndex": 7000,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApprovers.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxPendingApproversDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversDetails.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxPendingApproversHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.setDefaultUnit(kony.flex.DP);
            var lblApprovalDetails = new kony.ui.Label({
                "id": "lblApprovalDetails",
                "isVisible": true,
                "left": "23dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendinApprovers.PendingApprovalDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPopupclose = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgPopupclose",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.add(lblApprovalDetails, imgPopupclose);
            var flxSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxGroupDetails = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "78%",
                "horizontalScrollIndicator": true,
                "id": "flxGroupDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupDetails.setDefaultUnit(kony.flex.DP);
            var flxApprovalLimitHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalLimitHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalLimitHeader.setDefaultUnit(kony.flex.DP);
            var flxPerTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "190dp",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransaction.setDefaultUnit(kony.flex.DP);
            var lblPerTransaction = new kony.ui.Label({
                "id": "lblPerTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.PerTransactionApprovals\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPerTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxPerTransactionSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxPerTransactionSelected.add();
            flxPerTransaction.add(lblPerTransaction, flxPerTransactionSelected);
            var flxDailyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "240dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "125dp",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransaction.setDefaultUnit(kony.flex.DP);
            var lblDailyTransaction = new kony.ui.Label({
                "id": "lblDailyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.dailyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxDailyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxDailyTransactionSelected.add();
            flxDailyTransaction.add(lblDailyTransaction, flxDailyTransactionSelected);
            var flxWeekelyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeekelyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "395dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "145dp",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeekelyTransaction.setDefaultUnit(kony.flex.DP);
            var lblWeekelyTransaction = new kony.ui.Label({
                "id": "lblWeekelyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.weeklyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxWeeklyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "30dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxWeeklyTransactionSelected.add();
            flxWeekelyTransaction.add(lblWeekelyTransaction, flxWeeklyTransactionSelected);
            flxApprovalLimitHeader.add(flxPerTransaction, flxDailyTransaction, flxWeekelyTransaction);
            var flxNoteMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoteMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoteMessage.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Note: The transaction can be approved by any 2 of the sernior managers (or) any 1 of the admin.",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoteMessage.add(imgInfoIcon, lblInfo);
            var flxApproverList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApproverList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApproverList.setDefaultUnit(kony.flex.DP);
            flxApproverList.add();
            flxGroupDetails.add(flxApprovalLimitHeader, flxNoteMessage, flxApproverList);
            var flxNoPendingData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxNoPendingData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPendingData.setDefaultUnit(kony.flex.DP);
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon2",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoPendingApprovals = new kony.ui.Label({
                "id": "lblNoPendingApprovals",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.noPendingApprovals\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfoIcon2, lblNoPendingApprovals);
            flxNoPendingData.add(flxInfo);
            var flxPopupBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15%",
                "id": "flxPopupBottom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 500,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBottom.setDefaultUnit(kony.flex.DP);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ACHMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var btnClose = new kony.ui.Button({
                "bottom": "30dp",
                "height": "50dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupBottom.add(flxBottomSeparator, btnClose);
            flxPendingApproversDetails.add(flxPendingApproversHeader, flxSeparator, flxGroupDetails, flxNoPendingData, flxPopupBottom);
            flxPendingApprovers.add(flxPendingApproversDetails);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": true,
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxDropdown": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxImage": {
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.00%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblView": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblViewType": {
                        "left": {
                            "type": "string",
                            "value": "13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "77%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPaginationFirst": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew": {
                        "isVisible": true,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew.segTemplates": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxFilter": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-96%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "skin": "sknFlxscrollffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "70"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "instanceId": "createFlowFormActionsNew"
                    },
                    "flxErrorFlow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxUploadedFileDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": [],
                        "instanceId": "dbRightContainerNew"
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "70px"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.lblACHTitleText": {
                        "centerY": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentOptions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAckPaymentInstruction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAckPaymentInstructionValue": {
                        "left": {
                            "type": "string",
                            "value": "24.58%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblUpdateDefaultAmount": {
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.tbxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnProceed": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.lblSecureAccessCode": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.flxOTPContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnSave": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxClose": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "17%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbCompanyName": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "right": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCurrSymbol": {
                        "segmentProps": []
                    },
                    "tbxMaxAmt": {
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "calEffectiveDate": {
                        "padding": [5, 0, 5, 0],
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "right": {
                            "type": "string",
                            "value": "37.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lstbFormatType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": [],
                        "instanceId": "dbRightContainerNew"
                    },
                    "flxAcknowledgementContainer": {
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxAckContainer": {
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "10.50%"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblACHfileDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTopSepartor": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFomatType": {
                        "centerX": {
                            "type": "string",
                            "value": "49.86%"
                        },
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFileUploadRequest": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFileUploadAck": {
                        "centerX": {
                            "type": "string",
                            "value": "49.93%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxSupportingDocuments": {
                        "height": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxTopSepartor": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.lblACHTitleText": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.segDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "49.82%"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxEffectiveDateSelect": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDateBottomSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "top": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "lblPayemntInstruction": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentOptions": {
                        "left": {
                            "type": "string",
                            "value": "23.58%"
                        },
                        "segmentProps": []
                    },
                    "flxAckPaymentInstruction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAckPayemntInstruction": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblAckPaymentInstructionValue": {
                        "left": {
                            "type": "string",
                            "value": "23.58%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.66%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader1": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader2": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.66%"
                        },
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.TabBodyNew.segTemplates": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.btnUpdate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblAmountColon": {
                        "left": {
                            "type": "string",
                            "value": "77.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblCurrSymbol": {
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblUpdateDefaultAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.tbxUpdateDefaultAmount": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "14.90%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "4.10%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCount": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCountVal": {
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxOverlay": {
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalDetails": {
                        "segmentProps": []
                    },
                    "imgPopupclose": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerTransaction": {
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyTransaction": {
                        "left": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxWeekelyTransaction": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTabPaneContainer": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "TabPaneNew"
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption0": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab5": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab6": {
                        "segmentProps": []
                    },
                    "flxCreateUI": {
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCreateDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "isVisible": true,
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbCompanyName": {
                        "padding": [3, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "tbxMaxAmt": {
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "flxDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectiveDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calEffectiveDate": {
                        "padding": [6, 0, 5, 0],
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "flxBottomSeperator": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "45.50%"
                        },
                        "segmentProps": []
                    },
                    "flxACHFilesUpload": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.segDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.67%"
                        },
                        "segmentProps": []
                    },
                    "flxDateContainer": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectiveDateSelect": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1.67%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxDate1": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectDate1": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calEffectiveDate1": {
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblAmountColon": {
                        "left": {
                            "type": "string",
                            "value": "77.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "350px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICsknFlxffffff",
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "flxNoteMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxApproverList": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon2": {
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    },
                    "btnClose": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "100%",
                    "zIndex": 900
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": "",
                    "text": "Help"
                },
                "TabPaneNew.MobileCustomDropdown": {
                    "zIndex": 1
                },
                "TabPaneNew.MobileCustomDropdown.flxImage": {
                    "left": "91%"
                },
                "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "centerX": "",
                    "centerY": "",
                    "left": "4%"
                },
                "TabPaneNew.MobileCustomDropdown.imgDropdown": {
                    "src": "listboxarw.png"
                },
                "TabPaneNew.MobileCustomDropdown.lblView": {
                    "width": "100%"
                },
                "TabPaneNew.MobileCustomDropdown.lblViewType": {
                    "left": "0%",
                    "width": "85%"
                },
                "TabPaneNew.MobileCustomDropdown.segCurrency": {
                    "data": [
                        [{
                                "lblHedaerContent": "Single Transaction"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ],
                        [{
                                "lblHedaerContent": "Bulk Transaction"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ],
                        [{
                                "lblHedaerContent": "Other Requests"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ]
                    ]
                },
                "TabPaneNew.MobileCustomDropdown.segProcessingType": {
                    "data": [{
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }]
                },
                "TabPaneNew.MobileCustomDropdown.segTimePeriod": {
                    "data": [{
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }]
                },
                "TabPaneNew.MobileCustomDropdown.segTypeOfAccounts": {
                    "data": [{
                        "imgCheckBox": "D",
                        "imgCheckBox2": "D",
                        "lblAccountType1": "Savings",
                        "lblAccountType2": "Savings"
                    }]
                },
                "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                    "zIndex": 15
                },
                "TabPaneNew.PaginationContainer.flxPagination": {
                    "reverseLayoutDirection": true
                },
                "TabPaneNew.PaginationContainer.imgPaginationFirst": {
                    "src": "pagination_inactive.png"
                },
                "TabPaneNew.PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "TabPaneNew.PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "TabPaneNew.TabBodyNew": {
                    "top": "0dp"
                },
                "TabPaneNew.TabBodyNew.segTemplates": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "TabPaneNew.TabSearchBarNew": {
                    "centerY": "",
                    "zIndex": 1,
                    "layoutType": kony.flex.FREE_FORM
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                    "bottom": "",
                    "centerX": "",
                    "height": "80dp",
                    "top": "0dp",
                    "zIndex": 1
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                    "left": "4%",
                    "top": "60dp",
                    "width": "92%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxFilter": {
                    "centerX": "",
                    "left": "0%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxImage": {
                    "centerX": "",
                    "left": "",
                    "right": "0dp",
                    "width": "20%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "4%",
                    "minWidth": "",
                    "top": "20dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "20dp",
                    "src": "dropdown_expand.png",
                    "width": "20dp"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                    "centerX": "",
                    "left": "8dp",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "20%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                    "left": "48dp",
                    "right": "40%",
                    "top": "0%",
                    "width": "50%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.segCurrency": {
                    "data": [
                        [{
                                "lblHedaerContent": "Single Transaction"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ],
                        [{
                                "lblHedaerContent": "Bulk Transaction"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }, {
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ],
                        [{
                                "lblHedaerContent": "Other Requests"
                            },
                            [{
                                "lblCheckFeature": "L",
                                "lblFeatureName": "Label"
                            }]
                        ]
                    ]
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.segProcessingType": {
                    "data": [{
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }]
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.segTimePeriod": {
                    "data": [{
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }, {
                        "lblCheckFeature": "L",
                        "lblFeatureName": "Label"
                    }]
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.segTypeOfAccounts": {
                    "data": [{
                        "imgCheckBox": "D",
                        "imgCheckBox2": "D",
                        "lblAccountType1": "Savings",
                        "lblAccountType2": "Savings"
                    }]
                },
                "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                    "centerY": "47.50%",
                    "height": "40dp",
                    "left": "0%",
                    "top": "",
                    "width": "95%"
                },
                "TabPaneNew.TabSearchBarNew.flxDropDown": {
                    "centerY": "47.50%",
                    "height": "50dp",
                    "left": "68%",
                    "top": "",
                    "width": "30%",
                    "zIndex": 1
                },
                "TabPaneNew.TabSearchBarNew.flxOptions": {
                    "height": "100%"
                },
                "TabPaneNew.TabSearchBarNew.flxSearch": {
                    "left": "20dp",
                    "width": "68%"
                },
                "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                    "right": "10dp",
                    "width": "67.74%"
                },
                "NonEditableDetails": {
                    "left": "1%",
                    "top": "0dp",
                    "width": "98%"
                },
                "createFlowFormActionsNew.btnCancel": {
                    "left": "",
                    "right": "23%",
                    "width": "18%"
                },
                "createFlowFormActionsNew.btnNext": {
                    "left": "77.35%",
                    "width": "18.99%"
                },
                "createFlowFormActionsNew.btnOption": {
                    "left": "",
                    "right": "43.50%",
                    "width": "18%"
                },
                "ACHFilesActions": {
                    "left": "",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "dbRightContainerNew": {
                    "top": "0dp",
                    "width": "28.68%"
                },
                "dbRightContainerNew.imgBanner": {
                    "src": "nuo_banner_1.png"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "115dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxTickImage": {
                    "height": "50dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "src": "bbdownloadicon.png"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png"
                },
                "NonEditableDetailsNew.flxBtmSeperator": {
                    "centerX": "50%",
                    "top": "13dp",
                    "width": "96.67%"
                },
                "NonEditableDetailsNew.flxTopSepartor": {
                    "centerX": "50%",
                    "width": "96.67%"
                },
                "NonEditableDetailsNew.lblACHTitleText": {
                    "centerY": "27dp",
                    "top": ""
                },
                "NonEditableDetailsNew.segDetails": {
                    "centerX": "",
                    "top": "13dp",
                    "width": "100%"
                },
                "TemplateRecordsNew.TabBodyNew.segTemplates": {
                    "left": "0dp"
                },
                "TemplateRecordsNew.btnUpdate": {
                    "centerY": "50%",
                    "left": "0.93%",
                    "right": "3%",
                    "top": ""
                },
                "TemplateRecordsNew.flxSeparator": {
                    "width": "100%"
                },
                "TemplateRecordsNew.flxTotalAmount": {
                    "left": "79%"
                },
                "TemplateRecordsNew.lblAmountColon": {
                    "centerY": "54%"
                },
                "TemplateRecordsNew.lblCurrSymbol": {
                    "left": "7%"
                },
                "TemplateRecordsNew.lblTotalAmount": {
                    "left": ""
                },
                "TemplateRecordsNew.lblTotalAmountCreate": {
                    "left": "13%"
                },
                "TemplateRecordsNew.tbxTotalAmount": {
                    "left": "77%"
                },
                "OTPAuthenticator.OTPCode.imgViewCVVCode": {
                    "src": "view.png"
                },
                "OTPAuthenticator.OTPCode.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "100dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "top": "26.60%",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "13dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "icon_close_grey.png"
                },
                "flxPopup.flxClose": {
                    "right": "0dp"
                },
                "flxPopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopup.flxPopupContainer": {
                    "centerY": "",
                    "left": "",
                    "right": "",
                    "top": "280dp"
                },
                "flxPopup": {
                    "zIndex": 6000
                },
                "flxPopup.formActionsNew.btnCancel": {
                    "left": "",
                    "right": "190dp",
                    "width": "150dp"
                },
                "flxPopup.formActionsNew.btnNext": {
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "flxPopup.imgClose": {
                    "right": "20dp",
                    "src": "bbcloseicon.png"
                },
                "flxPopup.trComments": {
                    "left": "30dp",
                    "right": "",
                    "top": "12dp",
                    "width": "88.70%"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxTermsAndConditions, flxLogout, flxLoading, flxPopup, flxOverlay, flxPendingApprovers);
        };
        return [{
            "addWidgets": addWidgetsfrmACHDashboard,
            "enabledForIdleTimeout": false,
            "id": "frmACHDashboard",
            "init": controller.AS_Form_g3ee0f81ea9e43e2b4dfcae289ec00ac,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ACHMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});