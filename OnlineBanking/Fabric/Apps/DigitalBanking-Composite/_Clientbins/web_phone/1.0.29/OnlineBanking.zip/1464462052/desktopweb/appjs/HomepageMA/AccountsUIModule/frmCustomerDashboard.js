define("HomepageMA/AccountsUIModule/frmCustomerDashboard", function() {
    return function(controller) {
        function addWidgetsfrmCustomerDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu": {
                        "right": "6%",
                        "width": "100%"
                    },
                    "headermenu.flxResetUserImg": {
                        "isVisible": true
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "imgKony": {
                        "centerX": "50%",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "src": "kony_logo.png",
                        "top": "0px"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxCombinedAccessMenuMobile": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": 2,
                        "width": "170dp"
                    },
                    "topmenu.flxCombinedMobile": {
                        "isVisible": false
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedback": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "isVisible": false,
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblAccounts": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.overview\")"
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared",
                        "text": "Help"
                    },
                    "topmenu.segCombinedAccessMenuMobile": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeperatorheader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorheader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorheader.setDefaultUnit(kony.flex.DP);
            flxSeperatorheader.add();
            flxHeader.add(customheader, flxSeperatorheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblDashboardHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Account Overview",
                    "tagName": "h1"
                },
                "centerX": "50%",
                "id": "lblDashboardHeading",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblUserName",
                "text": "Overview",
                "top": "15dp",
                "width": "1200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxPriorityMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxPriorityMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPriorityMessage.setDefaultUnit(kony.flex.DP);
            var priorityMessageTag = new com.InfinityOLB.HomepageMA.priorityMessageTag({
                "centerX": "50%",
                "height": "100%",
                "id": "priorityMessageTag",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA",
                "overrides": {
                    "flxMsgContent": {
                        "left": "70dp",
                        "right": "70dp",
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "imgCross": {
                        "centerX": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": 10,
                        "src": "closeicon.png",
                        "width": "110dp"
                    },
                    "lblImgMessage": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "20dp",
                        "top": "viz.val_cleared"
                    },
                    "lblPriorityMessageCount": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "lblViewMessages": {
                        "left": "20dp",
                        "text": "View Messages(s)",
                        "top": "0dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "priorityMessageTag": {
                        "height": "100%",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPriorityMessage.add(priorityMessageTag);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var flxDownTimeClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDownTimeClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "top": "8dp",
                "width": "30dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownTimeClose.setDefaultUnit(kony.flex.DP);
            var lblImgCloseDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "lblImgCloseDowntimeWarning",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownTimeClose.add(lblImgCloseDowntimeWarning);
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning, flxDownTimeClose);
            var flxDeviceRegistrationWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDeviceRegistrationWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeviceRegistrationWarning.setDefaultUnit(kony.flex.DP);
            var DeviceRegisrationWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "DeviceRegisrationWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeviceRegistrationWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Our online Banking Application will be unavailable on 13/04/2017 between 12:00 AM to 4:00 AM while we upgrade our system to provide you a better Banking Experience.",
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblDeviceRegistrationWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDeviceRegistrationClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgDeviceRegistrationClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var flxDeviceRegistrationClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDeviceRegistrationClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "top": "10dp",
                "width": "30dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeviceRegistrationClose.setDefaultUnit(kony.flex.DP);
            var lblImgDeviceRegistrationClose = new kony.ui.Label({
                "bottom": "8dp",
                "height": "100%",
                "id": "lblImgDeviceRegistrationClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeviceRegistrationClose.add(lblImgDeviceRegistrationClose);
            flxDeviceRegistrationWarning.add(DeviceRegisrationWarning, lblDeviceRegistrationWarning, imgDeviceRegistrationClose, flxDeviceRegistrationClose);
            var flxUpgradeDashboardDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxUpgradeDashboardDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpgradeDashboardDisclaimer.setDefaultUnit(kony.flex.DP);
            var imgUpgradeDisclaimer = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgUpgradeDisclaimer",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "status_icon_blue_alert.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUpgradeDisclaimer = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Our online Banking Application will be unavailable on 13/04/2017 between 12:00 AM to 4:00 AM while we upgrade our system to provide you a better Banking Experience.",
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblUpgradeDisclaimer",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.homepage.upgradeDisclaimer\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUpgradeDisclaimerClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgUpgradeDisclaimerClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var flxUpgradeDisclaimerClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxUpgradeDisclaimerClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "top": "10dp",
                "width": "30dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpgradeDisclaimerClose.setDefaultUnit(kony.flex.DP);
            var lblUpgradeDisclaimerClose = new kony.ui.Label({
                "bottom": "8dp",
                "height": "100%",
                "id": "lblUpgradeDisclaimerClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUpgradeDisclaimerClose.add(lblUpgradeDisclaimerClose);
            flxUpgradeDashboardDisclaimer.add(imgUpgradeDisclaimer, lblUpgradeDisclaimer, imgUpgradeDisclaimerClose, flxUpgradeDisclaimerClose);
            var flxPasswordResetWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxPasswordResetWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPasswordResetWarning.setDefaultUnit(kony.flex.DP);
            var lblPasswordResetWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Our online Banking Application will be unavailable on 13/04/2017 between 12:00 AM to 4:00 AM while we upgrade our system to provide you a better Banking Experience.",
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblPasswordResetWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgClosePasswordResetWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgClosePasswordResetWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var ingPasswordResetWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "ingPasswordResetWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClosePassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxClosePassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "30dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClosePassword.setDefaultUnit(kony.flex.DP);
            var lblImgClosePasswordResetWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblImgClosePasswordResetWarning",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClosePassword.add(lblImgClosePasswordResetWarning);
            flxPasswordResetWarning.add(lblPasswordResetWarning, imgClosePasswordResetWarning, ingPasswordResetWarning, flxClosePassword);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "One or more of your accounts may be overdrawn once your scheduled transactions are executed. Please make sure your accounts have sufficient funds or reschedule your transactions to avoid overdraft fees.",
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var flxCloseWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCloseWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "top": "5dp",
                "width": "40dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseWarning.setDefaultUnit(kony.flex.DP);
            var lblImgCloseWarning = new kony.ui.Label({
                "height": "100%",
                "id": "lblImgCloseWarning",
                "isVisible": true,
                "left": 0,
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseWarning.add(lblImgCloseWarning);
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning, flxCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Close"
                },
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var flxOutageClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxOutageClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageClose.setDefaultUnit(kony.flex.DP);
            var lblImgCloseOutageWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "lblImgCloseOutageWarning",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOutageClose.add(lblImgCloseOutageWarning);
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning, flxOutageClose);
            var flxWelcomeAndActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "-50dp",
                "clipBounds": true,
                "id": "flxWelcomeAndActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeAndActions.setDefaultUnit(kony.flex.DP);
            var welcome = new com.InfinityOLB.HomepageMA.welcome({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "welcome",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0dc31dea6043a4f",
                "top": "0dp",
                "width": "58.20%",
                "appName": "HomepageMA",
                "overrides": {
                    "imgProfile": {
                        "src": "username_img.png"
                    },
                    "lblLastLoggedIn": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Lastloggedin\")"
                    },
                    "lblWelcome": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.WelcomeJohn\")"
                    },
                    "welcome": {
                        "left": "6%",
                        "width": "58.20%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxWelcomeAndActions.add(welcome);
            var flxAccountListAndBanner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAccountListAndBanner",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "15px",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountListAndBanner.setDefaultUnit(kony.flex.DP);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxTotalAssetsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxTotalAssetsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAssetsContainer.setDefaultUnit(kony.flex.DP);
            var totalAssetsCard = new com.InfinityOLB.HomepageMA.totalAssetsCard({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "totalAssetsCard",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "segLegend": {
                        "data": [{
                            "flxAssetClass": "Cash (50%)",
                            "flxMarketValue": "$30,574.50",
                            "img1": "imagedrag.png"
                        }, {
                            "flxAssetClass": "Stocks (20%)",
                            "flxMarketValue": "$12,229.80",
                            "img1": "imagedrag.png"
                        }, {
                            "flxAssetClass": "Bond (16%)",
                            "flxMarketValue": "$9,783.84",
                            "img1": "imagedrag.png"
                        }, {
                            "flxAssetClass": "Mutual Fund (10%)",
                            "flxMarketValue": "$6,114.93",
                            "img1": "imagedrag.png"
                        }, {
                            "flxAssetClass": "Term Deposit (4%)",
                            "flxMarketValue": "$2,445.97",
                            "img1": "imagedrag.png"
                        }]
                    },
                    "totalAssetsCard": {
                        "isVisible": false,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "totalAssetsChart": {
                        "height": "260dp",
                        "width": "260dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var totalAssets = new com.InfinityOLB.HomepageMA.totalAssets({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "totalAssets",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2000,
                "appName": "HomepageMA",
                "viewType": "totalAssets",
                "overrides": {
                    "totalAssets": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var totalAssets_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["totalAssets"]) || {};
            totalAssets.StrokeColors = totalAssets_data.StrokeColors || {
                "data": [{
                    "Colors": "#0475C4"
                }, {
                    "Colors": "#43A2CA"
                }, {
                    "Colors": "#7BCCC4"
                }, {
                    "Colors": "#BAE4BC"
                }, {
                    "Colors": "#E9FED4"
                }, {
                    "Colors": "#E55845"
                }, {
                    "Colors": "#E48444"
                }, {
                    "Colors": "#E8DD46"
                }, {
                    "Colors": "#54D75D"
                }, {
                    "Colors": "#04C477"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Colors",
                    "columnHeaderType": "text",
                    "columnID": "Colors",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "ff9f31d8746f437c8dd204be1c17e71b"
                }]
            };
            totalAssets.TooltipValues = totalAssets_data.TooltipValues || "assetClass, percentage, marketValue";
            totalAssets.LayoutType = totalAssets_data.LayoutType || "horizontal";
            totalAssets.Title = totalAssets_data.Title || "i18n.wealth.totalAssets";
            flxTotalAssetsContainer.add(totalAssetsCard, totalAssets);
            var flxInvestmentSummaryContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxInvestmentSummaryContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInvestmentSummaryContainer.setDefaultUnit(kony.flex.DP);
            var investmentSummaryCard = new com.InfinityOLB.HomepageMA.investmentSummaryCard({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "investmentSummaryCard",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "chartInvestmentSummary": {
                        "right": "viz.val_cleared"
                    },
                    "flxAccountDetails": {
                        "height": kony.flex.USE_PREFFERED_SIZE
                    },
                    "flxPeriodSelector": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxSelector1": {
                        "isVisible": true
                    },
                    "flxSelector2": {
                        "left": "25%"
                    },
                    "flxSelector3": {
                        "left": "50%"
                    },
                    "flxSelector4": {
                        "left": "75%"
                    },
                    "investmentSummaryCard": {
                        "isVisible": false,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "segInvestmentAccountsList": {
                        "data": [{
                            "imgBankLogo": "bank_icon_citi.png",
                            "lblAccountBalance": "$38,300.00",
                            "lblAccountName": "Investment Account.. .. 2235",
                            "lblInvestmentLogo": " Investment ",
                            "lblJointAccountLogo": " Investment ",
                            "lblProfitBalance": "+$12.22 (+0.90%)"
                        }, {
                            "imgBankLogo": "bank_icon_citi.png",
                            "lblAccountBalance": "$6,286.00",
                            "lblAccountName": "Investment Account.. .. 9844",
                            "lblInvestmentLogo": " Investment ",
                            "lblJointAccountLogo": " Investment ",
                            "lblProfitBalance": "+$12.22 (+0.90%)"
                        }, {
                            "imgBankLogo": "bank_icon_citi.png",
                            "lblAccountBalance": "$5,746.00",
                            "lblAccountName": "Investment Account.. .. 2202",
                            "lblInvestmentLogo": " Investment ",
                            "lblJointAccountLogo": " Investment ",
                            "lblProfitBalance": "+$12.22 (+0.90%)"
                        }]
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var investmentSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "investmentSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            investmentSummary.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTilte = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblTilte",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPSemiBold42424215px",
                "text": "My Investment Summary",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblTilte);
            var flxSeparatorInvestment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 1,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorInvestment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorInvestment.setDefaultUnit(kony.flex.DP);
            flxSeparatorInvestment.add();
            var flxPortofolioValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPortofolioValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPortofolioValues.setDefaultUnit(kony.flex.DP);
            var flxMarketValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxMarketValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 20,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 3,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarketValue.setDefaultUnit(kony.flex.DP);
            var lblMarketValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblMarketValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP72727215Pxspending",
                "text": "Total Value",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValueMarketValue = new kony.ui.Label({
                "id": "lblValueMarketValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "IWLabelTitleAccountBalance",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMarketValue.add(lblMarketValue, lblValueMarketValue);
            var lblVerticalSepeartor = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "lblVerticalSepeartor",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxProfitLoss = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxProfitLoss",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "300dp",
                "zIndex": 3,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfitLoss.setDefaultUnit(kony.flex.DP);
            var flxUnrealisedPL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxUnrealisedPL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "300dp",
                "zIndex": 3,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnrealisedPL.setDefaultUnit(kony.flex.DP);
            var lbllUnrealisedPL = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lbllUnrealisedPL",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Pxspending",
                "text": "Unrealised P&L : ",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUnrealisedPLValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUnrealisedPLValue",
                "isVisible": true,
                "left": "120dp",
                "skin": "IWLabelGreenText15Px",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUnrealisedPL.add(lbllUnrealisedPL, lblUnrealisedPLValue);
            var flxTodayPL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTodayPL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "300dp",
                "zIndex": 3,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTodayPL.setDefaultUnit(kony.flex.DP);
            var lblTodayPL = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTodayPL",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Pxspending",
                "text": "Today's P&L:",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTodayPLValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTodayPLValue",
                "isVisible": true,
                "left": "120dp",
                "skin": "IWLabelGreenText15Px",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTodayPL.add(lblTodayPL, lblTodayPLValue);
            flxProfitLoss.add(flxUnrealisedPL, flxTodayPL);
            flxPortofolioValues.add(flxMarketValue, lblVerticalSepeartor, flxProfitLoss);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 1,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxPortofolioLineChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "350dp",
                "id": "flxPortofolioLineChart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "200dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPortofolioLineChart.setDefaultUnit(kony.flex.DP);
            var investmentLineChart = new com.InfinityOLB.HomepageMA.investmentLineChart({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "investmentLineChart",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "investmentLineChart",
                "overrides": {
                    "investmentLineChart": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var investmentLineChart_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["investmentLineChart"]) || {};
            investmentLineChart.currencySymbol = investmentLineChart_data.currencySymbol || "$";
            investmentLineChart.currentFilter = investmentLineChart_data.currentFilter || "1Y";
            investmentLineChart.date1 = investmentLineChart_data.date1 || "1M";
            investmentLineChart.date2 = investmentLineChart_data.date2 || "1Y";
            investmentLineChart.date3 = investmentLineChart_data.date3 || "5Y";
            investmentLineChart.date4 = investmentLineChart_data.date4 || "YTD";
            var flxLineChartInvestmentNoResults = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": true,
                "id": "flxLineChartInvestmentNoResults",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineChartInvestmentNoResults.setDefaultUnit(kony.flex.DP);
            var imgNoRes = new kony.ui.Image2({
                "id": "imgNoRes",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bbrequests.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoRes = new kony.ui.Label({
                "id": "lblNoRes",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl424242SSP15Px",
                "text": "No chart data available",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLineChartInvestmentNoResults.add(imgNoRes, lblNoRes);
            flxPortofolioLineChart.add(investmentLineChart, flxLineChartInvestmentNoResults);
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 1,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 20,
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var segInvestmentAccounts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{
                    "imgBankLogo": "",
                    "lblAccountBalance": "",
                    "lblAccountName": "",
                    "lblInvestmentLogo": "",
                    "lblJointAccountLogo": "",
                    "lblProfitBalance": ""
                }],
                "groupCells": false,
                "id": "segInvestmentAccounts",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "HomepageMA",
                    "friendlyName": "flxInvestmentRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountBadges": "flxAccountBadges",
                    "flxInvestmentAccounts": "flxInvestmentAccounts",
                    "flxInvestmentAccounts1": "flxInvestmentAccounts1",
                    "flxInvestmentRow": "flxInvestmentRow",
                    "flxLeft": "flxLeft",
                    "flxLogo": "flxLogo",
                    "flxRight": "flxRight",
                    "imgBankLogo": "imgBankLogo",
                    "lblAccountBalance": "lblAccountBalance",
                    "lblAccountName": "lblAccountName",
                    "lblInvestmentLogo": "lblInvestmentLogo",
                    "lblJointAccountLogo": "lblJointAccountLogo",
                    "lblProfitBalance": "lblProfitBalance"
                },
                "width": "95%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAccountsResult = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": true,
                "id": "flxNoAccountsResult",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsResult.setDefaultUnit(kony.flex.DP);
            var imgNoResults = new kony.ui.Image2({
                "id": "imgNoResults",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bbrequests.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoResults = new kony.ui.Label({
                "id": "lblNoResults",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl424242SSP15Px",
                "text": "No results to display",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsResult.add(imgNoResults, lblNoResults);
            var flxLoadingData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": true,
                "id": "flxLoadingData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingData.setDefaultUnit(kony.flex.DP);
            var imgLoadingData = new kony.ui.Image2({
                "id": "imgLoadingData",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bbrequests.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoadingData = new kony.ui.Label({
                "id": "lblLoadingData",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl424242SSP15Px",
                "text": "Loading data...",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingData.add(imgLoadingData, lblLoadingData);
            investmentSummary.add(flxTitle, flxSeparatorInvestment, flxPortofolioValues, flxSeparator2, flxPortofolioLineChart, flxSeparator3, segInvestmentAccounts, flxNoAccountsResult, flxLoadingData);
            flxInvestmentSummaryContainer.add(investmentSummaryCard, investmentSummary);
            var flxAccountsContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxAccountsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.setDefaultUnit(kony.flex.DP);
            var lblShowing = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblShowing",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Show\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxFilterGroup = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxFilterGroup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "top": "5dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterGroup.setDefaultUnit(kony.flex.DP);
            var flxFilterListBox = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFilterListBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterListBox.setDefaultUnit(kony.flex.DP);
            var lblSelectedFilter = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblSelectedFilter",
                "isVisible": true,
                "left": "3%",
                "right": "13%",
                "skin": "sknLblSSPSemiBold0e4a7f15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDropDown = new kony.ui.Button({
                "centerY": "50%",
                "height": "22dp",
                "id": "btnDropDown",
                "isVisible": false,
                "right": "4.30%",
                "skin": "sknBtnOLBFontIcons",
                "text": "O",
                "width": "22dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "22dp",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "slFbox",
                "width": "22dp",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var lblDropDown = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDropDown",
                "isVisible": true,
                "left": "5dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(lblDropDown);
            flxFilterListBox.add(lblSelectedFilter, btnDropDown, flxDropDown);
            var accountsFilter = new com.InfinityOLB.HomepageMA.accountsFilter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountsFilter",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "40dp",
                "width": "340dp",
                "zIndex": 10,
                "appName": "HomepageMA",
                "overrides": {
                    "accountsFilter": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "40dp",
                        "width": "340dp",
                        "zIndex": 10
                    },
                    "imgOr": {
                        "src": "or_circle.png"
                    },
                    "lblDefaultFiltersHeader": {
                        "isVisible": true,
                        "top": "20dp"
                    },
                    "segDefaultFilters": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFilterGroup.add(flxFilterListBox, accountsFilter);
            var flxAdvancedGroup = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAdvancedGroup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "15dp",
                "width": "40dp",
                "zIndex": 20,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvancedGroup.setDefaultUnit(kony.flex.DP);
            var btnAdvancedFiltersDropdown = new kony.ui.Button({
                "height": "30dp",
                "id": "btnAdvancedFiltersDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnOLBFontIconsBorder",
                "text": "t",
                "top": "0dp",
                "width": "30dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAdvancedFilters = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvancedFilters",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 20,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvancedFilters.setDefaultUnit(kony.flex.DP);
            var advancedFilters = new com.InfinityOLB.HomepageMA.advancedFilters({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "advancedFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "99%",
                "appName": "HomepageMA",
                "overrides": {
                    "advancedFilters": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "isVisible": true,
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "99%"
                    },
                    "btnApplyFilter": {
                        "width": "40%"
                    },
                    "btnCancelFilter": {
                        "centerX": "viz.val_cleared",
                        "left": "12%",
                        "width": "40%"
                    },
                    "btnReset": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.reset\")",
                        "top": "viz.val_cleared"
                    },
                    "flxAccountsRightContainer": {
                        "isVisible": true,
                        "width": "20%"
                    },
                    "flxAdvancedFiltersTitle": {
                        "left": "4%"
                    },
                    "flxByAccounts": {
                        "width": "46%"
                    },
                    "flxByBalance": {
                        "minHeight": "viz.val_cleared",
                        "width": "46%"
                    },
                    "flxCurrencyTitle": {
                        "left": "4%"
                    },
                    "flxDropDown": {
                        "width": "30%"
                    },
                    "flxDropdownCurrency": {
                        "width": "30%"
                    },
                    "flxDropdownImage": {
                        "width": "30%"
                    },
                    "flxGroupByAccountType": {
                        "left": "4%",
                        "width": "46%"
                    },
                    "flxGroupByCompany": {
                        "left": "viz.val_cleared",
                        "width": "46%"
                    },
                    "flxGroupByHeader": {
                        "left": "4%"
                    },
                    "flxGroupDropDown": {
                        "width": "30%"
                    },
                    "flxGroupRow": {
                        "width": "92%"
                    },
                    "flxRow1": {
                        "left": "4%",
                        "width": "92%"
                    },
                    "flxRow2": {
                        "left": "4%",
                        "width": "92%"
                    },
                    "flxSeperatorCurrency": {
                        "width": "94%"
                    },
                    "flxSortByHeader": {
                        "left": "4%"
                    },
                    "flxToaHeaderTitle": {
                        "left": "4%"
                    },
                    "lblAccountsHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.AdvancedFilters\")"
                    },
                    "lblGroupCompany": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unifiedBeneficiary.dataGridCustomerLayerLabel2\")"
                    },
                    "lblIconAccountType": {
                        "width": "20dp"
                    },
                    "lblIconBalance": {
                        "left": "10dp",
                        "width": "20dp"
                    },
                    "lblSortBy": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.sortBy\")"
                    },
                    "lblTypeOfAccounts": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.TypeOfAccounts\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAdvancedFilters.add(advancedFilters);
            var lblAdvancedFiltersNumber = new kony.ui.Label({
                "centerY": "15%",
                "height": "15dp",
                "id": "lblAdvancedFiltersNumber",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblFFFFFF9PxBg003E75Circle",
                "text": "2",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvancedGroup.add(btnAdvancedFiltersDropdown, flxAdvancedFilters, lblAdvancedFiltersNumber);
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknBorderE3E3E3",
                "top": "50dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "18px",
                "id": "btnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "16px",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            btnConfirm.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            btnConfirm.add(lblSearch);
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "30dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accounts.searchByKeywords\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [30, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "skncursor",
                "width": "15dp",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxClearBtn.setDefaultUnit(kony.flex.DP);
            var lblClearSearch = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "lblClearSearch",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearBtn.add(lblClearSearch);
            flxSearch.add(btnConfirm, txtSearch, flxClearBtn);
            flxAccountsHeader.add(lblShowing, flxFilterGroup, flxAdvancedGroup, flxSearch);
            var accountList = new com.InfinityOLB.HomepageMA.accountList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "accountList": {
                        "isVisible": true
                    },
                    "btnShowAllAccounts": {
                        "right": "18%"
                    },
                    "flxAccountsHeader": {
                        "isVisible": false
                    },
                    "flxAccountsHeaderWrapper": {
                        "left": "15dp"
                    },
                    "flxAccountsRightContainer": {
                        "right": "0%"
                    },
                    "flxAccountsSegments": {
                        "bottom": "viz.val_cleared",
                        "top": "1dp"
                    },
                    "flxDropDown": {
                        "right": "0dp"
                    },
                    "flxTitleSeparator": {
                        "isVisible": false
                    },
                    "imgHolisticAccountsHeader": {
                        "src": "accounts_blue.png"
                    },
                    "lblHolisticAccountsHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OTHERBANKACCOUNTS\")"
                    },
                    "lblImgDropdown": {
                        "centerX": "53%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountsContainer.add(flxAccountsHeader, accountList);
            var flxCustomerContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxCustomerContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerContainer.setDefaultUnit(kony.flex.DP);
            var flxCustomerCount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCustomerCount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerCount.setDefaultUnit(kony.flex.DP);
            var lblCustomers = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "lblCustomers",
                "isVisible": true,
                "left": "20px",
                "skin": "sknlbl424242SSP17pxSemibold",
                "text": "Customers (5)",
                "width": "97.50%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerCount.add(lblCustomers);
            var flxCustomerContainerHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "65dp",
                "id": "flxCustomerContainerHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerContainerHeader.setDefaultUnit(kony.flex.DP);
            var flxCustomerSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCustomerSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20px",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "10dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerSearch.setDefaultUnit(kony.flex.DP);
            var flxBtnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "18px",
                "id": "flxBtnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "16px",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtnConfirm.setDefaultUnit(kony.flex.DP);
            var lblCustomerSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCustomerSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtnConfirm.add(lblCustomerSearch);
            var txtCustomerSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none"
                    },
                    "a11yLabel": "Search by Customer ID/Customer Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "30dp",
                "id": "txtCustomerSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Customer ID/Customer Name",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [30, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxCustomerClearBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCustomerClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "skncursor",
                "width": "15dp",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxCustomerClearBtn.setDefaultUnit(kony.flex.DP);
            var lblCustomerClearSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Clear Search button",
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCustomerClearSearch",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerClearBtn.add(lblCustomerClearSearch);
            flxCustomerSearch.add(flxBtnConfirm, txtCustomerSearch, flxCustomerClearBtn);
            var flxFilter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "10dp",
                "width": "38%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilter.setDefaultUnit(kony.flex.DP);
            var lblView = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "label"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "lblView",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "View:",
                "width": "25%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CustomerListBox = new kony.ui.ListBox({
                "bottom": "0",
                "height": "41dp",
                "id": "CustomerListBox",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "All Customers"],
                    ["lb2", "Favourite Customers"]
                ],
                "right": "0dp",
                "skin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "top": "0",
                "width": "100%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var SegDropDown = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblSeparator": "",
                    "lblUsers": "All Customers"
                }, {
                    "lblSeparator": "",
                    "lblUsers": "Favourite Customers"
                }],
                "groupCells": false,
                "id": "SegDropDown",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "segBorderE3E3E3",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAccountTypes"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "39dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountTypes": "flxAccountTypes",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "zIndex": 15,
                "appName": "HomepageMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCustDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "22dp",
                "id": "flxCustDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "slFbox",
                "width": "22dp",
                "zIndex": 10,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustDropDown.setDefaultUnit(kony.flex.DP);
            var lblCustDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCustDropDown",
                "isVisible": true,
                "left": "5dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustDropDown.add(lblCustDropDown);
            var lblFilterText = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "lblFilterText",
                "isVisible": true,
                "skin": "bbSknLbl424242SSP15Px",
                "text": "All Customers",
                "top": "0",
                "width": "68%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilter.add(lblView, CustomerListBox, SegDropDown, flxCustDropDown, lblFilterText);
            flxCustomerContainerHeader.add(flxCustomerSearch, flxFilter);
            var flxCustomerHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxCustomerHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxCustomerHeaderSeparator.add();
            var flxAccountsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSegment.setDefaultUnit(kony.flex.DP);
            var SegCustomers = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "SegCustomers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegDefault",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsSegment.add(SegCustomers);
            var PaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "id": "PaginationContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "appName": "ResourcesMA",
                "overrides": {
                    "PaginationContainer": {
                        "bottom": "10dp"
                    },
                    "flxPaginationNext": {
                        "left": "-20px"
                    },
                    "flxPaginationPrevious": {
                        "right": "-20px"
                    },
                    "imgPaginationNext": {
                        "src": "pagination_next_active_container.png"
                    },
                    "imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomerContainer.add(flxCustomerCount, flxCustomerContainerHeader, flxCustomerHeaderSeparator, flxAccountsSegment, PaginationContainer);
            var flxMyCashPosition = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "425dp",
                "id": "flxMyCashPosition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "17dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyCashPosition.setDefaultUnit(kony.flex.DP);
            var flxMyChartHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxMyChartHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyChartHeader.setDefaultUnit(kony.flex.DP);
            var flxUserTypeIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "24dp",
                "id": "flxUserTypeIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "24dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblUserTypeIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblUserTypeIcon",
                "isVisible": true,
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "r",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserTypeIcon.add(lblUserTypeIcon);
            var lblMyChartHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "49%",
                "id": "lblMyChartHeader",
                "isVisible": true,
                "left": "48dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.businessCashPosition\")",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSelectYears = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblSelection",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectYears",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "30%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectYears.setDefaultUnit(kony.flex.DP);
            var lblOccurence = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblOccurence",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Monthly\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelection = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblSelection",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLbl003e75SSP15px",
                "text": "December, 2020",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxYearsDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxYearsDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYearsDropDown.setDefaultUnit(kony.flex.DP);
            var imgYearsDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgYearsDropDown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOLBFonts003e7520px",
                "text": "c",
                "width": "20dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxYearsDropDown.add(imgYearsDropDown);
            flxSelectYears.add(lblOccurence, lblSelection, flxYearsDropDown);
            var flxSelectAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "btnSelectAccounts",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccounts.setDefaultUnit(kony.flex.DP);
            var btnSelectAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "btnSelectAccounts",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl003e75SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountsDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "50%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxAccountsDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsDropDown.setDefaultUnit(kony.flex.DP);
            var imgAccountsDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "imgAccountsDropDown",
                "isVisible": true,
                "left": "0dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsDropDown.add(imgAccountsDropDown);
            flxSelectAccounts.add(btnSelectAccounts, flxAccountsDropDown);
            flxMyChartHeader.add(flxUserTypeIcon, lblMyChartHeader, flxSelectYears, flxSelectAccounts);
            var flxChartHeaderAndBodySeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxChartHeaderAndBodySeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChartHeaderAndBodySeparator.setDefaultUnit(kony.flex.DP);
            flxChartHeaderAndBodySeparator.add();
            var flxCalendar = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxCalendar",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCalendar.setDefaultUnit(kony.flex.DP);
            var calendarWidget = new com.InfinityOLB.HomepageMA.calendarWidget({
                "height": "300dp",
                "id": "calendarWidget",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "375dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBorderE3E3E3Radius4Px",
                "top": "47dp",
                "width": "240dp",
                "zIndex": 100,
                "appName": "HomepageMA",
                "overrides": {
                    "calendarWidget": {
                        "height": "300dp",
                        "isVisible": false,
                        "left": "375dp",
                        "top": "47dp",
                        "width": "240dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCalendar.add(calendarWidget);
            var flxDurationList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDurationList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "58%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "180px",
                "zIndex": 100,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDurationList.setDefaultUnit(kony.flex.DP);
            var durationListMenu = new com.InfinityOLB.HomepageMA.accountListMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "durationListMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "HomepageMA",
                "overrides": {
                    "accountListMenu": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 100
                    },
                    "flxAccountListActionsSegment": {
                        "top": "-5dp"
                    },
                    "imgToolTip": {
                        "right": "4%",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDurationList.add(durationListMenu);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "92dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var lblCashPositErrorMionessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCashPositErrorMionessage",
                "isVisible": true,
                "skin": "sknLblSSP42424215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(lblCashPositErrorMionessage);
            var flxSelectYearsMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "btnSelectYearsMobile",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectYearsMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectYearsMobile.setDefaultUnit(kony.flex.DP);
            var btnSelectYearsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "btnSelectYearsMobile",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl003e75SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.cashPosition.lastYear\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxYearsDropDownMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "50%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxYearsDropDownMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYearsDropDownMobile.setDefaultUnit(kony.flex.DP);
            var imgYearsDropDownMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "imgYearsDropDownMobile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxYearsDropDownMobile.add(imgYearsDropDownMobile);
            flxSelectYearsMobile.add(btnSelectYearsMobile, flxYearsDropDownMobile);
            var flxAccountList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4%",
                "skin": "slFbox",
                "top": "30px",
                "width": "180px",
                "zIndex": 100,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountList.setDefaultUnit(kony.flex.DP);
            var selectAccountList = new com.InfinityOLB.HomepageMA.selectAccountList({
                "height": "220dp",
                "id": "selectAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "HomepageMA",
                "overrides": {
                    "flxAccountListActionsSegment": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "maxHeight": "200dp"
                    },
                    "flxSelectAccount": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": true,
                        "zIndex": 1
                    },
                    "flxShowDataFor": {
                        "height": "35dp",
                        "maxHeight": "viz.val_cleared"
                    },
                    "segAccountListActions": {
                        "data": [{
                            "lblRadioButton": "L",
                            "lblUsers": "snpgiqngpegn"
                        }]
                    },
                    "selectAccountList": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "220dp",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountList.add(selectAccountList);
            var flxSelectYearsNewMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblSelectionMobile",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectYearsNewMobile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "30%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectYearsNewMobile.setDefaultUnit(kony.flex.DP);
            var lblOccurenceMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblOccurenceMobile",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Monthly\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectionMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "100%",
                "id": "lblSelectionMobile",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLbl003e75SSP15px",
                "text": "December, 2020",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxYearsDropDownNewMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxYearsDropDownNewMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYearsDropDownNewMobile.setDefaultUnit(kony.flex.DP);
            var imgYearsDropDownNewMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgYearsDropDownNewMobile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOLBFonts003e7520px",
                "text": "c",
                "width": "20dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxYearsDropDownNewMobile.add(imgYearsDropDownNewMobile);
            flxSelectYearsNewMobile.add(lblOccurenceMobile, lblSelectionMobile, flxYearsDropDownNewMobile);
            var flxSelectAccountsMobile = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectAccountsMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": true,
                "left": "50%",
                "isModalContainer": false,
                "right": "20%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccountsMobile.setDefaultUnit(kony.flex.DP);
            var flxSelectAccountsMobileDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "50%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxSelectAccountsMobileDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccountsMobileDropDown.setDefaultUnit(kony.flex.DP);
            var imgAccountsDropdownMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "imgAccountsDropdownMobile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectAccountsMobileDropDown.add(imgAccountsDropdownMobile);
            var btnSelectAccountsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "btnSelectAccountsMobile",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl003e75SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectAccountsMobile.add(flxSelectAccountsMobileDropDown, btnSelectAccountsMobile);
            var flxTotalDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxTotalDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "75dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDetails.setDefaultUnit(kony.flex.DP);
            var flxLegendCredits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblCreditsTitle",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxLegendCredits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxF8F8F8NoBorder",
                "top": "0dp",
                "width": "30%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendCredits.setDefaultUnit(kony.flex.DP);
            var lblCreditsTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditsTitle",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSPSB04A61513Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.Credit\")",
                "top": "12dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreditsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditsValue",
                "isVisible": true,
                "left": "5%",
                "skin": "sknSSP42424218Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.AllCredits\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegendCredits.add(lblCreditsTitle, lblCreditsValue);
            var flxLegendDebits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblDebitsTitle",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "focusSkin": "sknFlxF8F8F8BottomE5690BBorder",
                "height": "100%",
                "id": "flxLegendDebits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxF8F8F8NoBorder",
                "top": "0dp",
                "width": "30%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendDebits.setDefaultUnit(kony.flex.DP);
            var lblDebitsTitle = new kony.ui.Label({
                "id": "lblDebitsTitle",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSPSBE5690B13Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.Debit\")",
                "top": "12dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDebitsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDebitsValue",
                "isVisible": true,
                "left": "5%",
                "skin": "sknSSP42424218Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.AllCredits\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegendDebits.add(lblDebitsTitle, lblDebitsValue);
            var flxLegendBalance = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblTotalBalanceTitle",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxLegendBalance",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxF8F8F8NoBorder",
                "top": "0dp",
                "width": "30%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendBalance.setDefaultUnit(kony.flex.DP);
            var lblTotalBalanceTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalBalanceTitle",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSP003E7513Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.TotalBalance\")",
                "top": "12dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalBalanceValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalBalanceValue",
                "isVisible": true,
                "left": "5%",
                "skin": "sknSSP42424218Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.AllCredits\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegendBalance.add(lblTotalBalanceTitle, lblTotalBalanceValue);
            var flxToggleChartTable = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxToggleChartTable",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "630dp",
                "isModalContainer": false,
                "skin": "sknFocusBorder293275",
                "top": "80dp",
                "width": "100dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToggleChartTable.setDefaultUnit(kony.flex.DP);
            var flxChart = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxChart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skbflx293276",
                "top": "0dp",
                "width": "50dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChart.setDefaultUnit(kony.flex.DP);
            var lblChartIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblChartIcon",
                "isVisible": true,
                "skin": "sknLblFontType3Selected",
                "text": "K",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChart.add(lblChartIcon);
            var flxTable = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxTable",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50dp",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTable.setDefaultUnit(kony.flex.DP);
            var lblTableIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTableIcon",
                "isVisible": true,
                "skin": "sknLblFontType3Unselected",
                "text": "L",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTable.add(lblTableIcon);
            flxToggleChartTable.add(flxChart, flxTable);
            flxTotalDetails.add(flxLegendCredits, flxLegendDebits, flxLegendBalance, flxToggleChartTable);
            var flxChartContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxChartContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "145dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChartContainer.setDefaultUnit(kony.flex.DP);
            var flxMainChartCon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "1dp",
                "clipBounds": false,
                "id": "flxMainChartCon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainChartCon.setDefaultUnit(kony.flex.DP);
            var flxCashPostionChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCashPostionChart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashPostionChart.setDefaultUnit(kony.flex.DP);
            flxCashPostionChart.add();
            flxMainChartCon.add(flxCashPostionChart);
            var segCashFlow = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "240dp",
                "id": "segCashFlow",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLegends = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "32dp",
                "id": "flxLegends",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegends.setDefaultUnit(kony.flex.DP);
            var imgLegend1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgLegend1",
                "isVisible": true,
                "left": "55dp",
                "skin": "sknLblFontTypeIcon003E7520px",
                "text": "p",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLegend1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLegend1",
                "isVisible": true,
                "left": "10dp",
                "skin": "lblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.AllCredits\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLegend2 = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgLegend2",
                "isVisible": true,
                "left": "55dp",
                "skin": "sknLblOLBFontIcon8E8E8E20px",
                "text": "p",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLegend2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLegend2",
                "isVisible": true,
                "left": "10dp",
                "skin": "lblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.accountsLanding.AllDebits\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLegend3 = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgLegend3",
                "isVisible": true,
                "left": "55dp",
                "skin": "sknLblOLBFontIcon8F99AC20px",
                "text": "q",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLegend3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLegend3",
                "isVisible": true,
                "left": "10dp",
                "skin": "lblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.availableBalance\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegends.add(imgLegend1, lblLegend1, imgLegend2, lblLegend2, imgLegend3, lblLegend3);
            flxChartContainer.add(flxMainChartCon, segCashFlow, flxLegends);
            flxMyCashPosition.add(flxMyChartHeader, flxChartHeaderAndBodySeparator, flxCalendar, flxDurationList, flxErrorMessage, flxSelectYearsMobile, flxAccountList, flxSelectYearsNewMobile, flxSelectAccountsMobile, flxTotalDetails, flxChartContainer);
            var upcomingTransactionsCombined = new com.InfinityOLB.HomepageMA.upcomingTransactions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 15,
                "id": "upcomingTransactionsCombined",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "btnViewAll": {
                        "isVisible": false
                    },
                    "flxNoTransactionWrapper": {
                        "height": "200dp",
                        "isVisible": true
                    },
                    "flxUpcomingTransactionWrapper": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false
                    },
                    "imgInfo": {
                        "left": "30dp",
                        "src": "info_large.png",
                        "top": "30dp"
                    },
                    "lblHeader": {
                        "left": "3%"
                    },
                    "rtxNoPaymentMessage": {
                        "left": "70dp",
                        "top": "33dp"
                    },
                    "upcomingTransactions": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": 15,
                        "isVisible": false,
                        "left": "0dp",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AddExternalAccounts = new com.InfinityOLB.HomepageMA.AddExternalAccounts({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AddExternalAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "Acknowledgment.btnAccountSummary": {
                        "height": "50dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.AccountSummary\")",
                        "left": "68.12%"
                    },
                    "Acknowledgment.btnAddMoreAccounts": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.AddMoreAccounts\")",
                        "left": "37.07%"
                    },
                    "Acknowledgment.imgSuccess": {
                        "src": "success_green.png"
                    },
                    "Acknowledgment.lblCongratulations": {
                        "text": "Congratulations!"
                    },
                    "Acknowledgment.lblSelectedAccounts": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.SelectedAccounts\")"
                    },
                    "AddExternalAccounts": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "LoginUsingSelectedBank.btnTermsAndConditions": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")"
                    },
                    "LoginUsingSelectedBank.flxCheckbox": {
                        "height": "30dp"
                    },
                    "LoginUsingSelectedBank.flxEnterUsername": {
                        "width": "330dp"
                    },
                    "LoginUsingSelectedBank.flxLoginSelectAccountsMain": {
                        "isVisible": false
                    },
                    "LoginUsingSelectedBank.flxLoginUsingSelectedBankHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.LoginUsingSelectedBank\")"
                    },
                    "LoginUsingSelectedBank.flxLoginUsingSelectedBankMain": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true
                    },
                    "LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                        "text": "Welcome to Chase Bank"
                    },
                    "LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                        "left": "30dp",
                        "width": "101dp"
                    },
                    "LoginUsingSelectedBank.imgAddAccountsError": {
                        "src": "error_yellow.png"
                    },
                    "LoginUsingSelectedBank.imgBank": {
                        "src": "bank_icon_chase.png"
                    },
                    "LoginUsingSelectedBank.imgLoginUsingSelectedBankError": {
                        "src": "error_yellow.png"
                    },
                    "LoginUsingSelectedBank.imgValidUsername": {
                        "src": "success_icon.png"
                    },
                    "LoginUsingSelectedBank.imgflxLoginUsingSelectedBank": {
                        "src": "bank_icon_chase.png"
                    },
                    "LoginUsingSelectedBank.lblBankKey": {
                        "left": "0%"
                    },
                    "LoginUsingSelectedBank.lblCheckBox": {
                        "centerY": "50%",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "LoginUsingSelectedBank.lblPassword": {
                        "text": "E"
                    },
                    "LoginUsingSelectedBank.lblUsername": {
                        "text": "E"
                    },
                    "LoginUsingSelectedBank.lblUsernameKey": {
                        "isVisible": true
                    },
                    "LoginUsingSelectedBank.segSelectedAccounts": {
                        "isVisible": false
                    },
                    "SelectBankOrVendor.btnProceed": {
                        "height": "40dp"
                    },
                    "SelectBankOrVendor.btnReset": {
                        "height": "40dp"
                    },
                    "SelectBankOrVendor.flxBank3": {
                        "left": "30dp"
                    },
                    "SelectBankOrVendor.flxBankList": {
                        "isVisible": true
                    },
                    "SelectBankOrVendor.imgBank1": {
                        "src": "bank_icon_chase.png"
                    },
                    "SelectBankOrVendor.imgBank2": {
                        "src": "bank_icon_wf.png"
                    },
                    "SelectBankOrVendor.imgBank3": {
                        "src": "bank_icon_boa.png"
                    },
                    "SelectBankOrVendor.imgBank4": {
                        "src": "bank_icon_citi.png"
                    },
                    "SelectBankOrVendor.imgBank5": {
                        "src": "bank_icon_hdfc.png"
                    },
                    "SelectBankOrVendor.imgBank6": {
                        "src": "bank_img_rounded.png"
                    },
                    "SelectBankOrVendor.imgError": {
                        "src": "error_yellow.png"
                    },
                    "SelectBankOrVendor.lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.bankName\")"
                    },
                    "SelectBankOrVendor.lblUserInformation": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.SelectBankVendor\")",
                        "left": "30dp"
                    },
                    "SelectBankOrVendor.tbxName": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.EnterBankName\")"
                    },
                    "flxAcknowledgment": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxLoginUsingSelectedBank": {
                        "isVisible": true
                    },
                    "flxSelectBankOrVendor": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AddExternalAccounts.LoginUsingSelectedBank.tbxEnterpassword.onKeyUp = controller.AS_TextField_g549b9bdf0a4413baacb4ad5d387e2a3;
            AddExternalAccounts.LoginUsingSelectedBank.tbxNewUsername.onKeyUp = controller.AS_TextField_d17503683a5b4245ab638d74249819d8;
            AddExternalAccounts.SelectBankOrVendor.tbxName.onKeyUp = controller.AS_TextField_g0658ad38fdb4668abebb3332301c07d;
            flxLeftContainer.add(flxTotalAssetsContainer, flxInvestmentSummaryContainer, flxAccountsContainer, flxCustomerContainer, flxMyCashPosition, upcomingTransactionsCombined, AddExternalAccounts);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "60dp",
                "width": "28.60%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var quickLinksNew = new com.InfinityOLB.Resources.quickLinksNew({
                "height": "100%",
                "id": "quickLinksNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "quickLinksNew",
                "overrides": {
                    "quickLinksNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var quickLinksNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["ResourcesMA"]["frmCustomerDashboard"]["quickLinksNew"]) || {};
            quickLinksNew.showMore = quickLinksNew_data.showMore || false;
            quickLinksNew.numberOfLinks = quickLinksNew_data.numberOfLinks || 3;
            var flxnewsAndWatch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxnewsAndWatch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxnewsAndWatch.setDefaultUnit(kony.flex.DP);
            var flxMarketNewsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxMarketNewsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarketNewsContainer.setDefaultUnit(kony.flex.DP);
            var marketIndexDashComp = new com.InfinityOLB.HomepageMA.marketIndexDashComp({
                "height": "150dp",
                "id": "marketIndexDashComp",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "marketIndexDashComp",
                "overrides": {
                    "marketIndexDashComp": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var marketIndexDashComp_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["marketIndexDashComp"]) || {};
            marketIndexDashComp.objService = marketIndexDashComp_data.objService || "PortfolioServicing";
            marketIndexDashComp.objName = marketIndexDashComp_data.objName || "MarketData";
            marketIndexDashComp.operation = marketIndexDashComp_data.operation || "getDailyMarket";
            marketIndexDashComp.viewAllBtnStatus = marketIndexDashComp_data.viewAllBtnStatus || "visible";
            var marketNewsCardComp = new com.InfinityOLB.HomepageMA.marketNewsCardComp({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "marketNewsCardComp",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "marketNewsCardComp",
                "overrides": {
                    "marketNewsCardComp": {
                        "right": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var marketNewsCardComp_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["marketNewsCardComp"]) || {};
            marketNewsCardComp.objService = marketNewsCardComp_data.objService || "PortfolioServicing";
            marketNewsCardComp.objName = marketNewsCardComp_data.objName || "MarketData";
            marketNewsCardComp.operation = marketNewsCardComp_data.operation || "getTopMarketNews";
            marketNewsCardComp.viewAllBtnStatus = marketNewsCardComp_data.viewAllBtnStatus || "hidden";
            marketNewsCardComp.headerLabel = marketNewsCardComp_data.headerLabel || "i18n.Wealth.topNews";
            marketNewsCardComp.skinHeading = marketNewsCardComp_data.skinHeading || "sknFlxf4f5f8ffradius2px";
            flxMarketNewsContainer.add(marketIndexDashComp, marketNewsCardComp);
            var flxWatchlistContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxWatchlistContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchlistContainer.setDefaultUnit(kony.flex.DP);
            var WatchlistDashCard = new com.InfinityOLB.HomepageMA.WatchlistDashCard({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "WatchlistDashCard",
                "isVisible": true,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "WatchlistDashCard",
                "overrides": {
                    "WatchlistDashCard": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var WatchlistDashCard_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["WatchlistDashCard"]) || {};
            WatchlistDashCard.objService = WatchlistDashCard_data.objService || "WealthOrder";
            WatchlistDashCard.objName = WatchlistDashCard_data.objName || "FavouriteInstruments";
            WatchlistDashCard.operation = WatchlistDashCard_data.operation || "getFavoriteInstruments";
            flxWatchlistContainer.add(WatchlistDashCard);
            flxnewsAndWatch.add(flxMarketNewsContainer, flxWatchlistContainer);
            var flxRecentActivityAndMarketing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRecentActivityAndMarketing",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentActivityAndMarketing.setDefaultUnit(kony.flex.DP);
            var flxRecentActivity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRecentActivity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentActivity.setDefaultUnit(kony.flex.DP);
            var recentActivityComp = new com.InfinityOLB.HomepageMA.recentActivityComp({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "recentActivityComp",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA",
                "viewType": "recentActivityComp",
                "overrides": {
                    "recentActivityComp": {
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var recentActivityComp_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["recentActivityComp"]) || {};
            recentActivityComp.objService = recentActivityComp_data.objService || "PortfolioServicing";
            recentActivityComp.objName = recentActivityComp_data.objName || "Dashboard";
            recentActivityComp.operation = recentActivityComp_data.operation || "getRecentActivity";
            flxRecentActivity.add(recentActivityComp);
            var flxBannerContainerDesktop = new kony.ui.FlexContainer({
                "bottom": "15dp",
                "clipBounds": false,
                "height": "175dp",
                "id": "flxBannerContainerDesktop",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBannerContainerDesktop.setDefaultUnit(kony.flex.DP);
            var imgBannerDesktop = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": " "
                },
                "bottom": "10dp",
                "id": "imgBannerDesktop",
                "isVisible": true,
                "left": "10dp",
                "right": "10dp",
                "skin": "slImage",
                "src": "nuo_banner_1.png",
                "top": "10dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBannerContainerDesktop.add(imgBannerDesktop);
            flxRecentActivityAndMarketing.add(flxRecentActivity, flxBannerContainerDesktop);
            var flxActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxActions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f76b9a4d883543d9adfa649b1a1e3121,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var btnUpdateAccntPreferences = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Update Account Preferences"
                },
                "height": "50dp",
                "id": "btnUpdateAccntPreferences",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtn0273e3SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.UpdateAccountPreferences\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Update Account Preferences"
            });
            flxActions.add(btnUpdateAccntPreferences);
            var flxApprovalAndRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalAndRequest",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalAndRequest.setDefaultUnit(kony.flex.DP);
            var flxMyApprovals = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxMyApprovals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyApprovals.setDefaultUnit(kony.flex.DP);
            var myApprovals = new com.InfinityOLB.HomepageMA.myApprovals({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "myApprovals",
                "isVisible": true,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "myApprovals",
                "overrides": {
                    "myApprovals": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var myApprovals_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["myApprovals"]) || {};
            flxMyApprovals.add(myApprovals);
            var flxMyRequests = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxMyRequests",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyRequests.setDefaultUnit(kony.flex.DP);
            var myRequests = new com.InfinityOLB.HomepageMA.myApprovals({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "myRequests",
                "isVisible": true,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "HomepageMA",
                "viewType": "myRequests",
                "overrides": {
                    "myApprovals": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var myRequests_data = (appConfig.componentMetadata && appConfig.componentMetadata["HomepageMA"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"] && appConfig.componentMetadata["HomepageMA"]["frmCustomerDashboard"]["myRequests"]) || {};
            flxMyRequests.add(myRequests);
            flxApprovalAndRequest.add(flxMyApprovals, flxMyRequests);
            var mySpending = new com.InfinityOLB.HomepageMA.mySpending({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "id": "mySpending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0px",
                "width": "100%",
                "appName": "HomepageMA",
                "overrides": {
                    "flxHeader": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxMySpending": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": 0,
                        "minHeight": "106dp"
                    },
                    "flxMySpendingWrapper": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "left": "0dp",
                        "minHeight": "168dp",
                        "top": "0dp"
                    },
                    "flxMySpendingWrapperdataUnavailable": {
                        "height": "168dp",
                        "isVisible": true,
                        "minHeight": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxNoTransactionsMySpending": {
                        "height": "140dp",
                        "left": "10dp",
                        "top": "12dp",
                        "width": "80%"
                    },
                    "flxServiceError": {
                        "isVisible": false
                    },
                    "imgInfoIconWarning": {
                        "src": "error_yellow.png"
                    },
                    "imgInfoMySpending": {
                        "left": "5%",
                        "src": "info_large.png",
                        "top": "5dp"
                    },
                    "imgInfoMySpendingNoDat": {
                        "isVisible": false,
                        "left": "53dp",
                        "src": "grey_donut.png",
                        "top": "21dp"
                    },
                    "imgMySpendingIcon": {
                        "height": "30px",
                        "isVisible": false,
                        "left": "3.59%",
                        "width": "30px"
                    },
                    "lblDataNotAvailable": {
                        "centerX": "50%",
                        "isVisible": false,
                        "left": "115dp",
                        "top": "235dp",
                        "width": "100dp"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.MySpending\")",
                        "left": "50dp",
                        "width": "50%"
                    },
                    "lblImgMySpending": {
                        "isVisible": false,
                        "left": "53dp"
                    },
                    "lblMySpending": {
                        "left": "17%",
                        "top": "10dp",
                        "width": "75%"
                    },
                    "lblOverallSpendingMySpending": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Spending\")"
                    },
                    "lblServiceErrorWarning": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.UnableToFetchData\")"
                    },
                    "lblimgRound": {
                        "isVisible": false
                    },
                    "mySpending": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "15dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "top": "0px",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightContainer.add(quickLinksNew, flxnewsAndWatch, flxRecentActivityAndMarketing, flxActions, flxApprovalAndRequest, mySpending);
            flxAccountListAndBanner.add(flxLeftContainer, flxRightContainer);
            var flxBannerContainerMobile = new kony.ui.FlexContainer({
                "bottom": 10,
                "clipBounds": true,
                "height": "420dp",
                "id": "flxBannerContainerMobile",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "383dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "15dp",
                "width": "45.50%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBannerContainerMobile.setDefaultUnit(kony.flex.DP);
            var imgBannerMobile = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": " "
                },
                "bottom": "10dp",
                "id": "imgBannerMobile",
                "isVisible": true,
                "left": "10dp",
                "right": "10dp",
                "skin": "slImage",
                "src": "banner_ad_mobile.png",
                "top": "10dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBannerContainerMobile.add(imgBannerMobile);
            flxMainWrapper.add(flxPriorityMessage, flxDowntimeWarning, flxDeviceRegistrationWarning, flxUpgradeDashboardDisclaimer, flxPasswordResetWarning, flxOverdraftWarning, flxOutageWarning, flxWelcomeAndActions, flxAccountListAndBanner, flxBannerContainerMobile);
            var accountListMenu = new com.InfinityOLB.HomepageMA.accountListMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountListMenu",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "590dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "160dp",
                "width": "250dp",
                "zIndex": 10,
                "appName": "HomepageMA",
                "overrides": {
                    "accountListMenu": {
                        "isVisible": false,
                        "left": "590dp",
                        "top": "160dp",
                        "width": "250dp",
                        "zIndex": 10
                    },
                    "imgToolTip": {
                        "right": "7%",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxskncontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            flxMain.add(lblDashboardHeading, flxMainWrapper, accountListMenu, flxskncontainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "viz.val_cleared",
                        "width": "100%",
                        "zIndex": 1
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "text": "Sign Out"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to Signout?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditionsPopUp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTermsAndConditionsPopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsPopUp.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "650dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Terms & Conditions",
                    "tagName": "span"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "CopyslFbox0e7e706a6ed2544",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>"
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0a7b5b9eb258749 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0a7b5b9eb258749",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "CopyslFbox0e7e706a6ed2544",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0a7b5b9eb258749.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0a7b5b9eb258749.add();
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0a7b5b9eb258749, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditionsPopUp.add(flxTC);
            var flxLargeAccLoadPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLargeAccLoadPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": true,
                "skin": "sknflx000000op50",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLargeAccLoadPopup.setDefaultUnit(kony.flex.DP);
            var flxLoadPopup = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "268dp",
                "id": "flxLoadPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "500dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadPopup.setDefaultUnit(kony.flex.DP);
            var flxLoad = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "20%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxLoad",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0",
                "width": "70dp",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxLoad.setDefaultUnit(kony.flex.DP);
            var imgLoad = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "70dp",
                "id": "imgLoad",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer",
                "src": "loader.png",
                "width": "70dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxLoad.add(imgLoad);
            var lblLargeAcconts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Terms & Conditions",
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "lblLargeAcconts",
                "isVisible": true,
                "skin": "sknLblSSP42424215px",
                "text": "As you have access to large number of Accounts and Customer Ids, we need few more seconds to load your data.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButton = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "80dp",
                "horizontalScrollIndicator": true,
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "HomepageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var btnOK = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnOK",
                "isVisible": true,
                "right": "7.50%",
                "skin": "slButtonGlossBlue",
                "text": "OK",
                "top": "0",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Create"
            });
            flxButton.add(flxSeparator, btnOK);
            flxLoadPopup.add(flxLoad, lblLargeAcconts, flxButton);
            flxLargeAccLoadPopup.add(flxLoadPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxCombinedAccessMenuMobile": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxCombinedMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblDropboxMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "customheader.topmenu.segCombinedAccessMenuMobile": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeperatorheader": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDashboardHeading": {
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxPriorityMessage": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.flxMsgContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.imgCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblImgMessage": {
                        "centerY": {
                            "type": "number",
                            "value": "30"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblPriorityMessageCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblViewMessages": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag": {
                        "segmentProps": [],
                        "instanceId": "priorityMessageTag"
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxDeviceRegistrationWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "DeviceRegisrationWarning": {
                        "segmentProps": []
                    },
                    "lblDeviceRegistrationWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgDeviceRegistrationClose": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgDeviceRegistrationClose": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxUpgradeDashboardDisclaimer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgUpgradeDisclaimer": {
                        "segmentProps": []
                    },
                    "lblUpgradeDisclaimer": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgUpgradeDisclaimerClose": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblUpgradeDisclaimerClose": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPasswordResetWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblPasswordResetWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgClosePasswordResetWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "ingPasswordResetWarning": {
                        "segmentProps": []
                    },
                    "lblImgClosePasswordResetWarning": {
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgOverDraft": {
                        "segmentProps": []
                    },
                    "lblOverdraftWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgCloseWarning": {
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoIconWarning": {
                        "segmentProps": []
                    },
                    "lblOutageWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseOutageWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgCloseOutageWarning": {
                        "segmentProps": []
                    },
                    "flxWelcomeAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountListAndBanner": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTotalAssetsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "totalAssetsCard": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxInvestmentSummaryContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "investmentSummaryCard": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAccountsContainer": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblShowing": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterGroup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "sknBorderE3E3E3",
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "17.50%"
                        },
                        "padding": [1, 0, 0, 0],
                        "skin": "sknLabelSSP42424217px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnDropDown": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "accountsFilter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "accountsFilter"
                    },
                    "accountsFilter.lblDefaultFiltersHeader": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdvancedGroup": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnAdvancedFiltersDropdown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdvancedFilters": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "92.50%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.btnApplyFilter": {
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.btnCancelFilter": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.flxByAccounts": {
                        "segmentProps": []
                    },
                    "advancedFilters.flxByBalance": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.flxGroupByAccountType": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.flxGroupByCompany": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.flxGroupRow": {
                        "segmentProps": []
                    },
                    "advancedFilters.flxRow1": {
                        "segmentProps": []
                    },
                    "advancedFilters.flxRow2": {
                        "segmentProps": []
                    },
                    "advancedFilters.flxSeperatorCurrency": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "advancedFilters.lblIconAccountType": {
                        "segmentProps": []
                    },
                    "advancedFilters.lblIconBalance": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdvancedFiltersNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "-89dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "placeholderSkin": "bbSknTbx949494SSP15pxItalic",
                        "segmentProps": []
                    },
                    "flxClearBtn": {
                        "segmentProps": []
                    },
                    "accountList.btnShowAllAccounts": {
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "accountList.flxDropDown": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerContainer": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerCount": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxCustomerContainerHeader": {
                        "segmentProps": []
                    },
                    "flxCustomerSearch": {
                        "segmentProps": []
                    },
                    "flxBtnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "txtCustomerSearch": {
                        "placeholderSkin": "bbSknTbx949494SSP15pxItalic",
                        "segmentProps": []
                    },
                    "flxCustomerClearBtn": {
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "segmentProps": []
                    },
                    "flxAccountsSegment": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxMyCashPosition": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxMyChartHeader": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserTypeIcon": {
                        "segmentProps": []
                    },
                    "lblUserTypeIcon": {
                        "segmentProps": []
                    },
                    "lblMyChartHeader": {
                        "segmentProps": []
                    },
                    "flxSelectYears": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxYearsDropDown": {
                        "segmentProps": []
                    },
                    "flxSelectAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChartHeaderAndBodySeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCalendar": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "calendarWidget": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDurationList": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "durationListMenu": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "93dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYearsMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnSelectYearsMobile": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxYearsDropDownMobile": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgYearsDropDownMobile": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYearsNewMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblOccurenceMobile": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxYearsDropDownNewMobile": {
                        "segmentProps": []
                    },
                    "flxSelectAccountsMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccountsMobileDropDown": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgAccountsDropdownMobile": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnSelectAccountsMobile": {
                        "left": {
                            "type": "string",
                            "value": "118dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegendCredits": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCreditsTitle": {
                        "segmentProps": []
                    },
                    "lblCreditsValue": {
                        "segmentProps": []
                    },
                    "flxLegendDebits": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblDebitsTitle": {
                        "segmentProps": []
                    },
                    "lblDebitsValue": {
                        "segmentProps": []
                    },
                    "flxLegendBalance": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBalanceTitle": {
                        "segmentProps": []
                    },
                    "lblTotalBalanceValue": {
                        "segmentProps": []
                    },
                    "flxToggleChartTable": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxChartContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainChartCon": {
                        "bottom": {
                            "type": "number",
                            "value": "1"
                        },
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegends": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgLegend1": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "lblLegend1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgLegend2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblLegend2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgLegend3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblLegend3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "instanceId": "upcomingTransactionsCombined"
                    },
                    "AddExternalAccounts.Acknowledgment.btnAccountSummary": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.Acknowledgment.btnAddMoreAccounts": {
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.Acknowledgment.flxAcknowledgementButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxAddAccountsError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxBankCredentials": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxBankImage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxEnterPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxEnterUsername": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginSelectAccountsMain": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankContainer": {
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankError": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMain": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "text": "Welcome to Chase Bank ",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessageBox": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.imgflxLoginUsingSelectedBank": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblAddAccountsError": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblBankKey": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblBankValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblPassword": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "Enter Password",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblUsername": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "Enter Username",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblUsernameKey": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.lblUsernameValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnReset": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank1": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank2": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank3": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank4": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank5": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxBank6": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxError": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxName": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxPopularBanks": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxSelectBankOrVendorButtons": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.lblError": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.lblPopularBanks": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.lblUserInformation": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxAcknowledgment": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxLoginUsingSelectedBank": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxSelectBankOrVendor": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.lblHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMarketNewsContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxWatchlistContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRecentActivity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnUpdateAccntPreferences": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalAndRequest": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapper": {
                        "segmentProps": []
                    },
                    "mySpending.flxNoTransactionsMySpending": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.flxSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpending": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpendingNoDat": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgMySpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblDataNotAvailable": {
                        "centerX": {
                            "type": "string",
                            "value": "60%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblHeader": {
                        "i18n_text": "i18n.accounts.MySpendingLastMonth",
                        "segmentProps": []
                    },
                    "mySpending.lblImgMySpending": {
                        "left": {
                            "type": "string",
                            "value": "53dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblMySpending": {
                        "segmentProps": []
                    },
                    "mySpending.lblOverallSpendingAmount": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblOverallSpendingMySpending": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "mySpending": {
                        "height": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxBannerContainerMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "imgBannerMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "banner_ad_mobile.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "2000dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew.btnLocateUs": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "55%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "height": {
                            "type": "string",
                            "value": "62dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "segmentProps": []
                    },
                    "flxBody": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxLargeAccLoadPopup": {
                        "segmentProps": []
                    },
                    "flxLoadPopup": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnOK": {
                        "focusSkin": "sknBtnSSPffffff15pxBg0273e3",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "skin": "sknBtnSSPffffff15pxBg0273e3",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "frmCustomerDashboard": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblDashboardHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxPriorityMessage": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.flxMsgContent": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "priorityMessageTag.imgCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblImgMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblPriorityMessageCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblViewMessages": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeviceRegistrationWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDeviceRegistrationClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxUpgradeDashboardDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgUpgradeDisclaimerClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxPasswordResetWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgClosePasswordResetWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgClosePasswordResetWarning": {
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblOutageWarning": {
                        "segmentProps": []
                    },
                    "imgCloseOutageWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountListAndBanner": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAssetsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvestmentSummaryContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segInvestmentAccounts": {
                        "segmentProps": []
                    },
                    "flxAccountsContainer": {
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "segmentProps": []
                    },
                    "lblShowing": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterGroup": {
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "accountsFilter": {
                        "segmentProps": [],
                        "instanceId": "accountsFilter"
                    },
                    "accountsFilter.segDefaultFilters": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAdvancedGroup": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "btnAdvancedFiltersDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvancedFilters": {
                        "width": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdvancedFiltersNumber": {
                        "zIndex": 25,
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "segmentProps": []
                    },
                    "accountList.btnShowAllAccounts": {
                        "segmentProps": []
                    },
                    "accountList.flxAccountsRightContainer": {
                        "segmentProps": []
                    },
                    "accountList.flxDropDown": {
                        "segmentProps": []
                    },
                    "flxCustomerContainer": {
                        "segmentProps": []
                    },
                    "flxCustomerCount": {
                        "segmentProps": []
                    },
                    "flxCustomerContainerHeader": {
                        "segmentProps": []
                    },
                    "flxCustomerSearch": {
                        "segmentProps": []
                    },
                    "txtCustomerSearch": {
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "segmentProps": []
                    },
                    "flxAccountsSegment": {
                        "segmentProps": []
                    },
                    "flxMyCashPosition": {
                        "segmentProps": []
                    },
                    "flxSelectYears": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccounts": {
                        "right": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "segmentProps": []
                    },
                    "flxCalendar": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "375dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "calendarWidget": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "durationListMenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "durationListMenu.flxIdentifier": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSelectYearsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSelectYearsNewMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSelectAccountsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTotalDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLegendCredits": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "flxLegendDebits": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "27%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "flxLegendBalance": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "flxToggleChartTable": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainChartCon": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined": {
                        "segmentProps": [],
                        "instanceId": "upcomingTransactionsCombined"
                    },
                    "AddExternalAccounts": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.btnCancel": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankHeading": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.lblHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxnewsAndWatch": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMarketNewsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "segmentProps": []
                    },
                    "marketNewsCardComp": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxWatchlistContainer": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxRecentActivityAndMarketing": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecentActivity": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.50%"
                        },
                        "segmentProps": []
                    },
                    "recentActivityComp": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "48.50%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapper": {
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapperdataUnavailable": {
                        "segmentProps": []
                    },
                    "mySpending.flxNoTransactionsMySpending": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.flxSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpending": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpendingNoDat": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblDataNotAvailable": {
                        "centerX": {
                            "type": "string",
                            "value": "60%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblHeader": {
                        "i18n_text": "i18n.accounts.MySpendingLastMonth",
                        "segmentProps": []
                    },
                    "mySpending.lblImgMySpending": {
                        "segmentProps": []
                    },
                    "mySpending.lblMySpending": {
                        "segmentProps": []
                    },
                    "mySpending": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "413dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgBannerMobile": {
                        "src": "banner_ad_tab.png",
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "accountListMenu.flxIdentifier": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "2.55%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "centerX": {
                            "type": "number",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.55%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    },
                    "flxLargeAccLoadPopup": {
                        "segmentProps": []
                    },
                    "flxLoadPopup": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnOK": {
                        "focusSkin": "sknBtnSSPffffff15pxBg0273e3",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSSPffffff15pxBg0273e3",
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDashboardHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "89%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxPriorityMessage": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.flxMsgContent": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "priorityMessageTag.imgCross": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblImgMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblPriorityMessageCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblViewMessages": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag": {
                        "segmentProps": [],
                        "instanceId": "priorityMessageTag"
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxDeviceRegistrationWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblDeviceRegistrationWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgDeviceRegistrationClose": {
                        "segmentProps": []
                    },
                    "flxUpgradeDashboardDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblUpgradeDisclaimer": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblUpgradeDisclaimerClose": {
                        "segmentProps": []
                    },
                    "flxPasswordResetWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.80%"
                        },
                        "segmentProps": []
                    },
                    "lblPasswordResetWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgClosePasswordResetWarning": {
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblOverdraftWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgCloseWarning": {
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblOutageWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgCloseOutageWarning": {
                        "segmentProps": []
                    },
                    "flxWelcomeAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "welcome": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountListAndBanner": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAssetsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvestmentSummaryContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segInvestmentAccounts": {
                        "segmentProps": []
                    },
                    "flxNoAccountsResult": {
                        "segmentProps": []
                    },
                    "imgNoResults": {
                        "segmentProps": []
                    },
                    "lblNoResults": {
                        "segmentProps": []
                    },
                    "flxLoadingData": {
                        "segmentProps": []
                    },
                    "imgLoadingData": {
                        "segmentProps": []
                    },
                    "lblLoadingData": {
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "segmentProps": []
                    },
                    "lblShowing": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterGroup": {
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "accountsFilter": {
                        "segmentProps": [],
                        "instanceId": "accountsFilter"
                    },
                    "flxAdvancedGroup": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAdvancedFiltersDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvancedFilters": {
                        "segmentProps": []
                    },
                    "lblAdvancedFiltersNumber": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "9%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "segmentProps": []
                    },
                    "accountList.btnShowAllAccounts": {
                        "segmentProps": []
                    },
                    "accountList.flxAccountsRightContainer": {
                        "segmentProps": []
                    },
                    "accountList.flxDropDown": {
                        "segmentProps": []
                    },
                    "flxCustomerCount": {
                        "segmentProps": []
                    },
                    "flxCustomerContainerHeader": {
                        "segmentProps": []
                    },
                    "flxCustomerSearch": {
                        "segmentProps": []
                    },
                    "txtCustomerSearch": {
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "segmentProps": []
                    },
                    "lblFilterText": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsSegment": {
                        "segmentProps": []
                    },
                    "SegCustomers": {
                        "data": [{
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }, {
                            "CopyimgMenu0a97e7ab1e83140": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "CopyimgThreeDotIcon0eac906fccd3d43": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "btn": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "."
                            },
                            "imgBankName": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bank_icon_boa.png"
                            },
                            "imgCustomerStar": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "k"
                            },
                            "imgFavourite": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "filled_star.png"
                            },
                            "imgIdentifier": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "accounts_sidebar_purple.png"
                            },
                            "imgMenu": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "contextual_menu.png"
                            },
                            "imgStarIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "F"
                            },
                            "imgThreeDotIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "O"
                            },
                            "imgWarning": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "aa_password_error.png"
                            },
                            "lblAccountName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAccountNumberValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblAvailableBalanceTitle": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02 Accounts"
                            },
                            "lblAvailableBalanceValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "02"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "HomepageMA",
                            "friendlyName": "flxCustomerListItem"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "CopyimgMenu0a97e7ab1e83140": "CopyimgMenu0a97e7ab1e83140",
                            "CopyimgThreeDotIcon0eac906fccd3d43": "CopyimgThreeDotIcon0eac906fccd3d43",
                            "btn": "btn",
                            "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                            "flxAccountName": "flxAccountName",
                            "flxAccountNameWrapper": "flxAccountNameWrapper",
                            "flxAccountNumber": "flxAccountNumber",
                            "flxAvailableBalance": "flxAvailableBalance",
                            "flxAvailableBalanceWrapper": "flxAvailableBalanceWrapper",
                            "flxAvailableBalances": "flxAvailableBalances",
                            "flxBankName": "flxBankName",
                            "flxContent": "flxContent",
                            "flxCustomerListItem": "flxCustomerListItem",
                            "flxFavourite": "flxFavourite",
                            "flxIdentifier": "flxIdentifier",
                            "flxMenu": "flxMenu",
                            "flxSeparator": "flxSeparator",
                            "flxWrapper": "flxWrapper",
                            "imgBankName": "imgBankName",
                            "imgCustomerStar": "imgCustomerStar",
                            "imgFavourite": "imgFavourite",
                            "imgIdentifier": "imgIdentifier",
                            "imgMenu": "imgMenu",
                            "imgStarIcon": "imgStarIcon",
                            "imgThreeDotIcon": "imgThreeDotIcon",
                            "imgWarning": "imgWarning",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNumber": "lblAccountNumber",
                            "lblAccountNumberValue": "lblAccountNumberValue",
                            "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                            "lblAvailableBalanceValue": "lblAvailableBalanceValue"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "HomepageMA"
                    },
                    "flxMyCashPosition": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYears": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxCalendar": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "calendarWidget": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYearsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "maxHeight": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "240px"
                        },
                        "segmentProps": []
                    },
                    "selectAccountList.flxAccountListActionsSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "selectAccountList.flxSelectAccount": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "selectAccountList.flxShowDataFor": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "selectAccountList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYearsNewMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSelectAccountsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTotalDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLegendCredits": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblCreditsTitle": {
                        "segmentProps": []
                    },
                    "lblCreditsValue": {
                        "segmentProps": []
                    },
                    "flxLegendDebits": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblDebitsTitle": {
                        "segmentProps": []
                    },
                    "lblDebitsValue": {
                        "segmentProps": []
                    },
                    "flxLegendBalance": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBalanceTitle": {
                        "segmentProps": []
                    },
                    "lblTotalBalanceValue": {
                        "segmentProps": []
                    },
                    "flxToggleChartTable": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxChart": {
                        "segmentProps": []
                    },
                    "lblChartIcon": {
                        "segmentProps": []
                    },
                    "flxTable": {
                        "segmentProps": []
                    },
                    "lblTableIcon": {
                        "segmentProps": []
                    },
                    "flxMainChartCon": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "segCashFlow": {
                        "data": [
                            [{
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }]
                            ],
                            [{
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }, {
                                    "lblCredit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDebit": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblDuration": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblTotal": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                }]
                            ]
                        ],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "HomepageMA",
                            "friendlyName": "flxCashFlowTable"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "HomepageMA",
                            "friendlyName": "flxCashFlowSectionHeader"
                        }),
                        "widgetDataMap": {
                            "flxCashFlowSectionHeader": "flxCashFlowSectionHeader",
                            "flxCashFlowTable": "flxCashFlowTable",
                            "flxCol1": "flxCol1",
                            "flxCol2": "flxCol2",
                            "flxCol3": "flxCol3",
                            "flxCol4": "flxCol4",
                            "flxImg1": "flxImg1",
                            "flxImg2": "flxImg2",
                            "flxImg3": "flxImg3",
                            "flxImg4": "flxImg4",
                            "flxRow": "flxRow",
                            "img1": "img1",
                            "img2": "img2",
                            "img3": "img3",
                            "img4": "img4",
                            "lblCredit": "lblCredit",
                            "lblDebit": "lblDebit",
                            "lblDuration": "lblDuration",
                            "lblSeperator": "lblSeperator",
                            "lblTotal": "lblTotal"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "HomepageMA"
                    },
                    "lblLegend1": {
                        "segmentProps": []
                    },
                    "lblLegend2": {
                        "segmentProps": []
                    },
                    "lblLegend3": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnProceed": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnReset": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.lblHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMarketNewsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxWatchlistContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecentActivity": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "recentActivityComp": {
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxffffffShadowdddcdcPointer",
                        "segmentProps": []
                    },
                    "imgBannerDesktop": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnUpdateAccntPreferences": {
                        "skin": "sknBtn0273e3SSP15px",
                        "segmentProps": []
                    },
                    "mySpending.flxHeader": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapper": {
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapperdataUnavailable": {
                        "segmentProps": []
                    },
                    "mySpending.flxNoTransactionsMySpending": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpending": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpendingNoDat": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgMySpendingIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblDataNotAvailable": {
                        "centerX": {
                            "type": "string",
                            "value": "60%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.accounts.MYSPENDING",
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "text": "MY SPENDING ",
                        "segmentProps": []
                    },
                    "mySpending.lblImgMySpending": {
                        "segmentProps": []
                    },
                    "mySpending.lblMySpending": {
                        "segmentProps": []
                    },
                    "mySpending": {
                        "segmentProps": []
                    },
                    "flxBannerContainerMobile": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "1100dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooternew.btnLocateUs": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "7.07%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "centerX": {
                            "type": "number",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "7.07%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "segmentProps": []
                    },
                    "flxLargeAccLoadPopup": {
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnOK": {
                        "focusSkin": "sknBtnSSPffffff15pxBg0273e3",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSSPffffff15pxBg0273e3",
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblDashboardHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxPriorityMessage": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.flxMsgContent": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "priorityMessageTag.imgCross": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblImgMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblPriorityMessageCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag.lblViewMessages": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "priorityMessageTag": {
                        "segmentProps": [],
                        "instanceId": "priorityMessageTag"
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDeviceRegistrationWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxUpgradeDashboardDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxPasswordResetWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblPasswordResetWarning": {
                        "segmentProps": []
                    },
                    "ingPasswordResetWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblImgClosePasswordResetWarning": {
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblOverdraftWarning": {
                        "segmentProps": []
                    },
                    "lblImgCloseWarning": {
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblOutageWarning": {
                        "segmentProps": []
                    },
                    "flxWelcomeAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountListAndBanner": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "54%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAssetsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvestmentSummaryContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "segmentProps": []
                    },
                    "lblShowing": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterGroup": {
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "accountsFilter": {
                        "segmentProps": [],
                        "instanceId": "accountsFilter"
                    },
                    "flxAdvancedGroup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAdvancedFiltersDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvancedFilters": {
                        "segmentProps": []
                    },
                    "lblAdvancedFiltersNumber": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "9%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "segmentProps": []
                    },
                    "accountList.btnShowAllAccounts": {
                        "segmentProps": []
                    },
                    "accountList.flxAccountsRightContainer": {
                        "segmentProps": []
                    },
                    "accountList.flxDropDown": {
                        "segmentProps": []
                    },
                    "flxCustomerCount": {
                        "segmentProps": []
                    },
                    "flxCustomerContainerHeader": {
                        "segmentProps": []
                    },
                    "flxCustomerSearch": {
                        "segmentProps": []
                    },
                    "txtCustomerSearch": {
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "segmentProps": []
                    },
                    "flxAccountsSegment": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "SegCustomers": {
                        "segmentProps": []
                    },
                    "flxMyCashPosition": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCalendar": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "375dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "calendarWidget": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "durationListMenu": {
                        "segmentProps": []
                    },
                    "flxSelectYearsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "240px"
                        },
                        "segmentProps": []
                    },
                    "flxSelectYearsNewMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSelectAccountsMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTotalDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblCreditsTitle": {
                        "segmentProps": []
                    },
                    "lblCreditsValue": {
                        "segmentProps": []
                    },
                    "lblDebitsTitle": {
                        "segmentProps": []
                    },
                    "lblDebitsValue": {
                        "segmentProps": []
                    },
                    "lblTotalBalanceTitle": {
                        "segmentProps": []
                    },
                    "lblTotalBalanceValue": {
                        "segmentProps": []
                    },
                    "flxToggleChartTable": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainChartCon": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "lblLegend1": {
                        "segmentProps": []
                    },
                    "lblLegend2": {
                        "segmentProps": []
                    },
                    "lblLegend3": {
                        "segmentProps": []
                    },
                    "upcomingTransactionsCombined": {
                        "segmentProps": [],
                        "instanceId": "upcomingTransactionsCombined"
                    },
                    "AddExternalAccounts": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnProceed": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.btnReset": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.SelectBankOrVendor.flxSelectBankOrVendorButtons": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxAcknowledgment": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxLoginUsingSelectedBank": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.flxSelectBankOrVendor": {
                        "segmentProps": []
                    },
                    "AddExternalAccounts.lblHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "31.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMarketNewsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "marketIndexDashComp": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "flxWatchlistContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecentActivity": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBannerDesktop": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnUpdateAccntPreferences": {
                        "skin": "sknBtn0273e3SSP15px",
                        "segmentProps": []
                    },
                    "flxApprovalAndRequest": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "mySpending.flxMySpendingWrapperdataUnavailable": {
                        "segmentProps": []
                    },
                    "mySpending.flxNoTransactionsMySpending": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpending": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.imgInfoMySpendingNoDat": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblDataNotAvailable": {
                        "centerX": {
                            "type": "string",
                            "value": "60%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "mySpending.lblMySpending": {
                        "segmentProps": []
                    },
                    "mySpending": {
                        "segmentProps": []
                    },
                    "flxBannerContainerMobile": {
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1100dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "flxLargeAccLoadPopup": {
                        "segmentProps": []
                    },
                    "flxLoadPopup": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoad": {
                        "segmentProps": []
                    },
                    "lblLargeAcconts": {
                        "segmentProps": []
                    },
                    "btnOK": {
                        "focusSkin": "sknBtnSSPffffff15pxBg0273e3",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSSPffffff15pxBg0273e3",
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.headermenu": {
                    "right": "6%",
                    "width": "100%"
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.imgKony": {
                    "centerX": "50%",
                    "left": "",
                    "src": "kony_logo.png",
                    "top": "0px"
                },
                "customheader.topmenu.flxCombinedAccessMenuMobile": {
                    "left": "",
                    "right": 2,
                    "width": "170dp"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": "",
                    "text": "Help"
                },
                "priorityMessageTag.flxMsgContent": {
                    "left": "70dp",
                    "right": "70dp"
                },
                "priorityMessageTag.imgCross": {
                    "centerX": "",
                    "left": "",
                    "right": 10,
                    "src": "closeicon.png",
                    "width": "110dp"
                },
                "priorityMessageTag.lblImgMessage": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "20dp",
                    "top": ""
                },
                "priorityMessageTag.lblPriorityMessageCount": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "priorityMessageTag.lblViewMessages": {
                    "left": "20dp",
                    "text": "View Messages(s)",
                    "top": "0dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "priorityMessageTag": {
                    "height": "100%",
                    "top": "0dp",
                    "width": "100%"
                },
                "welcome.imgProfile": {
                    "src": "username_img.png"
                },
                "welcome": {
                    "left": "6%",
                    "width": "58.20%"
                },
                "totalAssetsCard.segLegend": {
                    "data": [{
                        "flxAssetClass": "Cash (50%)",
                        "flxMarketValue": "$30,574.50",
                        "img1": "imagedrag.png"
                    }, {
                        "flxAssetClass": "Stocks (20%)",
                        "flxMarketValue": "$12,229.80",
                        "img1": "imagedrag.png"
                    }, {
                        "flxAssetClass": "Bond (16%)",
                        "flxMarketValue": "$9,783.84",
                        "img1": "imagedrag.png"
                    }, {
                        "flxAssetClass": "Mutual Fund (10%)",
                        "flxMarketValue": "$6,114.93",
                        "img1": "imagedrag.png"
                    }, {
                        "flxAssetClass": "Term Deposit (4%)",
                        "flxMarketValue": "$2,445.97",
                        "img1": "imagedrag.png"
                    }]
                },
                "totalAssetsCard": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "totalAssetsCard.totalAssetsChart": {
                    "height": "260dp",
                    "width": "260dp"
                },
                "totalAssets": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "investmentSummaryCard.chartInvestmentSummary": {
                    "right": ""
                },
                "investmentSummaryCard.flxAccountDetails": {
                    "height": kony.flex.USE_PREFFERED_SIZE
                },
                "investmentSummaryCard.flxPeriodSelector": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "investmentSummaryCard.flxSelector2": {
                    "left": "25%"
                },
                "investmentSummaryCard.flxSelector3": {
                    "left": "50%"
                },
                "investmentSummaryCard.flxSelector4": {
                    "left": "75%"
                },
                "investmentSummaryCard": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "investmentSummaryCard.segInvestmentAccountsList": {
                    "data": [{
                        "imgBankLogo": "bank_icon_citi.png",
                        "lblAccountBalance": "$38,300.00",
                        "lblAccountName": "Investment Account.. .. 2235",
                        "lblInvestmentLogo": " Investment ",
                        "lblJointAccountLogo": " Investment ",
                        "lblProfitBalance": "+$12.22 (+0.90%)"
                    }, {
                        "imgBankLogo": "bank_icon_citi.png",
                        "lblAccountBalance": "$6,286.00",
                        "lblAccountName": "Investment Account.. .. 9844",
                        "lblInvestmentLogo": " Investment ",
                        "lblJointAccountLogo": " Investment ",
                        "lblProfitBalance": "+$12.22 (+0.90%)"
                    }, {
                        "imgBankLogo": "bank_icon_citi.png",
                        "lblAccountBalance": "$5,746.00",
                        "lblAccountName": "Investment Account.. .. 2202",
                        "lblInvestmentLogo": " Investment ",
                        "lblJointAccountLogo": " Investment ",
                        "lblProfitBalance": "+$12.22 (+0.90%)"
                    }]
                },
                "investmentLineChart": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "accountsFilter": {
                    "centerX": "",
                    "left": "0dp",
                    "right": "",
                    "top": "40dp",
                    "width": "340dp",
                    "zIndex": 10
                },
                "accountsFilter.imgOr": {
                    "src": "or_circle.png"
                },
                "accountsFilter.lblDefaultFiltersHeader": {
                    "top": "20dp"
                },
                "advancedFilters": {
                    "bottom": "",
                    "centerX": "50%",
                    "centerY": "",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "99%"
                },
                "advancedFilters.btnApplyFilter": {
                    "width": "40%"
                },
                "advancedFilters.btnCancelFilter": {
                    "centerX": "",
                    "left": "12%",
                    "width": "40%"
                },
                "advancedFilters.btnReset": {
                    "centerY": "50%",
                    "top": ""
                },
                "advancedFilters.flxAccountsRightContainer": {
                    "width": "20%"
                },
                "advancedFilters.flxAdvancedFiltersTitle": {
                    "left": "4%"
                },
                "advancedFilters.flxByAccounts": {
                    "width": "46%"
                },
                "advancedFilters.flxByBalance": {
                    "minHeight": "",
                    "width": "46%"
                },
                "advancedFilters.flxCurrencyTitle": {
                    "left": "4%"
                },
                "advancedFilters.flxDropDown": {
                    "width": "30%"
                },
                "advancedFilters.flxDropdownCurrency": {
                    "width": "30%"
                },
                "advancedFilters.flxDropdownImage": {
                    "width": "30%"
                },
                "advancedFilters.flxGroupByAccountType": {
                    "left": "4%",
                    "width": "46%"
                },
                "advancedFilters.flxGroupByCompany": {
                    "left": "",
                    "width": "46%"
                },
                "advancedFilters.flxGroupByHeader": {
                    "left": "4%"
                },
                "advancedFilters.flxGroupDropDown": {
                    "width": "30%"
                },
                "advancedFilters.flxGroupRow": {
                    "width": "92%"
                },
                "advancedFilters.flxRow1": {
                    "left": "4%",
                    "width": "92%"
                },
                "advancedFilters.flxRow2": {
                    "left": "4%",
                    "width": "92%"
                },
                "advancedFilters.flxSeperatorCurrency": {
                    "width": "94%"
                },
                "advancedFilters.flxSortByHeader": {
                    "left": "4%"
                },
                "advancedFilters.flxToaHeaderTitle": {
                    "left": "4%"
                },
                "advancedFilters.lblIconAccountType": {
                    "width": "20dp"
                },
                "advancedFilters.lblIconBalance": {
                    "left": "10dp",
                    "width": "20dp"
                },
                "accountList.btnShowAllAccounts": {
                    "right": "18%"
                },
                "accountList.flxAccountsHeaderWrapper": {
                    "left": "15dp"
                },
                "accountList.flxAccountsRightContainer": {
                    "right": "0%"
                },
                "accountList.flxAccountsSegments": {
                    "bottom": "",
                    "top": "1dp"
                },
                "accountList.flxDropDown": {
                    "right": "0dp"
                },
                "accountList.imgHolisticAccountsHeader": {
                    "src": "accounts_blue.png"
                },
                "accountList.lblImgDropdown": {
                    "centerX": "53%"
                },
                "PaginationContainer": {
                    "bottom": "10dp"
                },
                "PaginationContainer.flxPaginationNext": {
                    "left": "-20px"
                },
                "PaginationContainer.flxPaginationPrevious": {
                    "right": "-20px"
                },
                "PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active_container.png"
                },
                "PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "calendarWidget": {
                    "height": "300dp",
                    "left": "375dp",
                    "top": "47dp",
                    "width": "240dp"
                },
                "durationListMenu": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 100
                },
                "durationListMenu.flxAccountListActionsSegment": {
                    "top": "-5dp"
                },
                "durationListMenu.imgToolTip": {
                    "right": "4%",
                    "src": "tool_tip.png"
                },
                "selectAccountList.flxAccountListActionsSegment": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "maxHeight": "200dp"
                },
                "selectAccountList.flxSelectAccount": {
                    "zIndex": 1
                },
                "selectAccountList.flxShowDataFor": {
                    "height": "35dp",
                    "maxHeight": ""
                },
                "selectAccountList.segAccountListActions": {
                    "data": [{
                        "lblRadioButton": "L",
                        "lblUsers": "snpgiqngpegn"
                    }]
                },
                "selectAccountList": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": "220dp",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "upcomingTransactionsCombined.flxNoTransactionWrapper": {
                    "height": "200dp"
                },
                "upcomingTransactionsCombined.imgInfo": {
                    "left": "30dp",
                    "src": "info_large.png",
                    "top": "30dp"
                },
                "upcomingTransactionsCombined.lblHeader": {
                    "left": "3%"
                },
                "upcomingTransactionsCombined.rtxNoPaymentMessage": {
                    "left": "70dp",
                    "top": "33dp"
                },
                "upcomingTransactionsCombined": {
                    "bottom": 15,
                    "left": "0dp",
                    "top": "0dp"
                },
                "AddExternalAccounts.Acknowledgment.btnAccountSummary": {
                    "height": "50dp",
                    "left": "68.12%"
                },
                "AddExternalAccounts.Acknowledgment.btnAddMoreAccounts": {
                    "height": "40dp",
                    "left": "37.07%"
                },
                "AddExternalAccounts.Acknowledgment.imgSuccess": {
                    "src": "success_green.png"
                },
                "AddExternalAccounts.Acknowledgment.lblCongratulations": {
                    "text": "Congratulations!"
                },
                "AddExternalAccounts": {
                    "width": "100%"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.flxCheckbox": {
                    "height": "30dp"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.flxEnterUsername": {
                    "width": "330dp"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankMessage": {
                    "text": "Welcome to Chase Bank"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.flxLoginUsingSelectedBankimage": {
                    "left": "30dp",
                    "width": "101dp"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.imgAddAccountsError": {
                    "src": "error_yellow.png"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.imgBank": {
                    "src": "bank_icon_chase.png"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.imgLoginUsingSelectedBankError": {
                    "src": "error_yellow.png"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.imgValidUsername": {
                    "src": "success_icon.png"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.imgflxLoginUsingSelectedBank": {
                    "src": "bank_icon_chase.png"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.lblBankKey": {
                    "left": "0%"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.lblCheckBox": {
                    "centerY": "50%",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "AddExternalAccounts.LoginUsingSelectedBank.lblPassword": {
                    "text": "E"
                },
                "AddExternalAccounts.LoginUsingSelectedBank.lblUsername": {
                    "text": "E"
                },
                "AddExternalAccounts.SelectBankOrVendor.btnProceed": {
                    "height": "40dp"
                },
                "AddExternalAccounts.SelectBankOrVendor.btnReset": {
                    "height": "40dp"
                },
                "AddExternalAccounts.SelectBankOrVendor.flxBank3": {
                    "left": "30dp"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank1": {
                    "src": "bank_icon_chase.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank2": {
                    "src": "bank_icon_wf.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank3": {
                    "src": "bank_icon_boa.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank4": {
                    "src": "bank_icon_citi.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank5": {
                    "src": "bank_icon_hdfc.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgBank6": {
                    "src": "bank_img_rounded.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.imgError": {
                    "src": "error_yellow.png"
                },
                "AddExternalAccounts.SelectBankOrVendor.lblUserInformation": {
                    "left": "30dp"
                },
                "AddExternalAccounts.flxAcknowledgment": {
                    "width": "100%"
                },
                "quickLinksNew": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "marketIndexDashComp": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "marketNewsCardComp": {
                    "right": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "WatchlistDashCard": {
                    "left": "",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "recentActivityComp": {
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "myApprovals": {
                    "left": "",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "myRequests": {
                    "left": "",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "mySpending.flxHeader": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "mySpending.flxMySpending": {
                    "centerX": "",
                    "centerY": "",
                    "left": 0,
                    "minHeight": "106dp"
                },
                "mySpending.flxMySpendingWrapper": {
                    "left": "0dp",
                    "minHeight": "168dp",
                    "top": "0dp"
                },
                "mySpending.flxMySpendingWrapperdataUnavailable": {
                    "height": "168dp",
                    "minHeight": "",
                    "width": "100%"
                },
                "mySpending.flxNoTransactionsMySpending": {
                    "height": "140dp",
                    "left": "10dp",
                    "top": "12dp",
                    "width": "80%"
                },
                "mySpending.imgInfoIconWarning": {
                    "src": "error_yellow.png"
                },
                "mySpending.imgInfoMySpending": {
                    "left": "5%",
                    "src": "info_large.png",
                    "top": "5dp"
                },
                "mySpending.imgInfoMySpendingNoDat": {
                    "left": "53dp",
                    "src": "grey_donut.png",
                    "top": "21dp"
                },
                "mySpending.imgMySpendingIcon": {
                    "height": "30px",
                    "left": "3.59%",
                    "width": "30px"
                },
                "mySpending.lblDataNotAvailable": {
                    "centerX": "50%",
                    "left": "115dp",
                    "top": "235dp",
                    "width": "100dp"
                },
                "mySpending.lblHeader": {
                    "left": "50dp",
                    "width": "50%"
                },
                "mySpending.lblImgMySpending": {
                    "left": "53dp"
                },
                "mySpending.lblMySpending": {
                    "left": "17%",
                    "top": "10dp",
                    "width": "75%"
                },
                "mySpending": {
                    "bottom": "15dp",
                    "left": "",
                    "minWidth": "",
                    "top": "0px",
                    "width": "100%"
                },
                "accountListMenu": {
                    "left": "590dp",
                    "top": "160dp",
                    "width": "250dp",
                    "zIndex": 10
                },
                "accountListMenu.imgToolTip": {
                    "right": "7%",
                    "src": "tool_tip.png"
                },
                "customfooternew": {
                    "centerX": "",
                    "width": "100%",
                    "zIndex": 1
                },
                "CustomPopup.lblHeading": {
                    "text": "Sign Out"
                },
                "CustomPopup.lblPopupMessage": {
                    "text": "Are you sure you want to Signout?"
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxLoading, flxTermsAndConditionsPopUp, flxLargeAccLoadPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmCustomerDashboard,
            "enabledForIdleTimeout": true,
            "id": "frmCustomerDashboard",
            "init": controller.AS_Form_c25b0d26cacf460788b0e38a5b51bd9b,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_bb6eb1496cfb437797a24347605e41ff,
            "postShow": controller.AS_Form_cae1ae1b7ed549afa3a84ebb5e8adda1,
            "preShow": function(eventobject) {
                controller.AS_Form_h8a1e72a088c4198a505e7dce011ed36(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Dashboard",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_f262befa4a7d435796a7c625e9e7be2b,
            "appName": "HomepageMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_h784ff98d71e4013aa166855b9c6ab5d,
            "retainScrollPosition": true
        }]
    }
});