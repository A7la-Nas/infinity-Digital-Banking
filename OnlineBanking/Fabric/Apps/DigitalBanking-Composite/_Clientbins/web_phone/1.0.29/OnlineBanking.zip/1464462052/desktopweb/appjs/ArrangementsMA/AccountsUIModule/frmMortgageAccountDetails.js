define("ArrangementsMA/AccountsUIModule/frmMortgageAccountDetails", function() {
    return function(controller) {
        function addWidgetsfrmMortgageAccountDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "isVisible": false,
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxHeaderMain": {
                        "isVisible": true
                    },
                    "flxTopmenu": {
                        "height": "51dp",
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu": {
                        "isVisible": true
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "headermenu.rtxWarning": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.YouHaveNotLoggedIn\")"
                    },
                    "imgKony": {
                        "isVisible": true,
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Loggedinas\")"
                    },
                    "lblUserEmail1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.usernamekonycom\")"
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedbackimg": {
                        "left": "viz.val_cleared"
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblFeedback": {
                        "right": "20dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "text": "Account Details"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader, customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "100dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            flxFormContent.add();
            var flxFormCont = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormCont",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormCont.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "28dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxAccountSummaryAndInformation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountSummaryAndInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSummaryAndInformation.setDefaultUnit(kony.flex.DP);
            flxAccountSummaryAndInformation.add();
            var flxPlansAndLinks = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPlansAndLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPlansAndLinks.setDefaultUnit(kony.flex.DP);
            var accountTransactionList = new com.InfinityMB.ArrangementsMA.accountTransactionList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountTransactionList",
                "isVisible": false,
                "left": "6.40%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "6.40%",
                "skin": "slFbox",
                "top": "22dp",
                "width": "794px",
                "appName": "ArrangementsMA",
                "viewType": "accountTransactionList",
                "overrides": {
                    "accountTransactionList": {
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var accountTransactionList_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmMortgageAccountDetails"] && appConfig.componentMetadata["ArrangementsMA"]["frmMortgageAccountDetails"]["accountTransactionList"]) || {};
            accountTransactionList.filterTab1 = accountTransactionList_data.filterTab1 || "{\"Savings\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":{\"640\":\"All\",\"default\":\"Alll\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Loan\":{\"title\":{\"640\":\"All Transactions\",\"default\":\"All Transactions\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Mortgage\":{\"title\":{\"640\":\"All Transactions\",\"default\":\"All Transactions\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Label = accountTransactionList_data.field1Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}}}";
            accountTransactionList.TLobjectServiceName = accountTransactionList_data.TLobjectServiceName || "Holdings";
            accountTransactionList.blockTitle = accountTransactionList_data.blockTitle || " ";
            accountTransactionList.sknFilterActiveTab = accountTransactionList_data.sknFilterActiveTab || "sknBtnSSP42424217PxSelectedTab";
            accountTransactionList.sknMBFieldValueBig = accountTransactionList_data.sknMBFieldValueBig || "ICSknSSP42424213Px";
            accountTransactionList.searchLabel1 = accountTransactionList_data.searchLabel1 || "By Keyword:";
            accountTransactionList.iconSearch = accountTransactionList_data.iconSearch || "{\"img\": \"search_blue.png\"}";
            accountTransactionList.amountFormat = accountTransactionList_data.amountFormat || "{ \"locale\":\"\", \"positiveFormat\" : \"{CS}{D}\", \"negativeFormat\" : \"-{CS}{D}\", \"fractionDigits\":\"2\"}";
            accountTransactionList.transactionListArray = accountTransactionList_data.transactionListArray || "{$.S1.Transactions}";
            accountTransactionList.dataGridColumn1 = accountTransactionList_data.dataGridColumn1 || "{\"Savings\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Deposit\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"}}";
            accountTransactionList.mobileDataGridField1 = accountTransactionList_data.mobileDataGridField1 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Account Number\",\"width\":\"100%\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Deposit\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"CreditCard\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Loan\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Mortgage\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"}}";
            accountTransactionList.TLaccountId = accountTransactionList_data.TLaccountId || "{$.c.accountID}";
            accountTransactionList.tab6ObjectServiceName = accountTransactionList_data.tab6ObjectServiceName || "Holdings";
            accountTransactionList.checkNumberField = accountTransactionList_data.checkNumberField || "Field 3";
            accountTransactionList.filterValueTab1 = accountTransactionList_data.filterValueTab1 || "{\"Savings\":{\"transactionsTypes\":\"All\"},\"Checking\":{\"transactionsTypes\":\"All\"},\"CreditCard\":{\"transactionsTypes\":\"All\"},\"Loan\":{\"transactionsTypes\":\"All\"},\"Deposit\":{\"transactionsTypes\":\"All\"},\"Mortgage\":{\"transactionsTypes\":\"All\"}}";
            accountTransactionList.GAserviceEnable = accountTransactionList_data.GAserviceEnable || true;
            accountTransactionList.isBackendPropEnabled = accountTransactionList_data.isBackendPropEnabled || true;
            accountTransactionList.cacheTotalRecords = accountTransactionList_data.cacheTotalRecords || "{$.c.transactionsCount}";
            accountTransactionList.tab6ObjectName = accountTransactionList_data.tab6ObjectName || "{\"Savings\":{\"objectName\":\"BlockFunds\"},\"Checking\":{\"objectName\":\"BlockFunds\"},\"Loan\":{\"objectName\":\"TransactionsList\"}}";
            accountTransactionList.TLaccountType = accountTransactionList_data.TLaccountType || "{$.c.accountType}";
            accountTransactionList.filterTab2 = accountTransactionList_data.filterTab2 || "{\"Savings\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Value = accountTransactionList_data.field1Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}}}";
            accountTransactionList.TLobjectName = accountTransactionList_data.TLobjectName || "TransactionsList";
            accountTransactionList.transDetailsVisibility = accountTransactionList_data.transDetailsVisibility || false;
            accountTransactionList.sknFilterActiveTabHover = accountTransactionList_data.sknFilterActiveTabHover || "sknBtnSSP42424217PxSelectedTabHover";
            accountTransactionList.sknMBFieldValueSmall = accountTransactionList_data.sknMBFieldValueSmall || "ICSknSSP9b9b9b13Px";
            accountTransactionList.searchLabel2 = accountTransactionList_data.searchLabel2 || "By Transaction Type:";
            accountTransactionList.iconDownload = accountTransactionList_data.iconDownload || "";
            accountTransactionList.dateFormat = accountTransactionList_data.dateFormat || "m/d/Y";
            accountTransactionList.transactionListIdentifier = accountTransactionList_data.transactionListIdentifier || "L1";
            accountTransactionList.dataGridColumn2 = accountTransactionList_data.dataGridColumn2 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Account Number\",\"width\":\"30%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Deposit\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"}}";
            accountTransactionList.mobileDataGridField2 = accountTransactionList_data.mobileDataGridField2 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.swiftTransactionField = accountTransactionList_data.swiftTransactionField || "Field 2";
            accountTransactionList.filterValueTab2 = accountTransactionList_data.filterValueTab2 || "{\"Savings\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Checking\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"CreditCard\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Loan\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Deposit\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Mortgage\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]}}";
            accountTransactionList.GAobjectServiceName = accountTransactionList_data.GAobjectServiceName || "DocumentManagement";
            accountTransactionList.filterTab3 = accountTransactionList_data.filterTab3 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Type = accountTransactionList_data.field1Type || "{\"Savings\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Checking\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Loan\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Deposit\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Mortgage\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}}}";
            accountTransactionList.TLoperationName = accountTransactionList_data.TLoperationName || "getRecent";
            accountTransactionList.sknFilterInactiveTab = accountTransactionList_data.sknFilterInactiveTab || "sknBtnSSP72727217PxUnSelectedTab";
            accountTransactionList.sknMBTransactionDetailsLabel = accountTransactionList_data.sknMBTransactionDetailsLabel || "ICSknSSP72727213Px";
            accountTransactionList.searchLabel3 = accountTransactionList_data.searchLabel3 || "By Time Period:";
            accountTransactionList.iconPrint = accountTransactionList_data.iconPrint || "{\"img\": \"print_blue.png\"}";
            accountTransactionList.backendDateFormat = accountTransactionList_data.backendDateFormat || "Y-m-d";
            accountTransactionList.dataGridColumn3 = accountTransactionList_data.dataGridColumn3 || "{\"Savings\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"}}";
            accountTransactionList.segregationDecider = accountTransactionList_data.segregationDecider || "statusDescription";
            accountTransactionList.mobileDataGridField3 = accountTransactionList_data.mobileDataGridField3 || "{\"Savings\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Checking\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Deposit\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"CreditCard\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Mortgage\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"}}";
            accountTransactionList.tab6OperationName = accountTransactionList_data.tab6OperationName || "{\"Savings\":{\"operationName\":\"getList\"},\"Checking\":{\"operationName\":\"getList\"},\"Loan\":{\"operationName\":\"getRecent\"}}";
            accountTransactionList.TLenableForSearch = accountTransactionList_data.TLenableForSearch || false;
            accountTransactionList.sknHyperlink = accountTransactionList_data.sknHyperlink || "ICSknLbl33659113Px";
            accountTransactionList.filterValueTab3 = accountTransactionList_data.filterValueTab3 || "{\"Savings\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Checking\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"CreditCard\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Loan\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Deposit\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Mortgage\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]}}";
            accountTransactionList.GAobjectName = accountTransactionList_data.GAobjectName || "CustomerAdvice";
            accountTransactionList.tab6Criteria = accountTransactionList_data.tab6Criteria || "{\"Savings\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}},\"Checking\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}},\"Loan\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"LoanSchedule\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}}}";
            accountTransactionList.sknFilterInactiveTabHover = accountTransactionList_data.sknFilterInactiveTabHover || " sknBtnSSP72727217PxUnSelectedTabHover";
            accountTransactionList.filterTab4 = accountTransactionList_data.filterTab4 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field2Label = accountTransactionList_data.field2Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}}}";
            accountTransactionList.TLcriteria = accountTransactionList_data.TLcriteria || "{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}";
            accountTransactionList.sknMBTransactionDetailsValue = accountTransactionList_data.sknMBTransactionDetailsValue || "ICSknSSP42424213Px";
            accountTransactionList.searchLabel4 = accountTransactionList_data.searchLabel4 || "By Check Number:";
            accountTransactionList.iconRowExpand = accountTransactionList_data.iconRowExpand || "{\"vizIcon\": \"O\", \"skin\": \"ICSknBtnIconOther\"}";
            accountTransactionList.dataGridColumn4 = accountTransactionList_data.dataGridColumn4 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.segregationTypes = accountTransactionList_data.segregationTypes || "{\"ST1\":{\"value\":\"Pending\",\"displayText\":\"Pending\"}, \"ST2\":{\"value\":\"Successful\",\"displayText\":\"Posted\"}, \"ST3\":{\"value\":\"due\",\"displayText\":\"Overdue Installments\"}, \"ST4\":{\"value\":\"paid\",\"displayText\":\"Paid Installments\"}}";
            accountTransactionList.filterValueTab4 = accountTransactionList_data.filterValueTab4 || "{\"Savings\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Checking\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"CreditCard\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Loan\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Deposit\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Mortgage\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]}}";
            accountTransactionList.GAoperationName = accountTransactionList_data.GAoperationName || "generate";
            accountTransactionList.sknTableHeader = accountTransactionList_data.sknTableHeader || "sknFlexF9F9F9";
            accountTransactionList.filterTab5 = accountTransactionList_data.filterTab5 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field2Value = accountTransactionList_data.field2Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}}}";
            accountTransactionList.tab6ServiceResponseIdentifier = accountTransactionList_data.tab6ServiceResponseIdentifier || "S2";
            accountTransactionList.searchLabel5 = accountTransactionList_data.searchLabel5 || "By Amount Range:";
            accountTransactionList.iconRowCollapse = accountTransactionList_data.iconRowCollapse || "{\"vizIcon\": \"P\", \"skin\": \"ICSknBtnIconOther\"}";
            accountTransactionList.percentageFormat = accountTransactionList_data.percentageFormat || "";
            accountTransactionList.dataGridColumn5 = accountTransactionList_data.dataGridColumn5 || "{\"Savings\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.dataAvailability = accountTransactionList_data.dataAvailability || "Service calls by component";
            accountTransactionList.filterValueTab5 = accountTransactionList_data.filterValueTab5 || "{\"Savings\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Checking\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"CreditCard\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Loan\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Deposit\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Mortgage\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]}}";
            accountTransactionList.GAcriteria = accountTransactionList_data.GAcriteria || "{\"customerId\":\"{$.c.customerId}\",\"transactionId\":\"{$.c.transactionId}\"}";
            accountTransactionList.sknTableHeaderText = accountTransactionList_data.sknTableHeaderText || "ICSknLblSSP42424215px";
            accountTransactionList.field2Type = accountTransactionList_data.field2Type || "{\"Savings\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Checking\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Loan\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Deposit\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Mortgage\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}}}";
            accountTransactionList.searchLabel6 = accountTransactionList_data.searchLabel6 || "Date Range:";
            accountTransactionList.currencyCode = accountTransactionList_data.currencyCode || "{$.c.currencyCode}";
            accountTransactionList.dataGridColumn6 = accountTransactionList_data.dataGridColumn6 || "";
            accountTransactionList.tab6Title = accountTransactionList_data.tab6Title || "{\"Savings\":{\"title\":\"{i.i18n.accounts.blockedFunds}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[]},\"Checking\":{\"title\":\"{i.i18n.accounts.blockedFunds}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[]},\"Loan\":{\"title\":\"{i.i18n.AccountsDetails.loanSchedule}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[\"VIEW_LOAN_SCHEDULE\"]}}";
            accountTransactionList.TLserviceResponseIdentifier = accountTransactionList_data.TLserviceResponseIdentifier || "S1";
            accountTransactionList.tab6TransactionListArray = accountTransactionList_data.tab6TransactionListArray || "{$.S2.Transactions}";
            accountTransactionList.sknPendingLabel = accountTransactionList_data.sknPendingLabel || "ICSknLblPendingTransactionsSemiBold";
            accountTransactionList.field3Label = accountTransactionList_data.field3Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}}}";
            accountTransactionList.val1PlaceHolder = accountTransactionList_data.val1PlaceHolder || "Type Keyword";
            accountTransactionList.tab6DataGridColumn1 = accountTransactionList_data.tab6DataGridColumn1 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"{$.S2.transactionReference}\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"{$.S2.transactionReference}\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.S2.paymentDate}\",\"fieldType\":\"date\",\"width\":\"20%\",\"defaultSorting\":true,\"order\":\"desc\",\"sortBy\":\"paymentDate\",\"alignment\":\"left\"}}";
            accountTransactionList.sknPostedLabel = accountTransactionList_data.sknPostedLabel || "sknLbl04AA1613pxSSPSemiBold";
            accountTransactionList.field3Value = accountTransactionList_data.field3Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}}}";
            accountTransactionList.val4FromPlaceHolder = accountTransactionList_data.val4FromPlaceHolder || "Check Number";
            accountTransactionList.iconColumnSort = accountTransactionList_data.iconColumnSort || "{\"img\": \"sorting.png\"}";
            accountTransactionList.tab6DataGridColumn2 = accountTransactionList_data.tab6DataGridColumn2 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"{$.S2.lockReason}\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"{$.S2.lockReason}\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.installmentAmount}\",\"fieldType\":\"amount\",\"width\":\"30%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowExpanded = accountTransactionList_data.sknRowExpanded || "ICSknFlxfbfbfb";
            accountTransactionList.field3Type = accountTransactionList_data.field3Type || "{\"Savings\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Checking\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"CreditCard\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Deposit\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Loan\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Mortgage\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}}}";
            accountTransactionList.val4ToPlaceHolder = accountTransactionList_data.val4ToPlaceHolder || "Check Number";
            accountTransactionList.iconColumnSortAsc = accountTransactionList_data.iconColumnSortAsc || "{\"img\": \"sorting_previous.png\"}";
            accountTransactionList.tab6DataGridColumn3 = accountTransactionList_data.tab6DataGridColumn3 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.fromDate}\",\"mapping\":\"{$.S2.fromDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"fromDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.accounts.fromDate}\",\"mapping\":\"{$.S2.fromDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"fromDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.accounts.principal}\",\"mapping\":\"{$.S2.principal}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowHover = accountTransactionList_data.sknRowHover || "ICSknFlxfbfbfb";
            accountTransactionList.field4Label = accountTransactionList_data.field4Label || "";
            accountTransactionList.iconColumnSortDesc = accountTransactionList_data.iconColumnSortDesc || "{\"img\": \"sorting_next.png\"}";
            accountTransactionList.tab6DataGridColumn4 = accountTransactionList_data.tab6DataGridColumn4 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.toDate}\",\"mapping\":\"{$.S2.toDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"toDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.accounts.toDate}\",\"mapping\":\"{$.S2.toDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"toDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.Transactions.displayInterest}\",\"mapping\":\"{$.S2.interest}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowSeperator = accountTransactionList_data.sknRowSeperator || "ICSknLabelBgDBDBDB";
            accountTransactionList.field4Value = accountTransactionList_data.field4Value || "";
            accountTransactionList.tab6DataGridColumn5 = accountTransactionList_data.tab6DataGridColumn5 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.lockedAmount}\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"lockedAmount\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.lockedAmount}\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"lockedAmount\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.accounts.outstandingBalance}\",\"mapping\":\"{$.S2.outstandingBalance}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknValueField = accountTransactionList_data.sknValueField || "ICSknLblSSP42424215px";
            accountTransactionList.field4Type = accountTransactionList_data.field4Type || "";
            accountTransactionList.tab6DataGridColumn6 = accountTransactionList_data.tab6DataGridColumn6 || "";
            accountTransactionList.sknTransDetailsLabel = accountTransactionList_data.sknTransDetailsLabel || "ICSknSSP72727213Px";
            accountTransactionList.field5Label = accountTransactionList_data.field5Label || "";
            accountTransactionList.tab6MobileDataGridField1 = accountTransactionList_data.tab6MobileDataGridField1 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"lockReason\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"lockReason\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"paymentDate\",\"fieldType\":\"date\",\"width\":\"100%\"}}";
            accountTransactionList.sknTransDetailsValue = accountTransactionList_data.sknTransDetailsValue || "ICSknSSP42424213Px";
            accountTransactionList.field5Value = accountTransactionList_data.field5Value || "";
            accountTransactionList.tab6MobileDataGridField2 = accountTransactionList_data.tab6MobileDataGridField2 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"lockedAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"lockedAmount\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"lockedAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"lockedAmount\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"installmentAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknActionButtons = accountTransactionList_data.sknActionButtons || "flxHoverSkinPointer";
            accountTransactionList.field5Type = accountTransactionList_data.field5Type || "";
            accountTransactionList.tab6MobileDataGridField3 = accountTransactionList_data.tab6MobileDataGridField3 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"transactionReference\",\"fieldType\":\"Label\",\"width\":\"40%\"},\"Checking\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"transactionReference\",\"fieldType\":\"Label\",\"width\":\"40%\"}}";
            accountTransactionList.sknSearchLabel = accountTransactionList_data.sknSearchLabel || "ICSknLblSSP72727215px";
            accountTransactionList.field6Label = accountTransactionList_data.field6Label || "";
            accountTransactionList.sknSearchTextbox = accountTransactionList_data.sknSearchTextbox || "skntbxffffffBordere3e3e3SSP15px424242";
            accountTransactionList.field6Value = accountTransactionList_data.field6Value || "";
            accountTransactionList.tab6Field1Label = accountTransactionList_data.tab6Field1Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"}}}}";
            accountTransactionList.sknSearchActiveTextbox = accountTransactionList_data.sknSearchActiveTextbox || "skntbxffffffBordere3e3e3SSP15px424242";
            accountTransactionList.field6Type = accountTransactionList_data.field6Type || "";
            accountTransactionList.tab6Field1Value = accountTransactionList_data.tab6Field1Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchDropdown = accountTransactionList_data.sknSearchDropdown || "sknlbxaltoffffffB1R2";
            accountTransactionList.field7Label = accountTransactionList_data.field7Label || "";
            accountTransactionList.tab6field1Type = accountTransactionList_data.tab6field1Type || "{\"Loan\": {\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchActiveDropdown = accountTransactionList_data.sknSearchActiveDropdown || "sknlbxaltoffffffB1R2";
            accountTransactionList.field7Value = accountTransactionList_data.field7Value || "";
            accountTransactionList.tab6Field2Label = accountTransactionList_data.tab6Field2Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"}}}}";
            accountTransactionList.sknSearchCalendar = accountTransactionList_data.sknSearchCalendar || "sknCalTransactions";
            accountTransactionList.field7Type = accountTransactionList_data.field7Type || "";
            accountTransactionList.tab6Field2Value = accountTransactionList_data.tab6Field2Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchActiveCalendar = accountTransactionList_data.sknSearchActiveCalendar || "sknCalTransactions";
            accountTransactionList.field8Label = accountTransactionList_data.field8Label || "";
            accountTransactionList.tab6Field2Type = accountTransactionList_data.tab6Field2Type || "{\"Loan\": {\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchButton = accountTransactionList_data.sknSearchButton || "sknBtnBlockedSSPFFFFFF15Px";
            accountTransactionList.field8Value = accountTransactionList_data.field8Value || "";
            accountTransactionList.tab6Field3Label = accountTransactionList_data.tab6Field3Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"}}}}";
            accountTransactionList.sknSearchButtonHover = accountTransactionList_data.sknSearchButtonHover || "sknbtnSSPffffff0278ee15pxbr3px";
            accountTransactionList.field8Type = accountTransactionList_data.field8Type || "";
            accountTransactionList.tab6Field3Value = accountTransactionList_data.tab6Field3Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchCancelButton = accountTransactionList_data.sknSearchCancelButton || "ICSknBtnffffffBorder0273e31pxRadius2px";
            accountTransactionList.field9Label = accountTransactionList_data.field9Label || "";
            accountTransactionList.tab6Field3Type = accountTransactionList_data.tab6Field3Type || "{\"Loan\": {\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchCancelButtonHover = accountTransactionList_data.sknSearchCancelButtonHover || "ICSknBtnffffffBorder0273e31pxRadius2px";
            accountTransactionList.field9Value = accountTransactionList_data.field9Value || "";
            accountTransactionList.tab6Field4Label = accountTransactionList_data.tab6Field4Label || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{i.i18n.accounts.charges} :\"},\"ST4\":{\"640\":\"{i.i18n.accounts.charges} :\"}}}}";
            accountTransactionList.sknPositiveAmount = accountTransactionList_data.sknPositiveAmount || "ICSknLblSSP42424215px";
            accountTransactionList.field9Type = accountTransactionList_data.field9Type || "";
            accountTransactionList.tab6Field4Value = accountTransactionList_data.tab6Field4Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknNegativeAmount = accountTransactionList_data.sknNegativeAmount || "ICSknLblSSP42424215px";
            accountTransactionList.field10Label = accountTransactionList_data.field10Label || "";
            accountTransactionList.tab6Field4Type = accountTransactionList_data.tab6Field4Type || "{\"Loan\":{\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.sknDate = accountTransactionList_data.sknDate || "ICSknLblSSP42424215px";
            accountTransactionList.field10Value = accountTransactionList_data.field10Value || "";
            accountTransactionList.tab6Field5Label = accountTransactionList_data.tab6Field5Label || "{\"Loan\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.tax} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.tax} :\"}}}}";
            accountTransactionList.sknPercentage = accountTransactionList_data.sknPercentage || "ICSknLblSSP42424215px";
            accountTransactionList.field10Type = accountTransactionList_data.field10Type || "";
            accountTransactionList.tab6Field5Value = accountTransactionList_data.tab6Field5Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.btnContextualAction1 = accountTransactionList_data.btnContextualAction1 || "{\"Savings\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Checking\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"CreditCard\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Loan\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Deposit\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Mortgage\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}}}";
            accountTransactionList.tab6Field5Type = accountTransactionList_data.tab6Field5Type || "{\"Loan\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.tab6Field6Label = accountTransactionList_data.tab6Field6Label || "{\"Loan\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.insurance} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.insurance} :\"}}}}";
            accountTransactionList.btnContextualAction2 = accountTransactionList_data.btnContextualAction2 || "{\"Savings\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Checking\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"CreditCard\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Loan\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Deposit\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}}}";
            accountTransactionList.btnContextualAction3 = accountTransactionList_data.btnContextualAction3 || "{\"Savings\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Checking\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"CreditCard\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Loan\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Deposit\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Mortgage\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}}}";
            accountTransactionList.tab6Field6Value = accountTransactionList_data.tab6Field6Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.tab6Field6Type = accountTransactionList_data.tab6Field6Type || "{\"Loan\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.btnContextualAction4 = accountTransactionList_data.btnContextualAction4 || "{\"Savings\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Checking\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"CreditCard\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Loan\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Deposit\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Mortgage\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"}}";
            accountTransactionList.tab6Field7Label = accountTransactionList_data.tab6Field7Label || "";
            accountTransactionList.tab6Field7Value = accountTransactionList_data.tab6Field7Value || "";
            accountTransactionList.tab6Field7Type = accountTransactionList_data.tab6Field7Type || "";
            accountTransactionList.tab6Field8Label = accountTransactionList_data.tab6Field8Label || "";
            accountTransactionList.tab6Field8Value = accountTransactionList_data.tab6Field8Value || "";
            accountTransactionList.tab6Field8Type = accountTransactionList_data.tab6Field8Type || "";
            accountTransactionList.tab6Field9Label = accountTransactionList_data.tab6Field9Label || "";
            accountTransactionList.tab6Field9Value = accountTransactionList_data.tab6Field9Value || "";
            accountTransactionList.tab6Field9Type = accountTransactionList_data.tab6Field9Type || "";
            accountTransactionList.tab6Field10Label = accountTransactionList_data.tab6Field10Label || "";
            accountTransactionList.tab6Field10Value = accountTransactionList_data.tab6Field10Value || "";
            accountTransactionList.tab6Field10Type = accountTransactionList_data.tab6Field10Type || "";
            accountTransactionList.tab6BtnContextualAction1 = accountTransactionList_data.tab6BtnContextualAction1 || "{\"Loan\":{\"id\":{\"ST3\":\"payOverDue\",\"ST4\":\"\"},\"text\":{\"ST3\":{\"default\":\"Pay Overdue\"},\"ST4\":{\"default\":\"\"}},\"width\":{\"ST3\":{\"default\":\"100%\"},\"ST4\":{\"default\":\"100%\"}},\"skin\":{\"ST3\":{\"default\":\"ICSknBtnSSP0273e315px\"},\"ST4\":{\"default\":\"\"}},\"entitlement_keys\":[\"VIEW_LOAN_SCHEDULE\"],\"entitlement_action\":{\"ST3\":false,\"ST4\":false}}}";
            accountTransactionList.tab6BtnContextualAction2 = accountTransactionList_data.tab6BtnContextualAction2 || "";
            accountTransactionList.tab6BtnContextualAction3 = accountTransactionList_data.tab6BtnContextualAction3 || "";
            accountTransactionList.tab6BtnContextualAction4 = accountTransactionList_data.tab6BtnContextualAction4 || "";
            accountTransactionList.onError = controller.AS_UWI_e218db2b649444b5a9b537ee486ae9b5;
            accountTransactionList.adjustScreen = controller.AS_UWI_f4aac8f9c347424aac80cca38cc92cc6;
            flxPlansAndLinks.add(accountTransactionList);
            var flxAccountTypesAndInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAccountTypesAndInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 100,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypesAndInfo.setDefaultUnit(kony.flex.DP);
            var flxTitleGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTitleGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "75%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitleGroup.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "40dp",
                "id": "lblTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlblUserName",
                "text": "Mortgage Account Details",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnByPass = new kony.ui.Button({
                "height": "50dp",
                "id": "btnByPass",
                "isVisible": true,
                "left": "0dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to Loans",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitleGroup.add(lblTitle, btnByPass);
            var flxAccountTypes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "clipBounds": false,
                "focusSkin": "flxHoverSkinPointer",
                "height": "60%",
                "id": "flxAccountTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "30dp",
                "width": "360dp",
                "zIndex": 250,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxAccountTypes.setDefaultUnit(kony.flex.DP);
            var flxGroup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblAccountTypes",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60%",
                "id": "flxGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroup.setDefaultUnit(kony.flex.DP);
            var flxImgAccountTypeIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgAccountTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20px",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgAccountTypeIcon.setDefaultUnit(kony.flex.DP);
            var imgAccountTypeIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgAccountTypeIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgAccountTypeIcon.add(imgAccountTypeIcon);
            var lblAccountTypes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAccountTypes",
                "isVisible": true,
                "left": "0px",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.MyCheckingAccount3254\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAccountTypes = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "7dp",
                "id": "imgAccountTypes",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_down.png",
                "top": "6dp",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGroup.add(flxImgAccountTypeIcon, lblAccountTypes, imgAccountTypes);
            var accountTypes = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountTypes",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 200,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "left": "70dp",
                        "top": "0dp",
                        "width": "320dp",
                        "zIndex": 200
                    },
                    "flxAccountTypesSegment": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp"
                    },
                    "imgToolTip": {
                        "isVisible": true,
                        "left": "200dp",
                        "right": "viz.val_cleared",
                        "src": "tool_tip.png"
                    },
                    "segAccountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }],
                        "maxHeight": "255dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountTypes.add(flxGroup, accountTypes);
            var btnViewAccountInfo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "btnViewAccountInfo",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknBtnSSP3343a813px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.viewAccountInfo\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flexRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "60%",
                "id": "flexRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "600dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flexRight.setDefaultUnit(kony.flex.DP);
            var lblAsOf = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAsOf",
                "isVisible": true,
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexRight.add(lblAsOf);
            flxAccountTypesAndInfo.add(flxTitleGroup, flxAccountTypes, btnViewAccountInfo, flexRight);
            var flxMortgagePropertyContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMortgagePropertyContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "110dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgagePropertyContainer.setDefaultUnit(kony.flex.DP);
            var flxMortgageSummary = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMortgageSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "84px",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "16px",
                "width": "389dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageSummary.setDefaultUnit(kony.flex.DP);
            var flxMortgageHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50px",
                "id": "flxMortgageHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageHeader.setDefaultUnit(kony.flex.DP);
            var lblMortgageSummary = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblMortgageSummary",
                "isVisible": true,
                "left": "29px",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.MortgageSummary\")",
                "top": "15px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxThree = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxThree",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxThree.setDefaultUnit(kony.flex.DP);
            var imgThreedot = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "imgThreedot",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxThree.add(imgThreedot);
            flxMortgageHeader.add(lblMortgageSummary, flxThree);
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1px",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "265px",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxBalance = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80px",
                "id": "flxBalance",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBalance.setDefaultUnit(kony.flex.DP);
            var lblOutstandingBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalance",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Total Outstanding Balance",
                "top": "12px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgInfo",
                "isVisible": false,
                "left": "195dp",
                "src": "info_grey.png",
                "top": "15dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblInfo",
                "isVisible": false,
                "left": "228px",
                "skin": "skna0a0a0Bgf7f7f720pxolbfonticons",
                "text": "K",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBalance",
                "isVisible": true,
                "left": "27px",
                "skin": "sknSSPBold42424240Px",
                "top": "35px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBalance.add(lblOutstandingBalance, imgInfo, lblInfo, lblBalance);
            var flxContentBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "186dp",
                "id": "flxContentBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentBody.setDefaultUnit(kony.flex.DP);
            var flxField1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxField1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxField1.setDefaultUnit(kony.flex.DP);
            var lblField1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField1",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Commitment Amount:",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblField1Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField1Value",
                "isVisible": true,
                "left": "185px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxField1.add(lblField1, lblField1Value);
            var flxField2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxField2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxField2.setDefaultUnit(kony.flex.DP);
            var lblField2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField2",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Utilised Amount:",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblField2Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField2Value",
                "isVisible": true,
                "left": "185px",
                "right": "0dp",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxField2.add(lblField2, lblField2Value);
            var flxField3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxField3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxField3.setDefaultUnit(kony.flex.DP);
            var lblField3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField3",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Total Paid to Date:",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblField3Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField3Value",
                "isVisible": true,
                "left": "185px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxField3.add(lblField3, lblField3Value);
            var flxField4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxField4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxField4.setDefaultUnit(kony.flex.DP);
            var lblField4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField4",
                "isVisible": false,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Home Ownership:",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblField4Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblField4Value",
                "isVisible": false,
                "left": "185px",
                "skin": "sknSSPSemiBold42424215px",
                "text": "50%",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxField4.add(lblField4, lblField4Value);
            flxContentBody.add(flxField1, flxField2, flxField3, flxField4);
            flxContent.add(flxBalance, flxContentBody);
            flxMortgageSummary.add(flxMortgageHeader, flxSeperator, flxContent);
            var flxPropertyAndTerm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPropertyAndTerm",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "16px",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "16px",
                "width": "389dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPropertyAndTerm.setDefaultUnit(kony.flex.DP);
            var flxPropertyHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50px",
                "id": "flxPropertyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPropertyHeader.setDefaultUnit(kony.flex.DP);
            var lblPropertyAndTerm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPropertyAndTerm",
                "isVisible": true,
                "left": "29px",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.PropertyTerm\")",
                "top": "15px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPropertyHeader.add(lblPropertyAndTerm);
            var flxPropertySeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1px",
                "id": "flxPropertySeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPropertySeperator.setDefaultUnit(kony.flex.DP);
            flxPropertySeperator.add();
            var flxAddressBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddressBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "minHeight": "265px",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressBody.setDefaultUnit(kony.flex.DP);
            var flxAddress = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var flxPropertyDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPropertyDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPropertyDetails.setDefaultUnit(kony.flex.DP);
            var lblPropertyAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPropertyAddress",
                "isVisible": true,
                "left": "77px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Property Address:",
                "top": "12px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPropertyAddressValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPropertyAddressValue",
                "isVisible": true,
                "left": "77px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "7px",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPropertyType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPropertyType",
                "isVisible": true,
                "left": "77px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Property Type:",
                "top": "10px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPropertyTypeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPropertyTypeValue",
                "isVisible": true,
                "left": "77px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPropertyDetails.add(lblPropertyAddress, lblPropertyAddressValue, lblPropertyType, lblPropertyTypeValue);
            var imgHomeIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "102dp",
                "id": "imgHomeIcon",
                "isVisible": true,
                "left": "0",
                "src": "domestic_transfer.png",
                "top": "0",
                "width": "91dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDetais = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDetais",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetais.setDefaultUnit(kony.flex.DP);
            var lblCommitmentTerm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCommitmentTerm",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Commitment Term:",
                "top": "129px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCommitmentTermValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCommitmentTermValue",
                "isVisible": true,
                "left": "185px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "129px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEffectiveDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEffectiveDate",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Effective Date:",
                "top": "160px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEffectiveDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEffectiveDateValue",
                "isVisible": true,
                "left": "185px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "159px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDate",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Maturity Date:",
                "top": "191px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDateValue",
                "isVisible": true,
                "left": "185px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "190px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetais.add(lblCommitmentTerm, lblCommitmentTermValue, lblEffectiveDate, lblEffectiveDateValue, lblMaturityDate, lblMaturityDateValue);
            flxAddress.add(flxPropertyDetails, imgHomeIcon, flxDetais);
            flxAddressBody.add(flxAddress);
            flxPropertyAndTerm.add(flxPropertyHeader, flxPropertySeperator, flxAddressBody);
            flxMortgagePropertyContainer.add(flxMortgageSummary, flxPropertyAndTerm);
            var flxMortgageQuickLinksContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMortgageQuickLinksContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "110dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageQuickLinksContainer.setDefaultUnit(kony.flex.DP);
            var flxMortgageInformation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMortgageInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "19px",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "16px",
                "width": "389dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageInformation.setDefaultUnit(kony.flex.DP);
            var flxMortgageInfoHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50px",
                "id": "flxMortgageInfoHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageInfoHeader.setDefaultUnit(kony.flex.DP);
            var lblMortgageInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblMortgageInformation",
                "isVisible": true,
                "left": "29px",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.MortgageInformation\")",
                "top": "15px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMortgageInfoHeader.add(lblMortgageInformation);
            var flxMortgageSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1px",
                "id": "flxMortgageSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageSeperator.setDefaultUnit(kony.flex.DP);
            flxMortgageSeperator.add();
            var flxInformation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "minHeight": "265px",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var flxInfoBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxInfoBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "minHeight": "266px",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoBody.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var flxiBan2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxiBan2",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "185dp",
                "isModalContainer": false,
                "top": "67dp",
                "width": "200dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxiBan2.setDefaultUnit(kony.flex.DP);
            var lblIBANValue2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIBANValue2",
                "isVisible": true,
                "left": "0px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowIcon3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxShowIcon3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "2dp",
                "width": "30dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowIcon3.setDefaultUnit(kony.flex.DP);
            var lblShowIcon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblShowIcon3",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLblFontIcon",
                "text": "g",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowIcon3.add(lblShowIcon3);
            flxiBan2.add(lblIBANValue2, flxShowIcon3);
            var lblAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "Account Number:",
                "top": "17px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "185dp",
                "isModalContainer": false,
                "top": "17dp",
                "width": "200dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblAccountNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumberValue",
                "isVisible": true,
                "left": "0px",
                "skin": "ICSknsknSSP42424215Px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxShowIcon",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "30dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowIcon.setDefaultUnit(kony.flex.DP);
            var lblShowIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblShowIcon",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLblFontIcon",
                "text": "h",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowIcon.add(lblShowIcon);
            flxAccountNumber.add(lblAccountNumberValue, flxShowIcon);
            var lblIBAN = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIBAN",
                "isVisible": true,
                "left": "27px",
                "skin": "bbSknLbl727272Lato13px",
                "text": "IBAN Number:",
                "top": "48px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxiBan1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxiBan1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "185dp",
                "isModalContainer": false,
                "top": "47dp",
                "width": "200dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxiBan1.setDefaultUnit(kony.flex.DP);
            var lblIBANValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIBANValue",
                "isVisible": true,
                "left": "0px",
                "skin": "ICSknsknSSP42424215Px",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowIcon2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxShowIcon2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "30dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowIcon2.setDefaultUnit(kony.flex.DP);
            var lblShowIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblShowIcon2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLblFontIcon",
                "text": "h",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowIcon2.add(lblShowIcon2);
            flxiBan1.add(lblIBANValue, flxShowIcon2);
            flxTop.add(flxiBan2, lblAccountNumber, flxAccountNumber, lblIBAN, flxiBan1);
            var flxBottom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "198dp",
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var segCoBorrower = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblCoBorrower": "",
                    "lblCoBorrowerValue": ""
                }],
                "groupCells": false,
                "id": "segCoBorrower",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxCoBorrower"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0px",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(segCoBorrower);
            flxInfoBody.add(flxTop, flxBottom);
            flxInformation.add(flxInfoBody);
            flxMortgageInformation.add(flxMortgageInfoHeader, flxMortgageSeperator, flxInformation);
            var flxLinksFacilityMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLinksFacilityMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "45%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLinksFacilityMain.setDefaultUnit(kony.flex.DP);
            var quicklinks = new com.InfinityOLB.ArrangementsMA.quicklinks({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "quicklinks",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "389px",
                "zIndex": 1,
                "appName": "ArrangementsMA",
                "viewType": "quicklinks",
                "overrides": {
                    "quicklinks": {
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var quicklinks_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmMortgageAccountDetails"] && appConfig.componentMetadata["ArrangementsMA"]["frmMortgageAccountDetails"]["quicklinks"]) || {};
            quicklinks.link1CTA = quicklinks_data.link1CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.sknRow = quicklinks_data.sknRow || "";
            quicklinks.link1Text = quicklinks_data.link1Text || "quicklinks  1";
            quicklinks.link2CTA = quicklinks_data.link2CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.sknRowSeperator = quicklinks_data.sknRowSeperator || "sknFlxe3e3e3bg";
            quicklinks.link2Text = quicklinks_data.link2Text || "quicklinks 2";
            quicklinks.link3CTA = quicklinks_data.link3CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.sknLink = quicklinks_data.sknLink || "btnskn4176a415px";
            quicklinks.link3Text = quicklinks_data.link3Text || "quicklinks3";
            quicklinks.link4CTA = quicklinks_data.link4CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.sknContainer = quicklinks_data.sknContainer || "sknFlxFFFFFF10Blur4R";
            quicklinks.link4Text = quicklinks_data.link4Text || "quicklinks 4";
            quicklinks.link5CTA = quicklinks_data.link5CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link5Text = quicklinks_data.link5Text || "";
            quicklinks.link6CTA = quicklinks_data.link6CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link6Text = quicklinks_data.link6Text || "";
            quicklinks.link7CTA = quicklinks_data.link7CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link7Text = quicklinks_data.link7Text || "";
            quicklinks.link8CTA = quicklinks_data.link8CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link8Text = quicklinks_data.link8Text || "";
            quicklinks.link9CTA = quicklinks_data.link9CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link9Text = quicklinks_data.link9Text || "";
            quicklinks.link10CTA = quicklinks_data.link10CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinks.link10Text = quicklinks_data.link10Text || "";
            var flxUpdateFacilityMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUpdateFacilityMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "390dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdateFacilityMain.setDefaultUnit(kony.flex.DP);
            var flxUpdateTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxUpdateTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdateTitle.setDefaultUnit(kony.flex.DP);
            var lblModify = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblModify",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.ModifyFacility\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblModify",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxImgDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "top": "0",
                "width": "10%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLblFontIcon",
                "text": "O",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDropdown.add(lblDropdown);
            flxUpdateTitle.add(lblModify, flxImgDropdown);
            var flxUpdateContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUpdateContent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdateContent.setDefaultUnit(kony.flex.DP);
            var segUpdate = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }],
                "groupCells": false,
                "id": "segUpdate",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAccountTypes"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountTypes": "flxAccountTypes",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUpdateContent.add(segUpdate);
            flxUpdateFacilityMain.add(flxUpdateTitle, flxUpdateContent);
            flxLinksFacilityMain.add(quicklinks, flxUpdateFacilityMain);
            flxMortgageQuickLinksContainer.add(flxMortgageInformation, flxLinksFacilityMain);
            var accountList = new com.InfinityOLB.ArrangementsMA.accountList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "450dp",
                "width": "794px",
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountList": {
                        "left": "6%",
                        "top": "450dp",
                        "width": "794px"
                    },
                    "flxAccountsHeader": {
                        "isVisible": false,
                        "top": "0dp"
                    },
                    "flxAccountsSegments": {
                        "bottom": "9dp",
                        "centerX": "50%",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxActivePlan": {
                        "left": "0",
                        "top": "0"
                    },
                    "flxTitleSeparator": {
                        "isVisible": true
                    },
                    "segAccounts": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp",
                        "right": 0,
                        "width": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMain.add(flxAccountSummaryAndInformation, flxPlansAndLinks, flxAccountTypesAndInfo, flxMortgagePropertyContainer, flxMortgageQuickLinksContainer, accountList);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "700dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "150dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            var accountListMenu = new com.InfinityOLB.ArrangementsMA.accountListMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountListMenu",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountListMenu": {
                        "isVisible": false
                    },
                    "flxAccountListActionsSegment": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp",
                        "top": "-3dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFormCont.add(flxMain, flxFooter, accountListMenu);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1100,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.customhamburger": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.customhamburger.flxMenuWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormCont": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSummaryAndInformation": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPlansAndLinks": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTitleGroup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "3px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "lblAccountTypes": {
                        "segmentProps": []
                    },
                    "imgAccountTypes": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flexRight": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "3px"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "-10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblAsOf": {
                        "left": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxMortgagePropertyContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageSummary": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblMortgageSummary": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "ICSknLabelSSPBold42424213px",
                        "top": {
                            "type": "string",
                            "value": "13px"
                        },
                        "segmentProps": []
                    },
                    "flxThree": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgThreedot": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "skin": "sknLblFontType0273E320px",
                        "text": "O",
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "height": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "flxBalance": {
                        "height": {
                            "type": "string",
                            "value": "53px"
                        },
                        "segmentProps": []
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "14px"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "183dp"
                        },
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "left": {
                            "type": "string",
                            "value": "102px"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "lblBalance": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "sknSSPBold42424220Px",
                        "top": {
                            "type": "string",
                            "value": "34px"
                        },
                        "segmentProps": []
                    },
                    "flxContentBody": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "lblField1": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblField1Value": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblField2": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblField2Value": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblField3": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblField3Value": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblField4Value": {
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxPropertyAndTerm": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyAndTerm": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "ICSknLabelSSPBold42424213px",
                        "top": {
                            "type": "string",
                            "value": "17px"
                        },
                        "segmentProps": []
                    },
                    "flxAddress": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxPropertyDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyAddress": {
                        "left": {
                            "type": "string",
                            "value": "35px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyAddressValue": {
                        "left": {
                            "type": "string",
                            "value": "35px"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyType": {
                        "left": {
                            "type": "string",
                            "value": "35px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "35px"
                        },
                        "segmentProps": []
                    },
                    "imgHomeIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "src": "a_zeera.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDetais": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCommitmentTerm": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "lblCommitmentTermValue": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "114px"
                        },
                        "segmentProps": []
                    },
                    "lblEffectiveDate": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "lblEffectiveDateValue": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "segmentProps": []
                    },
                    "lblMaturityDateValue": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "210px"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageQuickLinksContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageInformation": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblMortgageInformation": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "ICSknLabelSSPBold42424213px",
                        "top": {
                            "type": "string",
                            "value": "17px"
                        },
                        "segmentProps": []
                    },
                    "flxInformation": {
                        "minHeight": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoBody": {
                        "minHeight": {
                            "type": "string",
                            "value": "180px"
                        },
                        "segmentProps": []
                    },
                    "lblIBANValue2": {
                        "segmentProps": []
                    },
                    "lblShowIcon3": {
                        "segmentProps": []
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "top": {
                            "type": "string",
                            "value": "7px"
                        },
                        "segmentProps": []
                    },
                    "flxAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "segmentProps": []
                    },
                    "lblShowIcon": {
                        "segmentProps": []
                    },
                    "lblIBAN": {
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "top": {
                            "type": "string",
                            "value": "48px"
                        },
                        "segmentProps": []
                    },
                    "flxiBan1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "segmentProps": []
                    },
                    "lblIBANValue": {
                        "segmentProps": []
                    },
                    "lblShowIcon2": {
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "segCoBorrower": {
                        "segmentProps": []
                    },
                    "flxLinksFacilityMain": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "quicklinks": {
                        "isCustomLayout": false,
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "skin": "s239091db7434caea47c90b15e785665",
                        "top": {
                            "type": "string",
                            "value": "-835dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxUpdateFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountList": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "accountList"
                    },
                    "accountList.flxAccountsSegments": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "accountList.segAccounts": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1332dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "frmMortgageAccountDetails": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxverseperator2": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxFormCont": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "24px"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTitle": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flexRight": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "segmentProps": []
                    },
                    "lblAsOf": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "isVisible": true,
                        "skin": "sknlbla0a0a015px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgagePropertyContainer": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxMortgageSummary": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxThree": {
                        "segmentProps": []
                    },
                    "imgThreedot": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "left": {
                            "type": "string",
                            "value": "195px"
                        },
                        "segmentProps": []
                    },
                    "lblField1Value": {
                        "left": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "lblField2Value": {
                        "left": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "lblField3Value": {
                        "left": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "flxPropertyAndTerm": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "imgHomeIcon": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "src": "a_zeera.png",
                        "segmentProps": []
                    },
                    "flxDetais": {
                        "top": {
                            "type": "string",
                            "value": "-25dp"
                        },
                        "segmentProps": []
                    },
                    "lblCommitmentTermValue": {
                        "left": {
                            "type": "string",
                            "value": "177px"
                        },
                        "segmentProps": []
                    },
                    "lblEffectiveDateValue": {
                        "left": {
                            "type": "string",
                            "value": "177px"
                        },
                        "segmentProps": []
                    },
                    "lblMaturityDateValue": {
                        "left": {
                            "type": "string",
                            "value": "177px"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageQuickLinksContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageInformation": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "29px"
                        },
                        "segmentProps": []
                    },
                    "lblIBAN": {
                        "left": {
                            "type": "string",
                            "value": "29px"
                        },
                        "segmentProps": []
                    },
                    "flxLinksFacilityMain": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "quicklinks": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "105%"
                        },
                        "segmentProps": []
                    },
                    "flxUpdateFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountList": {
                        "left": {
                            "type": "string",
                            "value": "24px"
                        },
                        "top": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": [],
                        "instanceId": "accountList"
                    },
                    "accountList.flxTitleSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1030dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "frmMortgageAccountDetails": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormCont": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxAccountSummaryAndInformation": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPlansAndLinks": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "0.68%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.flxAccountTypesSegment": {
                        "top": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flexRight": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "segmentProps": []
                    },
                    "lblAsOf": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgagePropertyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageSummary": {
                        "left": {
                            "type": "string",
                            "value": "84px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "349dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageHeader": {
                        "left": {
                            "type": "string",
                            "value": "84px"
                        },
                        "segmentProps": []
                    },
                    "imgThreedot": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "left": {
                            "type": "string",
                            "value": "195px"
                        },
                        "segmentProps": []
                    },
                    "lblField2Value": {
                        "segmentProps": []
                    },
                    "lblField4Value": {
                        "skin": "sknlbl424242bold15px",
                        "segmentProps": []
                    },
                    "flxPropertyAndTerm": {
                        "left": {
                            "type": "string",
                            "value": "455px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "349dp"
                        },
                        "segmentProps": []
                    },
                    "imgHomeIcon": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "src": "a_zeera.png",
                        "segmentProps": []
                    },
                    "flxDetais": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-25dp"
                        },
                        "segmentProps": []
                    },
                    "lblCommitmentTerm": {
                        "text": "Commitment Term:",
                        "segmentProps": []
                    },
                    "flxMortgageQuickLinksContainer": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "828px"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageInformation": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "314dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "349dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "28px"
                        },
                        "segmentProps": []
                    },
                    "lblShowIcon": {
                        "segmentProps": []
                    },
                    "lblIBAN": {
                        "left": {
                            "type": "string",
                            "value": "28px"
                        },
                        "segmentProps": []
                    },
                    "lblShowIcon2": {
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "segmentProps": []
                    },
                    "flxLinksFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "quicklinks": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "106%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxUpdateFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountList": {
                        "left": {
                            "type": "string",
                            "value": "84px"
                        },
                        "width": {
                            "type": "string",
                            "value": "720px"
                        },
                        "segmentProps": [],
                        "instanceId": "accountList"
                    },
                    "accountList.flxAccountsSegments": {
                        "left": {
                            "type": "string",
                            "value": "1.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "accountList.flxTitleSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountList.segAccounts": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "704dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFormCont": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FREE_FORM,
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "6.55%"
                        },
                        "segmentProps": []
                    },
                    "flexRight": {
                        "left": {
                            "type": "string",
                            "value": "478dp"
                        },
                        "segmentProps": []
                    },
                    "lblAsOf": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "skin": "sknlbla0a0a015px",
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgagePropertyContainer": {
                        "segmentProps": []
                    },
                    "flxMortgageSummary": {
                        "left": {
                            "type": "string",
                            "value": "6.63%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblMortgageSummary": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "flxThree": {
                        "segmentProps": []
                    },
                    "imgThreedot": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "left": {
                            "type": "string",
                            "value": "195px"
                        },
                        "segmentProps": []
                    },
                    "lblField1Value": {
                        "segmentProps": []
                    },
                    "lblField2Value": {
                        "segmentProps": []
                    },
                    "lblField3Value": {
                        "segmentProps": []
                    },
                    "flxPropertyAndTerm": {
                        "left": {
                            "type": "string",
                            "value": "35.83%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblPropertyAddressValue": {
                        "segmentProps": []
                    },
                    "lblPropertyTypeValue": {
                        "segmentProps": []
                    },
                    "imgHomeIcon": {
                        "src": "a_zeera.png",
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "segmentProps": []
                    },
                    "flxDetais": {
                        "top": {
                            "type": "string",
                            "value": "-25dp"
                        },
                        "segmentProps": []
                    },
                    "lblCommitmentTermValue": {
                        "segmentProps": []
                    },
                    "lblEffectiveDateValue": {
                        "segmentProps": []
                    },
                    "lblMaturityDateValue": {
                        "segmentProps": []
                    },
                    "flxMortgageQuickLinksContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageInformation": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblShowIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "h",
                        "segmentProps": []
                    },
                    "lblShowIcon2": {
                        "text": "h",
                        "segmentProps": []
                    },
                    "flxLinksFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "quicklinks": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "105%"
                        },
                        "segmentProps": []
                    },
                    "flxUpdateFacilityMain": {
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountList": {
                        "left": {
                            "type": "string",
                            "value": "6.63%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57.33%"
                        },
                        "segmentProps": [],
                        "instanceId": "accountList"
                    },
                    "accountList.flxAccountsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountList.flxAccountsSegments": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountList.flxActivePlan": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "accountList.flxTitleSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountList.segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "accountListMenu.flxAccountListActionsSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.flxTopmenu": {
                    "height": "51dp"
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.flxFeedbackimg": {
                    "left": ""
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblFeedback": {
                    "right": "20dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customheadernew.lblHeaderMobile": {
                    "text": "Account Details"
                },
                "accountTransactionList": {
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "accountTypes": {
                    "left": "70dp",
                    "top": "0dp",
                    "width": "320dp",
                    "zIndex": 200
                },
                "accountTypes.flxAccountTypesSegment": {
                    "left": "0dp"
                },
                "accountTypes.imgToolTip": {
                    "left": "200dp",
                    "right": "",
                    "src": "tool_tip.png"
                },
                "accountTypes.segAccountTypes": {
                    "data": [{
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }],
                    "maxHeight": "255dp"
                },
                "quicklinks": {
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "centerY": ""
                },
                "accountList": {
                    "left": "6%",
                    "top": "450dp",
                    "width": "794px"
                },
                "accountList.flxAccountsHeader": {
                    "top": "0dp"
                },
                "accountList.flxAccountsSegments": {
                    "bottom": "9dp",
                    "centerX": "50%",
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "accountList.flxActivePlan": {
                    "left": "0",
                    "top": "0"
                },
                "accountList.segAccounts": {
                    "left": "0dp",
                    "right": 0,
                    "width": ""
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "150dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "accountListMenu.flxAccountListActionsSegment": {
                    "left": "0dp",
                    "top": "-3dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxFormCont, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmMortgageAccountDetails,
            "enabledForIdleTimeout": true,
            "id": "frmMortgageAccountDetails",
            "init": controller.AS_Form_b5d4432286234ad59d8242ac3e7b61a0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_h5f30bce48d14ec68ef4bbcd9044d5d9,
            "preShow": function(eventobject) {
                controller.AS_Form_b6bee9a197d246fe9a43f6fbb971ccb3(eventobject);
                controller.AS_Form_ec0a11a9ed2a46ea8a76dadb1477f1d7(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Mortgage Account Details",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_c5789eb70a974dfbb5e1a34065e1e1c0,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});