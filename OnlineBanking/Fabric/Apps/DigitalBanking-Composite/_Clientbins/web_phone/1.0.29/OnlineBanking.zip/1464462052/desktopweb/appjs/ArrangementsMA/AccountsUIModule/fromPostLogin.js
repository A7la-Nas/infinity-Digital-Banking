define("ArrangementsMA/AccountsUIModule/fromPostLogin", function() {
    return function(controller) {
        function addWidgetsfromPostLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var Button0aef029594c244f = new kony.ui.Button({
                "height": "50dp",
                "id": "Button0aef029594c244f",
                "isVisible": true,
                "left": "499dp",
                "text": "Button",
                "top": "453dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Button0aef029594c244f);
        };
        return [{
            "addWidgets": addWidgetsfromPostLogin,
            "enabledForIdleTimeout": false,
            "id": "fromPostLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});