define("TradeFinanceMA/ExportLCUIModule/frmExportLCCreateDrawings", function() {
    return function(controller) {
        function addWidgetsfrmExportLCCreateDrawings() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "121dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "23dp",
                "width": "25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblSubHeader = new kony.ui.Label({
                "id": "lblSubHeader",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel424242SSPRegular20px",
                "text": "Export LC - Create New Drawing",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSubHeader.add(lblSubHeader);
            var flxSuccess = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSuccess",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuccess.setDefaultUnit(kony.flex.DP);
            var flxExportSuccess = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "90dp",
                "id": "flxExportSuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportSuccess.setDefaultUnit(kony.flex.DP);
            var imgSuccessIcon = new kony.ui.Image2({
                "bottom": "20dp",
                "height": "50dp",
                "id": "imgSuccessIcon",
                "isVisible": true,
                "left": "20dp",
                "src": "success_icon.png",
                "top": "20dp",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExportSuccess = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExportSuccess",
                "isVisible": true,
                "left": "91dp",
                "text": "Your Export Drawing has been  saved successfully",
                "top": "43dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseBtn = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "29dp",
                "id": "flxCloseBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "61%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "29dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseBtn.setDefaultUnit(kony.flex.DP);
            var imgbtnClose = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgbtnClose",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseBtn.add(imgbtnClose);
            flxExportSuccess.add(imgSuccessIcon, lblExportSuccess, flxCloseBtn);
            flxSuccess.add(flxExportSuccess);
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var flxExportError = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "90dp",
                "id": "flxExportError",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "bottom": "20dp",
                "height": "50dp",
                "id": "imgError",
                "isVisible": true,
                "left": "20dp",
                "src": "error_cross_1x.png",
                "top": "20dp",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "91dp",
                "text": "Your Export Drawing has been  saved successfully",
                "top": "43dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "29dp",
                "id": "flxClose1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "61%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "29dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose1.setDefaultUnit(kony.flex.DP);
            var imgCross1 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgCross1",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose1.add(imgCross1);
            flxExportError.add(imgError, lblErrorMsg, flxClose1);
            flxError.add(flxExportError);
            var flxLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummary.setDefaultUnit(kony.flex.DP);
            var flxSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryLbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummaryLbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryLbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "LC Summary",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLCViewDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCViewDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCViewDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewLCDetails",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View LC Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCViewDetails.add(lblViewLCDetails);
            flxLCSummaryLbl.add(lblLCSummary, flxLCViewDetails);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var flxLCSummaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxLCSummaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryDetails.setDefaultUnit(kony.flex.DP);
            var flxRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow1.setDefaultUnit(kony.flex.DP);
            var flxApplicant = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApplicant",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicant.setDefaultUnit(kony.flex.DP);
            var flxApplicantLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApplicantLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantLabel.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "height": "18dp",
                "id": "lblApplicant",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Applicant:",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantLabel.add(lblApplicant);
            var flxAppliciantValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxAppliciantValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAppliciantValue.setDefaultUnit(kony.flex.DP);
            var lblApplicantValue = new kony.ui.Label({
                "id": "lblApplicantValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Katie Floyd",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAppliciantValue.add(lblApplicantValue);
            flxApplicant.add(flxApplicantLabel, flxAppliciantValue);
            flxRow1.add(flxApplicant);
            var flxRow2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow2.setDefaultUnit(kony.flex.DP);
            var flxAdvising = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvising",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvising.setDefaultUnit(kony.flex.DP);
            var flxAdvisingLCRefNo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvisingLCRefNo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "120dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvisingLCRefNo.setDefaultUnit(kony.flex.DP);
            var lblAdvisingLCRefNo = new kony.ui.Label({
                "id": "lblAdvisingLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Advising LC Ref No: ",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvisingLCRefNo.add(lblAdvisingLCRefNo);
            var flxAdvisingLCValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvisingLCValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvisingLCValue.setDefaultUnit(kony.flex.DP);
            var lblAdvisingLCValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblAdvisingLCValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "LC000100001",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvisingLCValue.add(lblAdvisingLCValue);
            flxAdvising.add(flxAdvisingLCRefNo, flxAdvisingLCValue);
            var flxLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmount.setDefaultUnit(kony.flex.DP);
            var flxLCAmountLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmountLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "78dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmountLabel.setDefaultUnit(kony.flex.DP);
            var lblLcAmount = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLcAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmountLabel.add(lblLcAmount);
            var flxLCAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmountValue.setDefaultUnit(kony.flex.DP);
            var lblLCAmountValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCAmountValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmountValue.add(lblLCAmountValue);
            flxLCAmount.add(flxLCAmountLabel, flxLCAmountValue);
            var flxLCUtilizedAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCUtilizedAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCUtilizedAmount.setDefaultUnit(kony.flex.DP);
            var flxLCUtilizedAmountLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCUtilizedAmountLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "120dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCUtilizedAmountLabel.setDefaultUnit(kony.flex.DP);
            var lblLCUtilizedAmount = new kony.ui.Label({
                "id": "lblLCUtilizedAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LCUtilizedAmount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCUtilizedAmountLabel.add(lblLCUtilizedAmount);
            var flxLCUtilizedAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCUtilizedAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCUtilizedAmountValue.setDefaultUnit(kony.flex.DP);
            var lblLCUtilizedAmountValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCUtilizedAmountValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCUtilizedAmountValue.add(lblLCUtilizedAmountValue);
            flxLCUtilizedAmount.add(flxLCUtilizedAmountLabel, flxLCUtilizedAmountValue);
            flxRow2.add(flxAdvising, flxLCAmount, flxLCUtilizedAmount);
            var flxRow3 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow3.setDefaultUnit(kony.flex.DP);
            var flxLCType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCType.setDefaultUnit(kony.flex.DP);
            var flxLCTypeLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCTypeLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCTypeLabel.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "LC Type:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCTypeLabel.add(lblLCType);
            var flxLCTypeValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCTypeValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCTypeValue.setDefaultUnit(kony.flex.DP);
            var lblLCTypeValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Sight",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCTypeValue.add(lblLCTypeValue);
            flxLCType.add(flxLCTypeLabel, flxLCTypeValue);
            var flxIssueDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDate.setDefaultUnit(kony.flex.DP);
            var flxIssueDateLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDateLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDateLabel.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssueDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Issue Date: ",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssueDateLabel.add(lblIssueDate);
            var flxIssueDateValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDateValue.setDefaultUnit(kony.flex.DP);
            var lblIssueDateValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssueDateValue.add(lblIssueDateValue);
            flxIssueDate.add(flxIssueDateLabel, flxIssueDateValue);
            var flxExpiryDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExpiryDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDate.setDefaultUnit(kony.flex.DP);
            var flxExpiryDateLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxExpiryDateLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "78dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDateLabel.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDateLabel.add(lblExpiryDate);
            var flxExpiryDateValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxExpiryDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDateValue.setDefaultUnit(kony.flex.DP);
            var lblExpiryDateValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "12/31/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDateValue.add(lblExpiryDateValue);
            flxExpiryDate.add(flxExpiryDateLabel, flxExpiryDateValue);
            flxRow3.add(flxLCType, flxIssueDate, flxExpiryDate);
            var flxRow4 = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "18px",
                "id": "flxRow4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow4.setDefaultUnit(kony.flex.DP);
            var flxIssuingBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssuingBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingBank.setDefaultUnit(kony.flex.DP);
            var flxIssuingBankLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxIssuingBankLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "87dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingBankLabel.setDefaultUnit(kony.flex.DP);
            var lblIssuingBank = new kony.ui.Label({
                "id": "lblIssuingBank",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Issuing Bank:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingBankLabel.add(lblIssuingBank);
            var flxIssuingBankValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxIssuingBankValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingBankValue.setDefaultUnit(kony.flex.DP);
            var lblIssuingBankValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssuingBankValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Bank of America",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingBankValue.add(lblIssuingBankValue);
            flxIssuingBank.add(flxIssuingBankLabel, flxIssuingBankValue);
            var flxIssuingLCRefNo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssuingLCRefNo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNo.setDefaultUnit(kony.flex.DP);
            var flxIssuingLCRefNoLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxIssuingLCRefNoLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "110dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNoLabel.setDefaultUnit(kony.flex.DP);
            var lblIssuingLCRefNo = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssuingLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Issuing LC ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNoLabel.add(lblIssuingLCRefNo);
            var flxIssuingLCRefNoValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxIssuingLCRefNoValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNoValue.setDefaultUnit(kony.flex.DP);
            var lblIssuingLCRefNoValue = new kony.ui.Label({
                "height": "18dp",
                "id": "lblIssuingLCRefNoValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "5678098765",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNoValue.add(lblIssuingLCRefNoValue);
            flxIssuingLCRefNo.add(flxIssuingLCRefNoLabel, flxIssuingLCRefNoValue);
            flxRow4.add(flxIssuingBank, flxIssuingLCRefNo);
            flxLCSummaryDetails.add(flxRow1, flxRow2, flxRow3, flxRow4);
            flxSummaryHeader.add(flxLCSummaryLbl, flxBottomSeparator, flxLCSummaryDetails);
            flxLCSummary.add(flxSummaryHeader);
            var flxCreateDrawingSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateDrawingSection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDrawingSection.setDefaultUnit(kony.flex.DP);
            var flxCreateDrawingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxCreateDrawingHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDrawingHeader.setDefaultUnit(kony.flex.DP);
            var flxCreateNewDrawing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCreateNewDrawing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateNewDrawing.setDefaultUnit(kony.flex.DP);
            var lblCreateNewDrawing = new kony.ui.Label({
                "id": "lblCreateNewDrawing",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Create New Drawing",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreateNewDrawing.add(lblCreateNewDrawing);
            var flxSave = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSave",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "95dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSave.setDefaultUnit(kony.flex.DP);
            var lblSave = new kony.ui.Label({
                "id": "lblSave",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "Save",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSave.add(lblSave);
            var flxCreateDrawingSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxCreateDrawingSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "50dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDrawingSeparator.setDefaultUnit(kony.flex.DP);
            flxCreateDrawingSeparator.add();
            flxCreateDrawingHeader.add(flxCreateNewDrawing, flxSave, flxCreateDrawingSeparator);
            var flxDrawingAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 4,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingAmount.setDefaultUnit(kony.flex.DP);
            var flxDrawingAmountHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDrawingAmountHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingAmountHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingAmount = new kony.ui.Label({
                "id": "lblDrawingAmount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "The Drawing Amount",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingAmountHeader.add(lblDrawingAmount);
            var flxCurrencyAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCurrencyAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyAmount.setDefaultUnit(kony.flex.DP);
            var flxCcyAmntHorizontal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxCcyAmntHorizontal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCcyAmntHorizontal.setDefaultUnit(kony.flex.DP);
            var flxCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "120dp",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrency.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblCurrency",
                "isVisible": true,
                "left": "2.50%",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Currency",
                "top": "20dp",
                "width": "250px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxCurrency = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxCurrency",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2.50%",
                "secureTextEntry": false,
                "skin": "ICSknTextBoxSSPR42424215px",
                "text": "$",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "8dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxDropdownCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDropdownCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Border",
                "top": "8dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownCurrency.setDefaultUnit(kony.flex.DP);
            var lblSelectedValueCurrency = new kony.ui.Label({
                "id": "lblSelectedValueCurrency",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDropdownIconCurrency = new kony.ui.Image2({
                "height": "7dp",
                "id": "imgDropdownIconCurrency",
                "isVisible": true,
                "right": "13dp",
                "src": "dropdown_expand.png",
                "top": "15dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownCurrency.add(lblSelectedValueCurrency, imgDropdownIconCurrency);
            var flxDropdownListCurrency = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "80dp",
                "horizontalScrollIndicator": true,
                "id": "flxDropdownListCurrency",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownListCurrency.setDefaultUnit(kony.flex.DP);
            var segDropdownListCurrency = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblListValue": "Label"
                }, {
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "height": "122dp",
                "id": "segDropdownListCurrency",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValue"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDropdownValue": "flxDropdownValue",
                    "lblListValue": "lblListValue"
                },
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownListCurrency.add(segDropdownListCurrency);
            flxCurrency.add(lblCurrency, tbxCurrency, flxDropdownCurrency, flxDropdownListCurrency);
            var flxAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.64%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "32.67%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblAmount",
                "isVisible": true,
                "left": 0,
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Drawing Amount",
                "top": "20dp",
                "width": "250px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter here",
                "secureTextEntry": false,
                "skin": "ICSknTextBoxSSPR42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "8dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxSSP42424213px"
            });
            flxAmount.add(lblAmount, tbxAmount);
            flxCcyAmntHorizontal.add(flxCurrency, flxAmount);
            flxCurrencyAmount.add(flxCcyAmntHorizontal);
            var flxCheckContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "44dp",
                "id": "flxCheckContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckContent.setDefaultUnit(kony.flex.DP);
            var flxCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "26dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "3%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var imgCheckBox = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgCheckBox",
                "isVisible": false,
                "left": "0",
                "src": "inactive.png",
                "top": "0",
                "width": "21dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCheckBox = new kony.ui.Label({
                "height": "20dp",
                "id": "lblCheckBox",
                "isVisible": true,
                "left": "0dp",
                "skin": "skn0273e320pxolbfonticons",
                "text": "D",
                "top": "2dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(imgCheckBox, lblCheckBox);
            var flxLblContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxLblContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "33dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblContent.setDefaultUnit(kony.flex.DP);
            var lblDrawingContent = new kony.ui.Label({
                "id": "lblDrawingContent",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Please Finance us for the draft amount by the negotiation with full resources to us",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblContent.add(lblDrawingContent);
            flxCheckContent.add(flxCheckBox, flxLblContent);
            flxDrawingAmount.add(flxDrawingAmountHeader, flxCurrencyAmount, flxCheckContent);
            var flxAmountCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCredited",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "23dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCredited.setDefaultUnit(kony.flex.DP);
            var flxAmountCreditedMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCreditedMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCreditedMain.setDefaultUnit(kony.flex.DP);
            var flxAssignInfoUploadMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAssignInfoUploadMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "270dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "70dp",
                "width": "300dp",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignInfoUploadMsg.setDefaultUnit(kony.flex.DP);
            var flxAssignUploadInfoHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxAssignUploadInfoHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignUploadInfoHeader.setDefaultUnit(kony.flex.DP);
            var lblAssignInfo = new kony.ui.Label({
                "id": "lblAssignInfo",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblSSP42424213pxBold",
                "text": "Information",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssignUploadInfoHeader.add(lblAssignInfo);
            var flxAssignInfoClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "15dp",
                "id": "flxAssignInfoClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignInfoClose.setDefaultUnit(kony.flex.DP);
            var imgAssignInfoClose = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgAssignInfoClose",
                "isVisible": true,
                "left": "0",
                "src": "bbcloseicon.png",
                "top": "0",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssignInfoClose.add(imgAssignInfoClose);
            var flxAssignInfoContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAssignInfoContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignInfoContent.setDefaultUnit(kony.flex.DP);
            var richTextAssignInfo = new kony.ui.RichText({
                "height": "40dp",
                "id": "richTextAssignInfo",
                "isVisible": true,
                "left": "0",
                "skin": "sknRtx42424212px",
                "text": "Select the account to which the amount is to be credited.",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssignInfoContent.add(richTextAssignInfo);
            flxAssignInfoUploadMsg.add(flxAssignUploadInfoHeader, flxAssignInfoClose, flxAssignInfoContent);
            var flxAmountCreditedContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCreditedContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCreditedContent.setDefaultUnit(kony.flex.DP);
            var flxAmountToBeCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAmountToBeCredited",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountToBeCredited.setDefaultUnit(kony.flex.DP);
            var lblAmountToBeCredited = new kony.ui.Label({
                "id": "lblAmountToBeCredited",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Amount to be Credited to",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountToBeCredited.add(lblAmountToBeCredited);
            var flxCreditAccAssign = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxCreditAccAssign",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-11dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditAccAssign.setDefaultUnit(kony.flex.DP);
            var flxCreditAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxCreditAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditAccount.setDefaultUnit(kony.flex.DP);
            var flxCreditRadio = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCreditRadio",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditRadio.setDefaultUnit(kony.flex.DP);
            var lblCreditRadio = new kony.ui.Label({
                "height": "20dp",
                "id": "lblCreditRadio",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreditRadio.add(lblCreditRadio);
            var flxCreditAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "22dp",
                "id": "flxCreditAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditAmount.setDefaultUnit(kony.flex.DP);
            var lblCreditAccount = new kony.ui.Label({
                "id": "lblCreditAccount",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Credit Account",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreditAmount.add(lblCreditAccount);
            flxCreditAccount.add(flxCreditRadio, flxCreditAmount);
            var flxAssigneeToProceeds = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAssigneeToProceeds",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "150dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssigneeToProceeds.setDefaultUnit(kony.flex.DP);
            var flxAssignProceedsRadio = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAssignProceedsRadio",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignProceedsRadio.setDefaultUnit(kony.flex.DP);
            var lblAssignRadio = new kony.ui.Label({
                "height": "20dp",
                "id": "lblAssignRadio",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssignProceedsRadio.add(lblAssignRadio);
            var flxAssignProceedsLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "22dp",
                "id": "flxAssignProceedsLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignProceedsLabel.setDefaultUnit(kony.flex.DP);
            var lblAssignProceeds = new kony.ui.Label({
                "id": "lblAssignProceeds",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Assignment of proceeds",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssignProceedsLabel.add(lblAssignProceeds);
            var flxInfoIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "200dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "24dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoIcon.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "0",
                "src": "info_large.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoIcon.add(imgInfoIcon);
            flxAssigneeToProceeds.add(flxAssignProceedsRadio, flxAssignProceedsLabel, flxInfoIcon);
            flxCreditAccAssign.add(flxCreditAccount, flxAssigneeToProceeds);
            var flxCreditAssigneeSelection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreditAssigneeSelection",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "32%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditAssigneeSelection.setDefaultUnit(kony.flex.DP);
            var flxCreditRadioSelected = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "65dp",
                "id": "flxCreditRadioSelected",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "zIndex": 6,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditRadioSelected.setDefaultUnit(kony.flex.DP);
            var flxSelecetCreditAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSelecetCreditAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Border",
                "top": "5dp",
                "width": "98%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelecetCreditAccount.setDefaultUnit(kony.flex.DP);
            var lblSelectCreditAccount = new kony.ui.Label({
                "id": "lblSelectCreditAccount",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Select Credit Account",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCreditAccountDropDown = new kony.ui.Image2({
                "height": "7dp",
                "id": "imgCreditAccountDropDown",
                "isVisible": true,
                "right": "13dp",
                "src": "dropdown_expand.png",
                "top": "15dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelecetCreditAccount.add(lblSelectCreditAccount, imgCreditAccountDropDown);
            var flxSegCreditAccount = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "122dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegCreditAccount",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.60%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxSegCreditAccount.setDefaultUnit(kony.flex.DP);
            var segCreditAccounts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblListValue": "Label"
                }, {
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "height": "122dp",
                "id": "segCreditAccounts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValueNew"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDropdownValueNew": "flxDropdownValueNew",
                    "lblListValue": "lblListValue"
                },
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegCreditAccount.add(segCreditAccounts);
            flxCreditRadioSelected.add(flxSelecetCreditAccount, flxSegCreditAccount);
            var flxAssignProceedsRadioSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxAssignProceedsRadioSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 5,
                "width": "92%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignProceedsRadioSelected.setDefaultUnit(kony.flex.DP);
            var txtAreaAssignmentofProceeds = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "70dp",
                "id": "txtAreaAssignmentofProceeds",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Enter here\n(Other beneficiary name/ internal/ external account)",
                "skin": "ICSknTxtAreaE3E3E3Border1px424242SSPRegular13px",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtAreaPlaceholderSSP94949415px"
            });
            flxAssignProceedsRadioSelected.add(txtAreaAssignmentofProceeds);
            flxCreditAssigneeSelection.add(flxCreditRadioSelected, flxAssignProceedsRadioSelected);
            flxAmountCreditedContent.add(flxAmountToBeCredited, flxCreditAccAssign, flxCreditAssigneeSelection);
            flxAmountCreditedMain.add(flxAssignInfoUploadMsg, flxAmountCreditedContent);
            flxAmountCredited.add(flxAmountCreditedMain);
            var flxUploadDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocuments.setDefaultUnit(kony.flex.DP);
            var flxUploadMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadMain.setDefaultUnit(kony.flex.DP);
            var flxInfoUploadMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxInfoUploadMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "160dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "40dp",
                "width": "300dp",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoUploadMsg.setDefaultUnit(kony.flex.DP);
            var UploadInfoHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "UploadInfoHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            UploadInfoHeader.setDefaultUnit(kony.flex.DP);
            var lblInfo2 = new kony.ui.Label({
                "id": "lblInfo2",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblSSP42424213pxBold",
                "text": "Information",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            UploadInfoHeader.add(lblInfo2);
            var flxInfoClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "15dp",
                "id": "flxInfoClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoClose.setDefaultUnit(kony.flex.DP);
            var imgInfoClose2 = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgInfoClose2",
                "isVisible": true,
                "left": "0",
                "src": "bbcloseicon.png",
                "top": "0",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoClose.add(imgInfoClose2);
            var flxInfoContent2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInfoContent2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoContent2.setDefaultUnit(kony.flex.DP);
            var RichText0baa69493ab2240 = new kony.ui.RichText({
                "height": "40dp",
                "id": "RichText0baa69493ab2240",
                "isVisible": true,
                "left": "0",
                "skin": "sknRtx42424212px",
                "text": "Please check and upload document in required format",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoContent2.add(RichText0baa69493ab2240);
            flxInfoUploadMsg.add(UploadInfoHeader, flxInfoClose, flxInfoContent2);
            var flxUploadDocContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocContent.setDefaultUnit(kony.flex.DP);
            var flxUploadScannedDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxUploadScannedDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "366dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadScannedDocs.setDefaultUnit(kony.flex.DP);
            var lblUploadScannedDocs = new kony.ui.Label({
                "height": "20dp",
                "id": "lblUploadScannedDocs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Upload Scanned documents",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadInfoIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxUploadInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadInfoIcon.setDefaultUnit(kony.flex.DP);
            var imgUploadIcon = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgUploadIcon",
                "isVisible": true,
                "left": "0",
                "src": "info_large.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadInfoIcon.add(imgUploadIcon);
            flxUploadScannedDocs.add(lblUploadScannedDocs, flxUploadInfoIcon);
            var flxUploadSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadSection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "400dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadSection.setDefaultUnit(kony.flex.DP);
            var flxUploadDocSeg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocSeg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocSeg.setDefaultUnit(kony.flex.DP);
            var segUploadDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDelete": "bin.png",
                    "imgPDF": "pdf.png",
                    "imgTickmark": "confirmation_tick.png",
                    "lblDocumentName": "Clearance Statement.pdf"
                }],
                "groupCells": false,
                "id": "segUploadDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportLCDrawingsUploadDocument"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDelete": "flxDelete",
                    "flxDocContent": "flxDocContent",
                    "flxDocumentName": "flxDocumentName",
                    "flxExportLCDrawingsUploadDocument": "flxExportLCDrawingsUploadDocument",
                    "flxMain": "flxMain",
                    "flxPDFImage": "flxPDFImage",
                    "flxTickmark": "flxTickmark",
                    "imgDelete": "imgDelete",
                    "imgPDF": "imgPDF",
                    "imgTickmark": "imgTickmark",
                    "lblDocumentName": "lblDocumentName"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDocSeg.add(segUploadDocs);
            var flxUploadButton = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "41dp",
                "id": "flxUploadButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadButton.setDefaultUnit(kony.flex.DP);
            var btnUpload = new kony.ui.Button({
                "height": "100%",
                "id": "btnUpload",
                "isVisible": true,
                "left": "0",
                "right": "190dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Upload Document",
                "top": "0dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadButton.add(btnUpload);
            flxUploadSection.add(flxUploadDocSeg, flxUploadButton);
            flxUploadDocContent.add(flxUploadScannedDocs, flxUploadSection);
            flxUploadMain.add(flxInfoUploadMsg, flxUploadDocContent);
            flxUploadDocuments.add(flxUploadMain);
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var flxBottomContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBottomContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomContent.setDefaultUnit(kony.flex.DP);
            var flxPhysicalDocTitleContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalDocTitleContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocTitleContent.setDefaultUnit(kony.flex.DP);
            var flxPhysicalDocHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPhysicalDocHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocHeader.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocTitle = new kony.ui.Label({
                "id": "lblPhysicalDocTitle",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Physical Document Title, Originals and Copies Count will submit to the bank",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalDocHeader.add(lblPhysicalDocTitle);
            var flxSelectDocContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelectDocContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectDocContent.setDefaultUnit(kony.flex.DP);
            var lblDocumentError = new kony.ui.Label({
                "id": "lblDocumentError",
                "isVisible": false,
                "left": "0",
                "skin": "ICSknLblErrorNew",
                "text": "Alert: Please add at least one Title from the List or Manually",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSegSelectDocTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegSelectDocTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSelectDocTitle.setDefaultUnit(kony.flex.DP);
            var segSelectDocTitle = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segSelectDocTitle",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSelectDocumentTitle"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxCopiesCount": "flxCopiesCount",
                    "flxDelete": "flxDelete",
                    "flxMain": "flxMain",
                    "flxOriginalCount": "flxOriginalCount",
                    "flxSelectDocTitle": "flxSelectDocTitle",
                    "flxSelectDocument": "flxSelectDocument",
                    "flxSelectDocumentTitle": "flxSelectDocumentTitle",
                    "flxTextField": "flxTextField",
                    "lblCopiesCount": "lblCopiesCount",
                    "lblDelete": "lblDelete",
                    "lblDropDown1": "lblDropDown1",
                    "lblDropDown2": "lblDropDown2",
                    "lblDropDown3": "lblDropDown3",
                    "lblOriginalsCount": "lblOriginalsCount",
                    "lblSelectEnter": "lblSelectEnter",
                    "tbxEnterTitle": "tbxEnterTitle"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSelectDocTitle.add(segSelectDocTitle);
            flxSelectDocContent.add(lblDocumentError, flxSegSelectDocTitle);
            var flxAddTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddTitle.setDefaultUnit(kony.flex.DP);
            var flxAddTitleList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAddTitleList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "150dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddTitleList.setDefaultUnit(kony.flex.DP);
            var btnAdd1 = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnAdd1",
                "isVisible": true,
                "left": "0dp",
                "right": "10dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Add Title from List",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTitleList.add(btnAdd1);
            var flxAddTitleManual = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAddTitleManual",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "150dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddTitleManual.setDefaultUnit(kony.flex.DP);
            var btnAdd2 = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnAdd2",
                "isVisible": true,
                "left": "0dp",
                "right": "10dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Add Title Manually",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTitleManual.add(btnAdd2);
            flxAddTitle.add(flxAddTitleList, flxAddTitleManual);
            var flxCheckContent2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "44dp",
                "id": "flxCheckContent2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckContent2.setDefaultUnit(kony.flex.DP);
            var flxCheckBox2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "24dp",
                "id": "flxCheckBox2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "2%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox2.setDefaultUnit(kony.flex.DP);
            var imgPhysicalCheckbox = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgPhysicalCheckbox",
                "isVisible": false,
                "left": "0",
                "src": "inactive.png",
                "top": "0",
                "width": "21dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhysicalCheckbox = new kony.ui.Label({
                "height": "20dp",
                "id": "lblPhysicalCheckbox",
                "isVisible": true,
                "left": "0",
                "skin": "skn0273e320pxolbfonticons",
                "text": "D",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox2.add(imgPhysicalCheckbox, lblPhysicalCheckbox);
            var flxLabelContent2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxLabelContent2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "31dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLabelContent2.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocContent = new kony.ui.Label({
                "id": "lblPhysicalDocContent",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Kindly forward documents to issuing bank as presented despite any discrepancy(ies) noted",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLabelContent2.add(lblPhysicalDocContent);
            flxCheckContent2.add(flxCheckBox2, flxLabelContent2);
            flxPhysicalDocTitleContent.add(flxPhysicalDocHeader, flxSelectDocContent, flxAddTitle, flxCheckContent2);
            var flxChargesAccount = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxChargesAccount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "98%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesAccount.setDefaultUnit(kony.flex.DP);
            var flxChargesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxChargesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesHeader.setDefaultUnit(kony.flex.DP);
            var lblChargesAccount = new kony.ui.Label({
                "id": "lblChargesAccount",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Charges Account and Message to Bank",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChargesHeader.add(lblChargesAccount);
            var flxChargesContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "32dp",
                "clipBounds": false,
                "id": "flxChargesContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesContent.setDefaultUnit(kony.flex.DP);
            var flxChargesDebitAcc = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "65dp",
                "id": "flxChargesDebitAcc",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesDebitAcc.setDefaultUnit(kony.flex.DP);
            var lblChargesDebitAcc = new kony.ui.Label({
                "id": "lblChargesDebitAcc",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Charges Debit Account",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "15dp",
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxff0000ErrorMsg",
                "top": "0dp",
                "width": "64.40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblWarning",
                "isVisible": true,
                "left": "2.54%",
                "skin": "sknlblff000015px",
                "text": "Please select the details below to proceed",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(lblWarning);
            var flxBankAccountValueContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "45dp",
                "id": "flxBankAccountValueContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankAccountValueContent.setDefaultUnit(kony.flex.DP);
            var flxBankAccountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBankAccountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Border",
                "top": "0dp",
                "width": "40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankAccountValue.setDefaultUnit(kony.flex.DP);
            var lblBankAccountValue = new kony.ui.Label({
                "id": "lblBankAccountValue",
                "isVisible": true,
                "left": "3.10%",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Select here",
                "top": 10,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankAccountDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7dp",
                "id": "flxBankAccountDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankAccountDropDown.setDefaultUnit(kony.flex.DP);
            var imgBankAccountDropDown = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBankAccountDropDown",
                "isVisible": true,
                "left": "0",
                "src": "listboxuparrow.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankAccountDropDown.add(imgBankAccountDropDown);
            flxBankAccountValue.add(lblBankAccountValue, flxBankAccountDropDown);
            var flxSegDebitedFromDropdown = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "122dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegDebitedFromDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "40dp",
                "verticalScrollIndicator": true,
                "width": "40%",
                "zIndex": 25
            }, {
                "paddingInPixel": false
            }, {});
            flxSegDebitedFromDropdown.setDefaultUnit(kony.flex.DP);
            var segDebitedFromDropdown = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblListValue": "Label"
                }, {
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "height": "122dp",
                "id": "segDebitedFromDropdown",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValueNew"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDropdownValueNew": "flxDropdownValueNew",
                    "lblListValue": "lblListValue"
                },
                "widgetSkin": "sknSegffffff",
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegDebitedFromDropdown.add(segDebitedFromDropdown);
            flxBankAccountValueContent.add(flxBankAccountValue, flxSegDebitedFromDropdown);
            flxChargesDebitAcc.add(lblChargesDebitAcc, flxWarning, flxBankAccountValueContent);
            var flxMessageToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMessageToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageToBank.setDefaultUnit(kony.flex.DP);
            var lblMessageToBank = new kony.ui.Label({
                "id": "lblMessageToBank",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Message to Bank (Optional)",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMessageToBankContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMessageToBankContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageToBankContent.setDefaultUnit(kony.flex.DP);
            var flxMessageToBankValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMessageToBankValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "40.40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageToBankValue.setDefaultUnit(kony.flex.DP);
            var txtMessageToBankValue = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "75dp",
                "id": "txtMessageToBankValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "maxTextLength": 50,
                "numberOfVisibleLines": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "skin": "ICSknTxtAreaE3E3E3Border1px424242SSPRegular13px",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [3, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTextAreaPlaceholder727272SSPR36px"
            });
            flxMessageToBankValue.add(txtMessageToBankValue);
            flxMessageToBankContent.add(flxMessageToBankValue);
            flxMessageToBank.add(lblMessageToBank, flxMessageToBankContent);
            flxChargesContent.add(flxChargesDebitAcc, flxMessageToBank);
            flxChargesAccount.add(flxChargesHeader, flxChargesContent);
            var flxActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var flxCreateDrawingBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxCreateDrawingBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDrawingBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxCreateDrawingBottomSeparator.add();
            var flxCreateDrawingButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxCreateDrawingButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDrawingButtons.setDefaultUnit(kony.flex.DP);
            var btnCreateDrawingClose = new kony.ui.Button({
                "bottom": "0",
                "centerY": "50%",
                "focusSkin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "height": "40dp",
                "id": "btnCreateDrawingClose",
                "isVisible": true,
                "right": "200dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Close",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateDrawingSubmit = new kony.ui.Button({
                "bottom": "0",
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnCreateDrawingSubmit",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknbtnDisablede2e9f036px",
                "text": "Save & Continue",
                "width": "160dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreateDrawingButtons.add(btnCreateDrawingClose, btnCreateDrawingSubmit);
            flxActions.add(flxCreateDrawingBottomSeparator, flxCreateDrawingButtons);
            flxBottomContent.add(flxPhysicalDocTitleContent, flxChargesAccount, flxActions);
            var flxSegDocTitleDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegDocTitleDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdcBottomRadius",
                "top": "130dp",
                "width": "26%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegDocTitleDropdown.setDefaultUnit(kony.flex.DP);
            var segDocTitleDropdown = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segDocTitleDropdown",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Normal",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDocumentDropDown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegDocTitleDropdown.add(segDocTitleDropdown);
            var flxSegSelectOriginal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegSelectOriginal",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30.50%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdcBottomRadius",
                "top": "130dp",
                "width": "13.30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSelectOriginal.setDefaultUnit(kony.flex.DP);
            var segSelectOriginalCopies = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segSelectOriginalCopies",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Normal",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDocumentDropDown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocumentDropDown": "flxDocumentDropDown",
                    "flxLabel": "flxLabel",
                    "flxMain": "flxMain",
                    "lblField": "lblField"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSelectOriginal.add(segSelectOriginalCopies);
            var flxSegCopiesCount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegCopiesCount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46.90%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdcBottomRadius",
                "top": "130dp",
                "width": "13.30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegCopiesCount.setDefaultUnit(kony.flex.DP);
            var segCopiesCount = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segCopiesCount",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Normal",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDocumentDropDown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocumentDropDown": "flxDocumentDropDown",
                    "flxLabel": "flxLabel",
                    "flxMain": "flxMain",
                    "lblField": "lblField"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegCopiesCount.add(segCopiesCount);
            flxBottom.add(flxBottomContent, flxSegDocTitleDropdown, flxSegSelectOriginal, flxSegCopiesCount);
            flxCreateDrawingSection.add(flxCreateDrawingHeader, flxDrawingAmount, flxAmountCredited, flxUploadDocuments, flxBottom);
            flxMain.add(flxSubHeader, flxSuccess, flxError, flxLCSummary, flxCreateDrawingSection);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "268dp",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "44.30%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "height": "268dp",
                        "width": "44.30%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxClose",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var ClosePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268dp",
                "id": "ClosePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "44.30%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "268dp",
                        "isVisible": true,
                        "width": "44.30%"
                    },
                    "btnNo": {
                        "text": "Close without Saving"
                    },
                    "btnYes": {
                        "text": "Save as Draft & Close"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                    },
                    "lblPopupMessage": {
                        "text": "Save the Export Drawing as draft before closing or close this without saved."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxClose.add(ClosePopup);
            var flxSaveDraft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxSaveDraft",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 15000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSaveDraft.setDefaultUnit(kony.flex.DP);
            var SaveDraftPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268dp",
                "id": "SaveDraftPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "44.30%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "268dp",
                        "width": "44.30%"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.SaveDraft\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AreYouSureYouWantToSaveThisDraft\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSaveDraft.add(SaveDraftPopup);
            var flxUploadDocumentPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxUploadDocumentPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocumentPopup.setDefaultUnit(kony.flex.DP);
            var UploadDocumentPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "268dp",
                "id": "UploadDocumentPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "44.30%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "268dp",
                        "width": "44.30%"
                    },
                    "btnNo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                    },
                    "btnYes": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.TryAgain\")"
                    },
                    "lblHeading": {
                        "text": "Upload Document"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxUploadDocumentPopup.add(UploadDocumentPopup);
            var flxViewLCDetailsPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewLCDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "630dp",
                "horizontalScrollIndicator": true,
                "id": "flxLCDetailsPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknNoBorder",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "50%"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxLCDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblLCDetailsHeader = new kony.ui.Label({
                "id": "lblLCDetailsHeader",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Export LC- LC0000100001",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "12dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCross",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "49dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            flxLCDetailsHeader.add(lblLCDetailsHeader, flxCross, flxSeparator1);
            var flxLCDetailsData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetailsData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsData.setDefaultUnit(kony.flex.DP);
            var flxLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetails.setDefaultUnit(kony.flex.DP);
            var lblLcDetails = new kony.ui.Label({
                "id": "lblLcDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCDetails\")",
                "top": "10dp",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorTop2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorTop2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "93.07%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop2.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop2.add();
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "565dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLeftLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoKey = new kony.ui.Label({
                "id": "lblLCRefNoKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCReferenceNumber\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeKey = new kony.ui.Label({
                "id": "lblLCTypeKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantKey = new kony.ui.Label({
                "id": "lblApplicantKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantAddressKey = new kony.ui.Label({
                "id": "lblApplicantAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Applicant Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankKey = new kony.ui.Label({
                "id": "lblIssuingBankKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankAddressKey = new kony.ui.Label({
                "id": "lblIssuingBankAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateKey = new kony.ui.Label({
                "id": "lblIssueDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Issue Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpireDateKey = new kony.ui.Label({
                "id": "lblExpireDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountKey = new kony.ui.Label({
                "id": "lblLCAmountKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Amount: ",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.add(lblLCRefNoKey, lblLCTypeKey, lblApplicantKey, lblApplicantAddressKey, lblIssuingBankKey, lblIssuingBankAddressKey, lblIssueDateKey, lblExpireDateKey, lblLCAmountKey);
            var flxRightLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "90dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoValue = new kony.ui.Label({
                "id": "lblLCRefNoValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeeValue = new kony.ui.Label({
                "id": "lblLCTypeeValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantValue = new kony.ui.Label({
                "id": "lblLCApplicantValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantAddValue = new kony.ui.Label({
                "id": "lblLCApplicantAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankalue = new kony.ui.Label({
                "id": "lblLCIssueBankalue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankAddValue = new kony.ui.Label({
                "id": "lblLCIssueBankAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueDateValue = new kony.ui.Label({
                "id": "lblLCIssueDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCExpireDateValue = new kony.ui.Label({
                "id": "lblLCExpireDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValuee = new kony.ui.Label({
                "id": "lblLCAmountValuee",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.add(lblLCRefNoValue, lblLCTypeeValue, lblLCApplicantValue, lblLCApplicantAddValue, lblLCIssueBankalue, lblLCIssueBankAddValue, lblLCIssueDateValue, lblLCExpireDateValue, lblLCAmountValuee);
            flxLCSummaryBody.add(flxLeftLCSummary, flxRightLCSummary);
            var flxSeparatorTop3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorTop3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "97.71%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop3.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop3.add();
            flxLCDetails.add(lblLcDetails, flxSeparatorTop2, flxLCSummaryBody, flxSeparatorTop3);
            var flxBeneficiaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryDetails.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryDetails = new kony.ui.Label({
                "id": "lblBeneficiaryDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Beneficiary Details",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorMid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorMid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "40dp",
                "width": "93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMid.setDefaultUnit(kony.flex.DP);
            flxSeparatorMid.add();
            var flxBeneficiaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "60dp",
                "width": "440dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryBody.setDefaultUnit(kony.flex.DP);
            var flxBenLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenLeft.setDefaultUnit(kony.flex.DP);
            var lblBenName = new kony.ui.Label({
                "id": "lblBenName",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddress = new kony.ui.Label({
                "id": "lblBenAddress",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenLeft.add(lblBenName, lblBenAddress);
            var flxBenRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "140dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenRight.setDefaultUnit(kony.flex.DP);
            var lblBenNameValue = new kony.ui.Label({
                "id": "lblBenNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddValue = new kony.ui.Label({
                "id": "lblBenAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenRight.add(lblBenNameValue, lblBenAddValue);
            flxBeneficiaryBody.add(flxBenLeft, flxBenRight);
            var flxSeparatorBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "140dp",
                "width": "98.72%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBen.setDefaultUnit(kony.flex.DP);
            flxSeparatorBen.add();
            flxBeneficiaryDetails.add(lblBeneficiaryDetails, flxSeparatorMid, flxBeneficiaryBody, flxSeparatorBen);
            var flxGoodShipment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipment.setDefaultUnit(kony.flex.DP);
            var lblGoodShipment = new kony.ui.Label({
                "id": "lblGoodShipment",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Good & Shipment Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorGoods = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorGoods",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "45dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorGoods.setDefaultUnit(kony.flex.DP);
            flxSeparatorGoods.add();
            var flxGoodShipmentBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipmentBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipmentBody.setDefaultUnit(kony.flex.DP);
            var flxGoodsLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.setDefaultUnit(kony.flex.DP);
            var lblGoodsDescription = new kony.ui.Label({
                "id": "lblGoodsDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Goods Description:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdditionalCon = new kony.ui.Label({
                "id": "lblAdditionalCon",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Additional Conditions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirm = new kony.ui.Label({
                "id": "lblConfirm",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Confirm Instructions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentDate = new kony.ui.Label({
                "id": "lblShipmentDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Latest Shipment Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.add(lblGoodsDescription, lblAdditionalCon, lblConfirm, lblShipmentDate);
            var flxGoodsRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsRight.setDefaultUnit(kony.flex.DP);
            var lblDescriptionValue = new kony.ui.Label({
                "id": "lblDescriptionValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddValue = new kony.ui.Label({
                "id": "lblAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirmValue = new kony.ui.Label({
                "id": "lblConfirmValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentValue = new kony.ui.Label({
                "id": "lblShipmentValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsRight.add(lblDescriptionValue, lblAddValue, lblConfirmValue, lblShipmentValue);
            flxGoodShipmentBody.add(flxGoodsLeft, flxGoodsRight);
            var flxSeparatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "200dp",
                "width": "97.63%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom.add();
            flxGoodShipment.add(lblGoodShipment, flxSeparatorGoods, flxGoodShipmentBody, flxSeparatorBottom);
            var flxDocumentTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTerms.setDefaultUnit(kony.flex.DP);
            var lblDocumentTerms = new kony.ui.Label({
                "id": "lblDocumentTerms",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Documents and Terms",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument.add();
            var flxDocumentTermsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxDocumentTermsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTermsBody.setDefaultUnit(kony.flex.DP);
            var flxLeftContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContent.setDefaultUnit(kony.flex.DP);
            var lblDocumentName = new kony.ui.Label({
                "id": "lblDocumentName",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Document Name:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadedFiles = new kony.ui.Label({
                "id": "lblUploadedFiles",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Uploaded Files:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftContent.add(lblDocumentName, lblUploadedFiles);
            var flxRightContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContent.setDefaultUnit(kony.flex.DP);
            var lblDocNameValue = new kony.ui.Label({
                "id": "lblDocNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadedDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.setDefaultUnit(kony.flex.DP);
            var segUploadedDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUploadedDocs",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportLCUploadDocPopup"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocContent": "flxDocContent",
                    "flxDocumentName": "flxDocumentName",
                    "flxExportLCUploadDocPopup": "flxExportLCUploadDocPopup",
                    "flxMain": "flxMain",
                    "flxPDFImage": "flxPDFImage",
                    "imgPDF": "imgPDF",
                    "lblDocumentName": "lblDocumentName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.add(segUploadedDocs);
            flxRightContent.add(lblDocNameValue, flxUploadedDocs);
            flxDocumentTermsBody.add(flxLeftContent, flxRightContent);
            var flxSeparatorBottom03 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom03",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom03.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom03.add();
            flxDocumentTerms.add(lblDocumentTerms, flxSeparatorDocument, flxDocumentTermsBody, flxSeparatorBottom03);
            var flxSwiftMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessage.setDefaultUnit(kony.flex.DP);
            var lblSwiftMessage = new kony.ui.Label({
                "id": "lblSwiftMessage",
                "isVisible": true,
                "left": 10,
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "SWIFT Message and Advises Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "35dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument02.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument02.add();
            var flxSwiftMessageBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxSwiftMessageBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageBody.setDefaultUnit(kony.flex.DP);
            var flxSwiftMessageLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessageLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.setDefaultUnit(kony.flex.DP);
            var lblMessageType = new kony.ui.Label({
                "id": "lblMessageType",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Type:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDelivered = new kony.ui.Label({
                "id": "lblDelivered",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Delivered To/From:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDate = new kony.ui.Label({
                "id": "lblSwiftDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoty = new kony.ui.Label({
                "id": "lblMessageCategoty",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Category:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.add(lblMessageType, lblDelivered, lblSwiftDate, lblMessageCategoty);
            var flxSwiftMessagesRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessagesRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.setDefaultUnit(kony.flex.DP);
            var lblMessageTypeValue = new kony.ui.Label({
                "id": "lblMessageTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliveredValue = new kony.ui.Label({
                "id": "lblDeliveredValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDateValue = new kony.ui.Label({
                "id": "lblSwiftDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoryValue = new kony.ui.Label({
                "id": "lblMessageCategoryValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.add(lblMessageTypeValue, lblDeliveredValue, lblSwiftDateValue, lblMessageCategoryValue);
            flxSwiftMessageBody.add(flxSwiftMessageLeft, flxSwiftMessagesRight);
            flxSwiftMessage.add(lblSwiftMessage, flxSeparatorDocument02, flxSwiftMessageBody);
            flxLCDetailsData.add(flxLCDetails, flxBeneficiaryDetails, flxGoodShipment, flxDocumentTerms, flxSwiftMessage);
            flxLCDetailsPopup.add(flxLCDetailsHeader, flxLCDetailsData);
            flxViewLCDetailsPopup.add(flxLCDetailsPopup);
            flxDialogs.add(flxLogout, flxClose, flxSaveDraft, flxUploadDocumentPopup, flxViewLCDetailsPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxExportSuccess": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "src": "success_green.png",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12.00%"
                        },
                        "right": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "segmentProps": []
                    },
                    "flxExportError": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgError": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxClose1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCross1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12.00%"
                        },
                        "right": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "segmentProps": []
                    },
                    "flxCurrencyAmount": {
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "segmentProps": []
                    },
                    "flxDropdownCurrency": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedValueCurrency": {
                        "skin": "ICSknLbl424242SSPRegular13px",
                        "segmentProps": []
                    },
                    "flxDropdownListCurrency": {
                        "segmentProps": []
                    },
                    "segDropdownListCurrency": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65.30%"
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "segmentProps": []
                    },
                    "flxCreditRadioSelected": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSelecetCreditAccount": {
                        "segmentProps": []
                    },
                    "lblSelectCreditAccount": {
                        "segmentProps": []
                    },
                    "flxSegCreditAccount": {
                        "segmentProps": []
                    },
                    "segCreditAccounts": {
                        "segmentProps": []
                    },
                    "btnUpload": {
                        "segmentProps": []
                    },
                    "btnAdd1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAdd2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxChargesContent": {
                        "segmentProps": []
                    },
                    "flxChargesDebitAcc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblChargesDebitAcc": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValueContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankAccountValue": {
                        "segmentProps": []
                    },
                    "imgBankAccountDropDown": {
                        "segmentProps": []
                    },
                    "flxSegDebitedFromDropdown": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "segDebitedFromDropdown": {
                        "segmentProps": []
                    },
                    "flxMessageToBank": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageToBank": {
                        "segmentProps": []
                    },
                    "flxMessageToBankContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "txtMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateDrawingBottomSeparator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateDrawingButtons": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnCreateDrawingClose": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "40.50%"
                        },
                        "segmentProps": []
                    },
                    "btnCreateDrawingSubmit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxSaveDraft": {
                        "segmentProps": []
                    },
                    "flxUploadDocumentPopup": {
                        "segmentProps": []
                    },
                    "UploadDocumentPopup": {
                        "segmentProps": [],
                        "instanceId": "UploadDocumentPopup"
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblLCRefNoKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCRefNoValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeeValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankalue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "Default": {
                            "contentAlignment": 4
                        },
                        "accessibilityConfig": {},
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "text": "User entered message will appear here in two lines with truncation in the en..",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "11.72%"
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "height": {
                            "type": "string",
                            "value": "43.07%"
                        },
                        "left": {
                            "type": "string",
                            "value": "92.87%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "4.25%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxExportError": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgError": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "11.72%"
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxClose1": {
                        "height": {
                            "type": "string",
                            "value": "43.07%"
                        },
                        "left": {
                            "type": "string",
                            "value": "92.87%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "4.25%"
                        },
                        "segmentProps": []
                    },
                    "imgCross1": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "segmentProps": []
                    },
                    "flxLCSummaryDetails": {
                        "segmentProps": []
                    },
                    "flxApplicant": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxApplicantLabel": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxAppliciantValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxRow2": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdvising": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisingLCValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLCAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLCUtilizedAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCUtilizedAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRow3": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCType": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDateValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDateValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxRow4": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingBank": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingBankValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingLCRefNo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingLCRefNoValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateDrawingSection": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxCurrencyAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxCcyAmntHorizontal": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "text": "$",
                        "segmentProps": []
                    },
                    "flxDropdownCurrency": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedValueCurrency": {
                        "segmentProps": []
                    },
                    "flxDropdownListCurrency": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "segmentProps": []
                    },
                    "segDropdownListCurrency": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "width": {
                            "type": "string",
                            "value": "36.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAssigneeSelection": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxSelecetCreditAccount": {
                        "segmentProps": []
                    },
                    "lblSelectCreditAccount": {
                        "segmentProps": []
                    },
                    "flxSegCreditAccount": {
                        "width": {
                            "type": "string",
                            "value": "97.80%"
                        },
                        "segmentProps": []
                    },
                    "txtAreaAssignmentofProceeds": {
                        "placeholder": "Enter here\n(Other beneficiary name/ internal/ external account)",
                        "segmentProps": []
                    },
                    "flxCheckBox2": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblPhysicalCheckbox": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxChargesDebitAcc": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblChargesDebitAcc": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValueContent": {
                        "segmentProps": []
                    },
                    "flxBankAccountValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblBankAccountValue": {
                        "segmentProps": []
                    },
                    "flxSegDebitedFromDropdown": {
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageToBank": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblMessageToBank": {
                        "segmentProps": []
                    },
                    "flxMessageToBankContent": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateDrawingBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSegDocTitleDropdown": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.10%"
                        },
                        "segmentProps": []
                    },
                    "flxSegSelectOriginal": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "31.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSegCopiesCount": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "UploadDocumentPopup": {
                        "segmentProps": [],
                        "instanceId": "UploadDocumentPopup"
                    },
                    "flxViewLCDetailsPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCDetailsPopup": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50.06%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsData": {
                        "segmentProps": []
                    },
                    "flxLCDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTop3": {
                        "segmentProps": []
                    },
                    "flxBeneficiaryDetails": {
                        "segmentProps": []
                    },
                    "flxSeparatorMid": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBen": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipment": {
                        "segmentProps": []
                    },
                    "flxSeparatorGoods": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipmentBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdditionalCon": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirm": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodsRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "lblAddValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "top": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentTerms": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument": {
                        "segmentProps": []
                    },
                    "flxDocumentTermsBody": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottom03": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument02": {
                        "segmentProps": []
                    },
                    "flxSwiftMessageBody": {
                        "segmentProps": []
                    },
                    "lblDelivered": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoty": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSwiftMessagesRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDeliveredValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDateValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoryValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxExportError": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgError": {
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxClose1": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "imgCross1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCurrencyAmount": {
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "text": "$",
                        "segmentProps": []
                    },
                    "flxDropdownCurrency": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedValueCurrency": {
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": []
                    },
                    "imgDropdownIconCurrency": {
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdownListCurrency": {
                        "isCustomLayout": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "segDropdownListCurrency": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "segmentProps": []
                    },
                    "flxAmountCredited": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAmountToBeCredited": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAccAssign": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAccount": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAssigneeToProceeds": {
                        "left": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAssigneeSelection": {
                        "left": {
                            "type": "string",
                            "value": "1.58%"
                        },
                        "segmentProps": []
                    },
                    "flxCreditRadioSelected": {
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelecetCreditAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectCreditAccount": {
                        "segmentProps": []
                    },
                    "imgCreditAccountDropDown": {
                        "segmentProps": []
                    },
                    "flxSegCreditAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segCreditAccounts": {
                        "segmentProps": []
                    },
                    "flxAssignProceedsRadioSelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentError": {
                        "segmentProps": []
                    },
                    "lblChargesDebitAcc": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValueContent": {
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSegDebitedFromDropdown": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segDebitedFromDropdown": {
                        "segmentProps": []
                    },
                    "lblMessageToBank": {
                        "segmentProps": []
                    },
                    "flxMessageToBankValue": {
                        "width": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "segmentProps": []
                    },
                    "flxSegDocTitleDropdown": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.20%"
                        },
                        "segmentProps": []
                    },
                    "flxSegSelectOriginal": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSegCopiesCount": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "ClosePopup.btnNo": {
                        "segmentProps": []
                    },
                    "UploadDocumentPopup": {
                        "segmentProps": [],
                        "instanceId": "UploadDocumentPopup"
                    },
                    "UploadDocumentPopup.btnNo": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxExportError": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxClose1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "imgCross1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateDrawingSection": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountCredited": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAmountToBeCredited": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAccAssign": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAccount": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAssigneeToProceeds": {
                        "left": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreditAssigneeSelection": {
                        "left": {
                            "type": "string",
                            "value": "1.58%"
                        },
                        "segmentProps": []
                    },
                    "flxCreditRadioSelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelecetCreditAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSegCreditAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAssignProceedsRadioSelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValueContent": {
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSegDebitedFromDropdown": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageToBank": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageToBankValue": {
                        "width": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "flxSegDocTitleDropdown": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.10%"
                        },
                        "segmentProps": []
                    },
                    "flxSegSelectOriginal": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSegCopiesCount": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxSaveDraft": {
                        "segmentProps": []
                    },
                    "flxUploadDocumentPopup": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "height": "268dp",
                    "width": "44.30%"
                },
                "ClosePopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "268dp",
                    "width": "44.30%"
                },
                "ClosePopup.btnNo": {
                    "text": "Close without Saving"
                },
                "ClosePopup.btnYes": {
                    "text": "Save as Draft & Close"
                },
                "ClosePopup.lblPopupMessage": {
                    "text": "Save the Export Drawing as draft before closing or close this without saved."
                },
                "SaveDraftPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "268dp",
                    "width": "44.30%"
                },
                "UploadDocumentPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "268dp",
                    "width": "44.30%"
                },
                "UploadDocumentPopup.lblHeading": {
                    "text": "Upload Document"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCCreateDrawings,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCCreateDrawings",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});