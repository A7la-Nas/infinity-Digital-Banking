define("SecureMessageMA/AlertsMsgsUIModule/frmNotificationsAndMessages", function() {
    return function(controller) {
        function addWidgetsfrmNotificationsAndMessages() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "121px",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxActionsMenu": {
                        "right": "80dp"
                    },
                    "flxFeedback": {
                        "right": "0%",
                        "width": "24%"
                    },
                    "flxHelp": {
                        "right": "26.50%"
                    },
                    "flxLogoAndActionsWrapper": {
                        "width": "1366dp"
                    },
                    "flxMenuLeft": {
                        "left": "83dp"
                    },
                    "flxMenuRight": {
                        "right": "83dp"
                    },
                    "flxMenuWrapper": {
                        "width": "1366dp"
                    },
                    "flxUser": {
                        "right": "71dp",
                        "width": "44dp"
                    },
                    "flxverseperator2": {
                        "left": "0dp"
                    },
                    "imgKony": {
                        "left": "0dp",
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblFeedback": {
                        "bottom": "viz.val_cleared",
                        "text": "Feedback"
                    },
                    "lblHeaderMobile": {
                        "centerX": "50%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblUser": {
                        "text": "*"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var breadcrumb = new com.InfinityOLB.Resources.breadcrumb({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "52dp",
                "id": "breadcrumb",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "breadcrumb": {
                        "height": "52dp",
                        "isVisible": false
                    },
                    "btnBreadcrumb1": {
                        "text": "ALERTS & MESSAGES"
                    },
                    "btnBreadcrumb2": {
                        "text": "ALERTS"
                    },
                    "flxBreadcrumbcontainer": {
                        "centerX": "50%",
                        "height": "50dp",
                        "top": "1dp",
                        "width": "1366dp"
                    },
                    "flxTopBorder": {
                        "top": "0dp"
                    },
                    "lblBreadcrumb2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_fbcf334cf8914206a1ba3c7449911284,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "87.84%",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Alerts & Messages",
                    "tagName": "h1"
                },
                "centerX": "50dp",
                "centerY": "50dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "249dp",
                "skin": "sknSSPLblFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AlertsAndMessages.AlertsAndMessages\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1000
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var NotficationsAndMessages = new com.InfinityOLB.SecureMessage.NotficationsAndMessages({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NotficationsAndMessages",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdcnoradius",
                "top": "0dp",
                "width": "100%",
                "appName": "SecureMessageMA",
                "overrides": {
                    "backToAlerts": {
                        "isVisible": false
                    },
                    "btnSearch": {
                        "width": "30dp"
                    },
                    "flxNewMessage": {
                        "isVisible": false
                    },
                    "flxSearchSeparator": {
                        "height": "1dp",
                        "top": "81dp"
                    },
                    "lblAttachmentBLue2": {
                        "left": "20dp"
                    },
                    "lblCategory": {
                        "left": "2.89%"
                    },
                    "lblDateAndTime": {
                        "right": "20%"
                    },
                    "lblDescripption": {
                        "left": "2.89%"
                    },
                    "lblNewMessage": {
                        "left": "2.89%"
                    },
                    "lblSubject": {
                        "left": "2.89%"
                    },
                    "lblWarningReplyMessage": {
                        "width": "55%"
                    },
                    "listbxCategory": {
                        "left": "2.89%"
                    },
                    "segMessageAndNotification": {
                        "width": "37%"
                    },
                    "tbxSubject": {
                        "left": "2.89%"
                    },
                    "textareaDescription": {
                        "left": "2.89%"
                    },
                    "txtSearch": {
                        "left": "45px",
                        "placeholder": "Search Subject"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMain.add(lblHeader, NotficationsAndMessages);
            var AllForms = new com.InfinityOLB.WireTransfer.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "80.20%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "180dp",
                "width": "250dp",
                "zIndex": 20,
                "appName": "WireTransferMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "80.20%",
                        "top": "180dp",
                        "width": "250dp",
                        "zIndex": 20
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AlertsMessages.msgInfo\")",
                        "width": "83%"
                    },
                    "imgToolTip": {
                        "left": "53.50%",
                        "src": "username_tooltip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainContainer.add(flxMain, AllForms);
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var tablePagination = new com.InfinityOLB.SecureMessage.tablePagination({
                "height": "60dp",
                "id": "tablePagination",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "appName": "SecureMessageMA",
                "overrides": {
                    "lblPagination": {
                        "centerY": "50%",
                        "left": "10dp"
                    },
                    "tablePagination": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBottom.add(tablePagination);
            flxContainer.add(breadcrumb, flxMainContainer, flxBottom);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxContainer, flxFooter);
            var FlxDismiss = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "FlxDismiss",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxDismiss.setDefaultUnit(kony.flex.DP);
            var CustomPopup1 = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "43.27%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "268px",
                        "top": "150dp",
                        "width": "43.27%"
                    },
                    "btnNo": {
                        "bottom": "20dp",
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "bottom": "20dp",
                        "centerX": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "text": "DISMISS"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to dismiss this Notification?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            FlxDismiss.add(CustomPopup1);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SecureMessageMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "-10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblFFFFFF15Px",
                        "text": "Confirm",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 10000,
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.btnNewMessageSend": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.flxNewMessage": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.flxSendNewMessage": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblDateAndTime": {
                        "right": {
                            "type": "string",
                            "value": "54%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblWarningNewMessage": {
                        "padding": [3, 0, 0, 0],
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblWarningNotMoreThan5files": {
                        "padding": [3, 0, 0, 0],
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblWarningReplyMessage": {
                        "padding": [3, 0, 0, 0],
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.listbxCategory": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.segMessageAndNotification": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "flxBottom": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "FlxDismiss": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup1"
                    },
                    "CustomPopup1.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.btnYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxActionsMenu": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxFeedback": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxverseperator2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.lblFeedback": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlblBrowserCheckMessage",
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblWarningReplyMessage": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.segMessageAndNotification": {
                        "width": {
                            "type": "string",
                            "value": "37.10%"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "centerX": {
                            "type": "number",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1": {
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup1"
                    },
                    "CustomPopup1.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.btnYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.lblUser": {
                        "text": "*",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlblUserName",
                        "text": "Alerts & Messages",
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.btnSearch": {
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.flxNewMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.flxSearch": {
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.flxtxtSearchandClearbtn": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknFlxffffffBorder3px",
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblAttachmentBLue2": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblCategory": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblDateAndTime": {
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblDescripption": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblNewMessage": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblSubject": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.listbxCategory": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.segMessageAndNotification": {
                        "width": {
                            "type": "string",
                            "value": "37.10%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.tbxSubject": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.textareaDescription": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.txtSearch": {
                        "left": {
                            "type": "string",
                            "value": "45px"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.93%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "centerX": {
                            "type": "number",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup1"
                    },
                    "CustomPopup1.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.btnYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.lblDateAndTime": {
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.segMessageAndNotification": {
                        "width": {
                            "type": "string",
                            "value": "37.10%"
                        },
                        "segmentProps": []
                    },
                    "NotficationsAndMessages.txtSearch": {
                        "left": {
                            "type": "string",
                            "value": "45px"
                        },
                        "placeholder": "Search Subject",
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": "121px",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "customheadernew.flxActionsMenu": {
                    "right": "80dp"
                },
                "customheadernew.flxFeedback": {
                    "right": "0%",
                    "width": "24%"
                },
                "customheadernew.flxHelp": {
                    "right": "26.50%"
                },
                "customheadernew.flxLogoAndActionsWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.flxMenuLeft": {
                    "left": "83dp"
                },
                "customheadernew.flxMenuRight": {
                    "right": "83dp"
                },
                "customheadernew.flxMenuWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.flxUser": {
                    "right": "71dp",
                    "width": "44dp"
                },
                "customheadernew.flxverseperator2": {
                    "left": "0dp"
                },
                "customheadernew.imgKony": {
                    "left": "0dp",
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customheadernew.lblFeedback": {
                    "bottom": "",
                    "text": "Feedback"
                },
                "customheadernew.lblHeaderMobile": {
                    "centerX": "50%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "customheadernew.lblUser": {
                    "text": "*"
                },
                "breadcrumb": {
                    "height": "52dp"
                },
                "breadcrumb.btnBreadcrumb1": {
                    "text": "ALERTS & MESSAGES"
                },
                "breadcrumb.btnBreadcrumb2": {
                    "text": "ALERTS"
                },
                "breadcrumb.flxBreadcrumbcontainer": {
                    "centerX": "50%",
                    "height": "50dp",
                    "top": "1dp",
                    "width": "1366dp"
                },
                "breadcrumb.flxTopBorder": {
                    "top": "0dp"
                },
                "NotficationsAndMessages.btnSearch": {
                    "width": "30dp"
                },
                "NotficationsAndMessages.flxSearchSeparator": {
                    "height": "1dp",
                    "top": "81dp"
                },
                "NotficationsAndMessages.lblAttachmentBLue2": {
                    "left": "20dp"
                },
                "NotficationsAndMessages.lblCategory": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.lblDateAndTime": {
                    "right": "20%"
                },
                "NotficationsAndMessages.lblDescripption": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.lblNewMessage": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.lblSubject": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.lblWarningReplyMessage": {
                    "width": "55%"
                },
                "NotficationsAndMessages.listbxCategory": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.segMessageAndNotification": {
                    "width": "37%"
                },
                "NotficationsAndMessages.tbxSubject": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.textareaDescription": {
                    "left": "2.89%"
                },
                "NotficationsAndMessages.txtSearch": {
                    "left": "45px"
                },
                "AllForms": {
                    "left": "80.20%",
                    "top": "180dp",
                    "width": "250dp",
                    "zIndex": 20
                },
                "AllForms.RichTextInfo": {
                    "width": "83%"
                },
                "AllForms.imgToolTip": {
                    "left": "53.50%",
                    "src": "username_tooltip.png"
                },
                "tablePagination.lblPagination": {
                    "centerY": "50%",
                    "left": "10dp"
                },
                "CustomPopup1": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "268px",
                    "top": "150dp",
                    "width": "43.27%"
                },
                "CustomPopup1.btnNo": {
                    "bottom": "20dp",
                    "centerX": "50%",
                    "left": "",
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup1.btnYes": {
                    "bottom": "20dp",
                    "centerX": "",
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup1.lblHeading": {
                    "text": "DISMISS"
                },
                "CustomPopup1.lblPopupMessage": {
                    "text": "Are you sure you want to dismiss this Notification?"
                }
            }
            this.add(flxHeader, flxFormContent, FlxDismiss, flxLoading, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmNotificationsAndMessages,
            "enabledForIdleTimeout": true,
            "id": "frmNotificationsAndMessages",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_jc89e0f1798348888ad96f03a01930d5,
            "postShow": controller.AS_Form_c577f98e99594a89ada0d0eeef83e7ae,
            "preShow": function(eventobject) {
                controller.AS_Form_ddf367ae84c94d78b2c653aa25fbbe6f(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Alerts and Messages",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "SecureMessageMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c25de95e48a04ccb81587c1758e62be0,
            "retainScrollPosition": false
        }]
    }
});