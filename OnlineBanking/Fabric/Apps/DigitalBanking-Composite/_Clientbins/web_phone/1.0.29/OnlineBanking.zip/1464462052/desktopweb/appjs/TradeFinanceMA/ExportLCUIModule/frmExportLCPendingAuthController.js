define("TradeFinanceMA/ExportLCUIModule/userfrmExportLCPendingAuthController", {
    //Type your controller code here 
});
define("TradeFinanceMA/ExportLCUIModule/frmExportLCPendingAuthControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("TradeFinanceMA/ExportLCUIModule/frmExportLCPendingAuthController", ["TradeFinanceMA/ExportLCUIModule/userfrmExportLCPendingAuthController", "TradeFinanceMA/ExportLCUIModule/frmExportLCPendingAuthControllerActions"], function() {
    var controller = require("TradeFinanceMA/ExportLCUIModule/userfrmExportLCPendingAuthController");
    var controllerActions = ["TradeFinanceMA/ExportLCUIModule/frmExportLCPendingAuthControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
