define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmSignatoryMatrixConditions", function() {
    return function(controller) {
        function addWidgetsfrmSignatoryMatrixConditions() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxLogoAndActionsWrapper": {
                        "width": "1366dp"
                    },
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "flxMenuWrapper": {
                        "width": "1366dp"
                    },
                    "imgKony": {
                        "centerX": "viz.val_cleared",
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "90px",
                "id": "flxAckHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": "5dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.Signatory.GroupDelete\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(flxImgContainer, lblSuccessMessage);
            var flxImgClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImgClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "92%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgClose.add(imgClose);
            flxAckHeader.add(flxLeft, flxImgClose);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "left": "83dp",
                "skin": "sknlblUserName",
                "text": "Approval Matrix- Create New Rule - Approval Condition & Rule",
                "top": "21dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAcknowledgementPopup = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxAcknowledgementPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.setDefaultUnit(kony.flex.DP);
            var imgAckNotification = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgAckNotification",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bulk_billpay_success.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAckNotificationContent = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAckNotificationContent",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP24px",
                "text": "Approval Rule has been successfully created. ",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAckClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgAckClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "100dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.add(imgAckNotification, lblAckNotificationContent, imgAckClose);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalConditionContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApprovalConditionContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.AddCondition\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHeaderSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "0.50%",
                "id": "flxHeaderSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "48dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeperator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeperator.add();
            flxHeaderContainer.add(lblCustomerLevelHeader, lblHeaderSeparator, flxHeaderSeperator);
            var flxApprovalConditionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "140dp",
                "id": "flxApprovalConditionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionDetails.setDefaultUnit(kony.flex.DP);
            var flxLimitDetailRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxLimitDetailRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow1.setDefaultUnit(kony.flex.DP);
            var lblRange = new kony.ui.Label({
                "id": "lblRange",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Range\")",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRangeValue = new kony.ui.Label({
                "id": "lblRangeValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Between",
                "top": "0dp",
                "width": "400dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow1.add(lblRange, lblRangeValue);
            var flxLimitDetailRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxLimitDetailRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow2.setDefaultUnit(kony.flex.DP);
            var lblRangeLimit = new kony.ui.Label({
                "id": "lblRangeLimit",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.RangeLimit\")",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRangeLimitValue = new kony.ui.Label({
                "id": "lblRangeLimitValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$500 - $800",
                "top": "0dp",
                "width": "400dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow2.add(lblRangeLimit, lblRangeLimitValue);
            var flxLimitDetailRow3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxLimitDetailRow3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow3.setDefaultUnit(kony.flex.DP);
            var lblApprovalRequired = new kony.ui.Label({
                "id": "lblApprovalRequired",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "Approval Required : ",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalRequiredValue = new kony.ui.Label({
                "id": "lblApprovalRequiredValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Yes",
                "top": "0dp",
                "width": "400dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitDetailRow3.add(lblApprovalRequired, lblApprovalRequiredValue);
            flxApprovalConditionDetails.add(flxLimitDetailRow1, flxLimitDetailRow2, flxLimitDetailRow3);
            var lblSepDetails = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSepDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxConditionSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionSection",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "132dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "69dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionSection.setDefaultUnit(kony.flex.DP);
            var flxConditionHdr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxConditionHdr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxE9E9E9Bdr1PxRds5Px",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionHdr.setDefaultUnit(kony.flex.DP);
            var lblConditoinHdr = new kony.ui.Label({
                "id": "lblConditoinHdr",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Condition 1",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnDeleteCondition",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "text": "Button",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionHdr.add(lblConditoinHdr, btnDeleteCondition);
            var flxCreateApprovalCondition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateApprovalCondition",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxffffffnoborder",
                "top": "0",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknsegf7f7f7hover"
            });
            flxCreateApprovalCondition.setDefaultUnit(kony.flex.DP);
            var flxApprovalConditionValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalConditionValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionValue.setDefaultUnit(kony.flex.DP);
            var flxConditionInputs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "160dp",
                "id": "flxConditionInputs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 20,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionInputs.setDefaultUnit(kony.flex.DP);
            var flxRequiredApprovals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRequiredApprovals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequiredApprovals.setDefaultUnit(kony.flex.DP);
            var lblRequiredApprovalsHdr = new kony.ui.Label({
                "id": "lblRequiredApprovalsHdr",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "Required Approvals",
                "top": "20dp",
                "width": "125dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRequiredAppraovalSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxRequiredAppraovalSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "190dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequiredAppraovalSelected.setDefaultUnit(kony.flex.DP);
            var lblRequiredApprovalsCount = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRequiredApprovalsCount",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "4",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRequiredApprovalsDrop = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgRequiredApprovalsDrop",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "listboxuparrow.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequiredAppraovalSelected.add(lblRequiredApprovalsCount, imgRequiredApprovalsDrop);
            var flxApprovalsDropDown = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxApprovalsDropDown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "5dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsDropDown.setDefaultUnit(kony.flex.DP);
            var lblApprovalCount = new kony.ui.Label({
                "id": "lblApprovalCount",
                "isVisible": true,
                "left": "11dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalsDropDown.add(lblApprovalCount);
            flxRequiredApprovals.add(lblRequiredApprovalsHdr, flxRequiredAppraovalSelected, flxApprovalsDropDown);
            var flxFromGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxFromGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "320dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroup.setDefaultUnit(kony.flex.DP);
            var lblFromGroupHdr = new kony.ui.Label({
                "id": "lblFromGroupHdr",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "From Group",
                "top": "20dp",
                "width": "125dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFromGroupSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFromGroupSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroupSelected.setDefaultUnit(kony.flex.DP);
            var lblFromGroupSelectedVal = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFromGroupSelectedVal",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Sr. Admin (4)",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFromGroupDrop = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgFromGroupDrop",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "listboxuparrow.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromGroupSelected.add(lblFromGroupSelectedVal, imgFromGroupDrop);
            var flxFromGroupDropDown = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxFromGroupDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "81dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroupDropDown.setDefaultUnit(kony.flex.DP);
            var lblFromGroupValue = new kony.ui.Label({
                "id": "lblFromGroupValue",
                "isVisible": true,
                "left": "28dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "27dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromGroupDropDown.add(lblFromGroupValue);
            flxFromGroup.add(lblFromGroupHdr, flxFromGroupSelected, flxFromGroupDropDown);
            var btnDeleteAndCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnDeleteAndCondition",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "text": "Delete",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalWarningMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalWarningMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalWarningMsg.setDefaultUnit(kony.flex.DP);
            var imgWarningIcon = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgWarningIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info.png",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalWarningMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalWarningMsg",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "This signatory group does not have sufficient approvers",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalWarningMsg.add(imgWarningIcon, lblApprovalWarningMsg);
            flxConditionInputs.add(flxRequiredApprovals, flxFromGroup, btnDeleteAndCondition, flxApprovalWarningMsg);
            flxApprovalConditionValue.add(flxConditionInputs);
            var flxANDText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxANDText",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDText.setDefaultUnit(kony.flex.DP);
            var flxAndVerticalLineTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxAndVerticalLineTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAndVerticalLineTop.setDefaultUnit(kony.flex.DP);
            flxAndVerticalLineTop.add();
            var flxANDLabelContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxANDLabelContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlx424242Rds5pxBdr1px",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDLabelContainer.setDefaultUnit(kony.flex.DP);
            var lblANDText = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblANDText",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AND",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxANDLabelContainer.add(lblANDText);
            var flxAndVerticalLineBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxAndVerticalLineBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAndVerticalLineBottom.setDefaultUnit(kony.flex.DP);
            flxAndVerticalLineBottom.add();
            flxANDText.add(flxAndVerticalLineTop, flxANDLabelContainer, flxAndVerticalLineBottom);
            flxCreateApprovalCondition.add(flxApprovalConditionValue, flxANDText);
            var flxANDConditionBtnMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "35dp",
                "id": "flxANDConditionBtnMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDConditionBtnMain.setDefaultUnit(kony.flex.DP);
            var flxANDBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxANDBtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003C7DBdr1PxRds5px",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDBtn.setDefaultUnit(kony.flex.DP);
            var lblPlusSymbol = new kony.ui.Label({
                "height": "100%",
                "id": "lblPlusSymbol",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl003D79Rds5PxSSPFFFFF26Px",
                "text": "+",
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAND = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAND",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLbl003D79SSP15Px",
                "text": "AND",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxANDBtn.add(lblPlusSymbol, lblAND);
            flxANDConditionBtnMain.add(flxANDBtn);
            flxConditionSection.add(flxConditionHdr, flxCreateApprovalCondition, flxANDConditionBtnMain);
            var flxORText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxORText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORText.setDefaultUnit(kony.flex.DP);
            var flxORVerticalLineTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxORVerticalLineTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORVerticalLineTop.setDefaultUnit(kony.flex.DP);
            flxORVerticalLineTop.add();
            var flxORLabelContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxORLabelContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlx424242Rds5pxBdr1px",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORLabelContainer.setDefaultUnit(kony.flex.DP);
            var lblORTest = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblORTest",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "OR",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxORLabelContainer.add(lblORTest);
            var flxORVerticalLineBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxORVerticalLineBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORVerticalLineBottom.setDefaultUnit(kony.flex.DP);
            flxORVerticalLineBottom.add();
            flxORText.add(flxORVerticalLineTop, flxORLabelContainer, flxORVerticalLineBottom);
            var flxConditionPartMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionPartMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionPartMain.setDefaultUnit(kony.flex.DP);
            flxConditionPartMain.add();
            var btnAddNewCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnAddNewCondition",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknBtnSSPRegular003E7515Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.AddORCondition\")",
                "top": "25dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.add(flxConditionSection, flxORText, flxConditionPartMain, btnAddNewCondition);
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "20dp",
                "right": "20dp",
                "skin": "sknSeparatore3e3e3",
                "top": "5dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "240dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnConfirmSave = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "btnConfirmSave",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknContinueEnabled",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnCancel, btnConfirmSave);
            flxApprovalConditionContainer.add(flxHeaderContainer, flxApprovalConditionDetails, lblSepDetails, flxApprovalDetailsContainer, flxBackContainer);
            var flxSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1200dp",
                "id": "flxSignatoryGroups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainerSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainerSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeaderrSignatoryGroups = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeaderrSignatoryGroups",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.viewManage\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparatorrSignatoryGroups = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparatorrSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateNewGroup = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnCreateNewGroup",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignaotryGoup.CreateNewGroup\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.add(lblCustomerLevelHeaderrSignatoryGroups, lblHeaderSeparatorrSignatoryGroups, btnCreateNewGroup);
            var flxSearchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchContainer.setDefaultUnit(kony.flex.DP);
            var flxBoxSearchSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearchSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearchSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxSearchimgSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimgSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var imgSearchSignatoryGroups = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Search"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearchSignatoryGroups",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.add(imgSearchSignatoryGroups);
            var tbxSearchSignatoryGroups = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "100%",
                "id": "tbxSearchSignatoryGroups",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.SearchPlaceHolder\")",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxItalic"
            });
            flxBoxSearchSignatoryGroups.add(flxSearchimgSignatoryGroups, tbxSearchSignatoryGroups);
            flxSearchContainer.add(flxBoxSearchSignatoryGroups);
            var flxSegSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "145dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var segSignatoryGroups = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ],
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "minHeight": "250dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAction": "btnAction",
                    "flxApprovalMatrixContractHeader": "flxApprovalMatrixContractHeader",
                    "flxApprovalMatrixContractRow": "flxApprovalMatrixContractRow",
                    "flxContract": "flxContract",
                    "flxCustomerName": "flxCustomerName",
                    "flxHeadersContainer": "flxHeadersContainer",
                    "flxNoRecords": "flxNoRecords",
                    "imgContractSort": "imgContractSort",
                    "imgCustomerNameSort": "imgCustomerNameSort",
                    "lblActionHeader": "lblActionHeader",
                    "lblBottomSepartor": "lblBottomSepartor",
                    "lblContract": "lblContract",
                    "lblContractHeader": "lblContractHeader",
                    "lblCustomerID": "lblCustomerID",
                    "lblCustomerIDHeader": "lblCustomerIDHeader",
                    "lblCustomerName": "lblCustomerName",
                    "lblCustomerNameHeader": "lblCustomerNameHeader",
                    "lblNoRecords": "lblNoRecords",
                    "lblRowSeparator": "lblRowSeparator",
                    "lblTopSeparator": "lblTopSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.add(segSignatoryGroups);
            var flxBackContainerSignatoryGruops = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainerSignatoryGruops",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparatorSignatoryGruops = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparatorSignatoryGruops",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackSignatoryGruops = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBackSignatoryGruops",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.add(lblBottomSeparatorSignatoryGruops, btnBackSignatoryGruops);
            flxSignatoryGroups.add(flxHeaderContainerSignatoryGroups, flxSearchContainer, flxSegSignatoryGroups, flxBackContainerSignatoryGruops);
            flxContent.add(flxAckHeader, lblApprovalMatrixHeader, flxAcknowledgementPopup, flxDowntimeWarning, flxContractContainer, flxApprovalConditionContainer, flxSignatoryGroups);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "viz.val_cleared",
                        "left": "6dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxDeletePopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDeletePopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopup.setDefaultUnit(kony.flex.DP);
            var deletepopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "deletepopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxDropdown": {
                        "isVisible": false
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Delete\")",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.DeleteCondition\")",
                        "left": "30dp"
                    },
                    "lblPopupMsg": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.DeleteConditionPopup\")"
                    },
                    "trComments": {
                        "isVisible": true,
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopup.add(deletepopup);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var cancelpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "cancelpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "flxPopupNew": {
                        "isVisible": true
                    },
                    "formActionsNew": {
                        "top": "0dp",
                        "width": "100%"
                    },
                    "formActionsNew.btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                        "right": "20dp",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "isVisible": true,
                        "src": "closeicon_1.png"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Cancel\")",
                        "left": "30dp"
                    },
                    "lblPopupMsg": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.confirmcancelchanges\")",
                        "width": "48%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(cancelpopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxAcknowledgementPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgAckNotification": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblAckNotificationContent": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "imgAckClose": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameHeader": {
                        "isVisible": true,
                        "text": "",
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxFromGroupDropDown": {
                        "skin": "ICSknFlx464545Rds3Px",
                        "segmentProps": []
                    },
                    "btnAddNewCondition": {
                        "focusSkin": "ICSknBtnSSPRegular003E7515Px",
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnConfirmSave": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "54%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderSeperator": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxConditionSection": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxORText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAddNewCondition": {
                        "focusSkin": "ICSknBtnSSPRegular003E7515Px",
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-37dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxActionLevel": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderContainer": {
                        "segmentProps": []
                    },
                    "flxApprovalConditionDetails": {
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxConditionSection": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skne3e3e3br3pxradius",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConditionHdr": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxCreateApprovalCondition": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxApprovalConditionValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "imgRequiredApprovalsDrop": {
                        "src": "listboxuparrow.png",
                        "segmentProps": []
                    },
                    "flxApprovalsDropDown": {
                        "accessibilityConfig": {},
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "zIndex": 1022,
                        "segmentProps": []
                    },
                    "lblApprovalCount": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [6, 0, 0, 0],
                        "skin": "bbSknLbl72727217pxSSP",
                        "text": "4",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "hoverSkin": "ICSknLblF7F7F7SSP17Px",
                        "segmentProps": []
                    },
                    "flxFromGroupDropDown": {
                        "accessibilityConfig": {},
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 1022,
                        "segmentProps": []
                    },
                    "lblFromGroupValue": {
                        "accessibilityConfig": {},
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [6, 0, 0, 0],
                        "skin": "bbSknLbl72727217pxSSP",
                        "text": "Manager (4)",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "hoverSkin": "ICSknLblF7F7F7SSP17Px",
                        "segmentProps": []
                    },
                    "btnDeleteAndCondition": {
                        "zIndex": 101,
                        "segmentProps": []
                    },
                    "flxApprovalWarningMsg": {
                        "isVisible": false,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblApprovalWarningMsg": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxANDText": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxANDConditionBtnMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxORText": {
                        "segmentProps": []
                    },
                    "btnAddNewCondition": {
                        "focusSkin": "ICSknBtnSSPRegular003E7515Px",
                        "segmentProps": []
                    },
                    "flxSignatoryGroups": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "deletepopup.flxDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "No",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxLogoAndActionsWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.flxMenuWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.imgKony": {
                    "centerX": "",
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew": {
                    "centerX": "",
                    "left": "6dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                },
                "deletepopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "deletepopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "deletepopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "deletepopup.formActionsNew": {
                    "top": "0dp"
                },
                "deletepopup.formActionsNew.btnCancel": {
                    "centerY": "50%",
                    "top": ""
                },
                "deletepopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "top": ""
                },
                "deletepopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "deletepopup.lblHeader": {
                    "left": "30dp"
                },
                "deletepopup.trComments": {
                    "right": "",
                    "top": "12dp"
                },
                "cancelpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "cancelpopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "cancelpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "cancelpopup.formActionsNew": {
                    "top": "0dp",
                    "width": "100%"
                },
                "cancelpopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "top": ""
                },
                "cancelpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "top": ""
                },
                "cancelpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "cancelpopup.lblHeader": {
                    "left": "30dp"
                },
                "cancelpopup.lblPopupMsg": {
                    "width": "48%"
                },
                "cancelpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxDeletePopup, flxCancelPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmSignatoryMatrixConditions,
            "enabledForIdleTimeout": true,
            "id": "frmSignatoryMatrixConditions",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_ifdc5e7e183c4dad8a3222da7dbc9bfd,
            "preShow": function(eventobject) {
                controller.AS_Form_cb5bec9042aa462eb914a7fa2d8ac541(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_d6eb54f7b95d4f20858efafa4ba2d11c,
            "retainScrollPosition": false
        }]
    }
});