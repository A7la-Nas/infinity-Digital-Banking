define("ArrangementsMA/AccountsUIModule/frmChangeRepaymentDay", function() {
    return function(controller) {
        function addWidgetsfrmChangeRepaymentDay() {
            this.setDefaultUnit(kony.flex.DP);
            var formChangeRepaymentDay = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formChangeRepaymentDay",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formChangeRepaymentDay",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formChangeRepaymentDay_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentDay"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentDay"]["formChangeRepaymentDay"]) || {};
            formChangeRepaymentDay.serviceParameters = formChangeRepaymentDay_data.serviceParameters || {};
            formChangeRepaymentDay.customPopupData = formChangeRepaymentDay_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formChangeRepaymentDay.dataFormatting = formChangeRepaymentDay_data.dataFormatting || {};
            formChangeRepaymentDay.dataMapping = formChangeRepaymentDay_data.dataMapping || {};
            formChangeRepaymentDay.conditionalMappingKey = formChangeRepaymentDay_data.conditionalMappingKey || "";
            formChangeRepaymentDay.conditionalMapping = formChangeRepaymentDay_data.conditionalMapping || {};
            formChangeRepaymentDay.pageTitle = formChangeRepaymentDay_data.pageTitle || "Change Repayment Day";
            formChangeRepaymentDay.pageTitlei18n = formChangeRepaymentDay_data.pageTitlei18n || "";
            formChangeRepaymentDay.primaryLinks = formChangeRepaymentDay_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formChangeRepaymentDay.flxMainWrapperzIndex = formChangeRepaymentDay_data.flxMainWrapperzIndex || 2;
            formChangeRepaymentDay.secondaryLinks = formChangeRepaymentDay_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formChangeRepaymentDay.supplementaryLinks = formChangeRepaymentDay_data.supplementaryLinks || {};
            formChangeRepaymentDay.pageTitleVisibility = formChangeRepaymentDay_data.pageTitleVisibility || true;
            formChangeRepaymentDay.logoConfig = formChangeRepaymentDay_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formChangeRepaymentDay.accountText = formChangeRepaymentDay_data.accountText || "";
            formChangeRepaymentDay.logoutConfig = formChangeRepaymentDay_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formChangeRepaymentDay.profileConfig = formChangeRepaymentDay_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formChangeRepaymentDay.activeMenuID = formChangeRepaymentDay_data.activeMenuID || "";
            formChangeRepaymentDay.activeSubMenuID = formChangeRepaymentDay_data.activeSubMenuID || "";
            formChangeRepaymentDay.backFlag = formChangeRepaymentDay_data.backFlag || false;
            formChangeRepaymentDay.hamburgerConfig = formChangeRepaymentDay_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formChangeRepaymentDay.backProperties = formChangeRepaymentDay_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentDay.breadCrumbProperties = formChangeRepaymentDay_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentDay.genricMessage = formChangeRepaymentDay_data.genricMessage || {};
            formChangeRepaymentDay.sessionTimeOutData = formChangeRepaymentDay_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formChangeRepaymentDay.footerProperties = formChangeRepaymentDay_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formChangeRepaymentDay.copyRight = formChangeRepaymentDay_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContentCPD = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentCPD",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentCPD.setDefaultUnit(kony.flex.DP);
            var flxMainCPD = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainCPD",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainCPD.setDefaultUnit(kony.flex.DP);
            var flxChangeRepaymentDay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChangeRepaymentDay",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0px",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeRepaymentDay.setDefaultUnit(kony.flex.DP);
            var flxMortgageFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMortgageFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityDetails.setDefaultUnit(kony.flex.DP);
            var lblMortgageFacilityDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblMortgageFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.displayMortgageFacilityDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "49dp",
                "width": "94%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityDetails.add(lblMortgageFacilityDetails, lblSeparator1);
            var flxCont = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCont",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCont.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FacilityNameWithColon\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValFacilityName = new kony.ui.Label({
                "id": "lblValFacilityName",
                "isVisible": true,
                "left": "270dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Mortgage Facility Account - 1234",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCurrentOutstandingBal",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentOutstandingBalanceWithColon\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValCurrentOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValCurrentOutstandingBal",
                "isVisible": true,
                "left": "270dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "$33,000.00",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "608dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NoOfLoansShortWithColon\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValNoOfLoans",
                "isVisible": true,
                "left": "818dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "3",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentMaturitDt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCurrentMaturitDt",
                "isVisible": true,
                "left": "608dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentMaturityDateWithColon\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValCurrentMaturityDt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValCurrentMaturityDt",
                "isVisible": true,
                "left": "818dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "25/09/2030",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentRepaymentDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCurrentRepaymentDay",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValCurrentRepaymentDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValCurrentRepaymentDay",
                "isVisible": false,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "1px",
                "id": "lblSeparator2",
                "isVisible": false,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "top": "10dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCont.add(lblFacilityName, lblValFacilityName, lblCurrentOutstandingBal, lblValCurrentOutstandingBal, lblNoOfLoans, lblValNoOfLoans, lblCurrentMaturitDt, lblValCurrentMaturityDt, lblCurrentRepaymentDay, lblValCurrentRepaymentDay, lblSeparator2);
            var flxSelectRepaymentDay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSelectRepaymentDay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectRepaymentDay.setDefaultUnit(kony.flex.DP);
            var lblSelectRepaymentDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSelectRepaymentDay",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SelectRepaymentDay\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "92dp",
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBorderE3E3E3Radius4Px",
                "top": "60dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true
                },
                "bottom": "42dp",
                "height": "30dp",
                "id": "imgWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "top": "20dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarning",
                "isVisible": true,
                "left": "60dp",
                "right": "0dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopPayment.PleaseNote\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDot = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "6dp",
                "id": "imgDot",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknImgPointer5vs",
                "src": "pageoffdot.png",
                "top": "61dp",
                "width": "6dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPoint = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPoint",
                "isVisible": true,
                "left": "78dp",
                "skin": "ICSknLabelSSPRegular42424211px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentMessage\")",
                "top": "55dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(imgWarning, lblWarning, imgDot, lblPoint);
            var flxRepaymentDay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxRepaymentDay",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "172dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentDay.setDefaultUnit(kony.flex.DP);
            var lblRepaymentDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRepaymentDay",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentDay\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flximgInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information regarding repayment day select"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20px",
                "id": "flximgInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "20px",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flximgInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey_2.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flximgInfo.add(imgInfo);
            flxRepaymentDay.add(lblRepaymentDay, flximgInfo);
            var flxRepaymentDayInfoIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "height": "110dp",
                "id": "flxRepaymentDayInfoIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "195dp",
                "isModalContainer": true,
                "skin": "sknFlxffffffShadowd464545",
                "top": "193dp",
                "width": "250dp",
                "zIndex": 5,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentDayInfoIcon.setDefaultUnit(kony.flex.DP);
            var lblInfoheader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "lblInfoheader",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Repayment Day",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxlblClose2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop-up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxlblClose2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "-15dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxlblClose2.setDefaultUnit(kony.flex.DP);
            var lblClose2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblClose2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxlblClose2.add(lblClose2);
            var lblInfoIcon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "37dp",
                "id": "lblInfoIcon1",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Select a day for changing the repayment day for the installments.",
                "top": "0dp",
                "width": "220dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentDayInfoIcon.add(lblInfoheader, flxlblClose2, lblInfoIcon1);
            var flxRepaymentDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": "false",
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Select Repayment Day"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRepaymentDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius2px",
                "top": "197dp",
                "width": "360dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDropdown",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SelectRepaymentDay\")",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "317dp",
                "isModalContainer": false,
                "top": "8dp",
                "width": "25dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "lblDropdownIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(lblDropdownIcon);
            flxRepaymentDropdown.add(lblDropdown, flxDropdown);
            var flxDropDownMenu = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxDropDownMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "249dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDownMenu.setDefaultUnit(kony.flex.DP);
            var segDays = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "data": [{
                    "lblAction": "1"
                }, {
                    "lblAction": "2"
                }, {
                    "lblAction": "3"
                }, {
                    "lblAction": "4"
                }, {
                    "lblAction": "5"
                }, {
                    "lblAction": "6"
                }, {
                    "lblAction": "7"
                }, {
                    "lblAction": "8"
                }, {
                    "lblAction": "9"
                }, {
                    "lblAction": "10"
                }, {
                    "lblAction": "11"
                }, {
                    "lblAction": "12"
                }, {
                    "lblAction": "13"
                }, {
                    "lblAction": "14"
                }, {
                    "lblAction": "15"
                }, {
                    "lblAction": "16"
                }, {
                    "lblAction": "17"
                }, {
                    "lblAction": "18"
                }, {
                    "lblAction": "19"
                }, {
                    "lblAction": "20"
                }, {
                    "lblAction": "21"
                }, {
                    "lblAction": "22"
                }, {
                    "lblAction": "23"
                }, {
                    "lblAction": "24"
                }, {
                    "lblAction": "25"
                }, {
                    "lblAction": "26"
                }, {
                    "lblAction": "27"
                }, {
                    "lblAction": "28"
                }],
                "groupCells": false,
                "height": "240dp",
                "id": "segDays",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ResourcesMA",
                    "friendlyName": "flxActionsMenu"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxActionsMenu": "flxActionsMenu",
                    "lblAction": "lblAction"
                },
                "width": "100%",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDownMenu.add(segDays);
            var flxSupDoc = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxSupDoc",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "267dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupDoc.setDefaultUnit(kony.flex.DP);
            var lblSupportingDoc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSupportingDoc",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SupportingDocumentsOptional\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flximgInfo1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about attaching supporting doc"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flximgInfo1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flximgInfo1.setDefaultUnit(kony.flex.DP);
            var imgInfo1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgInfo1",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey_2.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flximgInfo1.add(imgInfo1);
            flxSupDoc.add(lblSupportingDoc, flximgInfo1);
            var flxSuppDocInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxSuppDocInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "255dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "287dp",
                "width": "270dp",
                "zIndex": 5,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.setDefaultUnit(kony.flex.DP);
            var lblAttachmentRules = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblAttachmentRules",
                "isVisible": true,
                "left": 15,
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.attachmentRules\")",
                "top": 7,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxlblClose1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop-up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxlblClose1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15dp",
                "top": "7dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxlblClose1.setDefaultUnit(kony.flex.DP);
            var lblClose1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblClose1",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxlblClose1.add(lblClose1);
            var lblSuppDocInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "80dp",
                "id": "lblSuppDocInfo",
                "isVisible": true,
                "left": 15,
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FileAttachmentErrorMessage\")",
                "top": 27,
                "width": "245dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.add(lblAttachmentRules, flxlblClose1, lblSuppDocInfo);
            var flxDocumentComponent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentComponent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "290dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentComponent.setDefaultUnit(kony.flex.DP);
            var uploadFiles3 = new com.InfinityOLB.ArrangementsMA.uploadFiles3({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "uploadFiles3",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "viewType": "uploadFiles3",
                "overrides": {
                    "uploadFiles3": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var uploadFiles3_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmChangeRepaymentDay"] && appConfig.componentMetadata["ArrangementsMA"]["frmChangeRepaymentDay"]["uploadFiles3"]) || {};
            uploadFiles3.inErrorState = uploadFiles3_data.inErrorState || false;
            uploadFiles3.maxFilesCount = uploadFiles3_data.maxFilesCount || 5;
            uploadFiles3.aaa = uploadFiles3_data.aaa || true;
            var lblSeparatorLine2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparatorLine2",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknLabelD8D8D8",
                "text": "Label",
                "top": "5dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "71dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to confirmation"
                },
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnContinue\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel change repayment day process"
                },
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "175dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnCancel\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnContinue, btnCancel);
            flxDocumentComponent.add(uploadFiles3, lblSeparatorLine2, flxButtons);
            var flxSupportingDoc = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSupportingDoc",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "304dp",
                "width": "560dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDoc.setDefaultUnit(kony.flex.DP);
            var flxAttachIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxAttachIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "13dp",
                "width": "24dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachIcon.setDefaultUnit(kony.flex.DP);
            var lblAttachIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblAttachIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLblFontIcon",
                "text": "U",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAttachIcon.add(lblAttachIcon);
            var lblSeparatorLine = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "38dp",
                "id": "lblSeparatorLine",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknSeparatore3e3e3",
                "top": "6dp",
                "width": "1dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAttachDoc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAttachDoc",
                "isVisible": true,
                "left": "55dp",
                "skin": "bbSknLblSSP4176A415Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AttachDocuments\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDoc.add(flxAttachIcon, lblSeparatorLine, lblAttachDoc);
            var flxSupportingDocMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "284dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocMain.setDefaultUnit(kony.flex.DP);
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Supporting Documents"
                        },
                        [{}, {}, {}]
                    ]
                ],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocMain.add(segSupportingDocs);
            var lblSuppDocWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSuppDocWarning",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblee0005LatoReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FileAttachmentMessage\")",
                "top": "305dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectedDay",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Calendar.LastDayOfMonth\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectRepaymentDay.add(lblSelectRepaymentDay, flxWarning, flxRepaymentDay, flxRepaymentDayInfoIcon, flxRepaymentDropdown, flxDropDownMenu, flxSupDoc, flxSuppDocInfo, flxDocumentComponent, flxSupportingDoc, flxSupportingDocMain, lblSuppDocWarning, lblSelectedDay);
            flxChangeRepaymentDay.add(flxMortgageFacilityDetails, flxCont, flxSelectRepaymentDay);
            flxMainCPD.add(flxChangeRepaymentDay);
            flxContentCPD.add(flxMainCPD);
            formChangeRepaymentDay.flxContentTCCenter.add(flxContentCPD);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formChangeRepaymentDay": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxMainCPD": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "sknFlxffffffShadowPlain",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD"]
                    },
                    "flxChangeRepaymentDay": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD"]
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "52px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "skn4B4B4BSemiBold13px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "flxCont": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "117dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "134dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentMaturitDt": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "168dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentMaturityDt": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "184dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentRepaymentDay": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "text": "Current Repayment Day",
                        "top": {
                            "type": "string",
                            "value": "168dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentRepaymentDay": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "10th of every month",
                        "top": {
                            "type": "string",
                            "value": "184dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblSeparator2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblSelectRepaymentDay": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "104dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "53dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "imgWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "39dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "imgDot": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblPoint": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424211px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblRepaymentDay": {
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay"]
                    },
                    "imgInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay", "flximgInfo"]
                    },
                    "flxRepaymentDayInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblInfoheader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "lblInfoIcon1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "flxRepaymentDropdown": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblDropdown": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDropdown"]
                    },
                    "flxDropdown": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "89%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDropdown"]
                    },
                    "flxDropDownMenu": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "skin": "ICSknlbl424242SSPSemiBold15px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc"]
                    },
                    "imgInfo1": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc", "flximgInfo1"]
                    },
                    "flxSuppDocInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblSuppDocInfo": {
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "226dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxDocumentComponent"]
                    },
                    "lblSeparatorLine2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSupportingDoc": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "flxAttachIcon": {
                        "bottom": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "246dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "bottom": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblff000013px",
                        "text": "The file size exceeds the maximum limit. Please make sure that the file you are uploading doesn’t exceed 2MB.",
                        "top": {
                            "type": "string",
                            "value": "291dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "269dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDay": {
                        "left": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "(Last calendar day of every month)",
                        "top": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "formChangeRepaymentDay": {
                        "skin": "ICSknFlxF7F8F7Border",
                        "segmentProps": []
                    },
                    "flxMainCPD": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "sknFlxffffffShadowd464545",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD"]
                    },
                    "flxChangeRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD"]
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblMortgageFacilityDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblFacilityName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValFacilityName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "296dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentOutstandingBal": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentOutstandingBal": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "296dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblNoOfLoans": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValNoOfLoans": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "296dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentMaturitDt": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentMaturityDt": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "296dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentRepaymentDay": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Current Repayment Day:",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentRepaymentDay": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "296dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "25th of every month",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblSelectRepaymentDay": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "96dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "imgWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "imgDot": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblPoint": {
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay"]
                    },
                    "imgInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay", "flximgInfo"]
                    },
                    "flxRepaymentDayInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblInfoheader": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "lblClose2": {
                        "isVisible": true,
                        "text": "g",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon", "flxlblClose2"]
                    },
                    "lblInfoIcon1": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "flxRepaymentDropdown": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "191dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "359dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "flxDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "333dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDropdown"]
                    },
                    "flxDropDownMenu": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc"]
                    },
                    "imgInfo1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc", "flximgInfo1"]
                    },
                    "flxSuppDocInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblSuppDocInfo": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "flxSupportingDoc": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "680dp"
                        },
                        "segmentProps": []
                    },
                    "lblAttachIcon": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "635dp"
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "isVisible": false,
                        "text": "Label",
                        "segmentProps": []
                    },
                    "lblSelectedDay": {
                        "left": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "(Last calendar day of every month)",
                        "top": {
                            "type": "string",
                            "value": "166dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "formChangeRepaymentDay": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxMainCPD": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD"]
                    },
                    "flxChangeRepaymentDay": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopysknFlxffffffShadowdddcdc",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD"]
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblMortgageFacilityDetails": {
                        "i18n_text": "i18n.accounts.displayMortgageFacilityDetails",
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "text": "Mortgage Facility Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblFacilityName": {
                        "i18n_text": "i18n.accounts.FacilityNameWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Facility Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValFacilityName": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentOutstandingBal": {
                        "i18n_text": "i18n.accounts.CurrentOutstandingBalanceWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Current Outstanding Balance:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentOutstandingBal": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblNoOfLoans": {
                        "i18n_text": "i18n.accounts.NoOfLoansWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "No. of Loans:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValNoOfLoans": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentMaturitDt": {
                        "i18n_text": "i18n.accounts.CurrentMaturityDateWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Current Maturity Date:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentMaturityDt": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblCurrentRepaymentDay": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblValCurrentRepaymentDay": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblSeparator2": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblSelectRepaymentDay": {
                        "i18n_text": "i18n.accounts.SelectRepaymentDay",
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "text": "Select Repayment Day",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "flxWarning": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "i18n_text": "i18n.StopPayment.PleaseNote",
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Please note the following points:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblPoint": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentMessage",
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "This change applies to all the mortgage loan repayment days under this particular mortgage facility.",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxWarning"]
                    },
                    "lblRepaymentDay": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentDay",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Day",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay"]
                    },
                    "imgInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay", "flximgInfo"]
                    },
                    "flxRepaymentDayInfoIcon": {
                        "skin": "sknFlxffffffShadowd464545",
                        "width": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblInfoheader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "lblClose2": {
                        "bottom": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon", "flxlblClose2"]
                    },
                    "lblInfoIcon1": {
                        "text": "Select a day for changing the repayment day for the installments.",
                        "width": {
                            "type": "string",
                            "value": "213dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "flxRepaymentDropdown": {
                        "top": {
                            "type": "string",
                            "value": "197dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblDropdown": {
                        "i18n_text": "i18n.accounts.SelectRepaymentDay",
                        "skin": "bbsknLbl94949415px",
                        "text": "Select Repayment  Day",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDropdown"]
                    },
                    "flxDropDownMenu": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknFlxffffffShadowd464545",
                        "top": {
                            "type": "string",
                            "value": "238dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "zIndex": 10,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "segDays": {
                        "data": [{
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "1"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "2"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "3"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "4"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "5"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "6"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "7"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "8"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "9"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "10"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "11"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "13"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "14"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "15"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "16"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "17"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "18"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "19"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "20"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "21"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "22"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "23"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "24"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "25"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "26"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "27"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "28"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "29"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "30"
                            }
                        }, {
                            "lblAction": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "31"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "rowSkin": "seg2Normal2",
                        "segmentProps": ["data"],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxDropDownMenu"]
                    },
                    "lblSupportingDoc": {
                        "i18n_text": "i18n.accounts.SupportingDocumentsOptional",
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "text": "Supporting Document (Optional)",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc"]
                    },
                    "flxSuppDocInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblAttachmentRules": {
                        "i18n_text": "i18n.UnifiedTransfer.attachmentRules",
                        "text": "Attachment Rules",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "lblClose1": {
                        "bottom": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo", "flxlblClose1"]
                    },
                    "lblSuppDocInfo": {
                        "i18n_text": "i18n.accounts.FileAttachmentErrorMessage",
                        "text": "A Maximum of 5 Attachments are allowed. Only PDF, JPEG format are allowed. The file size should not excedd 2MB.",
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "i18n_text": "i18n.TransfersEur.btnContinue",
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "i18n_text": "i18n.TransfersEur.btnCancel",
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAttachIcon": {
                        "text": "U",
                        "segmentProps": []
                    },
                    "lblAttachDoc": {
                        "i18n_text": "i18n.ProfileManagement.AttachDocuments",
                        "text": "Attach Documents",
                        "segmentProps": []
                    },
                    "flxSupportingDocMain": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": []
                    },
                    "segSupportingDocs": {
                        "data": [{
                            "imgDoc": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDocName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Document1.pdf"
                            }
                        }, {
                            "imgDoc": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDocName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Document1.pdf"
                            }
                        }, {
                            "imgDoc": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDocName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Document1.pdf"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxSupportingDocs"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxContentDocs": "flxContentDocs",
                            "flxGap": "flxGap",
                            "flxImgDoc": "flxImgDoc",
                            "flxSupportingDocs": "flxSupportingDocs",
                            "imgDoc": "imgDoc",
                            "lblDocName": "lblDocName"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "lblSuppDocWarning": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.accounts.FileAttachmentMessage",
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "sknlblee0005LatoReg15px",
                        "text": "The file size exceeds the maximum limit. Please make sure that the file you are uploading doesn’t exceed 2MB.",
                        "top": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDay": {
                        "i18n_text": "i18n.Calendar.LastDayOfMonth",
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "(Last calendar day of every month)",
                        "top": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMainCPD": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD"]
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblMortgageFacilityDetails": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxMortgageFacilityDetails"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblCurrentRepaymentDay": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "lblSeparator2": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay"]
                    },
                    "lblSelectRepaymentDay": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "flxWarning": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDay"]
                    },
                    "flxRepaymentDayInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblInfoheader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "lblClose2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon", "flxlblClose2"]
                    },
                    "lblInfoIcon1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxRepaymentDayInfoIcon"]
                    },
                    "flxDropDownMenu": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSupDoc"]
                    },
                    "flxSuppDocInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay"]
                    },
                    "lblAttachmentRules": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "lblSuppDocInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentDay", "flxContentTCCenter", "flxContentCPD", "flxMainCPD", "flxChangeRepaymentDay", "flxSelectRepaymentDay", "flxSuppDocInfo"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSelectedDay": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formChangeRepaymentDay": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formChangeRepaymentDay.flxContentTCCenter.flxContentCPD.flxMainCPD.flxChangeRepaymentDay.flxSelectRepaymentDay.flxDocumentComponent.uploadFiles3": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formChangeRepaymentDay);
        };
        return [{
            "addWidgets": addWidgetsfrmChangeRepaymentDay,
            "enabledForIdleTimeout": true,
            "id": "frmChangeRepaymentDay",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_b9a6fd8be49d433b9b6ae008b20058dc,
            "preShow": function(eventobject) {
                controller.AS_Form_b58d86423cd741b699db0358c5df6d85(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});