define("BillPayMA/BillPaymentUIModule/frmAddPayee1", function() {
    return function(controller) {
        function addWidgetsfrmAddPayee1() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "text": "T"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var addPayee = new com.InfinityOLB.BillPay.payeeManagement.addPayee({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "addPayee",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA",
                "viewType": "addPayee",
                "overrides": {
                    "addPayee": {
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var addPayee_data = (appConfig.componentMetadata && appConfig.componentMetadata["BillPayMA"] && appConfig.componentMetadata["BillPayMA"]["frmAddPayee1"] && appConfig.componentMetadata["BillPayMA"]["frmAddPayee1"]["addPayee"]) || {};
            addPayee.payeeObjectService = addPayee_data.payeeObjectService || "BillPay";
            addPayee.billerSearchObjectService = addPayee_data.billerSearchObjectService || "BillPay";
            addPayee.blockTitle = addPayee_data.blockTitle || "{\"$.BREAKPTS.BP1\": \"{i.i18n.billPay.addPayee}\",\"default\": \"{i.i18n.billPay.addPayee}\"}";
            addPayee.masking = addPayee_data.masking || "{\"masking\" : true }";
            addPayee.tab1Title = addPayee_data.tab1Title || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.SearchByCompanyName}\",   \"default\": \"{i.i18n.AddPayee.SearchByCompanyName}\" }";
            addPayee.tab2Title = addPayee_data.tab2Title || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.ENTERPAYEEINFORMATION}\",   \"default\": \"{i.i18n.AddPayee.ENTERPAYEEINFORMATION}\" }";
            addPayee.editSectionTitle = addPayee_data.editSectionTitle || "{\"$.BREAKPTS.BP1\":\"{i.i18n.AddPayee.ADDPAYEEDETAILS}\",\"default\":\"{i.i18n.AddPayee.ADDPAYEEDETAILS}\"}";
            addPayee.categoryTitle = addPayee_data.categoryTitle || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.addPayeeTo}\",\"default\": \"{i.i18n.payments.addPayeeTo}\"}";
            addPayee.reviewSectionTitle = addPayee_data.reviewSectionTitle || "{\"$.BREAKPTS.BP1\":\"{i.i18n.AddPayee.VERIFYPAYEEINFORMATION}\",\"default\":\"{i.i18n.AddPayee.VERIFYPAYEEINFORMATION}\"}";
            addPayee.ackSection1Title = addPayee_data.ackSection1Title || "{\"$.BREAKPTS.BP1\": \"{i.i18n.konybb.common.Acknowledgement}\",\"default\": \"{i.i18n.konybb.common.Acknowledgement}\"}";
            addPayee.editblockTitle = addPayee_data.editblockTitle || "{\"$.BREAKPTS.BP1\": \"{i.i18n.billPay.editBiller}\",\"default\": \"{i.i18n.billPay.editBiller}\"}";
            addPayee.dvfConfig = addPayee_data.dvfConfig || "{\"tab1\":{\"Payee_BillPay\":{\"tbx1\":\"NAME\",\"tbx2\":\"ZIPCODE\",\"tbx3\":\"ACCOUNT_NUMBER\",\"tbx4\":\"ACCOUNT_NUMBER\",\"tbx5\":\"NUMBER\"}},\"tab2\":{\"Payee_BillPay\":{\"tbx1\":\"NAME\",\"tbx2\":\"MANDATORY\",\"tbx3\":\"NAME\",\"tbx4\":\"NAME\",\"tbx5\":\"ZIPCODE\",\"tbx6\":\"ACCOUNT_NUMBER\",\"tbx7\":\"ACCOUNT_NUMBER\"}},\"payeeDetails\":{\"Payee_BillPay\":{\"tbx1\":\"NAME\",\"tbx2\":\"NAME\"}},\"edit\":{\"Payee_BillPay\":{\"tbx1\":\"NAME\",\"tbx2\":\"ACCOUNT_NUMBER\",\"tbx3\":\"MANDATORY\",\"tbx4\":\"NAME\",\"tbx5\":\"NAME\",\"tbx6\":\"ZIPCODE\",\"tbx7\":\"NUMBER\"}}}";
            addPayee.userRoleType = addPayee_data.userRoleType || "{$.c.isCombinedUser}";
            addPayee.addressObjectService = addPayee_data.addressObjectService || "Utility";
            addPayee.ADDRgoogleApiEnabled = addPayee_data.ADDRgoogleApiEnabled || true;
            addPayee.sknAddLabel = addPayee_data.sknAddLabel || "ICSknsknLblSSP72727215px";
            addPayee.suggestionsObjectService = addPayee_data.suggestionsObjectService || "ContentManagement";
            addPayee.contractObjectService = addPayee_data.contractObjectService || "ExternalUserManagement";
            addPayee.isCodeVisible = addPayee_data.isCodeVisible || true;
            addPayee.countryObjectServiceName = addPayee_data.countryObjectServiceName || "Utility";
            addPayee.payeeObject = addPayee_data.payeeObject || "Payee_BillPay";
            addPayee.billerSearchObject = addPayee_data.billerSearchObject || "Biller";
            addPayee.BREAKPTS = addPayee_data.BREAKPTS || "{\"BP1\": \"640\",\"BP2\": \"1024\",\"BP3\": \"1366\"}";
            addPayee.accountNumberFormat = addPayee_data.accountNumberFormat || "{\"format\" : \"\\\\d(?=\\\\d{4})\", \"replaceCharacter\" : \"X\",  \"modifiers\" : \"g\"}";
            addPayee.tab1Visibility = addPayee_data.tab1Visibility || true;
            addPayee.tab2Visibility = addPayee_data.tab2Visibility || true;
            addPayee.editField1Label = addPayee_data.editField1Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.selectedPayeeWithColon}\",   \"default\": \"{i.i18n.payments.selectedPayeeWithColon}\" }";
            addPayee.roleBasedVisibility = addPayee_data.roleBasedVisibility || "{$.c.isCombinedUser}";
            addPayee.reviewField1Label = addPayee_data.reviewField1Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.selectedPayeeWithColon}\",   \"default\": \"{i.i18n.payments.selectedPayeeWithColon}\" }";
            addPayee.ackText = addPayee_data.ackText || "{   \"$.BREAKPTS.BP1\": \"{$.c.companyName}\",   \"default\": \"{$.c.companyName}\" }";
            addPayee.sectionTitle = addPayee_data.sectionTitle || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.billerDetails}\",\"default\": \"{i.i18n.payments.billerDetails}\"}";
            addPayee.minFillMapping = addPayee_data.minFillMapping || "{\"tab1\":{\"Payee_BillPay\":{\"tbx1\":\"1\",\"tbx2\":\"5\",\"tbx3\":\"3\",\"tbx4\":\"3\",\"tbx5\":\"3\"}},\"tab2\":{\"Payee_BillPay\":{\"tbx1\":\"3\",\"tbx2\":\"3\",\"tbx3\":\"0\",\"tbx4\":\"3\",\"tbx5\":\"5\",\"tbx6\":\"3\",\"tbx7\":\"3\"}},\"edit\":{\"Payee_BillPay\":{\"tbx1\":\"3\",\"tbx2\":\"3\",\"tbx3\":\"3\",\"tbx4\":\"0\",\"tbx5\":\"3\",\"tbx6\":\"3\",\"tbx7\":\"3\"}}}";
            addPayee.payeeId = addPayee_data.payeeId || "{$.c.payeeId}";
            addPayee.countryObject = addPayee_data.countryObject || "Country";
            addPayee.ADDRdefaultCountry = addPayee_data.ADDRdefaultCountry || "India";
            addPayee.sknAddTextBoxEnabled = addPayee_data.sknAddTextBoxEnabled || "ICSknTextBox424242";
            addPayee.sknAddTextBoxPlaceHolder = addPayee_data.sknAddTextBoxPlaceHolder || "ICSknTextBox94949415px";
            addPayee.sknAcknowledgementReferenceNumberLabel = addPayee_data.sknAcknowledgementReferenceNumberLabel || "sknLblLaoLight17px";
            addPayee.suggestionsObject = addPayee_data.suggestionsObject || "Locations";
            addPayee.contractObject = addPayee_data.contractObject || "ExternalUsers_1";
            addPayee.countryObjectName = addPayee_data.countryObjectName || "Country";
            addPayee.payeeCREATEOperation = addPayee_data.payeeCREATEOperation || "createBillPayPayee";
            addPayee.billerSearchOperation = addPayee_data.billerSearchOperation || "searchBillerByName";
            addPayee.maskeyeicon = addPayee_data.maskeyeicon || "{\"maskeyeicon\" : \"h\"}";
            addPayee.Tab1Field1Label = addPayee_data.Tab1Field1Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.ProfileManagement.Name}\",\"default\": \"{i.i18n.ProfileManagement.Name}\"}";
            addPayee.Tab2Field1Label = addPayee_data.Tab2Field1Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.ProfileManagement.Name}\",\"default\": \"{i.i18n.ProfileManagement.Name}\"}";
            addPayee.editField1Value = addPayee_data.editField1Value || "{\"text\": \"{$.c.companyName}\",\"fieldType\": \"Label\"}";
            addPayee.radioIcon1 = addPayee_data.radioIcon1 || "{\"icon\": {\"skin\": \"sknLblFontTypeIcon003E7520px\",\"vizIcon\": \"M\"},\"reviewIcon\": {\"skin\": \"bbSknLblFontIcon\",\"vizIcon\": \"s\"},\"selected\": true}";
            addPayee.reviewField1Value = addPayee_data.reviewField1Value || "{\"text\": \"{$.c.companyName}\",\"fieldType\": \"TextWithIcon\"}";
            addPayee.ackImage = addPayee_data.ackImage || "{\"img\":\"success_green_1.png\"}";
            addPayee.editFlowField1Label = addPayee_data.editFlowField1Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeNicknameWithColon}\",\"default\": \"{i.i18n.payments.payeeNicknameWithColon}\"}";
            addPayee.payeeNickName = addPayee_data.payeeNickName || "{$.c.payeeNickName}";
            addPayee.getCountriesOperation = addPayee_data.getCountriesOperation || "getAllCountries";
            addPayee.ADDRnumberOfCharsToTriggerAutoFill = addPayee_data.ADDRnumberOfCharsToTriggerAutoFill || "3";
            addPayee.sknAddTextBoxFocus = addPayee_data.sknAddTextBoxFocus || "ICSknsknSSP42424215PxBorder4A90E2";
            addPayee.sknAcknowledgementReferenceNumberValue = addPayee_data.sknAcknowledgementReferenceNumberValue || "sknSSPLight42424228px";
            addPayee.getAddressSuggestionsOperation = addPayee_data.getAddressSuggestionsOperation || "getAddressSuggestions";
            addPayee.FLOWTYPES = addPayee_data.FLOWTYPES || "{   \"FT1\": \"ADD\",   \"FT2\": \"EDIT\" }";
            addPayee.contractOperation = addPayee_data.contractOperation || "getInfinityUserContractCustomers";
            addPayee.countryOperationName = addPayee_data.countryOperationName || "getAllCountries";
            addPayee.payeeCREATECriteria = addPayee_data.payeeCREATECriteria || "{\"accountNumber\":\"{$.c.accountNumber}\",\"street\":\"{$.c.street}\",\"addressLine2\":\"{$.c.addressLine2}\",\"cityName\":\"{$.c.cityName}\",\"payeeNickName\":\"{$.c.payeeNickName}\",\"zipCode\":\"{$.c.zipCode}\",\"companyName\":\"{$.c.companyName}\",\"isBusinessPayee\":\"{$.c.isBusinessPayee}\",\"nameOnBill\":\"{$.c.nameOnBill}\",\"billerId\":\"{$.c.billerId}\",\"phone\":\"{$.c.phone}\",\"state\":\"{$.c.state}\",\"country\":\"{$.c.country}\",\"notes\":\"{$.c.notes}\",\"cif\":\"{$.c.cif}\"}";
            addPayee.billerSearchCriteria = addPayee_data.billerSearchCriteria || "{\"searchString\": \"{$.c.companyName}\",\"limit\": 5}";
            addPayee.unmaskeyeicon = addPayee_data.unmaskeyeicon || "{\"unmaskeyeicon\" : \"g\"}";
            addPayee.Tab1Field1Value = addPayee_data.Tab1Field1Value || "{\"mapping\":\"{$.c.companyName}\",\"placeHolder\":{\"$.BREAKPTS.BP1\":\"{i.i18n.BillPay.SearchforPayee}\",\"default\":\"{i.i18n.payments.searchPayee}\"},\"tooltip\":\"{i.i18n.ProfileManagement.Name}\",\"rootPath\":\"Biller\",\"text\":\"{$.billerSearch.rootPath.billerName}\",\"selectedCategoryID\":\"{$.billerSearch.rootPath.billerCategoryId}\"}";
            addPayee.Tab2Field1Value = addPayee_data.Tab2Field1Value || "{   \"mapping\": \"{$.c.companyName}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterCompanyName}\",     \"default\": \"{i.i18n.payments.enterCompanyName}\"   },   \"tooltip\": \"{i.i18n.konybb.Common.Name}\" }";
            addPayee.editField2Label = addPayee_data.editField2Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAddressWithColon}\",   \"default\": \"{i.i18n.payments.payeeAddressWithColon}\" }";
            addPayee.radioIcon2 = addPayee_data.radioIcon2 || "{\"icon\": {\"skin\": \"sknLblFontTypeIcon003E7520px\",\"vizIcon\": \"L\"},\"reviewIcon\": {\"skin\": \"bbSknLblFontIcon\",\"vizIcon\": \"r\"},\"selected\": false}";
            addPayee.reviewField2Label = addPayee_data.reviewField2Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAddressWithColon}\",   \"default\": \"{i.i18n.payments.payeeAddressWithColon}\" }";
            addPayee.ackReferenceText = addPayee_data.ackReferenceText || "{\"$.BREAKPTS.BP1\": \"{i.i18n.ChequeManagement.ReferenceNumber}\",\"default\": \"{i.i18n.ChequeManagement.ReferenceNumber}\"}";
            addPayee.editFlowField1Value = addPayee_data.editFlowField1Value || "{\"mapping\": \"{$.c.payeeNickName}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterNickName}\",\"default\": \"{i.i18n.payments.enterNickName}\"}}";
            addPayee.addressLine1 = addPayee_data.addressLine1 || "{$.c.addressLine1}";
            addPayee.getCountriesCriteria = addPayee_data.getCountriesCriteria || "{}";
            addPayee.ADDRdisplayAutoFillLongOrShortNames = addPayee_data.ADDRdisplayAutoFillLongOrShortNames || "short";
            addPayee.sknAddTextBoxHover = addPayee_data.sknAddTextBoxHover || "sknSSP42424215PxBorder4A90E2";
            addPayee.sknPrimaryButton = addPayee_data.sknPrimaryButton || "ICSknsknBtnSSPffffff15pxBg0273e3";
            addPayee.getAddressSuggestionCritera = addPayee_data.getAddressSuggestionCritera || "";
            addPayee.countryCriteria = addPayee_data.countryCriteria || "{}";
            addPayee.payeeCREATEIdentifier = addPayee_data.payeeCREATEIdentifier || "payeeCreate";
            addPayee.billerSearchIdentifier = addPayee_data.billerSearchIdentifier || "billerSearch";
            addPayee.Tab2AddressLine1 = addPayee_data.Tab2AddressLine1 || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.addressWithColon}\",\"default\": \"{i.i18n.payments.addressWithColon}\"}";
            addPayee.editField2Value = addPayee_data.editField2Value || "{   \"text\": \"{$.c.street}, {$.c.addressLine2}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.radioIcon1Criteria = addPayee_data.radioIcon1Criteria || "{\"isBusinessPayee\":\"0\"}";
            addPayee.reviewField2Value = addPayee_data.reviewField2Value || "{   \"text\": \"{$.c.street}, {$.c.addressLine2}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.ackReferenceValue = addPayee_data.ackReferenceValue || "{$.payeeCreate.payeeId}";
            addPayee.editFlowField2Label = addPayee_data.editFlowField2Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberWithColon}\",\"default\": \"{i.i18n.payments.accountNumberWithColon}\"}";
            addPayee.addressLine2 = addPayee_data.addressLine2 || "{$.c.addressLine2}";
            addPayee.getCountriesIdentifier = addPayee_data.getCountriesIdentifier || "countriesList";
            addPayee.ADDRdefaultState = addPayee_data.ADDRdefaultState || "Telangana";
            addPayee.sknBlockTitle = addPayee_data.sknBlockTitle || "sknSupportedFileTypes";
            addPayee.sknPrimaryButtonDisabled = addPayee_data.sknPrimaryButtonDisabled || "ICSknsknBtnBlockedSSPFFFFFF15Px";
            addPayee.searchResultIntoContext = addPayee_data.searchResultIntoContext || "{     \"street\": \"{$.billerSearch.rootPath.address}\",     \"accountNumber\": \"{$.billerSearch.rootPath.accountNumber}\",     \"billerId\": \"{$.billerSearch.rootPath.id}\",     \"cityName\": \"{$.billerSearch.rootPath.city}\",     \"state\": \"{$.billerSearch.rootPath.state}\"   }";
            addPayee.getAddressSuggestionIdentifier = addPayee_data.getAddressSuggestionIdentifier || "getAddressSuggestion";
            addPayee.countryIdentifier = addPayee_data.countryIdentifier || "countriesList";
            addPayee.Tab1Field2Label = addPayee_data.Tab1Field2Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.zipCodeWithColon}\",\"default\": \"{i.i18n.payments.zipCodeWithColon}\"}";
            addPayee.payeeEDITOperation = addPayee_data.payeeEDITOperation || "updateBillPayPayee";
            addPayee.Tab2AddressLine1Value = addPayee_data.Tab2AddressLine1Value || "{   \"mapping\": \"{$.c.street}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterBillingAddress}\",     \"default\": \"{i.i18n.payments.enterBillingAddress}\"   },   \"tooltip\": \"{i.kony.tab.p2p.address}\" }";
            addPayee.editField3Label = addPayee_data.editField3Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAccountNumberWithColon}\",   \"default\": \"{i.i18n.payments.payeeAccountNumberWithColon}\" }";
            addPayee.radioIcon2Criteria = addPayee_data.radioIcon2Criteria || "{\"isBusinessPayee\":\"1\"}";
            addPayee.reviewField3Label = addPayee_data.reviewField3Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAccountNumberWithColon}\",   \"default\": \"{i.i18n.payments.payeeAccountNumberWithColon}\" }";
            addPayee.ackSection2Title = addPayee_data.ackSection2Title || "{\"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.payeedetails}\",\"default\": \"{i.i18n.AddPayee.payeedetails}\"}";
            addPayee.editFlowField2Value = addPayee_data.editFlowField2Value || "{\"mapping\": \"{$.c.accountNumber}\",\"isEnabled\":false}";
            addPayee.state = addPayee_data.state || "{$.c.state}";
            addPayee.statesObject = addPayee_data.statesObject || "States";
            addPayee.sknSectionHeader = addPayee_data.sknSectionHeader || "{\"640\": \"sknSSP42424213Px\",\"default\": \"sknlbl424242SSP15pxSemibold\"}";
            addPayee.sknPrimaryButtonFocus = addPayee_data.sknPrimaryButtonFocus || "ICSknsknBtnNormalSSPFFFFFF15PxFocus";
            addPayee.getFormattedAddressOperation = addPayee_data.getFormattedAddressOperation || "getDetails";
            addPayee.countryServiceIdentifier = addPayee_data.countryServiceIdentifier || "records";
            addPayee.Tab1Field2Value = addPayee_data.Tab1Field2Value || "{   \"mapping\": \"{$.c.zipCode}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPayeeZipCode}\",     \"default\": \"{i.i18n.payments.enterPayeeZipCode}\"   },   \"inputMode\": \"NUMERIC\",   \"tooltip\": \"{i.i18n.common.zipcode}\" }";
            addPayee.payeeEDITCriteria = addPayee_data.payeeEDITCriteria || "{\"payeeId\":\"{$.c.payeeId}\",\"payeeNickName\":\"{$.c.payeeNickName}\",\"addressLine1\":\"{$.c.street}\",\"addressLine2\":\"{$.c.addressLine2}\",\"state\":\"{$.c.state}\",\"country\":\"{$.c.country}\",\"zipCode\":\"{$.c.zipCode}\",\"cityName\":\"{$.c.cityName}\",\"phone\":\"{$.c.phone}\",\"cif\":\"{$.c.cif}\"}";
            addPayee.Tab2AddressLine2 = addPayee_data.Tab2AddressLine2 || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.addresslineWithColon}\",\"default\": \"{i.i18n.payments.addresslineWithColon}\"}";
            addPayee.editField3Value = addPayee_data.editField3Value || "{\"text\": \"{$.c.accountNumber}\",\"fieldType\": \"Account Number\"}";
            addPayee.categoryLabel1 = addPayee_data.categoryLabel1 || "{\"$.BREAKPTS.BP1\": \"{i.i18n.header.personal}\",\"default\": \"{i.i18n.header.personal}\"}";
            addPayee.reviewField3Value = addPayee_data.reviewField3Value || "{\"text\": \"{$.c.accountNumber}\",\"fieldType\": \"Account Number\"}";
            addPayee.ackField1Label = addPayee_data.ackField1Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.selectedPayeeWithColon}\",   \"default\": \"{i.i18n.payments.selectedPayeeWithColon}\" }";
            addPayee.zipCode = addPayee_data.zipCode || "{$.c.zipCode}";
            addPayee.getStatesOperation = addPayee_data.getStatesOperation || "getAllRegions";
            addPayee.sknReviewLabel = addPayee_data.sknReviewLabel || "ICSknsknSSPRegular727272op10015px";
            addPayee.sknPrimaryButtonHover = addPayee_data.sknPrimaryButtonHover || "ICSknsknBtnNormalSSPFFFFFFHover15Px";
            addPayee.getFormattedAddressCriteria = addPayee_data.getFormattedAddressCriteria || "";
            addPayee.editFlowField3Label = addPayee_data.editFlowField3Label || "[   {     \"text\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.verifyDetails.phoneNumberOptional}\",       \"default\": \"{i.i18n.verifyDetails.phoneNumberOptional}\"     },     \"category\": [       \"Phone\"     ]   },   {     \"text\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.policyNumberWithColon}\",       \"default\": \"{i.i18n.payments.policyNumberWithColon}\"     },     \"category\": [       \"Insurance\"     ]   } ]";
            addPayee.Tab1Field3Label = addPayee_data.Tab1Field3Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberWithColon}\",\"default\": \"{i.i18n.payments.accountNumberWithColon}\"}";
            addPayee.payeeEDITIdentifier = addPayee_data.payeeEDITIdentifier || "payeeEdit";
            addPayee.Tab2AddressLine2Value = addPayee_data.Tab2AddressLine2Value || "{\"mapping\": \"{$.c.addressLine2}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.StopPayments.Optional}\",\"default\": \"{i.i18n.StopPayments.Optional}\"},\"tooltip\": \"Address Line2\"}";
            addPayee.editField4Label = addPayee_data.editField4Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeNicknameWithColon}\",\"default\": \"{i.i18n.payments.payeeNicknameWithColon}\"}";
            addPayee.categoryLabel2 = addPayee_data.categoryLabel2 || "{\"$.BREAKPTS.BP1\": \"{i.i18n.transfer.fasttransfer.businessbanking}\",\"default\": \"{i.i18n.transfer.fasttransfer.businessbanking}\"}";
            addPayee.reviewField4Label = addPayee_data.reviewField4Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeNicknameWithColon}\",   \"default\": \"{i.i18n.payments.payeeNicknameWithColon}\" }";
            addPayee.ackField1Value = addPayee_data.ackField1Value || "{\"text\": \"{$.c.companyName}\",\"fieldType\": \"TextWithIcon\"}";
            addPayee.cityName = addPayee_data.cityName || "{$.c.cityName}";
            addPayee.getStatesCriteria = addPayee_data.getStatesCriteria || "{}";
            addPayee.sknReviewValue = addPayee_data.sknReviewValue || "ICSknLabel42424215PXBG00";
            addPayee.sknSecondaryButton = addPayee_data.sknSecondaryButton || "ICSknsknBtnffffffBorder0273e31pxRadius2px";
            addPayee.getFormattedAddressIdentifier = addPayee_data.getFormattedAddressIdentifier || "getDetails";
            addPayee.editFlowField3Value = addPayee_data.editFlowField3Value || "[   {     \"placeholder\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPhoneNumber}\",       \"default\": \"{i.i18n.payments.enterPhoneNumber}\"     },     \"category\": [       \"Phone\"     ],     \"mapping\": \"{$.c.phone}\"   },   {     \"placeholder\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPolicyNumber}\",       \"default\": \"{i.i18n.payments.enterPolicyNumber}\"     },     \"category\": [       \"Insurance\"     ],     \"mapping\": \"{$.c.phone}\"   } ]";
            addPayee.Tab1Field3Value = addPayee_data.Tab1Field3Value || "{   \"mapping\": \"{$.c.accountNumber}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.UnifiedAddBeneficiary.AccountNumber}\",     \"default\": \"{i.i18n.UnifiedAddBeneficiary.AccountNumber}\"},   \"isMaskingEnabled\": true,   \"infoIconText\": \"\",   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.informationAboutWidget}\",     \"default\": \"{i.i18n.payments.informationAboutWidget}\"   },   \"inputMode\": \"NUMERIC\",   \"tooltip\": \"{i.i18n.common.accountNumber}\" }";
            addPayee.Tab2CountryLabel = addPayee_data.Tab2CountryLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.countryWithColon}\",\"default\": \"{i.i18n.payments.countryWithColon}\"}";
            addPayee.editField4Value = addPayee_data.editField4Value || "{   \"text\": \"{$.c.companyName}\",   \"mapping\": \"{$.c.payeeNickName}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPayeeNickName}\",     \"default\": \"{i.i18n.payments.enterPayeeNickName}\"   },   \"isMaskingEnabled\": false,   \"inputMode\": \"ANY\",   \"tooltip\": \"{i.i18n.payments.payeeNickName}\" }";
            addPayee.categoryButton1 = addPayee_data.categoryButton1 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"i.kony.tab.common.Cancel\",     \"default\": \"i.kony.tab.common.Cancel\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"categoryBtnRight3Onclick\"   } }";
            addPayee.reviewField4Value = addPayee_data.reviewField4Value || "{\"text\": \"{$.c.payeeNickName}\",\"fieldType\": \"Label\"}";
            addPayee.ackField2Label = addPayee_data.ackField2Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAddressWithColon}\",   \"default\": \"{i.i18n.payments.payeeAddressWithColon}\" }";
            addPayee.getStatesIdentifier = addPayee_data.getStatesIdentifier || "statesList";
            addPayee.sknAcknowledgementSuccess = addPayee_data.sknAcknowledgementSuccess || "sknLblSSP42424224px";
            addPayee.sknSecondaryButtonHover = addPayee_data.sknSecondaryButtonHover || "sknBtnffffffBorder3343a81pxRadius2px";
            addPayee.isManuallyAdded = addPayee_data.isManuallyAdded || "{$.c.isManuallyAdded}";
            addPayee.customCREATEIdentifier = addPayee_data.customCREATEIdentifier || "";
            addPayee.editFlowField4Label = addPayee_data.editFlowField4Label || "";
            addPayee.Tab1Field4Label = addPayee_data.Tab1Field4Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.confirmAccountNumberWithColon}\",\"default\": \"{i.i18n.payments.confirmAccountNumberWithColon}\"}";
            addPayee.Tab2CountryValue = addPayee_data.Tab2CountryValue || "{   \"mapping\": \"{$.c.country}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.selectCountry}\",     \"default\": \"{i.i18n.payments.selectCountry}\"   },   \"tooltip\": \"{i.i18n.TransfersEur.City}\" }";
            addPayee.editField5Label = addPayee_data.editField5Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.nameAsOntheBillWithColon}\",\"default\": \"{i.i18n.payments.nameAsOntheBillWithColon}\"}";
            addPayee.categoryButton2 = addPayee_data.categoryButton2 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.common.modifiy}\",     \"default\": \"{i.i18n.common.modifiy}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"categoryBtnRight2Onclick\"   } }";
            addPayee.reviewField5Label = addPayee_data.reviewField5Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.nameAsOntheBillWithColon}\",   \"default\": \"{i.i18n.payments.nameAsOntheBillWithColon}\" }";
            addPayee.ackField2Value = addPayee_data.ackField2Value || "{   \"text\": \"{$.c.street}, {$.c.addressLine2}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.sknSecondaryButtonFocus = addPayee_data.sknSecondaryButtonFocus || "ICSknsknBtnSecondaryFocusSSP3343a815Px";
            addPayee.editFlowField4Value = addPayee_data.editFlowField4Value || "";
            addPayee.selectedflowType = addPayee_data.selectedflowType || "{$.c.flowType}";
            addPayee.Tab1Field4Value = addPayee_data.Tab1Field4Value || "{   \"mapping\": \"{$.c.accountNumber}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberConfirm}\",     \"default\": \"{i.i18n.payments.accountNumberConfirm}\"   },   \"isMaskingEnabled\": false,   \"inputMode\": \"NUMERIC\",   \"tooltip\": \"{i.i18n.common.accountNumber}\" }";
            addPayee.Tab2StateLabel = addPayee_data.Tab2StateLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.stateWithColon}\",\"default\": \"{i.i18n.payments.stateWithColon}\"}";
            addPayee.editField5Value = addPayee_data.editField5Value || "{   \"text\": \"{$.c.userName}\",   \"mapping\": \"{$.c.nameOnBill}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterNameOnBill}\",     \"default\": \"{i.i18n.payments.enterNameOnBill}\"   },   \"isMaskingEnabled\": false,   \"inputMode\": \"ANY\",   \"tooltip\": \"{i.i18n.payments.payeeNickName}\" }";
            addPayee.categoryButton3 = addPayee_data.categoryButton3 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.common.proceed}\",     \"default\": \"{i.i18n.common.proceed}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"categoryBtnRight1Onclick\"   } }";
            addPayee.reviewField5Value = addPayee_data.reviewField5Value || "{\"text\": \"{$.c.nameOnBill}\",\"fieldType\": \"Label\"}";
            addPayee.ackField3Label = addPayee_data.ackField3Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeAccountNumberWithColon}\",   \"default\": \"{i.i18n.payments.payeeAccountNumberWithColon}\" }";
            addPayee.maskeyeiconskin = addPayee_data.maskeyeiconskin || "{\"640\":{\"skin\":\"ICSknGlyster20px\"},\"default\":{\"skin\":\"ICSknGlyster20px\"}}";
            addPayee.editFlowField5Label = addPayee_data.editFlowField5Label || "";
            addPayee.Tab1Field5Label = addPayee_data.Tab1Field5Label || "[   {     \"text\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.phoneNumberWithColon}\",       \"default\": \"{i.i18n.payments.phoneNumberWithColon}\"     },     \"category\": [       \"2\"     ]   },   {     \"text\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.policyNumberWithColon}\",       \"default\": \"{i.i18n.payments.policyNumberWithColon}\"     },     \"category\": [       \"4\"     ]   } ]";
            addPayee.Tab2StateValue = addPayee_data.Tab2StateValue || "{   \"mapping\": \"{$.c.state}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.selectState}\",     \"default\": \"{i.i18n.payments.selectState}\"   },   \"tooltip\": \"{i.i18n.common.state}\" }";
            addPayee.editButton1 = addPayee_data.editButton1 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.kony.tab.common.Cancel}\",     \"default\": \"{i.kony.tab.common.Cancel}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"editDetailsBtnRight3OnClick\"   } }";
            addPayee.reviewButton1 = addPayee_data.reviewButton1 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.transfers.Cancel}\",     \"default\": \"{i.i18n.transfers.Cancel}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"confirmBtnRight3OnClick\"   } }";
            addPayee.ackField3Value = addPayee_data.ackField3Value || "{\"text\": \"{$.c.accountNumber}\",\"fieldType\": \"Account Number\"}";
            addPayee.unmaskeyeiconskin = addPayee_data.unmaskeyeiconskin || "{\"640\":{\"skin\":\"ICSknGlyster20px\"},\"default\":{\"skin\":\"ICSknGlyster20px\"}}";
            addPayee.editFlowField5Value = addPayee_data.editFlowField5Value || "";
            addPayee.editFlowAddress1Label = addPayee_data.editFlowAddress1Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.addressWithColon}\",\"default\": \"{i.i18n.payments.addressWithColon}\"}";
            addPayee.Tab1Field5Value = addPayee_data.Tab1Field5Value || "[   {     \"placeholder\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPhoneNumber}\",       \"default\": \"{i.i18n.payments.enterPhoneNumber}\"     },     \"category\": [       \"2\"     ],     \"mapping\": \"{$.c.phone}\"   },   {     \"placeholder\": {       \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPolicyNumber}\",       \"default\": \"{i.i18n.payments.enterPolicyNumber}\"     },     \"category\": [       \"4\"     ],     \"mapping\": \"{$.c.phone}\"   } ]";
            addPayee.Tab2CityLabel = addPayee_data.Tab2CityLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.unified.city}\",\"default\": \"{i.i18n.unified.city}\"}";
            addPayee.editButton2 = addPayee_data.editButton2 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.CardManagement.Back}\",     \"default\": \"{i.i18n.CardManagement.Back}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"editDetailsBtnRight2OnClick\"   } }";
            addPayee.reviewButton2 = addPayee_data.reviewButton2 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.transfers.Modify}\",     \"default\": \"{i.i18n.transfers.Modify}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"confirmBtnRight2OnClick\"   } }";
            addPayee.ackField4Label = addPayee_data.ackField4Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.payeeNicknameWithColon}\",   \"default\": \"{i.i18n.payments.payeeNicknameWithColon}\" }";
            addPayee.accountNumberSkin = addPayee_data.accountNumberSkin || "{\"640\":{\"skin\":\"ICSknLabel42424215PXBG00\"},\"default\":{\"skin\":\"ICSknLabel42424215PXBG00\"}}";
            addPayee.editFlowAddress1Value = addPayee_data.editFlowAddress1Value || "{\"mapping\": \"{$.c.street}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.ProfileManagement.Address}\",\"default\": \"{i.i18n.ProfileManagement.Address}\"}}";
            addPayee.helpText = addPayee_data.helpText || "{\"$.BREAKPTS.BP1\": \"{i.i18n.addPayee.CantFindBiller}\",\"default\": \"{i.i18n.addPayee.CantFindBiller}\"}";
            addPayee.Tab2CityValue = addPayee_data.Tab2CityValue || "{   \"mapping\": \"{$.c.cityName}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPayeeCity}\",     \"default\": \"{i.i18n.payments.enterPayeeCity}\"   },   \"tooltip\": \"{i.i18n.TransfersEur.City}\" }";
            addPayee.editButton3 = addPayee_data.editButton3 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.userManagement.Continue}\",     \"default\": \"{i.i18n.userManagement.Continue}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"editDetailsBtnRight1OnClick\"   } }";
            addPayee.reviewButton3 = addPayee_data.reviewButton3 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.common.confirm}\",     \"default\": \"{i.i18n.common.confirm}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"confirmBtnRight1OnClick\"   } }";
            addPayee.ackField4Value = addPayee_data.ackField4Value || "{\"text\": \"{$.c.payeeNickName}\",\"fieldType\": \"Label\"}";
            addPayee.sknAddTextBoxDisabled = addPayee_data.sknAddTextBoxDisabled || "ICSknTbxDisabledSSPreg42424215px";
            addPayee.editFlowAddress2Label = addPayee_data.editFlowAddress2Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.addresslineWithColon}\",   \"default\": \"{i.i18n.payments.addresslineWithColon}\" }";
            addPayee.helpAction = addPayee_data.helpAction || "{\"text\": {\"$.BREAKPTS.BP1\": \"{i.i18n.addPayee.EnterInfoManually}\",\"default\": \"{i.i18n.addPayee.EnterInfoManually}\"},\"action\": {\"level\": \"Form\",\"method\": \"\"}}";
            addPayee.Tab2ZipCodeLabel = addPayee_data.Tab2ZipCodeLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.zipCodeWithColon}\",\"default\": \"{i.i18n.payments.zipCodeWithColon}\"}";
            addPayee.ackField5Label = addPayee_data.ackField5Label || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.Nametobeappearedonbill}\",   \"default\": \"{i.i18n.AddPayee.Nametobeappearedonbill}\" }";
            addPayee.sknSelectedTab = addPayee_data.sknSelectedTab || "ICSknsknBtnAccountSummarySelected";
            addPayee.payeeDetailsField2Value = addPayee_data.payeeDetailsField2Value || "{   \"text\": \"{$.c.street}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.reviewCancelYesButton = addPayee_data.reviewCancelYesButton || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.common.yes}\",     \"default\": \"{i.i18n.common.yes}\"   },   \"action\": {     \"level\": \"form\",     \"method\": \"cancelYesAction\"   } }";
            addPayee.editFlowAddress2Value = addPayee_data.editFlowAddress2Value || "{\"mapping\": \"{$.c.addressLine2}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.StopPayments.Optional}\",\"default\": \"{i.i18n.StopPayments.Optional}\"}}";
            addPayee.Tab1Button1 = addPayee_data.Tab1Button1 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.transfers.reset}\",     \"default\": \"{i.i18n.transfers.reset}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"screen1BtnRight2OnClick\"   } }";
            addPayee.Tab2ZipCodeValue = addPayee_data.Tab2ZipCodeValue || "{   \"mapping\": \"{$.c.zipCode}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.enterPayeeZipCode}\",     \"default\": \"{i.i18n.payments.enterPayeeZipCode}\"   },   \"tooltip\": \"{i.i18n.common.zipcode}\" }";
            addPayee.ackField5Value = addPayee_data.ackField5Value || "{\"text\": \"{$.c.nameOnBill}\",\"fieldType\": \"Label\"}";
            addPayee.reviewDetailsField2Value = addPayee_data.reviewDetailsField2Value || "{   \"text\": \"{$.c.street}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.sknUnSelectedTab = addPayee_data.sknUnSelectedTab || "ICSknsknBtnAccountSummaryUnSelected";
            addPayee.editFlowCountryLabel = addPayee_data.editFlowCountryLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.countryWithColon}\",\"default\": \"{i.i18n.payments.countryWithColon}\"}";
            addPayee.tab1Button2 = addPayee_data.tab1Button2 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.userManagement.Continue}\",     \"default\": \"{i.i18n.userManagement.Continue}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"screen1BtnRight1OnClick\"   } }";
            addPayee.Tab2Field8Label = addPayee_data.Tab2Field8Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberWithColon}\",\"default\": \"{i.i18n.payments.accountNumberWithColon}\"}";
            addPayee.ackButton1 = addPayee_data.ackButton1 || "{   \"$.FLOWTYPES.FT1\": {     \"text\": \"{i.i18n.payments.makeABillPayment}\",     \"action\": {       \"level\": \"Component\",       \"method\": \"ackBtnRight1OnClick\",       \"context\": \"\"     },     \"entitlement\": [       \"PAYEE_MANAGEMENT_CREATE\"     ]   },   \"$.FLOWTYPES.FT2\": {     \"text\": \"{i.i18n.hamburger.payABill}\",     \"action\": {       \"level\": \"Component\",       \"method\": \"ackBtnRight1OnClick\",       \"context\": \"\"     },     \"entitlement\": [       \"PAYEE_MANAGEMENT_CREATE\"     ]   } }";
            addPayee.sknTabHover = addPayee_data.sknTabHover || "sknBtnAccountSummaryHover";
            addPayee.editFlowCountryValue = addPayee_data.editFlowCountryValue || "{\"mapping\": \"{$.c.country}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.kony.mb.ProfileCountry.Title}\",\"default\": \"{i.kony.mb.ProfileCountry.Title}\"},\"tooltip\": \"{i.i18n.TransfersEur.City}\"}";
            addPayee.characterDelay = addPayee_data.characterDelay || 100;
            addPayee.Tab2Field8Value = addPayee_data.Tab2Field8Value || "{   \"mapping\": \"{$.c.accountNumber}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.UnifiedAddBeneficiary.AccountNumber}\",     \"default\": \"{i.i18n.UnifiedAddBeneficiary.AccountNumber}\"   },   \"isMaskingEnabled\": true,   \"infoIconText\": \"\",   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.informationAboutWidget}\",     \"default\": \"{i.i18n.payments.informationAboutWidget}\"   },   \"inputMode\": \"NUMERIC\",   \"tooltip\": \"{i.i18n.common.accountNumber}\" }";
            addPayee.ackButton2 = addPayee_data.ackButton2 || "{\"$.FLOWTYPES.FT1\":{\"text\":\"{i.i18n.payments.viewAllPayees}\",\"action\":{\"level\":\"Component\",\"method\":\"ackBtnRight2OnClick\",\"context\":\"\"},\"entitlement\":[\"PAYEE_MANAGEMENT_VIEW\"]},\"$.FLOWTYPES.FT2\":{\"text\":\"{i.i18n.billPay.ManagePayee}\",\"action\":{\"level\":\"Component\",\"method\":\"ackBtnRight2OnClick\",\"context\":\"\"},\"entitlement\":[\"PAYEE_MANAGEMENT_VIEW\"]}}";
            addPayee.sknAddTextBoxError = addPayee_data.sknAddTextBoxError || "ICSknskntxtSSP424242BorderFF0000Op100Radius2px";
            addPayee.editFlowStateLabel = addPayee_data.editFlowStateLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.stateWithColon}\",\"default\": \"{i.i18n.payments.stateWithColon}\"}";
            addPayee.ackDetailsField2Value = addPayee_data.ackDetailsField2Value || "{   \"text\": \"{$.c.street}, {$.c.country}, {$.c.state}, {$.c.cityName}, {$.c.zipCode}\",   \"fieldType\": \"Label\" }";
            addPayee.Tab2Field9Label = addPayee_data.Tab2Field9Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.confirmAccountNumberWithColon}\",\"default\": \"{i.i18n.payments.confirmAccountNumberWithColon}\"}";
            addPayee.Tab1Field6Label = addPayee_data.Tab1Field6Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.confirmAccountNumberWithColon}\",\"default\": \"{i.i18n.payments.confirmAccountNumberWithColon}\"}";
            addPayee.sknListBox = addPayee_data.sknListBox || "ICSknlbx42424220px";
            addPayee.editFlowStateValue = addPayee_data.editFlowStateValue || "{\"mapping\": \"{$.c.state}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.payments.stateSelect}\",\"default\": \"{i.i18n.payments.stateSelect}\"},\"tooltip\": \"{i.i18n.common.state}\"}";
            addPayee.field9ValueTab2 = addPayee_data.field9ValueTab2 || "{   \"mapping\": \"{$.c.accountNumber}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberConfirm}\",     \"default\": \"{i.i18n.payments.accountNumberConfirm}\"   },   \"isMaskingEnabled\": false,   \"inputMode\": \"NUMERIC\",   \"tooltip\": \"{i.i18n.common.accountNumber}\" }";
            addPayee.Tab1Field7Label = addPayee_data.Tab1Field7Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.confirmAccountNumberWithColon}\",\"default\": \"{i.i18n.payments.confirmAccountNumberWithColon}\"}";
            addPayee.editAckText = addPayee_data.editAckText || "{   \"$.BREAKPTS.BP1\": \"{$.c.companyName}\",   \"default\": \"{$.c.companyName}\" }";
            addPayee.editFlowCityLabel = addPayee_data.editFlowCityLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.unified.city}\",\"default\": \"{i.i18n.unified.city}\"}";
            addPayee.Tab2CheckBoxLabel = addPayee_data.Tab2CheckBoxLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.IdonthaveanAccount}\",\"default\": \"{i.i18n.AddPayee.IdonthaveanAccount}\"}";
            addPayee.Tab1Field6Value = addPayee_data.Tab1Field6Value || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberConfirm}\",   \"default\": \"{i.i18n.payments.accountNumberConfirm}\" }";
            addPayee.editFlowCityValue = addPayee_data.editFlowCityValue || "{\"mapping\": \"{$.c.cityName}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.EnterPayeesCity}\",\"default\": \"{i.i18n.AddPayee.EnterPayeesCity}\"},\"tooltip\": \"{i.i18n.TransfersEur.City}\"}";
            addPayee.Tab2CheckBox = addPayee_data.Tab2CheckBox || "{\"font\":\"\",\"selectedText\":\"\",\"unselectedText:\"\",clearFieldValue:\"{$.c.accountNumber}\"}";
            addPayee.Tab1Field7Value = addPayee_data.Tab1Field7Value || "{   \"$.BREAKPTS.BP1\": \"{i.i18n.payments.accountNumberConfirm}\",   \"default\": \"{i.i18n.payments.accountNumberConfirm}\" }";
            addPayee.editFlowZipCodeLabel = addPayee_data.editFlowZipCodeLabel || "{\"$.BREAKPTS.BP1\": \"{i.i18n.payments.zipCodeWithColon}\",\"default\": \"{i.i18n.payments.zipCodeWithColon}\"}";
            addPayee.Tab2Field10Label = addPayee_data.Tab2Field10Label || "";
            addPayee.enterInfoManuallyLink = addPayee_data.enterInfoManuallyLink || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.kony.mb.OBAddPersonalInfo.Enter}\",     \"default\": \"{i.kony.mb.OBAddPersonalInfo.Enter}\"   },   \"action\": {     \"level\": \"form\",     \"method\": \"enterInformationManually\"   } }";
            addPayee.editFlowZipCodeValue = addPayee_data.editFlowZipCodeValue || "{\"mapping\": \"{$.c.zipCode}\",\"placeHolder\": {\"$.BREAKPTS.BP1\": \"{i.i18n.AddPayee.EnterPayeesZipCode}\",\"default\": \"{i.i18n.AddPayee.EnterPayeesZipCode}\"},\"tooltip\": \"{i.i18n.common.zipcode}\"}";
            addPayee.Tab2Field10Value = addPayee_data.Tab2Field10Value || "";
            addPayee.editFlowButton1 = addPayee_data.editFlowButton1 || "{   \"text\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.transfers.Cancel}\",     \"default\": \"{i.i18n.transfers.Cancel}\"   },   \"action\": {     \"level\": \"Component\",     \"method\": \"cancelEditPayee\"   } }";
            addPayee.Tab2Button1 = addPayee_data.Tab2Button1 || "{\"text\": {\"$.BREAKPTS.BP1\": \"{i.i18n.transfers.reset}\",\"default\": \"{i.i18n.transfers.reset}\"},\"action\": {\"level\": \"Component\",\"method\": \"tab2ResetAction\"}}";
            addPayee.editFlowButton2 = addPayee_data.editFlowButton2 || "{\"text\": {\"$.BREAKPTS.BP1\": \"{i.i18n.unifiedBeneficiary.Continue}\",\"default\": \"{i.i18n.unifiedBeneficiary.Continue}\"},\"action\": {\"level\": \"Component\",\"method\": \"editPayee\"}}";
            addPayee.tab2Button2 = addPayee_data.tab2Button2 || "{\"text\": {\"$.BREAKPTS.BP1\": \"{i.i18n.userManagement.Continue}\",\"default\": \"{i.i18n.userManagement.Continue}\"},\"action\": {\"level\": \"Component\",\"method\": \"manualEntryNextTab2\"}}{\"text\": {\"$.BREAKPTS.BP1\": \"{i.i18n.userManagement.Continue}\",\"default\": \"{i.i18n.userManagement.Continue}\"},\"action\": {\"level\": \"Component\",\"method\": \"manualEntryNextTab2\"}}";
            addPayee.Tab2Field11Label = addPayee_data.Tab2Field11Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.accounts.Note}\",\"default\": \"{i.i18n.accounts.Note}\"}";
            addPayee.Tab2Field12Label = addPayee_data.Tab2Field12Label || "{\"$.BREAKPTS.BP1\": \"{i.i18n.accounts.Note}\",\"default\": \"{i.i18n.accounts.Note}\"}";
            addPayee.Tab2Field11Value = addPayee_data.Tab2Field11Value || "{   \"mapping\": \"{$.c.notes}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.optionallyEnterNote}\",     \"default\": \"{i.i18n.payments.optionallyEnterNote}\"   } }";
            addPayee.Tab2Field12Value = addPayee_data.Tab2Field12Value || "{   \"mapping\": \"{$.c.notes}\",   \"placeHolder\": {     \"$.BREAKPTS.BP1\": \"{i.i18n.payments.optionallyEnterNote}\",     \"default\": \"{i.i18n.payments.optionallyEnterNote}\"   } }";
            flxLeft.add(addPayee);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "top": "75dp",
                "width": "28.55%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxRegisteredPayees = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "537dp",
                "id": "flxRegisteredPayees",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRegisteredPayees.setDefaultUnit(kony.flex.DP);
            var flxMyRegisteredPayees = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMyRegisteredPayees",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyRegisteredPayees.setDefaultUnit(kony.flex.DP);
            var lblMyRegisteredPayees = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "bottom": "15px",
                "centerY": "50%",
                "height": "30px",
                "id": "lblMyRegisteredPayees",
                "isVisible": true,
                "left": "5.12%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.MYREGISTEREDPAYEES\")",
                "width": "80.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHorizontalLine1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 50,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine1.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine1.add();
            flxMyRegisteredPayees.add(lblMyRegisteredPayees, flxHorizontalLine1);
            var segRegisteredPayees = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "477dp",
                "id": "segRegisteredPayees",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxRegistered"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRegisteredPayees.add(flxMyRegisteredPayees, segRegisteredPayees);
            var flxBillPayActivities = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "View My Bills Activities"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxBillPayActivities",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayActivities.setDefaultUnit(kony.flex.DP);
            var lblViewBillPayActivities = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblViewBillPayActivities",
                "isVisible": true,
                "left": "20dp",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.ViewBillPayActivities\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBillPayActivities.add(lblViewBillPayActivities);
            flxRight.add(flxRegisteredPayees, flxBillPayActivities);
            flxContainer.add(flxLeft, flxRight);
            flxMain.add(flxDowntimeWarning, flxContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Data is Loading"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            flxDialogs.add(flxLogout, flxLoading);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1388,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "i18n.billPay.addPayee",
                        "text": "Add Payee",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "addPayee": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRegisteredPayees": {
                        "segmentProps": []
                    },
                    "flxBillPayActivities": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "addPayee": {
                        "skin": "slFboxBGf8f7f8B0",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRegisteredPayees": {
                        "segmentProps": []
                    },
                    "flxBillPayActivities": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.07%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "addPayee": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxRegisteredPayees": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxBillPayActivities": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "segmentProps": []
                    }
                },
                "1388": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "0.07000000000000028%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "addPayee": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxRegisteredPayees": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customheadernew.lblHeaderMobile": {
                    "text": "T"
                },
                "addPayee": {
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAddPayee1,
            "enabledForIdleTimeout": true,
            "id": "frmAddPayee1",
            "init": controller.AS_Form_h70b07ffe08f4bd1a249d3b986aec479,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Add Payee",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1388],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});