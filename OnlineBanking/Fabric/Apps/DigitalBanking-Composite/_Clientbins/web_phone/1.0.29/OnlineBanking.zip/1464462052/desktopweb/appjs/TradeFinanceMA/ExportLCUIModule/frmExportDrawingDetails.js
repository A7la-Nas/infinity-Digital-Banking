define("TradeFinanceMA/ExportLCUIModule/frmExportDrawingDetails", function() {
    return function(controller) {
        function addWidgetsfrmExportDrawingDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "1366px",
                "zIndex": 10,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionsMenu": {
                        "bottom": 32,
                        "right": "0dp",
                        "top": "0dp"
                    },
                    "flxShadowContainer": {
                        "isVisible": true
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxExportLCDrawingViewDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "-1000dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxExportLCDrawingViewDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "top": "150dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportLCDrawingViewDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingHeader.setDefaultUnit(kony.flex.DP);
            var lblExportLCDrawingHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExportLCDrawingHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "text": "Export LC - Drawing Details - DC1000017",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisBodyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "-10dp",
                "top": "0dp",
                "width": "5.80%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBodyContent.setDefaultUnit(kony.flex.DP);
            var flxVerticalEllipsisBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "6.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBody.setDefaultUnit(kony.flex.DP);
            var lblVerticalEllipsis = new kony.ui.Label({
                "centerX": "50%",
                "height": "100%",
                "id": "lblVerticalEllipsis",
                "isVisible": true,
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerticalEllipsisDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "-8dp",
                "skin": "slfBoxffffffB1R5",
                "top": "38dp",
                "width": "250dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.setDefaultUnit(kony.flex.DP);
            var segVerticalDropdownEllipsis = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segVerticalDropdownEllipsis",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCTypeOfAccountsList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListRow": "flxAccountListRow",
                    "flxLCAccountType": "flxLCAccountType",
                    "flxLCType": "flxLCType",
                    "flxLCTypeOfAccountsList": "flxLCTypeOfAccountsList",
                    "imgLCCheckbox": "imgLCCheckbox",
                    "lblLCAccountType": "lblLCAccountType",
                    "lblLCCheckbox": "lblLCCheckbox"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.add(segVerticalDropdownEllipsis);
            flxVerticalEllipsisBody.add(lblVerticalEllipsis, flxVerticalEllipsisDropdown);
            flxVerticalEllipsisBodyContent.add(flxVerticalEllipsisBody);
            flxDrawingHeader.add(lblExportLCDrawingHeader, flxVerticalEllipsisBodyContent);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "10dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var flxErrorDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "56dp",
                "id": "flxErrorDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorDetails.setDefaultUnit(kony.flex.DP);
            var imgErrorIcon = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50dp",
                "id": "imgErrorIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "failed_icon.png",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorMessage = new kony.ui.Label({
                "centerY": "45%",
                "id": "lblErrorMessage",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular42424224px",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorDetails.add(imgErrorIcon, lblErrorMessage);
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "18dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgCloseIcon = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCloseIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgCloseIcon);
            flxErrorMessage.add(flxErrorDetails, flxClose);
            var flxLCSummary = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummary.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummeryHeaderContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLCSummeryHeaderContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummeryHeaderContent.setDefaultUnit(kony.flex.DP);
            var flxLCSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.add(lblLCSummary);
            var flxViewLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetials = new kony.ui.Label({
                "id": "lblViewLCDetials",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "lblViewReturnedByBankHistory"
            });
            flxViewLCDetails.add(lblViewLCDetials);
            flxLCSummeryHeaderContent.add(flxLCSummarylbl, flxViewLCDetails);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            flxLCSummaryHeader.add(flxLCSummeryHeaderContent, flxBottomSeparator);
            var flxBodyContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "64.38%",
                "id": "flxBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32%",
                "width": "30.83%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContent.setDefaultUnit(kony.flex.DP);
            var flxContentLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "369dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "height": "18dp",
                "id": "lblApplicant",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantName = new kony.ui.Label({
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel.add(lblApplicant, lblApplicantName);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var lblLCRefNo = new kony.ui.Label({
                "id": "lblLCRefNo",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AdvisingLCRefNo\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRightLCRefNo = new kony.ui.Label({
                "id": "lblRightLCRefNo",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContent.add(lblLCRefNo, lblRightLCRefNo);
            var flxContentLabel1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel1.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeValue = new kony.ui.Label({
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel1.add(lblLCType, lblLCTypeValue);
            var flxContentLabel2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel2.setDefaultUnit(kony.flex.DP);
            var lblIssueBank = new kony.ui.Label({
                "id": "lblIssueBank",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.cardManage.issuingBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueBankValue = new kony.ui.Label({
                "id": "lblIssueBankValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel2.add(lblIssueBank, lblIssueBankValue);
            flxBodyContent.add(flxContentLabel, flxContent, flxContentLabel1, flxContentLabel2);
            var flxBodyContentRigh = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxBodyContentRigh",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "421dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentRigh.setDefaultUnit(kony.flex.DP);
            var flxContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCAmount\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValue = new kony.ui.Label({
                "id": "lblLCAmountValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight.add(lblLCAmount, lblLCAmountValue);
            var flxContentRight1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight1.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "id": "lblIssueDate",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssueDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateValue = new kony.ui.Label({
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight1.add(lblIssueDate, lblIssueDateValue);
            var flxContentRight2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "76dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight2.setDefaultUnit(kony.flex.DP);
            var lblIssueLCRefNo = new kony.ui.Label({
                "id": "lblIssueLCRefNo",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssuingLCRefNo\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingRefNoValue = new kony.ui.Label({
                "id": "lblIssuingRefNoValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight2.add(lblIssueLCRefNo, lblIssuingRefNoValue);
            flxBodyContentRigh.add(flxContentRight, flxContentRight1, flxContentRight2);
            var flxBodyContentLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxBodyContentLast",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "816dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentLast.setDefaultUnit(kony.flex.DP);
            var flxContentLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast.setDefaultUnit(kony.flex.DP);
            var lblLCUntilizedAmount = new kony.ui.Label({
                "id": "lblLCUntilizedAmount",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCUntilizedAmount\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCUntilizedAmountValue = new kony.ui.Label({
                "id": "lblLCUntilizedAmountValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast.add(lblLCUntilizedAmount, lblLCUntilizedAmountValue);
            var flxContentLast1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast1.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.ExpiryDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast1.add(lblExpiryDate, lblExpiryDateValue);
            flxBodyContentLast.add(flxContentLast, flxContentLast1);
            var flxLCSummaryContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLCSummaryContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryContent.setDefaultUnit(kony.flex.DP);
            var flxApplicant = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApplicant",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicant.setDefaultUnit(kony.flex.DP);
            var lblApplicantValue = new kony.ui.Label({
                "id": "lblApplicantValue",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblName",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicant.add(lblApplicantValue, lblName);
            var flxAdvisingLCReferenceNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvisingLCReferenceNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvisingLCReferenceNumber.setDefaultUnit(kony.flex.DP);
            var lblAdvisingLCReferenceNumber = new kony.ui.Label({
                "id": "lblAdvisingLCReferenceNumber",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "TotalDocuments:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdvisingLCReferenceNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblAdvisingLCReferenceNumberValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvisingLCReferenceNumber.add(lblAdvisingLCReferenceNumber, lblAdvisingLCReferenceNumberValue);
            var flxLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmount.setDefaultUnit(kony.flex.DP);
            var lblLCAmountLabel = new kony.ui.Label({
                "id": "lblLCAmountLabel",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCAmount\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValueContainer = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblLCAmountValueContainer",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmount.add(lblLCAmountLabel, lblLCAmountValueContainer);
            var flxLCUntilizedAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCUntilizedAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCUntilizedAmount.setDefaultUnit(kony.flex.DP);
            var lblLCUntilizedAmountLbl = new kony.ui.Label({
                "id": "lblLCUntilizedAmountLbl",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCUntilizedAmount\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCUtilizedAmount = new kony.ui.Label({
                "id": "lblLCUtilizedAmount",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCUntilizedAmount.add(lblLCUntilizedAmountLbl, lblLCUtilizedAmount);
            var flxLCType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCType.setDefaultUnit(kony.flex.DP);
            var lblLCTypeLeft = new kony.ui.Label({
                "id": "lblLCTypeLeft",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeRight = new kony.ui.Label({
                "id": "lblLCTypeRight",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCType.add(lblLCTypeLeft, lblLCTypeRight);
            var flxIssueDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssueDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssueDate.setDefaultUnit(kony.flex.DP);
            var lblIssueDateLeft = new kony.ui.Label({
                "id": "lblIssueDateLeft",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssueDate\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateRight = new kony.ui.Label({
                "id": "lblIssueDateRight",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssueDate.add(lblIssueDateLeft, lblIssueDateRight);
            var flxExpiryDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExpiryDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDate.setDefaultUnit(kony.flex.DP);
            var lblExpiryDateLeft = new kony.ui.Label({
                "id": "lblExpiryDateLeft",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.ExpiryDate\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateRight = new kony.ui.Label({
                "id": "lblExpiryDateRight",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDate.add(lblExpiryDateLeft, lblExpiryDateRight);
            var flxIssuingBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssuingBank",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingBank.setDefaultUnit(kony.flex.DP);
            var lblIssuingBankLeft = new kony.ui.Label({
                "id": "lblIssuingBankLeft",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.cardManage.issuingBank\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankRight = new kony.ui.Label({
                "id": "lblIssuingBankRight",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingBank.add(lblIssuingBankLeft, lblIssuingBankRight);
            var flxIssuingLCRefNo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIssuingLCRefNo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNo.setDefaultUnit(kony.flex.DP);
            var lblIssuingLCRefNoLeft = new kony.ui.Label({
                "id": "lblIssuingLCRefNoLeft",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssuingLCRefNo\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingLCRefNoRight = new kony.ui.Label({
                "id": "lblIssuingLCRefNoRight",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIssuingLCRefNo.add(lblIssuingLCRefNoLeft, lblIssuingLCRefNoRight);
            flxLCSummaryContent.add(flxApplicant, flxAdvisingLCReferenceNumber, flxLCAmount, flxLCUntilizedAmount, flxLCType, flxIssueDate, flxExpiryDate, flxIssuingBank, flxIssuingLCRefNo);
            flxLCSummary.add(flxLCSummaryHeader, flxBodyContent, flxBodyContentRigh, flxBodyContentLast, flxLCSummaryContent);
            var flxDrawingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox1",
                "top": "30dp",
                "width": "99.99%",
                "zIndex": 4,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDrawingDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDrawingDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.DrawingDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingDetailsDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingDetailsDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDrawingDetailsDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.add(imgDrawingDetailsDropdown);
            var flxViewLCDetails02 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails02",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "85%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35%",
                "width": "23.95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails02.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetials02 = new kony.ui.Label({
                "height": "20dp",
                "id": "lblViewLCDetials02",
                "isVisible": true,
                "left": "60%",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View LC Details",
                "top": "0dp",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewLCDetails02.add(lblViewLCDetials02);
            flxDrawingDetailsHeader.add(lblDrawingDetails, flxDrawingDetailsDropdown, flxViewLCDetails02);
            var flxDrawingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingContent.setDefaultUnit(kony.flex.DP);
            var flxSeparator01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator01.setDefaultUnit(kony.flex.DP);
            flxSeparator01.add();
            var flxDrawingStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.setDefaultUnit(kony.flex.DP);
            var lblDrawingStatusKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingStatusKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingStatus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingStatusValue = new kony.ui.Label({
                "id": "lblDrawingStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.add(lblDrawingStatusKey, lblDrawingStatusValue);
            var flxDrawingRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingRef.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingRefKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingRefNo\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefValue = new kony.ui.Label({
                "id": "lblDrawingRefValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingRef.add(lblDrawingRefKey, lblDrawingRefValue);
            var flxDrawingCreated = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingCreated",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingCreated.setDefaultUnit(kony.flex.DP);
            var lblDrawingCreatedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingCreatedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingCreatedDate\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingCreatedValue = new kony.ui.Label({
                "id": "lblDrawingCreatedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingCreated.add(lblDrawingCreatedKey, lblDrawingCreatedValue);
            var flxDrawingAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingAmount.setDefaultUnit(kony.flex.DP);
            var lblDrawingAmountKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingAmountKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DrawingAmount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingAmountValue = new kony.ui.Label({
                "id": "lblDrawingAmountValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingAmount.add(lblDrawingAmountKey, lblDrawingAmountValue);
            var flxAmountCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCredited",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCredited.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblAmountCreditedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmounttobeCreditto\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountCrediredValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCrediredValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedValue = new kony.ui.Label({
                "id": "lblAmountCreditedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountCreditedValueInfo = new kony.ui.Label({
                "id": "lblAmountCreditedValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.OtherBeneficiaryName\")",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.add(lblAmountCreditedValue, lblAmountCreditedValueInfo);
            flxAmountCredited.add(lblAmountCreditedKey, flxAmountCrediredValue);
            var flxFinanceUS = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUS",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUS.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblFinanceUSKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Financeus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFinanceUSValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUSValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSValue = new kony.ui.Label({
                "id": "lblFinanceUSValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFinanceUSInfo = new kony.ui.Label({
                "id": "lblFinanceUSInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "(Please Finance us for the draft amount by negotiation with full recourse to us)",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.add(lblFinanceUSValue, lblFinanceUSInfo);
            flxFinanceUS.add(lblFinanceUSKey, flxFinanceUSValue);
            var flxUploadDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocs.setDefaultUnit(kony.flex.DP);
            var lblUploadDocsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblUploadDocsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.UploadDocuments\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadDocsValue = new kony.ui.Label({
                "id": "lblUploadDocsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segUploadDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "id": "segUploadDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxFrmExportLCViewDetailsReturnedDoc"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFrmExportLCViewDetailsReturnedDoc": "flxFrmExportLCViewDetailsReturnedDoc",
                    "lblListValue": "lblListValue"
                },
                "width": "65%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDocs.add(lblUploadDocsKey, lblUploadDocsValue, segUploadDocuments);
            var flxPhysicalDocDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalDocDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocDetailsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPhysicalDocDetailsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PhysicalDocumentDetails\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhysicalDocDetailsValue = new kony.ui.Label({
                "id": "lblPhysicalDocDetailsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segPhysicalDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "id": "segPhysicalDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxFrmExportLCViewDetailsReturnedDoc"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFrmExportLCViewDetailsReturnedDoc": "flxFrmExportLCViewDetailsReturnedDoc",
                    "lblListValue": "lblListValue"
                },
                "width": "65%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.add(lblPhysicalDocDetailsKey, lblPhysicalDocDetailsValue, segPhysicalDocuments);
            var flxDiscrepancies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancies.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDiscrepanciesKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Forwarddespiteanydiscrepancies\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDiscrepanciesValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesValue = new kony.ui.Label({
                "id": "lblDiscrepanciesValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDiscrepanciesValueInfo = new kony.ui.Label({
                "id": "lblDiscrepanciesValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "(Kindly forward documents to issuing bank as presented despite any discrepancy noted)",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.add(lblDiscrepanciesValue, lblDiscrepanciesValueInfo);
            flxDiscrepancies.add(lblDiscrepanciesKey, flxDiscrepanciesValue);
            var flxChargesDebit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChargesDebit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesDebit.setDefaultUnit(kony.flex.DP);
            var lblChargesDebitKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblChargesDebitKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ChargesDebitAccount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChargesDebitValue = new kony.ui.Label({
                "id": "lblChargesDebitValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChargesDebit.add(lblChargesDebitKey, lblChargesDebitValue);
            var flxMsgToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxMsgToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsgToBank.setDefaultUnit(kony.flex.DP);
            var lblMsgToBankKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblMsgToBankKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBankDrawings\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMsgToBankValue = new kony.ui.Label({
                "id": "lblMsgToBankValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsgToBank.add(lblMsgToBankKey, lblMsgToBankValue);
            flxDrawingContent.add(flxSeparator01, flxDrawingStatus, flxDrawingRef, flxDrawingCreated, flxDrawingAmount, flxAmountCredited, flxFinanceUS, flxUploadDocs, flxPhysicalDocDetails, flxDiscrepancies, flxChargesDebit, flxMsgToBank);
            flxDrawingDetails.add(flxDrawingDetailsHeader, flxDrawingContent);
            var flxDocumentStatusAndPaymentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentStatusAndPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentStatusAndPaymentDetails.setDefaultUnit(kony.flex.DP);
            var flxDocumentsAndStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsAndStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsAndStatus.setDefaultUnit(kony.flex.DP);
            var flxDocumentsAndStatusHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDocumentsAndStatusHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsAndStatusHeader.setDefaultUnit(kony.flex.DP);
            var flxDocTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxDocTopSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocTopSeparator.setDefaultUnit(kony.flex.DP);
            flxDocTopSeparator.add();
            var flxDocumenstAndStatusLbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDocumenstAndStatusLbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumenstAndStatusLbl.setDefaultUnit(kony.flex.DP);
            var lblDrawingsAndStatus = new kony.ui.Label({
                "id": "lblDrawingsAndStatus",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DocumentsAndStatus\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumenstAndStatusLbl.add(lblDrawingsAndStatus);
            var flxDocumentAndStatusDropDown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "7dp",
                "id": "flxDocumentAndStatusDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentAndStatusDropDown.setDefaultUnit(kony.flex.DP);
            var imgDocumentAndStatus = new kony.ui.Image2({
                "height": "100%",
                "id": "imgDocumentAndStatus",
                "isVisible": true,
                "left": "0",
                "src": "arrowup_sm.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentAndStatusDropDown.add(imgDocumentAndStatus);
            var flxBottomSeparatorDoc = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparatorDoc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.45%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "120%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparatorDoc.setDefaultUnit(kony.flex.DP);
            flxBottomSeparatorDoc.add();
            flxDocumentsAndStatusHeader.add(flxDocTopSeparator, flxDocumenstAndStatusLbl, flxDocumentAndStatusDropDown, flxBottomSeparatorDoc);
            var flxDocumentsAndStatusContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "32dp",
                "clipBounds": false,
                "id": "flxDocumentsAndStatusContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsAndStatusContent.setDefaultUnit(kony.flex.DP);
            var flxTotalDocument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocument",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocument.setDefaultUnit(kony.flex.DP);
            var lblTotalDocument = new kony.ui.Label({
                "id": "lblTotalDocument",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TotalDocuments\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalDocumentValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocumentValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocumentValue.setDefaultUnit(kony.flex.DP);
            var flxtotoalDocumentValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxtotoalDocumentValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalDocumentValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalDocumentValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentValueContainer.add(lblTotalDocumentValue);
            flxTotalDocumentValue.add(flxtotoalDocumentValueContainer);
            flxTotalDocument.add(lblTotalDocument, flxTotalDocumentValue);
            var flxDocumentsName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsName.setDefaultUnit(kony.flex.DP);
            var lblDocumentName = new kony.ui.Label({
                "id": "lblDocumentName",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.Documents\")",
                "top": "21dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentsNameSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsNameSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "325dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsNameSegment.setDefaultUnit(kony.flex.DP);
            var segDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblHeading": "Clearance Statement.Pdf"
                }, {
                    "lblHeading": "Invoices.Pdf"
                }],
                "groupCells": false,
                "id": "segDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSectionHeaderTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSectionHeaderTemplate": "flxSectionHeaderTemplate",
                    "lblHeading": "lblHeading"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentsNameSegment.add(segDocuments);
            flxDocumentsName.add(lblDocumentName, flxDocumentsNameSegment);
            var flxDocumentStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentStatus.setDefaultUnit(kony.flex.DP);
            var lblDocumentStatus = new kony.ui.Label({
                "id": "lblDocumentStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DocumentStatus\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentStatusValue.setDefaultUnit(kony.flex.DP);
            var flxDocumentStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblDocumentStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblDocumentStatusValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Clean",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentStatusValueContainer.add(lblDocumentStatusValue);
            flxDocumentStatusValue.add(flxDocumentStatusValueContainer);
            flxDocumentStatus.add(lblDocumentStatus, flxDocumentStatusValue);
            var flxMessageFromBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMessageFromBank",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageFromBank.setDefaultUnit(kony.flex.DP);
            var lblMessageFromBank = new kony.ui.Label({
                "id": "lblMessageFromBank",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessagefromBank\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBankMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankMessage.setDefaultUnit(kony.flex.DP);
            var flxBankMessageText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBankMessageText",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankMessageText.setDefaultUnit(kony.flex.DP);
            var lblBankMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblBankMessage",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankMessageText.add(lblBankMessage);
            flxBankMessage.add(flxBankMessageText);
            flxMessageFromBank.add(lblMessageFromBank, flxBankMessage);
            flxDocumentsAndStatusContent.add(flxTotalDocument, flxDocumentsName, flxDocumentStatus, flxMessageFromBank);
            flxDocumentsAndStatus.add(flxDocumentsAndStatusHeader, flxDocumentsAndStatusContent);
            var flxPaymentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetails.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            flxTopSeparator.add();
            var flxPaymentDetailsLbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPaymentDetailsLbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsLbl.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetails = new kony.ui.Label({
                "id": "lblPaymentDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.PaymentDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsLbl.add(lblPaymentDetails);
            var flxPaymentDetailsDropDown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "7dp",
                "id": "flxPaymentDetailsDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsDropDown.setDefaultUnit(kony.flex.DP);
            var imgPaymentDetails = new kony.ui.Image2({
                "height": "100%",
                "id": "imgPaymentDetails",
                "isVisible": true,
                "left": "0",
                "src": "arrowup_sm.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsDropDown.add(imgPaymentDetails);
            var flxBottomSeparator0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator0.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator0.add();
            flxPaymentDetailsHeader.add(flxTopSeparator, flxPaymentDetailsLbl, flxPaymentDetailsDropDown, flxBottomSeparator0);
            var flxPaymentDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "32dp",
                "clipBounds": false,
                "id": "flxPaymentDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxPaymentStatus = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPaymentStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentStatus.setDefaultUnit(kony.flex.DP);
            var lblPaymentStatus = new kony.ui.Label({
                "id": "lblPaymentStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.PaymentStatus\")",
                "top": "20dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentStatusValue.setDefaultUnit(kony.flex.DP);
            var flxPaymentStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblPaymentStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblPaymentStatusValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Awaiting for Payment ",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentStatusValueContainer.add(lblPaymentStatusValue);
            flxPaymentStatusValue.add(flxPaymentStatusValueContainer);
            flxPaymentStatus.add(lblPaymentStatus, flxPaymentStatusValue);
            var flxApprovedDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovedDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedDate.setDefaultUnit(kony.flex.DP);
            var lblApprovedDate = new kony.ui.Label({
                "id": "lblApprovedDate",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ApprovedDate\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovedDateValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovedDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedDateValue.setDefaultUnit(kony.flex.DP);
            var flxApprovedDateValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovedDateValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedDateValueContainer.setDefaultUnit(kony.flex.DP);
            var lblApprovedDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblApprovedDateValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "04/01/2022",
                "top": "0",
                "width": "66.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovedDateValueContainer.add(lblApprovedDateValue);
            flxApprovedDateValue.add(flxApprovedDateValueContainer);
            flxApprovedDate.add(lblApprovedDate, flxApprovedDateValue);
            var flxTotalAmountToBePaid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalAmountToBePaid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmountToBePaid.setDefaultUnit(kony.flex.DP);
            var lblTotalAmountToBePaid = new kony.ui.Label({
                "id": "lblTotalAmountToBePaid",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.TotalAmountTobePaid\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalAmountToBePaidValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalAmountToBePaidValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmountToBePaidValue.setDefaultUnit(kony.flex.DP);
            var flxTotalAmountToBePaidValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalAmountToBePaidValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmountToBePaidValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalAmountToBePaidValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalAmountToBePaidValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "$ 1,567.99",
                "top": "0",
                "width": "66.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalAmountToBePaidValueContainer.add(lblTotalAmountToBePaidValue);
            flxTotalAmountToBePaidValue.add(flxTotalAmountToBePaidValueContainer);
            flxTotalAmountToBePaid.add(lblTotalAmountToBePaid, flxTotalAmountToBePaidValue);
            var flxAmounttobeCreditto = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmounttobeCreditto",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmounttobeCreditto.setDefaultUnit(kony.flex.DP);
            var lblAmounttobeCreditto = new kony.ui.Label({
                "id": "lblAmounttobeCreditto",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmounttobeCreditto\")",
                "top": "10dp",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmounttobeCredittoValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmounttobeCredittoValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmounttobeCredittoValue.setDefaultUnit(kony.flex.DP);
            var flxAmounttobeCredittoValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmounttobeCredittoValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmounttobeCredittoValueContainer.setDefaultUnit(kony.flex.DP);
            var lblAmounttobeCredittoValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblAmounttobeCredittoValue",
                "isVisible": true,
                "left": "2.54%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Companys Checking Acc…1234",
                "top": "0",
                "width": "66.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmounttobeCredittoValueContainer.add(lblAmounttobeCredittoValue);
            flxAmounttobeCredittoValue.add(flxAmounttobeCredittoValueContainer);
            flxAmounttobeCreditto.add(lblAmounttobeCreditto, flxAmounttobeCredittoValue);
            flxPaymentDetailsContent.add(flxPaymentStatus, flxApprovedDate, flxTotalAmountToBePaid, flxAmounttobeCreditto);
            flxPaymentDetails.add(flxPaymentDetailsHeader, flxPaymentDetailsContent);
            var flxPaymentAdvice = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentAdvice",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdvice.setDefaultUnit(kony.flex.DP);
            var flxPaymentAdviceHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentAdviceHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator1.setDefaultUnit(kony.flex.DP);
            flxTopSeparator1.add();
            var flxPaymentAdviceHeaderLbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPaymentAdviceHeaderLbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceHeaderLbl.setDefaultUnit(kony.flex.DP);
            var lblPaymentAdvice = new kony.ui.Label({
                "id": "lblPaymentAdvice",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PaymentAdvice\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceHeaderLbl.add(lblPaymentAdvice);
            var flxPaymentAdviseDropDown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "7dp",
                "id": "flxPaymentAdviseDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "15dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviseDropDown.setDefaultUnit(kony.flex.DP);
            var imgPaymentAdvise = new kony.ui.Image2({
                "height": "100%",
                "id": "imgPaymentAdvise",
                "isVisible": true,
                "left": "0",
                "src": "arrowup_sm.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentAdviseDropDown.add(imgPaymentAdvise);
            var flxBottomSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator1.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator1.add();
            flxPaymentAdviceHeader.add(flxTopSeparator1, flxPaymentAdviceHeaderLbl, flxPaymentAdviseDropDown, flxBottomSeparator1);
            var flxPaymentAdviceSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentAdviceSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceSubHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator2.setDefaultUnit(kony.flex.DP);
            flxTopSeparator2.add();
            var flxPaymentAdviceSubHeaderContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48dp",
                "id": "flxPaymentAdviceSubHeaderContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceSubHeaderContent.setDefaultUnit(kony.flex.DP);
            var flxAdviceName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAdviceName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdviceName.setDefaultUnit(kony.flex.DP);
            var lblAdviceName = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblAdviceName",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AdviseName\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdviceName.add(lblAdviceName);
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "23%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Date\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(lblDate);
            var flxAdviseParty = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAdviseParty",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "27%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdviseParty.setDefaultUnit(kony.flex.DP);
            var lblAdviseParty = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblAdviseParty",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AdviseParty\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdviseParty.add(lblAdviseParty);
            var flxAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "0",
                "width": "10%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var lblAction = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblAction",
                "isVisible": true,
                "left": "52%",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAction.add(lblAction);
            flxPaymentAdviceSubHeaderContent.add(flxAdviceName, flxDate, flxAdviseParty, flxAction);
            var flxBottomSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator2.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator2.add();
            flxPaymentAdviceSubHeader.add(flxTopSeparator2, flxPaymentAdviceSubHeaderContent, flxBottomSeparator2);
            var flxPaymentAdviceMessageBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentAdviceMessageBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceMessageBox.setDefaultUnit(kony.flex.DP);
            var segPaymentAdvise = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblActions": "View",
                    "lblAdvisingParty": "Advising Bank",
                    "lblDate": "12/20/2021",
                    "lblPaymentAdvice": "Payment Message"
                }],
                "groupCells": false,
                "id": "segPaymentAdvise",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxPaymentAdvice"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": 0,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPaymentAdvice": "flxPaymentAdvice",
                    "lblActions": "lblActions",
                    "lblAdvisingParty": "lblAdvisingParty",
                    "lblDate": "lblDate",
                    "lblPaymentAdvice": "lblPaymentAdvice"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentAdviceMessageBox.add(segPaymentAdvise);
            flxPaymentAdvice.add(flxPaymentAdviceHeader, flxPaymentAdviceSubHeader, flxPaymentAdviceMessageBox);
            flxDocumentStatusAndPaymentDetails.add(flxDocumentsAndStatus, flxPaymentDetails, flxPaymentAdvice);
            var flxDiscrepanciesandResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesandResponse",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "100.49%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponse.setDefaultUnit(kony.flex.DP);
            var flxDiscrepanciesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDiscrepanciesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeperator2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator2.setDefaultUnit(kony.flex.DP);
            flxTopSeperator2.add();
            var flxDiscrepanciesandResponseLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDiscrepanciesandResponseLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesandResponseValue = new kony.ui.Label({
                "id": "lblDiscrepanciesandResponseValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DiscrepanciesandResponse\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.add(lblDiscrepanciesandResponseValue);
            var flxViewReturnedByBankHistory = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewReturnedByBankHistory",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1.46%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "22%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewReturnedByBankHistory.setDefaultUnit(kony.flex.DP);
            var lblViewReturnedByBankHistory = new kony.ui.Label({
                "id": "lblViewReturnedByBankHistory",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewReturnedbyBankHistory\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "lblViewReturnedByBankHistory"
            });
            flxViewReturnedByBankHistory.add(lblViewReturnedByBankHistory);
            var flxBottomSeparate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparate.setDefaultUnit(kony.flex.DP);
            flxBottomSeparate.add();
            flxDiscrepanciesHeader.add(flxTopSeperator2, flxDiscrepanciesandResponseLabel, flxViewReturnedByBankHistory, flxBottomSeparate);
            var flxDiscrepanciesMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesMain.setDefaultUnit(kony.flex.DP);
            var flxTotalDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocuments.setDefaultUnit(kony.flex.DP);
            var lblTotalDocuments = new kony.ui.Label({
                "id": "lblTotalDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TotalDocuments\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "295dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxtotoalDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxtotoalDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalDocumentsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalDocumentsValue",
                "isVisible": true,
                "left": "2.10%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.add(lblTotalDocumentsValue);
            flxTotalDocumentsValue.add(flxtotoalDocumentsValueContainer);
            flxTotalDocuments.add(lblTotalDocuments, flxTotalDocumentsValue);
            var flxDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocuments.setDefaultUnit(kony.flex.DP);
            var lblDocuments = new kony.ui.Label({
                "id": "lblDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.Documents\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "295dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var segDocumentsValueContainer = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblHeading": "Clearance Statement.Pdf"
                }, {
                    "lblHeading": "Invoices.Pdf"
                }, {
                    "lblHeading": "Invoices.Pdf"
                }, {
                    "lblHeading": "Invoices.Pdf"
                }, {
                    "lblHeading": "Invoices.Pdf"
                }],
                "groupCells": false,
                "id": "segDocumentsValueContainer",
                "isVisible": true,
                "left": "2.10%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSectionHeaderTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSectionHeaderTemplate": "flxSectionHeaderTemplate",
                    "lblHeading": "lblHeading"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.add(segDocumentsValueContainer);
            flxDocumentsValue.add(flxDocumentsValueContainer);
            flxDocuments.add(lblDocuments, flxDocumentsValue);
            var flxDocStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatus.setDefaultUnit(kony.flex.DP);
            var lblDocStatus = new kony.ui.Label({
                "id": "lblDocStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DocumentStatus\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "295dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValue.setDefaultUnit(kony.flex.DP);
            var flxDocStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblDocStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblDocStatusValue",
                "isVisible": true,
                "left": "2.10%",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Discrepant",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.add(lblDocStatusValue);
            flxDocStatusValue.add(flxDocStatusValueContainer);
            flxDocStatus.add(lblDocStatus, flxDocStatusValue);
            var flxDiscrepancyResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancyResponse",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.setDefaultUnit(kony.flex.DP);
            var segDiscrepancyResponse = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblLeft1": "Reason for Return:",
                    "lblRight1": "Check the Packing list and Shipping advise and clear this",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Discrepancy 1:",
                    "lblRight1": "Packing list not signed",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "D1 User Response:",
                    "lblRight1": "I Accept this discrepancy, I will submit a revised document",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Discrepancy 2:",
                    "lblRight1": "Shipping Advise stamp is missing",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "D2 User Response:",
                    "lblRight1": "I Reject this discrepancy, Please proceed with the existing document",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "D2 User Comment:",
                    "lblRight1": "Shipping has started",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Return Message to Bank:",
                    "lblRight1": "Kindly forward this with revised packing list",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }],
                "groupCells": false,
                "id": "segDiscrepancyResponse",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingDetailsExport"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                    "flxRight1": "flxRight1",
                    "lblLeft1": "lblLeft1",
                    "lblRight1": "lblRight1",
                    "lblRight2": "lblRight2",
                    "lblRight3": "lblRight3",
                    "lblRight4": "lblRight4"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.add(segDiscrepancyResponse);
            flxDiscrepanciesMain.add(flxTotalDocuments, flxDocuments, flxDocStatus, flxDiscrepancyResponse);
            flxDiscrepanciesandResponse.add(flxDiscrepanciesHeader, flxDiscrepanciesMain);
            var flxBackbutton = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBackbutton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 4,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackbutton.setDefaultUnit(kony.flex.DP);
            var btnBack = new kony.ui.Button({
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "left": "86.52%",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.transaction.back\")",
                "top": "0dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackbutton.add(btnBack);
            flxExportLCDrawingViewDetails.add(flxDrawingHeader, flxErrorMessage, flxLCSummary, flxDrawingDetails, flxDocumentStatusAndPaymentDetails, flxDiscrepanciesandResponse, flxBackbutton);
            flxMain.add(flxExportLCDrawingViewDetails);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxFooterMenu": {
                        "left": "8.07%",
                        "width": "91.93%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxMainContainer.add(flxMain, flxFooter);
            flxFormContent.add(flxMainContainer);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "215dp",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxViewLCDetailsPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewLCDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "630dp",
                "horizontalScrollIndicator": true,
                "id": "flxLCDetailsPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknNoBorder",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "50%"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxLCDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblLCDetailsHeader = new kony.ui.Label({
                "id": "lblLCDetailsHeader",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Export LC - LC0000100001",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "12dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCross",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var flxSeparator02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "49dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator02.setDefaultUnit(kony.flex.DP);
            flxSeparator02.add();
            flxLCDetailsHeader.add(lblLCDetailsHeader, flxCross, flxSeparator02);
            var flxLCDetailsData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetailsData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsData.setDefaultUnit(kony.flex.DP);
            var flxLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetails.setDefaultUnit(kony.flex.DP);
            var lblLcDetails = new kony.ui.Label({
                "id": "lblLcDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCDetails\")",
                "top": "0dp",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorTop02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorTop02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "93.07%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop02.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop02.add();
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "565dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLeftLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoKey = new kony.ui.Label({
                "id": "lblLCRefNoKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCReferenceNumber\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeKey = new kony.ui.Label({
                "id": "lblLCTypeKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantKey = new kony.ui.Label({
                "id": "lblApplicantKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantAddressKey = new kony.ui.Label({
                "id": "lblApplicantAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Applicant Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankKey = new kony.ui.Label({
                "id": "lblIssuingBankKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankAddressKey = new kony.ui.Label({
                "id": "lblIssuingBankAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateKey = new kony.ui.Label({
                "id": "lblIssueDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Issue Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpireDateKey = new kony.ui.Label({
                "id": "lblExpireDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Expire Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountKey = new kony.ui.Label({
                "id": "lblLCAmountKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Amount: ",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.add(lblLCRefNoKey, lblLCTypeKey, lblApplicantKey, lblApplicantAddressKey, lblIssuingBankKey, lblIssuingBankAddressKey, lblIssueDateKey, lblExpireDateKey, lblLCAmountKey);
            var flxRightLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "90dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoValue = new kony.ui.Label({
                "id": "lblLCRefNoValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeeValue = new kony.ui.Label({
                "id": "lblLCTypeeValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantValue = new kony.ui.Label({
                "id": "lblLCApplicantValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantAddValue = new kony.ui.Label({
                "id": "lblLCApplicantAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankalue = new kony.ui.Label({
                "id": "lblLCIssueBankalue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankAddValue = new kony.ui.Label({
                "id": "lblLCIssueBankAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueDateValue = new kony.ui.Label({
                "id": "lblLCIssueDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCExpireDateValue = new kony.ui.Label({
                "id": "lblLCExpireDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValuee = new kony.ui.Label({
                "id": "lblLCAmountValuee",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.add(lblLCRefNoValue, lblLCTypeeValue, lblLCApplicantValue, lblLCApplicantAddValue, lblLCIssueBankalue, lblLCIssueBankAddValue, lblLCIssueDateValue, lblLCExpireDateValue, lblLCAmountValuee);
            flxLCSummaryBody.add(flxLeftLCSummary, flxRightLCSummary);
            var flxSeparatorTop03 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorTop03",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "97.71%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop03.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop03.add();
            flxLCDetails.add(lblLcDetails, flxSeparatorTop02, flxLCSummaryBody, flxSeparatorTop03);
            var flxBeneficiaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryDetails.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryDetails = new kony.ui.Label({
                "id": "lblBeneficiaryDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Beneficiary Details",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorMid01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorMid01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "40dp",
                "width": "93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMid01.setDefaultUnit(kony.flex.DP);
            flxSeparatorMid01.add();
            var flxBeneficiaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "60dp",
                "width": "440dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryBody.setDefaultUnit(kony.flex.DP);
            var flxBenLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenLeft.setDefaultUnit(kony.flex.DP);
            var lblBenName = new kony.ui.Label({
                "id": "lblBenName",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddress = new kony.ui.Label({
                "id": "lblBenAddress",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenLeft.add(lblBenName, lblBenAddress);
            var flxBenRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "140dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenRight.setDefaultUnit(kony.flex.DP);
            var lblBenNameValue = new kony.ui.Label({
                "id": "lblBenNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddValue = new kony.ui.Label({
                "id": "lblBenAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenRight.add(lblBenNameValue, lblBenAddValue);
            flxBeneficiaryBody.add(flxBenLeft, flxBenRight);
            var flxSeparatorBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "140dp",
                "width": "98.72%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBen.setDefaultUnit(kony.flex.DP);
            flxSeparatorBen.add();
            flxBeneficiaryDetails.add(lblBeneficiaryDetails, flxSeparatorMid01, flxBeneficiaryBody, flxSeparatorBen);
            var flxGoodShipment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipment.setDefaultUnit(kony.flex.DP);
            var lblGoodShipment = new kony.ui.Label({
                "id": "lblGoodShipment",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Good & Shipment Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorGoods = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorGoods",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "45dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorGoods.setDefaultUnit(kony.flex.DP);
            flxSeparatorGoods.add();
            var flxGoodShipmentBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipmentBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipmentBody.setDefaultUnit(kony.flex.DP);
            var flxGoodsLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.setDefaultUnit(kony.flex.DP);
            var lblGoodsDescription = new kony.ui.Label({
                "id": "lblGoodsDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Goods Description:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdditionalCon = new kony.ui.Label({
                "id": "lblAdditionalCon",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Additional Conditions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirm = new kony.ui.Label({
                "id": "lblConfirm",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Confirm Instructions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentDate = new kony.ui.Label({
                "id": "lblShipmentDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Latest Shipment Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.add(lblGoodsDescription, lblAdditionalCon, lblConfirm, lblShipmentDate);
            var flxGoodsRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "115dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsRight.setDefaultUnit(kony.flex.DP);
            var lblDescriptionValue = new kony.ui.Label({
                "id": "lblDescriptionValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddValue = new kony.ui.Label({
                "id": "lblAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirmValue = new kony.ui.Label({
                "id": "lblConfirmValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentValue = new kony.ui.Label({
                "id": "lblShipmentValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsRight.add(lblDescriptionValue, lblAddValue, lblConfirmValue, lblShipmentValue);
            flxGoodShipmentBody.add(flxGoodsLeft, flxGoodsRight);
            var flxSeparatorBottom02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "200dp",
                "width": "97.63%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom02.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom02.add();
            flxGoodShipment.add(lblGoodShipment, flxSeparatorGoods, flxGoodShipmentBody, flxSeparatorBottom02);
            var flxDocumentTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTerms.setDefaultUnit(kony.flex.DP);
            var lblDocumentTerms = new kony.ui.Label({
                "id": "lblDocumentTerms",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Documents and Terms",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument.add();
            var flxDocumentTermsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxDocumentTermsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTermsBody.setDefaultUnit(kony.flex.DP);
            var flxLeftContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContent.setDefaultUnit(kony.flex.DP);
            var lblDocumentName02 = new kony.ui.Label({
                "id": "lblDocumentName02",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Document Name:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadedFiles = new kony.ui.Label({
                "id": "lblUploadedFiles",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Uploaded Files:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftContent.add(lblDocumentName02, lblUploadedFiles);
            var flxRightContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContent.setDefaultUnit(kony.flex.DP);
            var lblDocNameValue = new kony.ui.Label({
                "id": "lblDocNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadedDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "22dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.setDefaultUnit(kony.flex.DP);
            var segUploadedDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUploadedDocs",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportLCUploadDocPopup"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocContent": "flxDocContent",
                    "flxDocumentName": "flxDocumentName",
                    "flxExportLCUploadDocPopup": "flxExportLCUploadDocPopup",
                    "flxMain": "flxMain",
                    "flxPDFImage": "flxPDFImage",
                    "imgPDF": "imgPDF",
                    "lblDocumentName": "lblDocumentName"
                },
                "width": "65%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.add(segUploadedDocs);
            flxRightContent.add(lblDocNameValue, flxUploadedDocs);
            flxDocumentTermsBody.add(flxLeftContent, flxRightContent);
            var flxSeparatorBottom03 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom03",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "97.63%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom03.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom03.add();
            flxDocumentTerms.add(lblDocumentTerms, flxSeparatorDocument, flxDocumentTermsBody, flxSeparatorBottom03);
            var flxSwiftMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessage.setDefaultUnit(kony.flex.DP);
            var lblSwiftMessage = new kony.ui.Label({
                "id": "lblSwiftMessage",
                "isVisible": true,
                "left": 10,
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "SWIFT Message and Advises Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "30dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument02.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument02.add();
            var flxSwiftMessageBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxSwiftMessageBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageBody.setDefaultUnit(kony.flex.DP);
            var flxSwiftMessageLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessageLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.setDefaultUnit(kony.flex.DP);
            var lblMessageType = new kony.ui.Label({
                "id": "lblMessageType",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Type:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDelivered = new kony.ui.Label({
                "id": "lblDelivered",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Delivered To/From:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDate = new kony.ui.Label({
                "id": "lblSwiftDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoty = new kony.ui.Label({
                "id": "lblMessageCategoty",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Category:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.add(lblMessageType, lblDelivered, lblSwiftDate, lblMessageCategoty);
            var flxSwiftMessagesRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessagesRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "115dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.setDefaultUnit(kony.flex.DP);
            var lblMessageTypeValue = new kony.ui.Label({
                "id": "lblMessageTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliveredValue = new kony.ui.Label({
                "id": "lblDeliveredValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDateValue = new kony.ui.Label({
                "id": "lblSwiftDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoryValue = new kony.ui.Label({
                "id": "lblMessageCategoryValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.add(lblMessageTypeValue, lblDeliveredValue, lblSwiftDateValue, lblMessageCategoryValue);
            flxSwiftMessageBody.add(flxSwiftMessageLeft, flxSwiftMessagesRight);
            flxSwiftMessage.add(lblSwiftMessage, flxSeparatorDocument02, flxSwiftMessageBody);
            flxLCDetailsData.add(flxLCDetails, flxBeneficiaryDetails, flxGoodShipment, flxDocumentTerms, flxSwiftMessage);
            flxLCDetailsPopup.add(flxLCDetailsHeader, flxLCDetailsData);
            flxViewLCDetailsPopup.add(flxLCDetailsPopup);
            var flxMainPaymentPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainPaymentPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainPaymentPopup.setDefaultUnit(kony.flex.DP);
            var flxPaymentAdvicePopup = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "340dp",
                "id": "flxPaymentAdvicePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffOuterShadowdddcdc",
                "top": "100dp",
                "width": "38%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentAdvicePopup.setDefaultUnit(kony.flex.DP);
            var flxPaymentPopupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPaymentPopupHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentPopupHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentAdvice02 = new kony.ui.Label({
                "id": "lblPaymentAdvice02",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Payment Advice",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "86%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "14dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearchIcon = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearchIcon",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearchIcon);
            flxPaymentPopupHeader.add(lblPaymentAdvice02, flxSearchIcon);
            var flxSeparatorPayment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorPayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "47dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorPayment.setDefaultUnit(kony.flex.DP);
            flxSeparatorPayment.add();
            var segPaymentAdvice = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblLeft1": "Beneficiary:",
                    "lblRight1": "Mark Phippard"
                }, {
                    "lblLeft1": "Payment Date:",
                    "lblRight1": "04/05/2021"
                }, {
                    "lblLeft1": "Credited Amount:",
                    "lblRight1": "$1,657.38"
                }, {
                    "lblLeft1": "Credited Account:",
                    "lblRight1": "Company's Checking Acc....3412"
                }, {
                    "lblLeft1": "Charges Debited:",
                    "lblRight1": "$153.29"
                }, {
                    "lblLeft1": "Advising Bank:",
                    "lblRight1": "Infinity Bank"
                }, {
                    "lblLeft1": "Drawing Ref No:",
                    "lblRight1": "D10011004"
                }],
                "groupCells": false,
                "id": "segPaymentAdvice",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxPaymentAdvice"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "60dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPaymentAdvice": "flxPaymentAdvice",
                    "lblLeft1": "lblLeft1",
                    "lblRight1": "lblRight1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentAdvicePopup.add(flxPaymentPopupHeader, flxSeparatorPayment, segPaymentAdvice);
            flxMainPaymentPopup.add(flxPaymentAdvicePopup);
            var flxMainReturnBankPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainReturnBankPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "1290dp",
                "isModalContainer": false,
                "skin": "ICSknflxPopupBg",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainReturnBankPopup.setDefaultUnit(kony.flex.DP);
            var flxMainReturnPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "530dp",
                "id": "flxMainReturnPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "150dp",
                "width": "610dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainReturnPopup.setDefaultUnit(kony.flex.DP);
            var flxReturnByBankPopup = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "655dp",
                "id": "flxReturnByBankPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "84dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffOuterShadowdddcdc",
                "top": "210dp",
                "width": "700dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReturnByBankPopup.setDefaultUnit(kony.flex.DP);
            var flxPopupHeaderTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPopupHeaderTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupHeaderTop.setDefaultUnit(kony.flex.DP);
            var lblReturnByBank = new kony.ui.Label({
                "id": "lblReturnByBank",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Return by Bank History (3)",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearchClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxSearchClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchClose.setDefaultUnit(kony.flex.DP);
            var imgSearchClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearchClose",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchClose.add(imgSearchClose);
            flxPopupHeaderTop.add(lblReturnByBank, flxSearchClose);
            var flxSeparatorReturnTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorReturnTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "46dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorReturnTop.setDefaultUnit(kony.flex.DP);
            flxSeparatorReturnTop.add();
            flxReturnByBankPopup.add(flxPopupHeaderTop, flxSeparatorReturnTop);
            var flxMainBodyContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470dp",
                "id": "flxMainBodyContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "84dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffNoShadow",
                "top": "255dp",
                "width": "100.00%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainBodyContainer.setDefaultUnit(kony.flex.DP);
            var segReturnByBank = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }],
                "groupCells": false,
                "height": "476dp",
                "id": "segReturnByBank",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxReturnedByBank"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxReturnByBankInner": "flxReturnByBankInner",
                    "flxReturnByBankOuter": "flxReturnByBankOuter",
                    "flxReturnedByBank": "flxReturnedByBank",
                    "flxReturnedByBankBodyContent": "flxReturnedByBankBodyContent",
                    "flxReturnedByBankBodyContent02": "flxReturnedByBankBodyContent02",
                    "flxReturnedByBankBodyContent03": "flxReturnedByBankBodyContent03",
                    "flxSeparatorReturnTop03": "flxSeparatorReturnTop03",
                    "flxSeparatorTopReturnBank": "flxSeparatorTopReturnBank",
                    "lblReasonReturn": "lblReasonReturn",
                    "lblReasonReturn02": "lblReasonReturn02",
                    "lblReasonReturn03": "lblReasonReturn03",
                    "lblReturnBank": "lblReturnBank",
                    "lblReturnDate": "lblReturnDate",
                    "lblRightValue": "lblRightValue",
                    "lblRightValue02": "lblRightValue02",
                    "lblRightValue03": "lblRightValue03"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMainBodyContainer.add(segReturnByBank);
            flxMainReturnPopup.add(flxReturnByBankPopup, flxMainBodyContainer);
            flxMainReturnBankPopup.add(flxMainReturnPopup);
            flxDialogs.add(flxLogout, flxViewLCDetailsPopup, flxMainPaymentPopup, flxMainReturnBankPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxExportLCDrawingViewDetails": {
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxViewLCDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApplicant": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblApplicantValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblName": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxAdvisingLCReferenceNumber": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdvisingLCReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdvisingLCReferenceNumberValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxLCAmount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCAmountLabel": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCAmountValueContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxLCUntilizedAmount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmountLbl": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCType": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCTypeLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDate": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDate": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpiryDateLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingBank": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblIssuingBankLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingLCRefNo": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblIssuingLCRefNoLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "segmentProps": []
                    },
                    "flxSeparator01": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxDocumenstAndStatusLbl": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblDrawingsAndStatus": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentAndStatusDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "imgDocumentAndStatus": {
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDoc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsAndStatusContent": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocument": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocument": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxtotoalDocumentValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDocumentsName": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentName": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsNameSegment": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "segDocuments": {
                        "segmentProps": []
                    },
                    "flxDocumentStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentStatus": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxMessageFromBank": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageFromBank": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankMessageText": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxPaymentDetails": {
                        "segmentProps": []
                    },
                    "flxPaymentDetailsLbl": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentDetails": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "Payment Details",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetailsDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "imgPaymentDetails": {
                        "segmentProps": []
                    },
                    "flxBottomSeparator0": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetailsContent": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentStatus": {
                        "height": {
                            "type": "string",
                            "value": "62dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblPaymentStatus": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPaymentStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxApprovedDate": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovedDate": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxApprovedDateValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxApprovedDateValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovedDateValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaid": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountToBePaid": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaidValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaidValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountToBePaidValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxAmounttobeCreditto": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmounttobeCreditto": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAmounttobeCredittoValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAmounttobeCredittoValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmounttobeCredittoValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxPaymentAdvice": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxPaymentAdviceHeaderLbl": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentAdvice": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPaymentAdviseDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "imgPaymentAdvise": {
                        "segmentProps": []
                    },
                    "flxBottomSeparator1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentAdviceSubHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesandResponseValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": []
                    },
                    "flxViewReturnedByBankHistory": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBottomSeparate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxtotoalDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblLCRefNoKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCRefNoValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeeValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankalue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "Default": {
                            "contentAlignment": 4
                        },
                        "accessibilityConfig": {},
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "text": "User entered message will appear here in two lines with truncation in the en..",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainPaymentPopup": {
                        "segmentProps": []
                    },
                    "flxPaymentAdvicePopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "lblPaymentAdvice02": {
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "right": {
                            "type": "string",
                            "value": "5.30%"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnBankPopup": {
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchClose": {
                        "right": {
                            "type": "string",
                            "value": "5.30%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxExportLCDrawingViewDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingHeader": {
                        "segmentProps": []
                    },
                    "flxVerticalEllipsisDropdown": {
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "segmentProps": []
                    },
                    "flxViewLCDetails": {
                        "segmentProps": []
                    },
                    "lblViewLCDetials": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBodyContentRigh": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBodyContentLast": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCSummaryContent": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxApplicant": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblApplicantValue": {
                        "i18n_text": "i18n.ExportLC.Applicant",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Applicant:",
                        "segmentProps": []
                    },
                    "lblName": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "text": "Katie Floyd",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisingLCReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblAdvisingLCReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Advising LC Reference Number:",
                        "segmentProps": []
                    },
                    "lblAdvisingLCReferenceNumberValue": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "text": "LC0000100001",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCAmount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblLCAmountLabel": {
                        "i18n_text": "i18n.ExportLC.LCAmount",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "LC Amount:",
                        "segmentProps": []
                    },
                    "lblLCAmountValueContainer": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "text": "$ 2,567.87",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxLCUntilizedAmount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmountLbl": {
                        "i18n_text": "i18n.TradeFinance.LCUntilizedAmount",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "LC Untilized Amount:",
                        "segmentProps": []
                    },
                    "lblLCUtilizedAmount": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "$ 2,567.87",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxLCType": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblLCTypeLeft": {
                        "i18n_text": "i18n.ImportLC.LCType",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "LC Type:",
                        "segmentProps": []
                    },
                    "lblLCTypeRight": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "Sight",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxIssueDate": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateLeft": {
                        "i18n_text": "i18n.TradeFinance.IssueDate",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Issue Date:",
                        "segmentProps": []
                    },
                    "lblIssueDateRight": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "10/01/2021",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxExpiryDate": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblExpiryDateLeft": {
                        "i18n_text": "i18n.ImportLC.ExpiryDate",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Expiry Date:",
                        "segmentProps": []
                    },
                    "lblExpiryDateRight": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "12/31/2022",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingBank": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "105%"
                        },
                        "segmentProps": []
                    },
                    "lblIssuingBankLeft": {
                        "i18n_text": "kony.mb.cardManage.issuingBank",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Issuing Bank:",
                        "segmentProps": []
                    },
                    "lblIssuingBankRight": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "Bank of America",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxIssuingLCRefNo": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120%"
                        },
                        "segmentProps": []
                    },
                    "lblIssuingLCRefNoLeft": {
                        "i18n_text": "i18n.TradeFinance.IssuingLCRefNo",
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Issuing LC Ref No:",
                        "segmentProps": []
                    },
                    "lblIssuingLCRefNoRight": {
                        "left": {
                            "type": "string",
                            "value": "39.42%"
                        },
                        "skin": "ICSknLbl424242SSPRegular15px",
                        "text": "5678098765",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46.40%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewLCDetails02": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "75.04%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblViewLCDetials02": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "47%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatusAndPaymentDetails": {
                        "segmentProps": []
                    },
                    "flxDocumenstAndStatusLbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentAndStatusDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDoc": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocument": {
                        "segmentProps": []
                    },
                    "lblTotalDocument": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentValue": {
                        "segmentProps": []
                    },
                    "lblTotalDocumentValue": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsName": {
                        "segmentProps": []
                    },
                    "lblDocumentName": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsNameSegment": {
                        "segmentProps": []
                    },
                    "segDocuments": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatus": {
                        "segmentProps": []
                    },
                    "lblDocumentStatus": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatusValue": {
                        "segmentProps": []
                    },
                    "lblDocumentStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageFromBank": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageFromBank": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankMessage": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankMessage": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxPaymentDetailsLbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetailsDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator0": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentStatus": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentStatus": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentStatusValue": {
                        "segmentProps": []
                    },
                    "lblPaymentStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovedDate": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblApprovedDate": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovedDateValue": {
                        "segmentProps": []
                    },
                    "lblApprovedDateValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaid": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblTotalAmountToBePaid": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaidValue": {
                        "segmentProps": []
                    },
                    "lblTotalAmountToBePaidValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxAmounttobeCreditto": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblAmounttobeCreditto": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxAmounttobeCredittoValue": {
                        "segmentProps": []
                    },
                    "lblAmounttobeCredittoValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentAdvice": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxPaymentAdviceHeaderLbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentAdvice": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentAdviseDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "imgPaymentAdvise": {
                        "right": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator1": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxAdviceName": {
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "flxAdviseParty": {
                        "segmentProps": []
                    },
                    "flxAction": {
                        "left": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblAction": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "segPaymentAdvise": {
                        "data": [{
                            "lblActions": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "View"
                            },
                            "lblAdvisingParty": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising Bank"
                            },
                            "lblDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12/20/2021"
                            },
                            "lblPaymentAdvice": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Payment Message"
                            }
                        }],
                        "segmentProps": ["data"]
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxViewReturnedByBankHistory": {
                        "right": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblViewReturnedByBankHistory": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparate": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "data": [{
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Clearance Statement.Pdf"
                            }
                        }, {
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Invoices.Pdf"
                            }
                        }],
                        "left": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": ["data"]
                    },
                    "flxDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxBackbutton": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "zIndex": 5000,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50.06%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsData": {
                        "segmentProps": []
                    },
                    "flxLCDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTop03": {
                        "segmentProps": []
                    },
                    "flxBeneficiaryDetails": {
                        "segmentProps": []
                    },
                    "flxSeparatorMid01": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBen": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipment": {
                        "segmentProps": []
                    },
                    "flxSeparatorGoods": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipmentBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdditionalCon": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirm": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodsRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAddValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom02": {
                        "top": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentTerms": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument": {
                        "segmentProps": []
                    },
                    "flxDocumentTermsBody": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottom03": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument02": {
                        "segmentProps": []
                    },
                    "flxSwiftMessageBody": {
                        "segmentProps": []
                    },
                    "lblDelivered": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoty": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSwiftMessagesRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDeliveredValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDateValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoryValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainPaymentPopup": {
                        "segmentProps": []
                    },
                    "flxPaymentAdvicePopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknFlxffffffNoShadow",
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentAdvice02": {
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "left": {
                            "type": "string",
                            "value": "91.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "segPaymentAdvice": {
                        "data": [{
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Beneficiary:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Mark Phippard"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Payment Date:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "04/05/2021"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Amount:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 1,657.38"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Account:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Companys Checking Acc....1234"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Charges Debited:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 153.29"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising Bank:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Infinity Bank"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Drawing Ref No:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D10011004"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingDetailsExport"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                            "flxRight1": "flxRight1",
                            "lblLeft1": "lblLeft1",
                            "lblRight1": "lblRight1",
                            "lblRight2": "lblRight2",
                            "lblRight3": "lblRight3",
                            "lblRight4": "lblRight4"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxMainReturnBankPopup": {
                        "minHeight": {
                            "type": "string",
                            "value": "1270dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchClose": {
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "segReturnByBank": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxExportLCDrawingViewDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingHeader": {
                        "segmentProps": []
                    },
                    "lblExportLCDrawingHeader": {
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "i18n_text": "i18n.TradeFinance.LCSummary",
                        "segmentProps": []
                    },
                    "lblApplicant": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "i18n_text": "i18n.ExportLC.Applicant",
                        "text": "Applicant: ",
                        "segmentProps": []
                    },
                    "lblLCRefNo": {
                        "i18n_text": "i18n.TradeFinance.AdvisingLCRefNo",
                        "segmentProps": []
                    },
                    "lblLCType": {
                        "i18n_text": "i18n.ImportLC.LCType",
                        "segmentProps": []
                    },
                    "lblIssueBank": {
                        "i18n_text": "kony.mb.cardManage.issuingBank",
                        "segmentProps": []
                    },
                    "lblLCAmount": {
                        "i18n_text": "i18n.ExportLC.LCAmount",
                        "segmentProps": []
                    },
                    "lblIssueDate": {
                        "i18n_text": "i18n.TradeFinance.IssueDate",
                        "segmentProps": []
                    },
                    "lblIssueLCRefNo": {
                        "i18n_text": "i18n.TradeFinance.IssuingLCRefNo",
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmount": {
                        "i18n_text": "i18n.TradeFinance.LCUntilizedAmount",
                        "segmentProps": []
                    },
                    "lblExpiryDate": {
                        "i18n_text": "i18n.ImportLC.ExpiryDate",
                        "segmentProps": []
                    },
                    "flxLCSummaryContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxApplicant": {
                        "segmentProps": []
                    },
                    "lblApplicantValue": {
                        "segmentProps": []
                    },
                    "flxAdvisingLCReferenceNumber": {
                        "segmentProps": []
                    },
                    "lblAdvisingLCReferenceNumber": {
                        "segmentProps": []
                    },
                    "flxLCAmount": {
                        "segmentProps": []
                    },
                    "lblLCAmountLabel": {
                        "segmentProps": []
                    },
                    "flxLCUntilizedAmount": {
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmountLbl": {
                        "segmentProps": []
                    },
                    "flxLCType": {
                        "segmentProps": []
                    },
                    "lblLCTypeLeft": {
                        "segmentProps": []
                    },
                    "flxIssueDate": {
                        "segmentProps": []
                    },
                    "lblIssueDateLeft": {
                        "segmentProps": []
                    },
                    "flxExpiryDate": {
                        "segmentProps": []
                    },
                    "lblExpiryDateLeft": {
                        "segmentProps": []
                    },
                    "flxIssuingBank": {
                        "segmentProps": []
                    },
                    "lblIssuingBankLeft": {
                        "segmentProps": []
                    },
                    "flxIssuingLCRefNo": {
                        "segmentProps": []
                    },
                    "lblIssuingLCRefNoLeft": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetails02": {
                        "segmentProps": []
                    },
                    "flxSeparator01": {
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxDocumentStatusAndPaymentDetails": {
                        "segmentProps": []
                    },
                    "flxDocumentsAndStatus": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentAndStatusDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "122%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "imgDocumentAndStatus": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDoc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsAndStatusContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocument": {
                        "segmentProps": []
                    },
                    "lblTotalDocument": {
                        "segmentProps": []
                    },
                    "flxDocumentsName": {
                        "segmentProps": []
                    },
                    "lblDocumentName": {
                        "segmentProps": []
                    },
                    "flxDocumentsNameSegment": {
                        "width": {
                            "type": "string",
                            "value": "48%"
                        },
                        "segmentProps": []
                    },
                    "segDocuments": {
                        "segmentProps": []
                    },
                    "flxDocumentStatus": {
                        "segmentProps": []
                    },
                    "lblDocumentStatus": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentStatusValue": {
                        "segmentProps": []
                    },
                    "flxMessageFromBank": {
                        "segmentProps": []
                    },
                    "lblMessageFromBank": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankMessage": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankMessage": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetails": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetailsDropDown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgPaymentDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator0": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPaymentStatus": {
                        "segmentProps": []
                    },
                    "flxPaymentStatusValue": {
                        "segmentProps": []
                    },
                    "lblApprovedDate": {
                        "segmentProps": []
                    },
                    "flxApprovedDateValue": {
                        "segmentProps": []
                    },
                    "lblTotalAmountToBePaid": {
                        "segmentProps": []
                    },
                    "flxTotalAmountToBePaidValue": {
                        "segmentProps": []
                    },
                    "lblAmounttobeCreditto": {
                        "segmentProps": []
                    },
                    "flxAmounttobeCredittoValue": {
                        "segmentProps": []
                    },
                    "flxPaymentAdvice": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPaymentAdviseDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator1": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAdviceName": {
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "flxAdviseParty": {
                        "segmentProps": []
                    },
                    "flxAction": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.93%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainPaymentPopup": {
                        "segmentProps": []
                    },
                    "flxPaymentAdvicePopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "lblPaymentAdvice02": {
                        "segmentProps": []
                    },
                    "segPaymentAdvice": {
                        "data": [{
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": " Beneficiary:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Mark Phippard"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Payment Date:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "04/05/2021"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Amount:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 1,657.38"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Account:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Companys Checking Acc....1234"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Charges Debited:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 153.29"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising Bank:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Infinity Bank"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Drawing Ref No:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D10011004"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingDetailsExport"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                            "flxRight1": "flxRight1",
                            "lblLeft1": "lblLeft1",
                            "lblRight1": "lblRight1",
                            "lblRight2": "lblRight2",
                            "lblRight3": "lblRight3",
                            "lblRight4": "lblRight4"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxMainReturnBankPopup": {
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxExportLCDrawingViewDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummary": {
                        "segmentProps": []
                    },
                    "flxLCSummaryContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "segmentProps": []
                    },
                    "flxViewLCDetails02": {
                        "segmentProps": []
                    },
                    "flxMsgToBank": {
                        "segmentProps": []
                    },
                    "flxDocumentStatusAndPaymentDetails": {
                        "segmentProps": []
                    },
                    "segDocuments": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "data": [{
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Clearance Statement.Pdf"
                            }
                        }, {
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Invoices.Pdf"
                            }
                        }],
                        "segmentProps": ["data"]
                    },
                    "customfooternew.flxFooterMenu": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainPaymentPopup": {
                        "segmentProps": []
                    },
                    "flxPaymentAdvicePopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "lblPaymentAdvice02": {
                        "segmentProps": []
                    },
                    "segPaymentAdvice": {
                        "data": [{
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Beneficiary:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Mark phippard"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Payment Date:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "04/05/2021"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Amount:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 1,657.38"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credited Account:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Companys Checking Acc....1234 "
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Charges Debited:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 153.29"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising Bank:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Infinity Bank"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Drawing Ref No:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D10011004"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingDetailsExport"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                            "flxRight1": "flxRight1",
                            "lblLeft1": "lblLeft1",
                            "lblRight1": "lblRight1",
                            "lblRight2": "lblRight2",
                            "lblRight3": "lblRight3",
                            "lblRight4": "lblRight4"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxMainReturnBankPopup": {
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "segReturnByBank": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxActionsMenu": {
                    "bottom": 32,
                    "right": "0dp",
                    "top": "0dp"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew.flxFooterMenu": {
                    "left": "8.07%",
                    "width": "91.93%"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmExportDrawingDetails,
            "enabledForIdleTimeout": true,
            "id": "frmExportDrawingDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_a14ba603f3654708826c6d3873251104,
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});