define("BillPayMA/BillPaymentUIModule/frmBillPayHistory", function() {
    return function(controller) {
        function addWidgetsfrmBillPayHistory() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblPayABill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblPayABill",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "25dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnByPass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Skip to other payment options",
                    "render": true
                },
                "height": "30dp",
                "id": "btnByPass",
                "isVisible": true,
                "right": "40%",
                "skin": "btnSkipNavigation",
                "text": "Skip to other payment options",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "58%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxLeftSub = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftSub",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftSub.setDefaultUnit(kony.flex.DP);
            var flxTabsChecking = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "tablist",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "50dp",
                "horizontalScrollIndicator": true,
                "id": "flxTabsChecking",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_HORIZONTAL,
                "skin": "slFbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 5
            }, {
                "paddingInPixel": false
            }, {});
            flxTabsChecking.setDefaultUnit(kony.flex.DP);
            var btnAllPayees = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")"
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnAllPayees",
                "isVisible": true,
                "left": "3.7%",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnPayementDue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDue\")"
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnPayementDue",
                "isVisible": true,
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnScheduled = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduled\")"
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnScheduled",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduled\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnHistory = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": true,
                        "role": "tab",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.History\")"
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnHistory",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtnAccountSummarySelected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.History\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummarySelectedHover"
            });
            var btnManagePayee = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.ManagePayee\")"
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnManagePayee",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ManagePayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            flxTabsChecking.add(btnAllPayees, btnPayementDue, btnScheduled, btnHistory, btnManagePayee);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor0c9e5c72af19e4d",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxtxtSearchandClearbtn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtSearchandClearbtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.70%",
                "isModalContainer": false,
                "right": "30.50%",
                "skin": "sknFlxffffffBorder3px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtSearchandClearbtn.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "search text"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "btnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "4%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            btnConfirm.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Search "
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            btnConfirm.add(lblSearch);
            var txtSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "tabindex": 0
                    },
                    "a11yLabel": "Search using keywords such as Name, Bank, Account Type …"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "40dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.SearchMessage\")",
                "secureTextEntry": false,
                "skin": "Copyskntxt0b2e1fe36dece41",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearBtn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "clear text"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "width": "5%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClearBtn.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearBtn.add(imgCross);
            flxtxtSearchandClearbtn.add(btnConfirm, txtSearch, flxClearBtn);
            var flxFiltersListMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "role": "button",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxFiltersListMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "72%",
                "isModalContainer": false,
                "right": "271px",
                "skin": "slFbox",
                "top": "30dp",
                "zIndex": 6,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersListMain.setDefaultUnit(kony.flex.DP);
            var flxFiltersList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFiltersList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "0",
                "width": "99%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersList.setDefaultUnit(kony.flex.DP);
            var flxtxtFilters = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtFilters.setDefaultUnit(kony.flex.DP);
            var txtFilters = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtFilters",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "secureTextEntry": false,
                "skin": "bbSknTbx455574SSP15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lbltxtFilters = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lbltxtFilters",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtxtFilters.add(txtFilters, lbltxtFilters);
            var flxLblType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLblType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "height": "40dp",
                "id": "lblType",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblType.add(lblType);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gbb52155891440a4971350aca54624c4,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "top": "0",
                "width": "16dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(lblDropdown);
            flxFiltersList.add(flxtxtFilters, flxLblType, flxDropdown);
            var lstBoxFilters = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "id": "lstBoxFilters",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "All Payees"],
                    ["lb2", "Business Payees"],
                    ["lb3", "Personal Payees"]
                ],
                "skin": "sknlbxaltoffffffB1R2",
                "top": "0",
                "width": "100%",
                "blur": {
                    "enabled": true,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var accountTypesBillPayHistory = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountTypesBillPayHistory",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "top": "0dp",
                        "zIndex": 5
                    },
                    "flxAccountTypesSegment": {
                        "top": "-4dp",
                        "zIndex": 5
                    },
                    "imgToolTip": {
                        "isVisible": false,
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFiltersListMain.add(flxFiltersList, lstBoxFilters, accountTypesBillPayHistory);
            flxSearch.add(flxtxtSearchandClearbtn, flxFiltersListMain);
            var flxHorizontalLine1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine1.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine1.add();
            var flxBillPayeeHistoryHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBillPayeeHistoryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayeeHistoryHeader.setDefaultUnit(kony.flex.DP);
            var flxSortSixColumn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSortSixColumn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "92%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSortSixColumn.setDefaultUnit(kony.flex.DP);
            var flxSortDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSortDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSortDate.setDefaultUnit(kony.flex.DP);
            var lblSortDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Date",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSortDate",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSortDate = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortDate",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Date"
            });
            flxSortDate.add(lblSortDate, imgSortDate);
            var flxSendTo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSendTo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "150dp",
                "isModalContainer": false,
                "right": "365dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSendTo.setDefaultUnit(kony.flex.DP);
            var lblSortDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sent to",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSortDescription",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.sendTo\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSortDescription = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortDescription",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Description"
            });
            flxSendTo.add(lblSortDescription, imgSortDescription);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "240dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "130dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblSortAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Amount",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSortAmount",
                "isVisible": true,
                "right": "70dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSortAmount = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortAmount",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "50dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Amount"
            });
            flxAmount.add(lblSortAmount, imgSortAmount);
            var flxStatus = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "100dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "135dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblSortBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Status",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSortBalance",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSortCategory = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortCategory",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "12dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Status"
            });
            flxStatus.add(lblSortBalance, imgSortCategory);
            var flxSortType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSortType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "95dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSortType.setDefaultUnit(kony.flex.DP);
            var lblSortType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Action",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSortType",
                "isVisible": true,
                "right": "30px",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblAction\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSortType = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortType",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Type"
            });
            flxSortType.add(lblSortType, imgSortType);
            flxSortSixColumn.add(flxSortDate, flxSendTo, flxAmount, flxStatus, flxSortType);
            flxBillPayeeHistoryHeader.add(flxSortSixColumn);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var flxSegmentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.setDefaultUnit(kony.flex.DP);
            var segmentBillpay = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }, {
                    "btnEdit": "",
                    "btnRepeat": "",
                    "lblDate": "",
                    "lblDateA": "",
                    "lblDropdown": "",
                    "lblIdentifier": "",
                    "lblNotes": "",
                    "lblNotesValue": "",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "",
                    "lblSendTo": "",
                    "lblSendToA": "",
                    "lblSendToUser": "",
                    "lblSentFrom": "",
                    "lblSentFromUser": "",
                    "lblSentFromValue": "",
                    "lblSeparator": "",
                    "lblSeperatorone": "",
                    "lblSortAmount": "",
                    "lblSortAmountA": "",
                    "lblSortBalance": "",
                    "lblSortBalanceA": ""
                }],
                "groupCells": false,
                "id": "segmentBillpay",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegfffff",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentHistorySelected"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "widgetSkin": "sknsegWatchlist",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.add(segmentBillpay);
            var flxNoPayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoPayment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPayment.setDefaultUnit(kony.flex.DP);
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billpay.noTransactionHistory\")"
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billpay.noTransactionHistory\")",
                "top": "41dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImginfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImginfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImginfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Info"
            });
            flxImginfo.add(imgInfo);
            flxNoPayment.add(rtxNoPaymentMessage, flxImginfo);
            flxLeftSub.add(flxTabsChecking, flxSearch, flxHorizontalLine1, flxBillPayeeHistoryHeader, flxHorizontalLine2, flxSegmentContainer, flxNoPayment);
            var flxPagination = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxPagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var flxPaginationWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "30px",
                "width": "250dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationWrapper.setDefaultUnit(kony.flex.DP);
            var flxPaginationPrevious = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationPrevious",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationPrevious.setDefaultUnit(kony.flex.DP);
            var imgPaginationPrevious = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Pagination left"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationPrevious",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_back_inactive.png",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Previous"
            });
            flxPaginationPrevious.add(imgPaginationPrevious);
            var lblPagination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblPagination",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "1 - 10 Payees",
                "width": "157dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaginationNext = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationNext",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationNext.setDefaultUnit(kony.flex.DP);
            var imgPaginationNext = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Pagination Right"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationNext",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_next_active.png",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Next"
            });
            flxPaginationNext.add(imgPaginationNext);
            flxPaginationWrapper.add(flxPaginationPrevious, lblPagination, flxPaginationNext);
            flxPagination.add(flxPaginationWrapper);
            flxLeft.add(flxLeftSub, flxPagination);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "6.04%",
                "skin": "slFbox",
                "top": "0px",
                "width": "28.40%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add External Account"
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add External Account"
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAddPayee.add(lblAddPayee, flxSeperator3);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMakeOneTimePayment.add(lblMakeOneTimePayment);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxRight);
            var flxNote = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNote",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNote.setDefaultUnit(kony.flex.DP);
            var lblTerms = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Terms & Conditions"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTerms",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNote.add(lblTerms);
            flxContent.add(flxDowntimeWarning, flxMainContainer, flxNote);
            flxMain.add(lblPayABill, btnByPass, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.Quit\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.Areyousureyouwanttoundo\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(CustomPopupCancel);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            flxDialogs.add(flxLogout, flxCancelPopup, flxLoading);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeftSub": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxTabsChecking": {
                        "skin": "sknscrollFlxffffffShadowdddcdcnoradius2vs",
                        "segmentProps": []
                    },
                    "btnAllPayees": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnScheduled": {
                        "segmentProps": []
                    },
                    "btnHistory": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "skin": "sknFlxf7f7f7Shadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersListMain": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory": {
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPayHistory"
                    },
                    "flxBillPayeeHistoryHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSegmentContainer": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "segmentBillpay": {
                        "segmentProps": []
                    },
                    "flxNoPayment": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLeftSub": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersListMain": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory": {
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPayHistory"
                    },
                    "accountTypesBillPayHistory.flxAccountTypesSegment": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxPaginationWrapper": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxLeftSub": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersListMain": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory": {
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPayHistory"
                    },
                    "accountTypesBillPayHistory.flxAccountTypesSegment": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxLeftSub": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersListMain": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPayHistory"
                    },
                    "accountTypesBillPayHistory.flxAccountTypesSegment": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayHistory.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "accountTypesBillPayHistory": {
                    "top": "0dp",
                    "zIndex": 5
                },
                "accountTypesBillPayHistory.flxAccountTypesSegment": {
                    "top": "-4dp",
                    "zIndex": 5
                },
                "accountTypesBillPayHistory.imgToolTip": {
                    "src": "tool_tip.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmBillPayHistory,
            "enabledForIdleTimeout": true,
            "id": "frmBillPayHistory",
            "init": controller.AS_Form_d30f3614dc224fc5bedc49e4aa8443b8,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});