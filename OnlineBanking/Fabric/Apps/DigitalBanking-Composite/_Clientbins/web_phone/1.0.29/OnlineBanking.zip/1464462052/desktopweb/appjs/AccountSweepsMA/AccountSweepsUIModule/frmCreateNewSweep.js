define("AccountSweepsMA/AccountSweepsUIModule/frmCreateNewSweep", function() {
    return function(controller) {
        function addWidgetsfrmCreateNewSweep() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmCreateNewSweep"] && appConfig.componentMetadata["ResourcesMA"]["frmCreateNewSweep"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "Create New Sweep";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.accountsweeps.createNewSweep";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxAccountsSweepMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountsSweepMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSweepMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxSetAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50px",
                "id": "flxSetAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetAccount.setDefaultUnit(kony.flex.DP);
            var lblSetPrimaryAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblSetPrimaryAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLbl000d19SSPSemiBold18Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.sweepDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSetAccount.add(lblSetPrimaryAccount);
            flxHeader.add(flxSetAccount);
            var flxHorizontalSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator.add();
            var flxSweepContentSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSweepContentSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSweepContentSpacing.setDefaultUnit(kony.flex.DP);
            var flxHeaderSep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSep.setDefaultUnit(kony.flex.DP);
            flxHeaderSep.add();
            var flxSweepContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSweepContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "top": "20dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSweepContent.setDefaultUnit(kony.flex.DP);
            var lblSweepError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "58dp",
                "id": "lblSweepError",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblff000015px",
                "text": "Selected sweep start date is not a working day",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxErrMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrMessage.setDefaultUnit(kony.flex.DP);
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "90%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var lblWarningIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "21dp",
                "id": "lblWarningIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblOlbfonticonsFFA50021px",
                "text": "K",
                "top": "0dp",
                "width": "21dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblErrInfo",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(lblWarningIcon, lblErrInfo);
            var flxError1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxError1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "5dp",
                "width": "90%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError1.setDefaultUnit(kony.flex.DP);
            var lblErrorIcon1 = new kony.ui.Label({
                "centerY": "55%",
                "id": "lblErrorIcon1",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknOlbfonticonsE425386px",
                "text": "F",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "45%",
                "id": "lblError1",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlblff000015px",
                "text": "Selected sweep start date is not a working day",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError1.add(lblErrorIcon1, lblError1);
            var flxError2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxError2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "5dp",
                "width": "90%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError2.setDefaultUnit(kony.flex.DP);
            var lblErrorIcon2 = new kony.ui.Label({
                "centerY": "60%",
                "id": "lblErrorIcon2",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknOlbfonticonsE425386px",
                "text": "F",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "45%",
                "id": "lblError2",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlblff000015px",
                "text": "Selected sweep end date is not a working day",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError2.add(lblErrorIcon2, lblError2);
            flxErrMessage.add(flxWarning, flxError1, flxError2);
            var flxInfoMessage = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxInfoMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknfbfbfb",
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoMessage.setDefaultUnit(kony.flex.DP);
            var flxInfoIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "5dp",
                "width": "60dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoIcon.setDefaultUnit(kony.flex.DP);
            var lblInfoIcon = new kony.ui.Label({
                "id": "lblInfoIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl6E7081OlbFonticons20px",
                "text": "K",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoIcon.add(lblInfoIcon);
            var rtxInfoMessage = new kony.ui.RichText({
                "id": "rtxInfoMessage",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknRText72727213PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.sweepInformation\")",
                "top": "0dp",
                "width": "86%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 20, 0, 20],
                "paddingInPixel": true
            }, {});
            var flxClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this notification bar"
                },
                "height": "30dp",
                "id": "flxClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "btnClose",
                "top": 10,
                "width": "30dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoMessage.add(flxInfoIcon, rtxInfoMessage, flxClose);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var lblErrorMessage = new kony.ui.Label({
                "id": "lblErrorMessage",
                "isVisible": true,
                "left": "0",
                "skin": "sknIblEE0005SSPR45px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.existingSecondaryAccount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(lblErrorMessage);
            var flxPrimaryAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxPrimaryAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 16,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryAccount.setDefaultUnit(kony.flex.DP);
            var flxPrimaryKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryKey.setDefaultUnit(kony.flex.DP);
            var lblPrimaryKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblPrimaryKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.primaryAccountWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrimaryKey.add(lblPrimaryKey);
            var flxPrimaryAccountList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPrimaryAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "560dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryAccountList.setDefaultUnit(kony.flex.DP);
            var flxPrimaryAccountTextBoxAndIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPrimaryAccountTextBoxAndIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryAccountTextBoxAndIcon.setDefaultUnit(kony.flex.DP);
            var flxPrimaryText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPrimaryText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "12dp",
                "width": "90%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryText.setDefaultUnit(kony.flex.DP);
            var lblPrimaryText = new kony.ui.Label({
                "id": "lblPrimaryText",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "My Checking Account - 3432",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrimaryText.add(lblPrimaryText);
            var flxPrimaryTextBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPrimaryTextBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryTextBox.setDefaultUnit(kony.flex.DP);
            var lblPrimaryRecordField = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblPrimaryRecordField",
                "isVisible": false,
                "left": "15dp",
                "skin": "slLabel0d8a72616b3cc47",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPrimaryAccount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxPrimaryAccount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.primaryPlaceholder\")",
                "secureTextEntry": false,
                "skin": "ICSknTbxSSP42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [15, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblPrimaryRecordField1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "18dp",
                "id": "lblPrimaryRecordField1",
                "isVisible": false,
                "right": "15dp",
                "skin": "slLabel0d8a72616b3cc47",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoadingIndicatorPrimary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorPrimary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorPrimary.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorPrimary = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorPrimary",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingIndicatorPrimary.add(imgLoadingIndicatorPrimary);
            flxPrimaryTextBox.add(lblPrimaryRecordField, tbxPrimaryAccount, lblPrimaryRecordField1, flxLoadingIndicatorPrimary);
            var flxClearPrimaryText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxClearPrimaryText",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxClearPrimaryText.setDefaultUnit(kony.flex.DP);
            var lblClearPrimaryText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblClearPrimaryText",
                "isVisible": true,
                "skin": "ICSknLblClearFontIcona0a0a016px",
                "text": "J",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearPrimaryText.add(lblClearPrimaryText);
            flxPrimaryAccountTextBoxAndIcon.add(flxPrimaryText, flxPrimaryTextBox, flxClearPrimaryText);
            var flxPrimaryAccountSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxPrimaryAccountSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCbebebeShadow",
                "top": "1dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryAccountSegment.setDefaultUnit(kony.flex.DP);
            var segPrimaryAccounts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segPrimaryAccounts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AccountSweepsMA",
                    "friendlyName": "flxAccountsDropdown"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AccountSweepsMA",
                    "friendlyName": "flxAccountDropdownHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountDropdownHeader": "flxAccountDropdownHeader",
                    "flxAccountRecordField": "flxAccountRecordField",
                    "flxAccountsDropdown": "flxAccountsDropdown",
                    "flxBottomSeparator": "flxBottomSeparator",
                    "flxDropdownIcon": "flxDropdownIcon",
                    "flxRecordFieldType": "flxRecordFieldType",
                    "flxRecordFieldTypeIcon1": "flxRecordFieldTypeIcon1",
                    "flxRecordFieldTypeIcon2": "flxRecordFieldTypeIcon2",
                    "flxRecordType": "flxRecordType",
                    "flxTopSeparator": "flxTopSeparator",
                    "imgRecordFieldTypeIcon2": "imgRecordFieldTypeIcon2",
                    "lblDropdownIcon": "lblDropdownIcon",
                    "lblRecordField1": "lblRecordField1",
                    "lblRecordField2": "lblRecordField2",
                    "lblRecordField3": "lblRecordField3",
                    "lblRecordFieldTypeIcon1": "lblRecordFieldTypeIcon1",
                    "lblRecordType": "lblRecordType"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrimaryAccountSegment.add(segPrimaryAccounts);
            var flxNoPrimaryRecords = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "111dp",
                "id": "flxNoPrimaryRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxbebebeShadow",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPrimaryRecords.setDefaultUnit(kony.flex.DP);
            var lblNoPrimaryRecordMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblNoPrimaryRecordMessage",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.FromAccountsEmptyRecordMessage\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoPrimaryRecords.add(lblNoPrimaryRecordMessage);
            flxPrimaryAccountList.add(flxPrimaryAccountTextBoxAndIcon, flxPrimaryAccountSegment, flxNoPrimaryRecords);
            flxPrimaryAccount.add(flxPrimaryKey, flxPrimaryAccountList);
            var flxSecondaryAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxSecondaryAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryAccount.setDefaultUnit(kony.flex.DP);
            var flxSecondaryKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSecondaryKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryKey.setDefaultUnit(kony.flex.DP);
            var lblSecondaryKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblSecondaryKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.secondaryAccountWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSecondaryKey.add(lblSecondaryKey);
            var flxSecondaryAccountList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecondaryAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "560dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryAccountList.setDefaultUnit(kony.flex.DP);
            var flxSecondaryAccountTextBoxAndIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSecondaryAccountTextBoxAndIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryAccountTextBoxAndIcon.setDefaultUnit(kony.flex.DP);
            var flxSecondaryTextBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSecondaryTextBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryTextBox.setDefaultUnit(kony.flex.DP);
            var lblSecondaryRecordField = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblSecondaryRecordField",
                "isVisible": false,
                "left": "15dp",
                "skin": "slLabel0d8a72616b3cc47",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSecondaryAccount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxSecondaryAccount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.secondaryPlaceholder\")",
                "secureTextEntry": false,
                "skin": "ICSknTbxSSP42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [15, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblSecondaryRecordField1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "18dp",
                "id": "lblSecondaryRecordField1",
                "isVisible": false,
                "right": "15dp",
                "skin": "slLabel0d8a72616b3cc47",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoadingIndicatorSecondary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorSecondary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorSecondary.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorSecondary = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorSecondary",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingIndicatorSecondary.add(imgLoadingIndicatorSecondary);
            flxSecondaryTextBox.add(lblSecondaryRecordField, tbxSecondaryAccount, lblSecondaryRecordField1, flxLoadingIndicatorSecondary);
            var flxClearSecondaryText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxClearSecondaryText",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxClearSecondaryText.setDefaultUnit(kony.flex.DP);
            var lblClearSecondaryText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblClearSecondaryText",
                "isVisible": true,
                "skin": "ICSknLblClearFontIcona0a0a016px",
                "text": "J",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearSecondaryText.add(lblClearSecondaryText);
            flxSecondaryAccountTextBoxAndIcon.add(flxSecondaryTextBox, flxClearSecondaryText);
            var flxSecondaryAccountSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxSecondaryAccountSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCbebebeShadow",
                "top": "1dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryAccountSegment.setDefaultUnit(kony.flex.DP);
            var segSecondaryAccounts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segSecondaryAccounts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AccountSweepsMA",
                    "friendlyName": "flxAccountsDropdown"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AccountSweepsMA",
                    "friendlyName": "flxAccountDropdownHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountDropdownHeader": "flxAccountDropdownHeader",
                    "flxAccountRecordField": "flxAccountRecordField",
                    "flxAccountsDropdown": "flxAccountsDropdown",
                    "flxBottomSeparator": "flxBottomSeparator",
                    "flxDropdownIcon": "flxDropdownIcon",
                    "flxRecordFieldType": "flxRecordFieldType",
                    "flxRecordFieldTypeIcon1": "flxRecordFieldTypeIcon1",
                    "flxRecordFieldTypeIcon2": "flxRecordFieldTypeIcon2",
                    "flxRecordType": "flxRecordType",
                    "flxTopSeparator": "flxTopSeparator",
                    "imgRecordFieldTypeIcon2": "imgRecordFieldTypeIcon2",
                    "lblDropdownIcon": "lblDropdownIcon",
                    "lblRecordField1": "lblRecordField1",
                    "lblRecordField2": "lblRecordField2",
                    "lblRecordField3": "lblRecordField3",
                    "lblRecordFieldTypeIcon1": "lblRecordFieldTypeIcon1",
                    "lblRecordType": "lblRecordType"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSecondaryAccountSegment.add(segSecondaryAccounts);
            var flxNoSecondaryRecords = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "111dp",
                "id": "flxNoSecondaryRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxbebebeShadow",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoSecondaryRecords.setDefaultUnit(kony.flex.DP);
            var lblNoSecondaryRecordMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblNoSecondaryRecordMessage",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.FromAccountsEmptyRecordMessage\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoSecondaryRecords.add(lblNoSecondaryRecordMessage);
            flxSecondaryAccountList.add(flxSecondaryAccountTextBoxAndIcon, flxSecondaryAccountSegment, flxNoSecondaryRecords);
            flxSecondaryAccount.add(flxSecondaryKey, flxSecondaryAccountList);
            var flxSetSweep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSetSweep",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetSweep.setDefaultUnit(kony.flex.DP);
            var flxSetSweepConditionTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSetSweepConditionTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetSweepConditionTitle.setDefaultUnit(kony.flex.DP);
            var lblSetSweepConditionTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblSetSweepConditionTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.setSweepConditionWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSetSweepConditionTitle.add(lblSetSweepConditionTitle);
            var flxSetSweepCondition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSetSweepCondition",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "50dp",
                "isModalContainer": false,
                "right": "50dp",
                "skin": "sknfbfbfb",
                "top": "15dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetSweepCondition.setDefaultUnit(kony.flex.DP);
            var flxSweepCondition1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSweepCondition1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSweepCondition1.setDefaultUnit(kony.flex.DP);
            var flxConditionAndAmount1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionAndAmount1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "top": "0",
                "width": "540dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionAndAmount1.setDefaultUnit(kony.flex.DP);
            var flxCondition1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCondition1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "-10px",
                "top": "0dp",
                "width": "370dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCondition1.setDefaultUnit(kony.flex.DP);
            var flxCheckBox1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCheckBox1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxCheckBox1.setDefaultUnit(kony.flex.DP);
            var imgCheck1 = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgCheck1",
                "isVisible": true,
                "skin": "sknFontIconCheckBoxSelected",
                "text": "D",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox1.add(imgCheck1);
            var lblPreCondition1 = new kony.ui.Label({
                "id": "lblPreCondition1",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.belowBalanceInfo\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmount1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAmount1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "180px",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount1.setDefaultUnit(kony.flex.DP);
            var lblSelectedCurrencySymbol1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "48.75%",
                "id": "lblSelectedCurrencySymbol1",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknCurrencySSP94949415px",
                "text": "$",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmount1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxAmount1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.enterAmount\")",
                "secureTextEntry": false,
                "skin": "ICSknTbxDisabledSSPreg42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [20, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxAmount1.add(lblSelectedCurrencySymbol1, tbxAmount1);
            flxCondition1.add(flxCheckBox1, lblPreCondition1, flxAmount1);
            flxConditionAndAmount1.add(flxCondition1);
            var lblPostCondition1 = new kony.ui.Label({
                "id": "lblPostCondition1",
                "isVisible": true,
                "left": "25dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.topupAmountInfo\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSweepCondition1.add(flxConditionAndAmount1, lblPostCondition1);
            var flxSweepCondition2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSweepCondition2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSweepCondition2.setDefaultUnit(kony.flex.DP);
            var flxConditionAndAmount2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionAndAmount2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "top": "0",
                "width": "550dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionAndAmount2.setDefaultUnit(kony.flex.DP);
            var flxCondition2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCondition2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": -10,
                "top": "0dp",
                "width": "370dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCondition2.setDefaultUnit(kony.flex.DP);
            var flxCheckBox2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCheckBox2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxCheckBox2.setDefaultUnit(kony.flex.DP);
            var imgCheck2 = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgCheck2",
                "isVisible": true,
                "skin": "sknFontIconCheckBoxSelected",
                "text": "D",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox2.add(imgCheck2);
            var lblPreCondition2 = new kony.ui.Label({
                "bottom": "0",
                "id": "lblPreCondition2",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.aboveBalanceInfo\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmount2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAmount2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "10dp",
                "width": "180px",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount2.setDefaultUnit(kony.flex.DP);
            var lblSelectedCurrencySymbol2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "48.75%",
                "id": "lblSelectedCurrencySymbol2",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknCurrencySSP94949415px",
                "text": "$",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmount2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxAmount2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.enterAmount\")",
                "secureTextEntry": false,
                "skin": "ICSknTbxDisabledSSPreg42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [20, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxAmount2.add(lblSelectedCurrencySymbol2, tbxAmount2);
            flxCondition2.add(flxCheckBox2, lblPreCondition2, flxAmount2);
            flxConditionAndAmount2.add(flxCondition2);
            var lblPostCondition2 = new kony.ui.Label({
                "id": "lblPostCondition2",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.excessAmountInfo\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSweepCondition2.add(flxConditionAndAmount2, lblPostCondition2);
            var flxGap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxGap",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGap.setDefaultUnit(kony.flex.DP);
            flxGap.add();
            flxSetSweepCondition.add(flxSweepCondition1, flxSweepCondition2, flxGap);
            flxSetSweep.add(flxSetSweepConditionTitle, flxSetSweepCondition);
            var flxFrequencyAndStartDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFrequencyAndStartDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 12,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequencyAndStartDate.setDefaultUnit(kony.flex.DP);
            var flxFrequency = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "65dp",
                "id": "flxFrequency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "270dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency.setDefaultUnit(kony.flex.DP);
            var flxNewGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNewGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewGroup.setDefaultUnit(kony.flex.DP);
            var lblFrequency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFrequency",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.frequency\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFrequencyInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about frequency "
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "16dp",
                "id": "flxFrequencyInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "2dp",
                "width": "16dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequencyInfo.setDefaultUnit(kony.flex.DP);
            var lblFrequencyInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblFrequencyInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl6e7081OLBFontSet316px",
                "text": "T",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequencyInfo.add(lblFrequencyInfo);
            flxNewGroup.add(lblFrequency, flxFrequencyInfo);
            var flxFrequencyDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFrequencyDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "25dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxFrequencyDropdown.setDefaultUnit(kony.flex.DP);
            var lblSelectedFrequency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectedFrequency",
                "isVisible": true,
                "left": "15dp",
                "skin": "slLabel0d8a72616b3cc47",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFrequencyDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblFrequencyDropdownIcon",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequencyDropdown.add(lblSelectedFrequency, lblFrequencyDropdownIcon);
            var flxFrequencyList = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "160dp",
                "horizontalScrollIndicator": true,
                "id": "flxFrequencyList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCbebebeShadow",
                "top": "66dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequencyList.setDefaultUnit(kony.flex.DP);
            var segFrequencyList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segFrequencyList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Normal",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AccountSweepsMA",
                    "friendlyName": "flxFrequencyListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFrequencyListDropdown": "flxFrequencyListDropdown",
                    "lblListValue": "lblListValue"
                },
                "widgetSkin": "seg2Normal",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequencyList.add(segFrequencyList);
            flxFrequency.add(flxNewGroup, flxFrequencyDropdown, flxFrequencyList);
            var flxStartDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "65dp",
                "id": "flxStartDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "270dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartDate.setDefaultUnit(kony.flex.DP);
            var flxStartDateInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStartDateInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "270dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartDateInfo.setDefaultUnit(kony.flex.DP);
            var lblStartDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblStartDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStartFromInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about starting from date"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "16dp",
                "id": "flxStartFromInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "2dp",
                "width": "16dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartFromInfo.setDefaultUnit(kony.flex.DP);
            var lblStartFromInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblStartFromInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl6e7081OLBFontSet316px",
                "text": "T",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStartFromInfo.add(lblStartFromInfo);
            flxStartDateInfo.add(lblStartDate, flxStartFromInfo);
            var flxCalStartDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCalStartDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxCalStartDate.setDefaultUnit(kony.flex.DP);
            var calStartDate = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calendar_2.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "height": "40dp",
                "hour": 0,
                "id": "calStartDate",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "seconds": 0,
                "skin": "ICSknCalender424242SSPRegular15px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "allowWeekendSelectable": true
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [15, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxCalStartDate.add(calStartDate);
            flxStartDate.add(flxStartDateInfo, flxCalStartDate);
            flxFrequencyAndStartDate.add(flxFrequency, flxStartDate);
            var flxEndDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEndDate",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AccountSweepsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndDate.setDefaultUnit(kony.flex.DP);
            var flxEndDateTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxEndDateTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateTitle.setDefaultUnit(kony.flex.DP);
            var lblEndDateTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEndDateTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.endSpaceDateColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEndDateInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about end date"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "16dp",
                "id": "flxEndDateInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "1dp",
                "width": "16dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateInfo.setDefaultUnit(kony.flex.DP);
            var lblEndDateInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblEndDateInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl6e7081OLBFontSet316px",
                "text": "T",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndDateInfo.add(lblEndDateInfo);
            flxEndDateTitle.add(lblEndDateTitle, flxEndDateInfo);
            var flxEndDateOptions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "radiogroup",
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxEndDateOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 10,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateOptions.setDefaultUnit(kony.flex.DP);
            var flxEndManually = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxEndManually",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 1,
                        "1380": 1
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndManually.setDefaultUnit(kony.flex.DP);
            var flxManulaOption = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25dp",
                "id": "flxManulaOption",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxManulaOption.setDefaultUnit(kony.flex.DP);
            var lblManualOption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblManualOption",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnSelectedFontIcon003e7520px",
                "text": "M",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "ICSknLblRadioBtnSelectedFontIcon003e7520px"
            });
            flxManulaOption.add(lblManualOption);
            var lblEndManually = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEndManually",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endManually\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndManually.add(flxManulaOption, lblEndManually);
            var flxCustomDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCustomDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 1,
                        "1380": 1
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomDate.setDefaultUnit(kony.flex.DP);
            var flxCustomOption = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCustomOption",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxCustomOption.setDefaultUnit(kony.flex.DP);
            var lblCustomOption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCustomOption",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnSelectedFontIcon003e7520px",
                "text": "L",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "ICSknLblRadioBtnSelectedFontIcon003e7520px"
            });
            flxCustomOption.add(lblCustomOption);
            var lblCustomDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCustomDate",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.customDate\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomDate.add(flxCustomOption, lblCustomDate);
            flxEndDateOptions.add(flxEndManually, flxCustomDate);
            flxEndDate.add(flxEndDateTitle, flxEndDateOptions);
            var flxSelectEndDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "65dp",
                "id": "flxSelectEndDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectEndDate.setDefaultUnit(kony.flex.DP);
            var lblSelectEndDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectEndDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.selectEndDateWithColumn\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCalEndDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCalEndDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "25dp",
                "width": "270dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxCalEndDate.setDefaultUnit(kony.flex.DP);
            var calEndDate = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calendar_2.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "height": "40dp",
                "hour": 0,
                "id": "calEndDate",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "seconds": 0,
                "skin": "ICSknCalender424242SSPRegular15px",
                "top": "0dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [15, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxCalEndDate.add(calEndDate);
            flxSelectEndDate.add(lblSelectEndDate, flxCalEndDate);
            flxSweepContent.add(lblSweepError, flxErrMessage, flxInfoMessage, flxErrorMessage, flxPrimaryAccount, flxSecondaryAccount, flxSetSweep, flxFrequencyAndStartDate, flxEndDate, flxSelectEndDate);
            var flxPaymentMethods = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentMethods",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "112dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "255dp",
                "width": "430dp",
                "zIndex": 200,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethods.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethodHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxPaymentMethodHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblPaymentMethodHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl42424215pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblFrequency\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentMethodClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPaymentMethodClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15dp",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 10,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodClose.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblPaymentMethodClose",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLbl6e7081olbfonts15px",
                "text": "g",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodClose.add(lblPaymentMethodClose);
            flxPaymentMethodHeader.add(lblPaymentMethodHeader, flxPaymentMethodClose);
            var flxSep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep.setDefaultUnit(kony.flex.DP);
            flxSep.add();
            var flxDaily = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDaily",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDaily.setDefaultUnit(kony.flex.DP);
            var lblDaily = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblDaily",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Daily\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyChevron = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDailyChevron",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "0dp",
                "width": "20dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyChevron.setDefaultUnit(kony.flex.DP);
            var lblDailyChevron = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDailyChevron",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl6e7081olbfonticons14px",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyChevron.add(lblDailyChevron);
            flxDaily.add(lblDaily, flxDailyChevron);
            var lblDailyDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100dp",
                "id": "lblDailyDesc",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.dailyInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailySep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxDailySep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailySep.setDefaultUnit(kony.flex.DP);
            flxDailySep.add();
            var flxWeekly = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxWeekly",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeekly.setDefaultUnit(kony.flex.DP);
            var lblWeekly = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblWeekly",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Weekly\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyChevron = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxWeeklyChevron",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "0dp",
                "width": "20dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyChevron.setDefaultUnit(kony.flex.DP);
            var lblWeeklyChevron = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblWeeklyChevron",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl6e7081olbfonticons14px",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyChevron.add(lblWeeklyChevron);
            flxWeekly.add(lblWeekly, flxWeeklyChevron);
            var lblWeeklyDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100dp",
                "id": "lblWeeklyDesc",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.weeklyInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklySep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxWeeklySep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklySep.setDefaultUnit(kony.flex.DP);
            flxWeeklySep.add();
            var flxMonthly = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMonthly",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMonthly.setDefaultUnit(kony.flex.DP);
            var lblMonthly = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblMonthly",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Monthly\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMonthlyChevron = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxMonthlyChevron",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "0dp",
                "width": "20dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMonthlyChevron.setDefaultUnit(kony.flex.DP);
            var lblMonthlyChevron = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Show more information about monthly frequency",
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblMonthlyChevron",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl6e7081olbfonticons14px",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMonthlyChevron.add(lblMonthlyChevron);
            flxMonthly.add(lblMonthly, flxMonthlyChevron);
            var lblMonthlyDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100dp",
                "id": "lblMonthlyDesc",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.monthlyInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMonthlySep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMonthlySep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMonthlySep.setDefaultUnit(kony.flex.DP);
            flxMonthlySep.add();
            var flxSixMonths = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSixMonths",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSixMonths.setDefaultUnit(kony.flex.DP);
            var lblSixMonths = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblSixMonths",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.everySixMonths\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSixMonthsChevron = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSixMonthsChevron",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "0dp",
                "width": "20dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSixMonthsChevron.setDefaultUnit(kony.flex.DP);
            var lblSixMonthsChevron = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblSixMonthsChevron",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknLbl6e7081olbfonticons14px",
                "text": "O",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSixMonthsChevron.add(lblSixMonthsChevron);
            flxSixMonths.add(lblSixMonths, flxSixMonthsChevron);
            var lblSixMonthsDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100dp",
                "id": "lblSixMonthsDesc",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.every6monthsInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            flxPaymentMethods.add(flxPaymentMethodHeader, flxSep, flxDaily, lblDailyDesc, flxDailySep, flxWeekly, lblWeeklyDesc, flxWeeklySep, flxMonthly, lblMonthlyDesc, flxMonthlySep, flxSixMonths, lblSixMonthsDesc, flxDummy);
            var flxEndDatePopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEndDatePopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "102dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "298dp",
                "width": "430dp",
                "zIndex": 200,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDatePopup.setDefaultUnit(kony.flex.DP);
            var flxEndDateHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxEndDateHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateHeader.setDefaultUnit(kony.flex.DP);
            var lblEndDateHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblEndDateHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl42424215pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEndDateClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxEndDateClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15dp",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 10,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateClose.setDefaultUnit(kony.flex.DP);
            var lblEndDateClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblEndDateClose",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLbl6e7081olbfonts15px",
                "text": "g",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndDateClose.add(lblEndDateClose);
            flxEndDateHeader.add(lblEndDateHeader, flxEndDateClose);
            var flxEndDateSep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEndDateSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateSep.setDefaultUnit(kony.flex.DP);
            flxEndDateSep.add();
            var flxEnd = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEnd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnd.setDefaultUnit(kony.flex.DP);
            var lblEnd = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblEnd",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endManually\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEnd.add(lblEnd);
            var lblEndDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "80dp",
                "id": "lblEndDesc",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endManuallyInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEnd1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEnd1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnd1.setDefaultUnit(kony.flex.DP);
            var lblEnd1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "centerY": "50%",
                "id": "lblEnd1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl000d19SSB13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.customDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEnd1.add(lblEnd1);
            var lblEnd2Desc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblEnd2Desc",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.customDateInfo\")",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "13dp",
                "id": "flxDummy1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy1.setDefaultUnit(kony.flex.DP);
            flxDummy1.add();
            flxEndDatePopup.add(flxEndDateHeader, flxEndDateSep, flxEnd, lblEndDesc, flxEnd1, lblEnd2Desc, flxDummy1);
            var flxStartingFromPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStartingFromPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "420dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "385dp",
                "width": "430dp",
                "zIndex": 200,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartingFromPopup.setDefaultUnit(kony.flex.DP);
            var flxStartingFromHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxStartingFromHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartingFromHeader.setDefaultUnit(kony.flex.DP);
            var lblStartingFromHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblStartingFromHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl42424215pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromWithoutColon\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStartFromClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxStartFromClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15dp",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 10,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartFromClose.setDefaultUnit(kony.flex.DP);
            var lblStartFromClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblStartFromClose",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLbl6e7081olbfonts15px",
                "text": "g",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStartFromClose.add(lblStartFromClose);
            flxStartingFromHeader.add(lblStartingFromHeader, flxStartFromClose);
            var flxStartFromSep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxStartFromSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStartFromSep.setDefaultUnit(kony.flex.DP);
            flxStartFromSep.add();
            var lblStartFromDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblStartFromDesc",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSR000d1913px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromInfo\")",
                "top": "10dp",
                "width": "390dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "13dp",
                "id": "flxDummy3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy3.setDefaultUnit(kony.flex.DP);
            flxDummy3.add();
            flxStartingFromPopup.add(flxStartingFromHeader, flxStartFromSep, lblStartFromDesc, flxDummy3);
            flxSweepContentSpacing.add(flxHeaderSep, flxSweepContent, flxPaymentMethods, flxEndDatePopup, flxStartingFromPopup);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to confirmation"
                },
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "30dp",
                "skin": "ICSknbtnDisablede2e9f036px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnContinue\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel sweep"
                },
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "200dp",
                "skin": "ICSknBtnSSPRegular003E7515Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnCancel\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(flxSeparator, btnContinue, btnCancel);
            flxAccountsSweepMain.add(flxHeader, flxHorizontalSeparator, flxSweepContentSpacing, flxButtons);
            formTemplate12.flxContentTCCenter.add(flxAccountsSweepMain);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxAccountsSweepMain": {
                        "top": {
                            "type": "string",
                            "value": "-40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "flxSetAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxHeader"]
                    },
                    "lblSetPrimaryAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxHeader", "flxSetAccount"]
                    },
                    "flxHorizontalSeparator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "flxSweepContentSpacing": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "flxHeaderSep": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxSweepContent": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "lblSweepError": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "tagName": "span"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxErrMessage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxWarning": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage"]
                    },
                    "lblWarningIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxWarning"]
                    },
                    "lblErrInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxWarning"]
                    },
                    "flxError1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage"]
                    },
                    "lblErrorIcon1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError1"]
                    },
                    "lblError1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError1"]
                    },
                    "flxError2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage"]
                    },
                    "lblErrorIcon2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError2"]
                    },
                    "lblError2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError2"]
                    },
                    "flxInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxInfoIcon": {
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "lblInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage", "flxInfoIcon"]
                    },
                    "rtxInfoMessage": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxClose": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxErrorMessage": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxPrimaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblPrimaryKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryKey"]
                    },
                    "flxPrimaryAccountList": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount"]
                    },
                    "flxPrimaryAccountTextBoxAndIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "tbxPrimaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList", "flxPrimaryAccountTextBoxAndIcon", "flxPrimaryTextBox"]
                    },
                    "flxPrimaryAccountSegment": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "flxNoPrimaryRecords": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "flxSecondaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblSecondaryKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryKey"]
                    },
                    "flxSecondaryAccountList": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount"]
                    },
                    "flxSecondaryAccountTextBoxAndIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "tbxSecondaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList", "flxSecondaryAccountTextBoxAndIcon", "flxSecondaryTextBox"]
                    },
                    "flxSecondaryAccountSegment": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "flxNoSecondaryRecords": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "flxSetSweep": {
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblSetSweepConditionTitle": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepConditionTitle"]
                    },
                    "flxSetSweepCondition": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep"]
                    },
                    "flxSweepCondition1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition"]
                    },
                    "flxConditionAndAmount1": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1"]
                    },
                    "flxCondition1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1"]
                    },
                    "flxCheckBox1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1"]
                    },
                    "lblPreCondition1": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1"]
                    },
                    "flxAmount1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "230px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1"]
                    },
                    "lblSelectedCurrencySymbol1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1", "flxAmount1"]
                    },
                    "tbxAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1", "flxAmount1"]
                    },
                    "lblPostCondition1": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1"]
                    },
                    "flxSweepCondition2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition"]
                    },
                    "flxConditionAndAmount2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2"]
                    },
                    "flxCondition2": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2"]
                    },
                    "flxCheckBox2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "lblPreCondition2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "flxAmount2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "230px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "lblSelectedCurrencySymbol2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2", "flxAmount2"]
                    },
                    "tbxAmount2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2", "flxAmount2"]
                    },
                    "lblPostCondition2": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2"]
                    },
                    "flxFrequencyAndStartDate": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxFrequency": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate"]
                    },
                    "lblFrequency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency", "flxNewGroup"]
                    },
                    "flxFrequencyInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency", "flxNewGroup"]
                    },
                    "lblFrequencyInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency", "flxNewGroup", "flxFrequencyInfo"]
                    },
                    "flxFrequencyDropdown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency"]
                    },
                    "flxFrequencyList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency"]
                    },
                    "flxStartDate": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate"]
                    },
                    "flxStartDateInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate"]
                    },
                    "lblStartDate": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate", "flxStartDateInfo"]
                    },
                    "flxStartFromInfo": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate", "flxStartDateInfo"]
                    },
                    "lblStartFromInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate", "flxStartDateInfo", "flxStartFromInfo"]
                    },
                    "flxCalStartDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate"]
                    },
                    "flxEndDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxEndDateTitle": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate"]
                    },
                    "lblEndDateTitle": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateTitle"]
                    },
                    "flxEndDateInfo": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateTitle"]
                    },
                    "lblEndDateInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateTitle", "flxEndDateInfo"]
                    },
                    "flxEndDateOptions": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate"]
                    },
                    "flxEndManually": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "lblEndManually": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions", "flxEndManually"]
                    },
                    "flxCustomDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "lblCustomDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions", "flxCustomDate"]
                    },
                    "flxSelectEndDate": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblSelectEndDate": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSelectEndDate"]
                    },
                    "flxCalEndDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSelectEndDate"]
                    },
                    "flxPaymentMethods": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "473dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxPaymentMethodHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 200,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblPaymentMethodHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxPaymentMethodHeader"]
                    },
                    "lblPaymentMethodClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxPaymentMethodHeader", "flxPaymentMethodClose"]
                    },
                    "flxDaily": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblDaily": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxDaily"]
                    },
                    "lblDailyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxDaily", "flxDailyChevron"]
                    },
                    "lblDailyDesc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "flxWeekly": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblWeekly": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxWeekly"]
                    },
                    "lblWeeklyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxWeekly", "flxWeeklyChevron"]
                    },
                    "lblWeeklyDesc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "flxMonthly": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblMonthly": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxMonthly"]
                    },
                    "lblMonthlyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxMonthly", "flxMonthlyChevron"]
                    },
                    "lblMonthlyDesc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "flxSixMonths": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblSixMonths": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxSixMonths"]
                    },
                    "lblSixMonthsChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxSixMonths", "flxSixMonthsChevron"]
                    },
                    "lblSixMonthsDesc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "flxEndDatePopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "580dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxEndDateHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "lblEndDateHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup", "flxEndDateHeader"]
                    },
                    "lblEndDateClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup", "flxEndDateHeader", "flxEndDateClose"]
                    },
                    "flxEnd": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "lblEnd": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup", "flxEnd"]
                    },
                    "lblEndDesc": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "flxEnd1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "lblEnd1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup", "flxEnd1"]
                    },
                    "lblEnd2Desc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "flxStartingFromPopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxStartingFromHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup"]
                    },
                    "lblStartingFromHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup", "flxStartingFromHeader"]
                    },
                    "lblStartFromClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup", "flxStartingFromHeader", "flxStartFromClose"]
                    },
                    "lblStartFromDesc": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup"]
                    },
                    "flxButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "btnContinue": {
                        "left": {
                            "type": "number",
                            "value": "10"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxButtons"]
                    },
                    "btnCancel": {
                        "left": {
                            "type": "number",
                            "value": "10"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxButtons"]
                    }
                },
                "1024": {
                    "lblSetPrimaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxHeader", "flxSetAccount"]
                    },
                    "flxErrMessage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblWarningIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxWarning"]
                    },
                    "lblErrorIcon1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError1"]
                    },
                    "lblErrorIcon2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxErrMessage", "flxError2"]
                    },
                    "flxInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "lblInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage", "flxInfoIcon"]
                    },
                    "rtxInfoMessage": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxClose": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxPrimaryAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxPrimaryAccountList": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount"]
                    },
                    "flxPrimaryAccountTextBoxAndIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "flxPrimaryAccountSegment": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "flxNoPrimaryRecords": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList"]
                    },
                    "flxSecondaryAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxSecondaryAccountList": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount"]
                    },
                    "flxSecondaryAccountTextBoxAndIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "flxSecondaryAccountSegment": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "flxNoSecondaryRecords": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSecondaryAccount", "flxSecondaryAccountList"]
                    },
                    "lblPreCondition2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "flxFrequencyAndStartDate": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxFrequency": {
                        "width": {
                            "type": "string",
                            "value": "48.90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate"]
                    },
                    "lblFrequencyInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxFrequency", "flxNewGroup", "flxFrequencyInfo"]
                    },
                    "flxStartDate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate"]
                    },
                    "flxStartDateInfo": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate"]
                    },
                    "lblStartFromInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate", "flxStartDateInfo", "flxStartFromInfo"]
                    },
                    "flxCalStartDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxFrequencyAndStartDate", "flxStartDate"]
                    },
                    "flxEndDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxEndDateTitle": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate"]
                    },
                    "lblEndDateInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateTitle", "flxEndDateInfo"]
                    },
                    "flxEndDateOptions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate"]
                    },
                    "flxEndManually": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxCustomDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxSelectEndDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent"]
                    },
                    "flxCalEndDate": {
                        "width": {
                            "type": "string",
                            "value": "48.90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSelectEndDate"]
                    },
                    "calEndDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSelectEndDate", "flxCalEndDate"]
                    },
                    "flxPaymentMethods": {
                        "top": {
                            "type": "string",
                            "value": "346dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxPaymentMethodHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblPaymentMethodClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxPaymentMethodHeader", "flxPaymentMethodClose"]
                    },
                    "flxDaily": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblDailyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxDaily", "flxDailyChevron"]
                    },
                    "flxWeekly": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblWeeklyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxWeekly", "flxWeeklyChevron"]
                    },
                    "flxMonthly": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblMonthlyChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxMonthly", "flxMonthlyChevron"]
                    },
                    "flxSixMonths": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods"]
                    },
                    "lblSixMonthsChevron": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxPaymentMethods", "flxSixMonths", "flxSixMonthsChevron"]
                    },
                    "flxEndDatePopup": {
                        "top": {
                            "type": "string",
                            "value": "388dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxEndDateHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "lblEndDateClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup", "flxEndDateHeader", "flxEndDateClose"]
                    },
                    "flxEnd": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "flxEnd1": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "flxStartingFromPopup": {
                        "left": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "465dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxStartingFromHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup"]
                    },
                    "lblStartFromClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup", "flxStartingFromHeader", "flxStartFromClose"]
                    },
                    "lblStartFromDesc": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxStartingFromPopup"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxClose": {
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxClearPrimaryText": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxPrimaryAccount", "flxPrimaryAccountList", "flxPrimaryAccountTextBoxAndIcon"]
                    },
                    "flxConditionAndAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1"]
                    },
                    "flxAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1"]
                    },
                    "lblSelectedCurrencySymbol1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1", "flxConditionAndAmount1", "flxCondition1", "flxAmount1"]
                    },
                    "flxConditionAndAmount2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2"]
                    },
                    "flxCondition2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2"]
                    },
                    "flxCheckBox2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "lblPreCondition2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "flxAmount2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "lblSelectedCurrencySymbol2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2", "flxAmount2"]
                    },
                    "flxEndManually": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxCustomDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxCalEndDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSelectEndDate"]
                    },
                    "flxStartingFromPopup": {
                        "top": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxButtons": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "btnCancel": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxButtons"]
                    }
                },
                "1380": {
                    "flxSweepContentSpacing": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    },
                    "flxClose": {
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxInfoMessage"]
                    },
                    "flxConditionAndAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition1"]
                    },
                    "lblPreCondition2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxSetSweep", "flxSetSweepCondition", "flxSweepCondition2", "flxConditionAndAmount2", "flxCondition2"]
                    },
                    "flxEndManually": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxCustomDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxSweepContent", "flxEndDate", "flxEndDateOptions"]
                    },
                    "flxPaymentMethods": {
                        "top": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "lblEndDesc": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing", "flxEndDatePopup"]
                    },
                    "flxStartingFromPopup": {
                        "top": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain", "flxSweepContentSpacing"]
                    },
                    "flxButtons": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxAccountsSweepMain"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateNewSweep,
            "enabledForIdleTimeout": true,
            "id": "frmCreateNewSweep",
            "init": controller.AS_Form_f930e3d79f944c109cb62beaac4db795,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AccountSweepsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});