define("TradeFinanceMA/ExportLCUIModule/userfrmAllAlertsController", {
    //Type your controller code here 
});
define("TradeFinanceMA/ExportLCUIModule/frmAllAlertsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("TradeFinanceMA/ExportLCUIModule/frmAllAlertsController", ["TradeFinanceMA/ExportLCUIModule/userfrmAllAlertsController", "TradeFinanceMA/ExportLCUIModule/frmAllAlertsControllerActions"], function() {
    var controller = require("TradeFinanceMA/ExportLCUIModule/userfrmAllAlertsController");
    var controllerActions = ["TradeFinanceMA/ExportLCUIModule/frmAllAlertsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
