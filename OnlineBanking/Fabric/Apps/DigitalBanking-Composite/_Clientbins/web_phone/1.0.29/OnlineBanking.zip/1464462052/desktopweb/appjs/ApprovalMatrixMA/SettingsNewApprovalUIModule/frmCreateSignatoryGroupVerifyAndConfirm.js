define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmCreateSignatoryGroupVerifyAndConfirm", function() {
    return function(controller) {
        function addWidgetsfrmCreateSignatoryGroupVerifyAndConfirm() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "121px",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxLogoAndActionsWrapper": {
                        "minWidth": "viz.val_cleared",
                        "width": "1366dp"
                    },
                    "flxMenuLeft": {
                        "left": "83dp",
                        "top": "0dp"
                    },
                    "flxMenuWrapper": {
                        "minWidth": "viz.val_cleared",
                        "width": "1366dp"
                    },
                    "imgKony": {
                        "left": "83dp",
                        "src": "kony_logo.png",
                        "top": "15dp"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "centerX": "50%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxMainWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "minHeight": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent_2.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow_2.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent_2.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey_2.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            flxMainWrapper.add(flxDowntimeWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": 0,
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "87.84%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.createSignatoryVerifyConfirm\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserName = new kony.ui.Label({
                "bottom": "32px",
                "id": "lblUserName",
                "isVisible": false,
                "right": "17px",
                "skin": "bblblskn424242Bold",
                "text": "Jeffrey Ballard",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmail = new kony.ui.Label({
                "bottom": "11px",
                "id": "lblEmail",
                "isVisible": false,
                "right": "17px",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Jeffery.ballard@yahoo.com",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentHeader.add(lblContentHeader, lblUserName, lblEmail);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSelectPermissions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelectPermissions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectPermissions.setDefaultUnit(kony.flex.DP);
            var flxCustomer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80px",
                "id": "flxCustomer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.account\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxCustomer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxSelectPermissionsBulk = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelectPermissionsBulk",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectPermissionsBulk.setDefaultUnit(kony.flex.DP);
            var flxEditRecipientsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditRecipientsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFFFFFF",
                "top": "20dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditRecipientsHeader.setDefaultUnit(kony.flex.DP);
            var lblRecipientsHeader = new kony.ui.Label({
                "id": "lblRecipientsHeader",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLabelBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.viewDetailsConfirm\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewNEdit = new kony.ui.Button({
                "focusSkin": "bbSknBtn4176a4NoBorder",
                "id": "btnViewNEdit",
                "isVisible": false,
                "left": "85%",
                "skin": "slButtonGlossBlue",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupNameHeader\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditRecipientsHeader.add(lblRecipientsHeader, btnViewNEdit);
            var flxSeparatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorHeader.setDefaultUnit(kony.flex.DP);
            flxSeparatorHeader.add();
            var flxSelectAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxSelectAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "bbSknFlxffffffNoBorder",
                "top": "20dp",
                "width": "97%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccounts.setDefaultUnit(kony.flex.DP);
            var flxAccntHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccntHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccntHeader.setDefaultUnit(kony.flex.DP);
            var lblSelectAccounts = new kony.ui.Label({
                "id": "lblSelectAccounts",
                "isVisible": false,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Select Accounts to update permissions in bulk",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCompany = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCompany",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompany.setDefaultUnit(kony.flex.DP);
            var lblCompany = new kony.ui.Label({
                "id": "lblCompany",
                "isVisible": false,
                "left": "300dp",
                "right": "0px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UserManagement.Company\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCompanyName = new kony.ui.Label({
                "id": "lblCompanyName",
                "isVisible": false,
                "left": "10dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Altair International, Inc.",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCompany.add(lblCompany, lblCompanyName);
            flxAccntHeader.add(lblSelectAccounts, flxCompany);
            var imgArrow = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "40dp",
                "id": "imgArrow",
                "isVisible": false,
                "left": "66.50%",
                "right": "0dp",
                "skin": "slImage",
                "src": "listboxdownarrow.png",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountSelectSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAccountSelectSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSelectSeperator.setDefaultUnit(kony.flex.DP);
            flxAccountSelectSeperator.add();
            var flxFeatureContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxFeatureContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "25%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureContainer.setDefaultUnit(kony.flex.DP);
            var lblSelectFeature = new kony.ui.Label({
                "id": "lblSelectFeature",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "Select Features",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxFilterListBoxFeatures = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFilterListBoxFeatures",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterListBoxFeatures.setDefaultUnit(kony.flex.DP);
            var lblSelectedFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectedFilter",
                "isVisible": true,
                "left": "3%",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "All Features",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDown = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "sknFlxHover",
                "width": "22dp",
                "zIndex": 11,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var lblDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "More"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "10dp",
                "id": "lblDropDown",
                "isVisible": true,
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(lblDropDown);
            flxFilterListBoxFeatures.add(lblSelectedFilter, flxDropDown);
            var MobileCustomDropdown = new com.InfinityOLB.Resources.MobileCustomDropdown({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "MobileCustomDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "MobileCustomDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "left": "0dp",
                        "minWidth": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 1
                    },
                    "flxApproveType": {
                        "isVisible": false
                    },
                    "flxButtons": {
                        "isVisible": false
                    },
                    "flxDropdown": {
                        "isVisible": false,
                        "left": "0%",
                        "top": "80dp",
                        "width": "100%",
                        "zIndex": 10
                    },
                    "flxImage": {
                        "left": "87%"
                    },
                    "flxIphoneDropdown": {
                        "clipBounds": false,
                        "isVisible": true,
                        "left": "0%",
                        "top": "40dp",
                        "width": "100%"
                    },
                    "flxStatus": {
                        "isVisible": false
                    },
                    "flxTimePeriod": {
                        "isVisible": false
                    },
                    "imgDropdown": {
                        "src": "listboxuparrow.png"
                    },
                    "lblView": {
                        "isVisible": false
                    },
                    "lblViewType": {
                        "text": "All Transactions"
                    },
                    "segViewTypes": {
                        "zIndex": 5
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxListBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40%",
                "width": "100%",
                "zIndex": 50,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListBox.setDefaultUnit(kony.flex.DP);
            var ListBox1 = new kony.ui.ListBox({
                "focusSkin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "height": "100%",
                "id": "ListBox1",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "All Features"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "selectedKey": "lb1",
                "skin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopycompanyListAllFeatures = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopycompanyListAllFeatures",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 70,
                "isModalContainer": false,
                "right": 2,
                "skin": "slfBoxffffffB1R5",
                "top": "40dp",
                "width": "100%",
                "zIndex": 200,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopycompanyListAllFeatures.setDefaultUnit(kony.flex.DP);
            var segAccountListActions1 = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }],
                "groupCells": false,
                "height": "240dp",
                "id": "segAccountListActions1",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxRowDefaultAccounts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRowDefaultAccounts": "flxRowDefaultAccounts",
                    "lblDefaultAccountIcon": "lblDefaultAccountIcon",
                    "lblDefaultAccountName": "lblDefaultAccountName"
                },
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopycompanyListAllFeatures.add(segAccountListActions1);
            var flxAccountsRightContainer1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAccountsRightContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxAccountsRightContainer1.setDefaultUnit(kony.flex.DP);
            var lblShowAllFeatures = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Show All Accounts"
                },
                "centerY": "50%",
                "id": "lblShowAllFeatures",
                "isVisible": true,
                "right": "16%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Per Transaction",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "Copyskn0e7cb98784ed448"
            });
            var flxDropDown1 = new kony.ui.FlexContainer({
                "bottom": 0,
                "centerY": "55%",
                "clipBounds": false,
                "height": "10dp",
                "id": "flxDropDown1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d3a44c95e0844f8b91e7d195da058b94,
                "right": "0dp",
                "skin": "slFbox",
                "width": "6dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxDropDown1.setDefaultUnit(kony.flex.DP);
            var lblImgDropdown1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Favourite account dropdown"
                },
                "centerX": "50%",
                "centerY": "55%",
                "id": "lblImgDropdown1",
                "isVisible": true,
                "skin": "bbSknLblFontIcon",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown1.add(lblImgDropdown1);
            flxAccountsRightContainer1.add(lblShowAllFeatures, flxDropDown1);
            flxListBox.add(ListBox1, CopycompanyListAllFeatures, flxAccountsRightContainer1);
            var lblHeader1 = new kony.ui.Label({
                "id": "lblHeader1",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UserManagement.SelectFeatures\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeatureContainer.add(lblSelectFeature, flxFilterListBoxFeatures, MobileCustomDropdown, flxListBox, lblHeader1);
            var flxAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "350dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 50,
                "width": "25%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var lblHeader2 = new kony.ui.Label({
                "id": "lblHeader2",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": "Select Actions",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxActionListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxActionListBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40%",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActionListBox.setDefaultUnit(kony.flex.DP);
            var ActionListBox = new kony.ui.ListBox({
                "focusSkin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "height": "100%",
                "id": "ActionListBox",
                "isVisible": false,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Selected 5 of 8"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "selectedKey": "lb1",
                "skin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var companyListAllFeatures2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "companyListAllFeatures2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 70,
                "isModalContainer": false,
                "right": 2,
                "skin": "slfBoxffffffB1R5",
                "top": "40dp",
                "width": "100%",
                "zIndex": 200,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            companyListAllFeatures2.setDefaultUnit(kony.flex.DP);
            var segAccountListActions2 = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }, {
                    "lblDefaultAccountIcon": "",
                    "lblDefaultAccountName": "Label"
                }],
                "groupCells": false,
                "height": "240dp",
                "id": "segAccountListActions2",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxRowDefaultAccounts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRowDefaultAccounts": "flxRowDefaultAccounts",
                    "lblDefaultAccountIcon": "lblDefaultAccountIcon",
                    "lblDefaultAccountName": "lblDefaultAccountName"
                },
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            companyListAllFeatures2.add(segAccountListActions2);
            var flxAccountsRightContainer2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAccountsRightContainer2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "100%",
                "zIndex": 51,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxAccountsRightContainer2.setDefaultUnit(kony.flex.DP);
            var lblShowAllFeatures2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Show All Accounts"
                },
                "centerY": "50%",
                "id": "lblShowAllFeatures2",
                "isVisible": true,
                "right": "16%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Selected 5 of 8",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "Copyskn0e7cb98784ed448"
            });
            var flxDropDown2 = new kony.ui.FlexContainer({
                "bottom": 0,
                "centerY": "55%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxDropDown2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d3a44c95e0844f8b91e7d195da058b94,
                "right": "0dp",
                "skin": "slFbox",
                "width": "6%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxDropDown2.setDefaultUnit(kony.flex.DP);
            var lblImgDropdown2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Favourite account dropdown"
                },
                "centerX": "50%",
                "centerY": "55%",
                "id": "lblImgDropdown2",
                "isVisible": true,
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown2.add(lblImgDropdown2);
            flxAccountsRightContainer2.add(lblShowAllFeatures2, flxDropDown2);
            flxActionListBox.add(ActionListBox, companyListAllFeatures2, flxAccountsRightContainer2);
            flxAction.add(lblHeader2, flxActionListBox);
            var flxGroupName = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxGroupName",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupName.setDefaultUnit(kony.flex.DP);
            var lblGroupName = new kony.ui.Label({
                "id": "lblGroupName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxGroupNameValue = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxGroupNameValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameValue.setDefaultUnit(kony.flex.DP);
            var CopylblDollar0cc0645c227ea49 = new kony.ui.Label({
                "centerY": "50%",
                "id": "CopylblDollar0cc0645c227ea49",
                "isVisible": false,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxGroupNameValue = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Username"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "84%",
                "id": "tbxGroupNameValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5dp",
                "right": "15%",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxGroupNameValue.add(CopylblDollar0cc0645c227ea49, tbxGroupNameValue);
            var btnCheckAvailability = new kony.ui.Button({
                "focusSkin": "bbSknBtn4176a4NoBorder",
                "id": "btnCheckAvailability",
                "isVisible": true,
                "left": "370dp",
                "skin": "ICSknBtn4176A415PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.CheckAvailability\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGroupName.add(lblGroupName, flxGroupNameValue, btnCheckAvailability);
            var flxSelectAccountBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxSelectAccountBottom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "85dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccountBottom.setDefaultUnit(kony.flex.DP);
            var flxTransactionType = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxTransactionType",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionType.setDefaultUnit(kony.flex.DP);
            var lblTransactiobType = new kony.ui.Label({
                "id": "lblTransactiobType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.TransactionType\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var MobileCustomDropdownTransaction = new com.InfinityOLB.Resources.MobileCustomDropdown({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "MobileCustomDropdownTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "MobileCustomDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "minWidth": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxApproveType": {
                        "isVisible": false
                    },
                    "flxButtons": {
                        "isVisible": false
                    },
                    "flxDropdown": {
                        "isVisible": false,
                        "left": "0dp",
                        "top": "80dp",
                        "width": "100%"
                    },
                    "flxImage": {
                        "clipBounds": false,
                        "left": "87%"
                    },
                    "flxIphoneDropdown": {
                        "clipBounds": false,
                        "left": "0dp",
                        "top": "40dp",
                        "width": "100%"
                    },
                    "flxStatus": {
                        "isVisible": false
                    },
                    "flxTimePeriod": {
                        "isVisible": false
                    },
                    "imgDropdown": {
                        "src": "listboxuparrow.png"
                    },
                    "lblView": {
                        "isVisible": false
                    },
                    "lblViewType": {
                        "text": "All Transaction"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxFiltersListBoxTransaction = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFiltersListBoxTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersListBoxTransaction.setDefaultUnit(kony.flex.DP);
            var lblPerTransaction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPerTransaction",
                "isVisible": true,
                "left": "3%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.perTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTransactionDropdown = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxTransactionDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "sknFlxHover",
                "width": "22dp",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDropdown.setDefaultUnit(kony.flex.DP);
            var lblTransactionDropdownArrow = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "More"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "10dp",
                "id": "lblTransactionDropdownArrow",
                "isVisible": true,
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionDropdown.add(lblTransactionDropdownArrow);
            flxFiltersListBoxTransaction.add(lblPerTransaction, flxTransactionDropdown);
            flxTransactionType.add(lblTransactiobType, MobileCustomDropdownTransaction, flxFiltersListBoxTransaction);
            var flxGroupDesc = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxGroupDesc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "35%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupDesc.setDefaultUnit(kony.flex.DP);
            var lblGroupDesc = new kony.ui.Label({
                "id": "lblGroupDesc",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupDescHeader\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxGrpDescValue = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxGrpDescValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGrpDescValue.setDefaultUnit(kony.flex.DP);
            var lblDollar = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDollar",
                "isVisible": false,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxGroupDescValue = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Username"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "84%",
                "id": "tbxGroupDescValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5dp",
                "right": "15%",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxGrpDescValue.add(lblDollar, tbxGroupDescValue);
            flxGroupDesc.add(lblGroupDesc, flxGrpDescValue);
            var flxDeny = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxDeny",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "56%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeny.setDefaultUnit(kony.flex.DP);
            var lblDenyAbove = new kony.ui.Label({
                "id": "lblDenyAbove",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.userMgmt.DenyIfAbove\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxDenyContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDenyContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "40dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDenyContainer.setDefaultUnit(kony.flex.DP);
            var lblDollar2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDollar2",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxDenyLimit = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Username"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "84%",
                "id": "tbxDenyLimit",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5dp",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "text": "600",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxDenyContainer.add(lblDollar2, tbxDenyLimit);
            flxDeny.add(lblDenyAbove, flxDenyContainer);
            var btnApply = new kony.ui.Button({
                "height": "40dp",
                "id": "btnApply",
                "isVisible": false,
                "right": "30dp",
                "skin": "sknBtnBlockedSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")",
                "top": "38dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Save And Update"
            });
            flxSelectAccountBottom.add(flxTransactionType, flxGroupDesc, flxDeny, btnApply);
            var flxAccntsSelceted = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccntsSelceted",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "68dp",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccntsSelceted.setDefaultUnit(kony.flex.DP);
            var lblAccountsSelected = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountsSelected",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.AccountsSelected\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAccountsSelected = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNoAccountsSelected",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "text": "125 of 230",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccntsSelceted.add(lblAccountsSelected, lblNoAccountsSelected);
            flxSelectAccounts.add(flxAccntHeader, imgArrow, flxAccountSelectSeperator, flxFeatureContainer, flxAction, flxGroupName, flxSelectAccountBottom, flxAccntsSelceted);
            var flxSearchSortSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSearchSortSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchSortSeparator.setDefaultUnit(kony.flex.DP);
            flxSearchSortSeparator.add();
            var flxConfirmAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmAck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmAck.setDefaultUnit(kony.flex.DP);
            var flxGroupNameVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxGroupNameVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameVerify.setDefaultUnit(kony.flex.DP);
            var flxGroupNameKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGroupNameKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameKey.setDefaultUnit(kony.flex.DP);
            var lblGroupNameKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bank Name"
                },
                "id": "lblGroupNameKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolonGroupName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblsemicolonGroupName",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGroupNameKey.add(lblGroupNameKey, lblsemicolonGroupName);
            var flxGroupNameVerifyValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGroupNameVerifyValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameVerifyValue.setDefaultUnit(kony.flex.DP);
            var lblGroupNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "American Express Credit Card"
                },
                "id": "lblGroupNameValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Senior Managers",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxGroupNameVerifyValue.add(lblGroupNameValue);
            flxGroupNameVerify.add(flxGroupNameKey, flxGroupNameVerifyValue);
            var flxTotalSelectedUsersVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTotalSelectedUsersVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSelectedUsersVerify.setDefaultUnit(kony.flex.DP);
            var flxTotalSeelectedUsersKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTotalSeelectedUsersKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersKey.setDefaultUnit(kony.flex.DP);
            var lblTotalSeelectedUsersKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Type"
                },
                "id": "lblTotalSeelectedUsersKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.totalSelectedUsers\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersKey.add(lblTotalSeelectedUsersKey);
            var flxTotalSeelectedUsersValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTotalSeelectedUsersValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersValue.setDefaultUnit(kony.flex.DP);
            var lblTotalSeelectedUsersVerifyKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Personal Savings"
                },
                "id": "lblTotalSeelectedUsersVerifyKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "21",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersValue.add(lblTotalSeelectedUsersVerifyKey);
            flxTotalSelectedUsersVerify.add(flxTotalSeelectedUsersKey, flxTotalSeelectedUsersValue);
            var flxCustomerNameVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCustomerNameVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerify.setDefaultUnit(kony.flex.DP);
            var flxCustomerNameVerifyKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerNameVerifyKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerifyKey.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameVerifyKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Number"
                },
                "id": "lblCustomerNameVerifyKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolon4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblsemicolon4",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerifyKey.add(lblCustomerNameVerifyKey, lblsemicolon4);
            var flxCustomerNameValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerNameValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameVerifyValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "773663272624427"
                },
                "id": "lblCustomerNameVerifyValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Temenos Ind",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.add(lblCustomerNameVerifyValue);
            flxCustomerNameVerify.add(flxCustomerNameVerifyKey, flxCustomerNameValue);
            var flxCustomerIdVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCustomerIdVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerIdVerify.setDefaultUnit(kony.flex.DP);
            var flxCustomerIdKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerIdKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerIdKey.setDefaultUnit(kony.flex.DP);
            var lblCustomerIdKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Recipient Name"
                },
                "id": "lblCustomerIdKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolonCustomerId = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblsemicolonCustomerId",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerIdKey.add(lblCustomerIdKey, lblsemicolonCustomerId);
            var flxCustomerIdValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerIdValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerIdValue.setDefaultUnit(kony.flex.DP);
            var lblCustomerIdVerifyValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "John Bailey"
                },
                "id": "lblCustomerIdVerifyValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "56987",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerIdValue.add(lblCustomerIdVerifyValue);
            flxCustomerIdVerify.add(flxCustomerIdKey, flxCustomerIdValue);
            var flxContractVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxContractVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractVerify.setDefaultUnit(kony.flex.DP);
            var flxContractKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContractKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractKey.setDefaultUnit(kony.flex.DP);
            var lblContractKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Nickname"
                },
                "id": "lblContractKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolon6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblsemicolon6",
                "isVisible": false,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContractKey.add(lblContractKey, lblsemicolon6);
            var flxContractValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContractValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractValue.setDefaultUnit(kony.flex.DP);
            var lblContractVerifyValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Johns BOA Account"
                },
                "id": "lblContractVerifyValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Temenos Corp",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxContractValue.add(lblContractVerifyValue);
            flxContractVerify.add(flxContractKey, flxContractValue);
            var flxDriversLicence = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDriversLicence",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriversLicence.setDefaultUnit(kony.flex.DP);
            var flxLicenceNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLicenceNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLicenceNumber.setDefaultUnit(kony.flex.DP);
            var lblLicenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Nickname"
                },
                "id": "lblLicenceNumber",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.DriversLicenseNumber\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblSemiColon9 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblSemiColon9",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLicenceNumber.add(lblLicenceNumber, lblSemiColon9);
            var flxDriverLicenceNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxDriverLicenceNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverLicenceNumber.setDefaultUnit(kony.flex.DP);
            var lblDriverLicenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Johns BOA Account"
                },
                "id": "lblDriverLicenceNumber",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "John's BOA Account",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxDriverLicenceNumber.add(lblDriverLicenceNumber);
            flxDriversLicence.add(flxLicenceNumber, flxDriverLicenceNumber);
            flxConfirmAck.add(flxGroupNameVerify, flxTotalSelectedUsersVerify, flxCustomerNameVerify, flxCustomerIdVerify, flxContractVerify, flxDriversLicence);
            var flxSearchSortSeparatorVerify = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSearchSortSeparatorVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchSortSeparatorVerify.setDefaultUnit(kony.flex.DP);
            flxSearchSortSeparatorVerify.add();
            var flxRowSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxRowSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRowSeperator.setDefaultUnit(kony.flex.DP);
            flxRowSeperator.add();
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var lblSelectAccntsHeader = new kony.ui.Label({
                "id": "lblSelectAccntsHeader",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.customRole.selectedUsers\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedUsers = new kony.ui.Label({
                "id": "lblSelectedUsers",
                "isVisible": false,
                "right": "50dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.totalSelected\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsersValue = new kony.ui.Label({
                "id": "lblUsersValue",
                "isVisible": false,
                "right": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "12",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUsersSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxUsersSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "45dp",
                "width": "97.50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersSeparator.setDefaultUnit(kony.flex.DP);
            flxUsersSeparator.add();
            var Search = new com.InfinityOLB.ApprovalMatrixMA.BillPay.Search({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "50dp",
                "id": "Search",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "75%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA",
                "overrides": {
                    "Search": {
                        "bottom": "viz.val_cleared",
                        "height": "50dp",
                        "left": "20dp",
                        "minWidth": "viz.val_cleared",
                        "top": "45dp",
                        "width": "100%",
                        "zIndex": 1
                    },
                    "btnConfirm": {
                        "centerX": "viz.val_cleared",
                        "left": "15px",
                        "top": "0dp",
                        "width": "25dp"
                    },
                    "btnConfirm1": {
                        "isVisible": false
                    },
                    "flxClearBtn": {
                        "isVisible": false,
                        "width": "40dp"
                    },
                    "flxtxtSearchandClearbtn": {
                        "centerY": "viz.val_cleared",
                        "clipBounds": false,
                        "height": "45dp",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "right": "2%",
                        "top": "20dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "imgCross": {
                        "src": "search_close.png"
                    },
                    "lblSearch": {
                        "height": "100%",
                        "width": "100%"
                    },
                    "txtSearch": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.approvals.searchPlaceHolder\")",
                        "left": "42px",
                        "right": "40px",
                        "width": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxViewOnlySeletced = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxViewOnlySeletced",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "51dp",
                "width": "220dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewOnlySeletced.setDefaultUnit(kony.flex.DP);
            var lblViewOnlySelected = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewOnlySelected",
                "isVisible": true,
                "left": "85dp",
                "right": "85dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.viewonlyselected\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View only selected"
            });
            var flxStatus = new kony.ui.FlexContainer({
                "bottom": "20dp",
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblLoan2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "height": "100%",
                "id": "lblLoan2",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknC0C0C020pxNotFontIconsMOD",
                "text": "L",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var toggleSwitch = new kony.ui.Switch({
                "height": "100%",
                "id": "toggleSwitch",
                "isVisible": true,
                "left": "0dp",
                "leftSideText": "ON",
                "rightSideText": "OFF",
                "selectedIndex": 0,
                "skin": "sknSwitchToggle",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatus.add(lblLoan2, toggleSwitch);
            flxViewOnlySeletced.add(lblViewOnlySelected, flxStatus);
            var flxAllUsers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAllUsers",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15dp",
                "skin": "slFbox",
                "top": 50,
                "width": "20%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAllUsers.setDefaultUnit(kony.flex.DP);
            var CopylblHeader0f7d0ec4d3d8c42 = new kony.ui.Label({
                "id": "CopylblHeader0f7d0ec4d3d8c42",
                "isVisible": false,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": "Select Actions",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAllUsersListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxAllUsersListBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20%",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAllUsersListBox.setDefaultUnit(kony.flex.DP);
            var CopyActionListBox0b6d43a10490642 = new kony.ui.ListBox({
                "focusSkin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "height": "100%",
                "id": "CopyActionListBox0b6d43a10490642",
                "isVisible": false,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Selected 5 of 8"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "selectedKey": "lb1",
                "skin": "sknlistbxffffffSSPReg15pxNB3e3e31px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxAllUsersList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAllUsersList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 70,
                "isModalContainer": false,
                "right": 2,
                "skin": "slfBoxffffffB1R5",
                "top": "40dp",
                "width": "100%",
                "zIndex": 200,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAllUsersList.setDefaultUnit(kony.flex.DP);
            var lblFilterByFeatures = new kony.ui.Label({
                "id": "lblFilterByFeatures",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "text": "Users By Role",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1000
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxFeaturesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxFeaturesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "CopyslFbox0e66b99d4b9eb42",
                "top": "10dp",
                "width": "90%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeaturesSeparator.setDefaultUnit(kony.flex.DP);
            flxFeaturesSeparator.add();
            var segAllUsersLIst = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblDefaultAccountIcon": "D",
                    "lblDefaultAccountName": "Label"
                }],
                "groupCells": false,
                "id": "segAllUsersLIst",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxRowDefaultAccounts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRowDefaultAccounts": "flxRowDefaultAccounts",
                    "lblDefaultAccountIcon": "lblDefaultAccountIcon",
                    "lblDefaultAccountName": "lblDefaultAccountName"
                },
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDownBtns = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "90px",
                "id": "flxDropDownBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDownBtns.setDefaultUnit(kony.flex.DP);
            var flxSeperatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0e66b99d4b9eb42",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeperatorBottom.add();
            var flxBtn = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85%",
                "id": "flxBtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "99%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtn.setDefaultUnit(kony.flex.DP);
            var btnApplyDropDown = new kony.ui.Button({
                "centerY": "50%",
                "height": "45dp",
                "id": "btnApplyDropDown",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknbtnEnabed003e7536px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")",
                "width": "110dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "ICSknbtnEnabed003e7536px",
                "toolTip": "Continue"
            });
            var btnCancelDropDown = new kony.ui.Button({
                "centerY": "50%",
                "height": "45dp",
                "id": "btnCancelDropDown",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "110dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxBtn.add(btnApplyDropDown, btnCancelDropDown);
            flxDropDownBtns.add(flxSeperatorBottom, flxBtn);
            flxAllUsersList.add(lblFilterByFeatures, flxFeaturesSeparator, segAllUsersLIst, flxDropDownBtns);
            var flxShowAllUsers = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxShowAllUsers",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "100%",
                "zIndex": 51,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxShowAllUsers.setDefaultUnit(kony.flex.DP);
            var lblAllUsers = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Show All Accounts"
                },
                "centerY": "50%",
                "id": "lblAllUsers",
                "isVisible": true,
                "right": "16%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.ViewAllUsers\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "Copyskn0e7cb98784ed448"
            });
            var flxAllUsersDropdown = new kony.ui.FlexContainer({
                "bottom": 0,
                "centerY": "55%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxAllUsersDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d3a44c95e0844f8b91e7d195da058b94,
                "right": "0dp",
                "skin": "slFbox",
                "width": "6%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxAllUsersDropdown.setDefaultUnit(kony.flex.DP);
            var imgAllUsersDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Favourite account dropdown"
                },
                "centerX": "50%",
                "centerY": "55%",
                "id": "imgAllUsersDropdown",
                "isVisible": true,
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAllUsersDropdown.add(imgAllUsersDropdown);
            flxShowAllUsers.add(lblAllUsers, flxAllUsersDropdown);
            flxAllUsersListBox.add(CopyActionListBox0b6d43a10490642, flxAllUsersList, flxShowAllUsers);
            flxAllUsers.add(CopylblHeader0f7d0ec4d3d8c42, flxAllUsersListBox);
            var flxSearchSortSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSearchSortSeparator1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchSortSeparator1.setDefaultUnit(kony.flex.DP);
            flxSearchSortSeparator1.add();
            flxSearch.add(lblSelectAccntsHeader, lblSelectedUsers, lblUsersValue, flxUsersSeparator, Search, flxViewOnlySeletced, flxAllUsers, flxSearchSortSeparator1);
            var flxSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxe3e3e31px",
                "top": "150dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegment.setDefaultUnit(kony.flex.DP);
            var flxCreateSignatoryValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCreateSignatoryValues",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateSignatoryValues.setDefaultUnit(kony.flex.DP);
            var flxTopSeparatorApprove = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeparatorApprove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparatorApprove.setDefaultUnit(kony.flex.DP);
            var imgFlexSeparatorApprove = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgFlexSeparatorApprove",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopSeparatorApprove.add(imgFlexSeparatorApprove);
            var flxUserName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxUserName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "20%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserName.setDefaultUnit(kony.flex.DP);
            var btnUserName = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnUserName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"Kony.mb.userdetail.Username\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUserName = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgUserName",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserName.add(btnUserName, imgUserName);
            var flxUserRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxUserRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserRole.setDefaultUnit(kony.flex.DP);
            var btnUserRole = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnUserRole",
                "isVisible": true,
                "left": "0%",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"Kony.mb.userdetail.UserRole\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUserRole = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "sentDate Sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgUserRole",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserRole.add(btnUserRole, imgUserRole);
            var flxSentByApprovePending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxSentByApprovePending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "45%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "17%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSentByApprovePending.setDefaultUnit(kony.flex.DP);
            var btnSentByApprovePending = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnSentByApprovePending",
                "isVisible": true,
                "left": "0%",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "text": "Sent By",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSentByApprovePending = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "sentBy sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgSentByApprovePending",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSentByApprovePending.add(btnSentByApprovePending, imgSentByApprovePending);
            var flxRequestTypeApprovePending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRequestTypeApprovePending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "65%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "18%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestTypeApprovePending.setDefaultUnit(kony.flex.DP);
            var btnRequestTypeApprovePending = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnRequestTypeApprovePending",
                "isVisible": true,
                "left": "0%",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.RequestType\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRequestTypeApprovePending = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "requestType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRequestTypeApprovePending",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequestTypeApprovePending.add(btnRequestTypeApprovePending, imgRequestTypeApprovePending);
            var flxSelectAll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSelectAll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAll.setDefaultUnit(kony.flex.DP);
            var lblSelectAll = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectAll",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.selectAll\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblDropdown0fe2ee09157f246 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Checkbox"
                },
                "centerY": "50%",
                "height": "22dp",
                "id": "CopylblDropdown0fe2ee09157f246",
                "isVisible": true,
                "right": "28dp",
                "skin": "sknlblDelete20px",
                "text": "z",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectAll.add(lblSelectAll, CopylblDropdown0fe2ee09157f246);
            var flxBootomSeparatorApprovePending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBootomSeparatorApprovePending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBootomSeparatorApprovePending.setDefaultUnit(kony.flex.DP);
            var imgApprovePending = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgApprovePending",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBootomSeparatorApprovePending.add(imgApprovePending);
            flxCreateSignatoryValues.add(flxTopSeparatorApprove, flxUserName, flxUserRole, flxSentByApprovePending, flxRequestTypeApprovePending, flxSelectAll, flxBootomSeparatorApprovePending);
            var segmentFileTransactions = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }, {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "imagedrag.png",
                    "CopyimgSample0h544e7378d6e46": "imagedrag.png",
                    "blNoofCreditsVal": "",
                    "btnTrActions": "Actions",
                    "imgDropDown": "O",
                    "imgFlxBottomSeparator": "imagedrag.png",
                    "imgFlxTopSeparator": "imagedrag.png",
                    "imgInfoIcon": "info_large.png",
                    "lblACFFileRequestType": "Request Type",
                    "lblACFFileRequestTypeVal": "",
                    "lblACHDebitCredit": "Debi/Credit Acount",
                    "lblACHDebitCreditVal": "",
                    "lblACHFileAmount": "Amount",
                    "lblACHFileAmountVal": "",
                    "lblACHFileApprovals": "",
                    "lblACHFileApprovalsVal": "",
                    "lblACHFileCreditAmount": "TotalCreditAmount",
                    "lblACHFileCreditAmountVal": "",
                    "lblACHFileFileName": "FileName",
                    "lblACHFileFileNameVal": "",
                    "lblACHFileNumberofDebits": "",
                    "lblACHRequestType": "Request Type",
                    "lblACHRequestTypeVal": "",
                    "lblACHTemplateName": "Template Name",
                    "lblACHTemplateNameVal": "",
                    "lblACHapprovals": "Approvals",
                    "lblACHapprovalsVal": "",
                    "lblAchAmount": "Amount",
                    "lblAchAmountVal": "",
                    "lblAchCustomerName": "Customer Name",
                    "lblAchCustomerNameVal": "",
                    "lblApproveDate": "Approve",
                    "lblBulkReference": "",
                    "lblBulkReferenceVal": "",
                    "lblBulkStatus": "",
                    "lblBulkStatusVal": "",
                    "lblCheckCreatedBY": "Created By",
                    "lblCheckCreatedBYVal": "",
                    "lblCustomerName": "",
                    "lblCustomerNameCheckBook": "Cusomte Name",
                    "lblCustomerNameVal": "",
                    "lblCustomerNameValCheck": "",
                    "lblDropdownValue": "D",
                    "lblExecutionDate": "",
                    "lblExecutionDateVal": "",
                    "lblFeesService": "Fees inclusive of serive",
                    "lblFeesServiceVal": "",
                    "lblFileName": "",
                    "lblFileNameVal": "",
                    "lblFontIconAChFile": "r",
                    "lblFontIconAch": "r",
                    "lblFontIconCheckRequest": "r",
                    "lblFromIcon": "r",
                    "lblNACHumberOfDebits": "Number of Debits",
                    "lblNoRecords": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                    "lblNoofBooks": "Number of Books",
                    "lblNoofBooksVal": "",
                    "lblNoofCredits": "Number of Credits",
                    "lblOPDecription": "",
                    "lblOPDecriptionVal": "",
                    "lblOPFromAccount": "",
                    "lblOPFromAccountValue": "",
                    "lblOPPaymentID": "",
                    "lblOPPaymentIDValue": "",
                    "lblOPTotalAmount": "",
                    "lblOPTotalAmountValue": "",
                    "lblOPTotalTransactions": "",
                    "lblOPTotalTransactionsValue": "",
                    "lblOpStatus": "Status",
                    "lblProcessingMode": "",
                    "lblProcessingModeVal": "",
                    "lblRequestAccount": "Request Account",
                    "lblRequestAccountval": "",
                    "lblRequestId": "Request ID",
                    "lblRequestIdVal": "",
                    "lblRequestType": "",
                    "lblRequestTypeVal": "",
                    "lblStatus": "Status",
                    "lblTotalDebitAmount": "Total Debit Amount",
                    "lblTotalDebitAmountVal": "",
                    "lblTrStatus": "View Deatails",
                    "lblTransactionAmount": "Amount",
                    "lblTransactionAmountVal": "",
                    "lblTransactionApprovals": "Approvals",
                    "lblTransactionApprovalsVal": "",
                    "lblTransactionCustomerName": "CustomerName",
                    "lblTransactionCustomerNameVal": "",
                    "lblTransactionFrequency": "Frequency",
                    "lblTransactionFrequencyVal": "",
                    "lblTransactionIcon": "r",
                    "lblTransactionPayee": "Payee",
                    "lblTransactionPayeeVal": "",
                    "lblTransactionRecurrence": "Recurrence",
                    "lblTransactionRecurrenceVal": "",
                    "lblTransactionReference": "Refereence",
                    "lblTransactionReferenceVal": "",
                    "lblTransactionTransactionID": "Transaction Id",
                    "lblTransactionTransactionIDVal": "",
                    "lblTransactionTypeDebit": "Debit Acccount",
                    "lblTransactionTypeDebitVal": "",
                    "lblUploadDateTime": "Uploaded Date & Time",
                    "lblUploadDateTimeVal": "",
                    "lblUserNameValue": "Benjamin Patterson",
                    "lblUserRoleValue": "Admin"
                }],
                "groupCells": false,
                "id": "segmentFileTransactions",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Normal",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxCreateSignatoryVerifyRowTemplate"
                }),
                "sectionHeaderSkin": "seg2Normal",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "CopyimgFlxTopSeparator0d4f93c4ad23743": "CopyimgFlxTopSeparator0d4f93c4ad23743",
                    "CopyimgSample0h544e7378d6e46": "CopyimgSample0h544e7378d6e46",
                    "blNoofCreditsVal": "blNoofCreditsVal",
                    "btnTrActions": "btnTrActions",
                    "flxACHFile": "flxACHFile",
                    "flxACHFileContent": "flxACHFileContent",
                    "flxACHFileIcon": "flxACHFileIcon",
                    "flxACHPaymentsMain": "flxACHPaymentsMain",
                    "flxAChPayments": "flxAChPayments",
                    "flxAchIcon": "flxAchIcon",
                    "flxBPOngoingPaymentsDetails": "flxBPOngoingPaymentsDetails",
                    "flxBottomSeperator": "flxBottomSeperator",
                    "flxBulkPaymentsDetails": "flxBulkPaymentsDetails",
                    "flxCheck": "flxCheck",
                    "flxCheckBookRequest": "flxCheckBookRequest",
                    "flxCheckRequestIcon": "flxCheckRequestIcon",
                    "flxCreateSignatoryRowValues": "flxCreateSignatoryRowValues",
                    "flxCreateSignatoryVerifyRowTemplate": "flxCreateSignatoryVerifyRowTemplate",
                    "flxDetilsHighlighterMain": "flxDetilsHighlighterMain",
                    "flxDropDown": "flxDropDown",
                    "flxHeader": "flxHeader",
                    "flxIcon": "flxIcon",
                    "flxMain": "flxMain",
                    "flxNoRecords": "flxNoRecords",
                    "flxSelectAllValues": "flxSelectAllValues",
                    "flxTemplateDetails": "flxTemplateDetails",
                    "flxTopSeparatorHeader": "flxTopSeparatorHeader",
                    "flxTopSeperator": "flxTopSeperator",
                    "flxTransactionIcon": "flxTransactionIcon",
                    "flxTransactionTypeValue": "flxTransactionTypeValue",
                    "flxTransactionTypes": "flxTransactionTypes",
                    "flxTransactionTypesMain": "flxTransactionTypesMain",
                    "imgDropDown": "imgDropDown",
                    "imgFlxBottomSeparator": "imgFlxBottomSeparator",
                    "imgFlxTopSeparator": "imgFlxTopSeparator",
                    "imgInfoIcon": "imgInfoIcon",
                    "lblACFFileRequestType": "lblACFFileRequestType",
                    "lblACFFileRequestTypeVal": "lblACFFileRequestTypeVal",
                    "lblACHDebitCredit": "lblACHDebitCredit",
                    "lblACHDebitCreditVal": "lblACHDebitCreditVal",
                    "lblACHFileAmount": "lblACHFileAmount",
                    "lblACHFileAmountVal": "lblACHFileAmountVal",
                    "lblACHFileApprovals": "lblACHFileApprovals",
                    "lblACHFileApprovalsVal": "lblACHFileApprovalsVal",
                    "lblACHFileCreditAmount": "lblACHFileCreditAmount",
                    "lblACHFileCreditAmountVal": "lblACHFileCreditAmountVal",
                    "lblACHFileFileName": "lblACHFileFileName",
                    "lblACHFileFileNameVal": "lblACHFileFileNameVal",
                    "lblACHFileNumberofDebits": "lblACHFileNumberofDebits",
                    "lblACHRequestType": "lblACHRequestType",
                    "lblACHRequestTypeVal": "lblACHRequestTypeVal",
                    "lblACHTemplateName": "lblACHTemplateName",
                    "lblACHTemplateNameVal": "lblACHTemplateNameVal",
                    "lblACHapprovals": "lblACHapprovals",
                    "lblACHapprovalsVal": "lblACHapprovalsVal",
                    "lblAchAmount": "lblAchAmount",
                    "lblAchAmountVal": "lblAchAmountVal",
                    "lblAchCustomerName": "lblAchCustomerName",
                    "lblAchCustomerNameVal": "lblAchCustomerNameVal",
                    "lblApproveDate": "lblApproveDate",
                    "lblBulkReference": "lblBulkReference",
                    "lblBulkReferenceVal": "lblBulkReferenceVal",
                    "lblBulkStatus": "lblBulkStatus",
                    "lblBulkStatusVal": "lblBulkStatusVal",
                    "lblCheckCreatedBY": "lblCheckCreatedBY",
                    "lblCheckCreatedBYVal": "lblCheckCreatedBYVal",
                    "lblCustomerName": "lblCustomerName",
                    "lblCustomerNameCheckBook": "lblCustomerNameCheckBook",
                    "lblCustomerNameVal": "lblCustomerNameVal",
                    "lblCustomerNameValCheck": "lblCustomerNameValCheck",
                    "lblDropdownValue": "lblDropdownValue",
                    "lblExecutionDate": "lblExecutionDate",
                    "lblExecutionDateVal": "lblExecutionDateVal",
                    "lblFeesService": "lblFeesService",
                    "lblFeesServiceVal": "lblFeesServiceVal",
                    "lblFileName": "lblFileName",
                    "lblFileNameVal": "lblFileNameVal",
                    "lblFontIconAChFile": "lblFontIconAChFile",
                    "lblFontIconAch": "lblFontIconAch",
                    "lblFontIconCheckRequest": "lblFontIconCheckRequest",
                    "lblFromIcon": "lblFromIcon",
                    "lblNACHumberOfDebits": "lblNACHumberOfDebits",
                    "lblNoRecords": "lblNoRecords",
                    "lblNoofBooks": "lblNoofBooks",
                    "lblNoofBooksVal": "lblNoofBooksVal",
                    "lblNoofCredits": "lblNoofCredits",
                    "lblOPDecription": "lblOPDecription",
                    "lblOPDecriptionVal": "lblOPDecriptionVal",
                    "lblOPFromAccount": "lblOPFromAccount",
                    "lblOPFromAccountValue": "lblOPFromAccountValue",
                    "lblOPPaymentID": "lblOPPaymentID",
                    "lblOPPaymentIDValue": "lblOPPaymentIDValue",
                    "lblOPTotalAmount": "lblOPTotalAmount",
                    "lblOPTotalAmountValue": "lblOPTotalAmountValue",
                    "lblOPTotalTransactions": "lblOPTotalTransactions",
                    "lblOPTotalTransactionsValue": "lblOPTotalTransactionsValue",
                    "lblOpStatus": "lblOpStatus",
                    "lblProcessingMode": "lblProcessingMode",
                    "lblProcessingModeVal": "lblProcessingModeVal",
                    "lblRequestAccount": "lblRequestAccount",
                    "lblRequestAccountval": "lblRequestAccountval",
                    "lblRequestId": "lblRequestId",
                    "lblRequestIdVal": "lblRequestIdVal",
                    "lblRequestType": "lblRequestType",
                    "lblRequestTypeVal": "lblRequestTypeVal",
                    "lblStatus": "lblStatus",
                    "lblTotalDebitAmount": "lblTotalDebitAmount",
                    "lblTotalDebitAmountVal": "lblTotalDebitAmountVal",
                    "lblTrStatus": "lblTrStatus",
                    "lblTransactionAmount": "lblTransactionAmount",
                    "lblTransactionAmountVal": "lblTransactionAmountVal",
                    "lblTransactionApprovals": "lblTransactionApprovals",
                    "lblTransactionApprovalsVal": "lblTransactionApprovalsVal",
                    "lblTransactionCustomerName": "lblTransactionCustomerName",
                    "lblTransactionCustomerNameVal": "lblTransactionCustomerNameVal",
                    "lblTransactionFrequency": "lblTransactionFrequency",
                    "lblTransactionFrequencyVal": "lblTransactionFrequencyVal",
                    "lblTransactionIcon": "lblTransactionIcon",
                    "lblTransactionPayee": "lblTransactionPayee",
                    "lblTransactionPayeeVal": "lblTransactionPayeeVal",
                    "lblTransactionRecurrence": "lblTransactionRecurrence",
                    "lblTransactionRecurrenceVal": "lblTransactionRecurrenceVal",
                    "lblTransactionReference": "lblTransactionReference",
                    "lblTransactionReferenceVal": "lblTransactionReferenceVal",
                    "lblTransactionTransactionID": "lblTransactionTransactionID",
                    "lblTransactionTransactionIDVal": "lblTransactionTransactionIDVal",
                    "lblTransactionTypeDebit": "lblTransactionTypeDebit",
                    "lblTransactionTypeDebitVal": "lblTransactionTypeDebitVal",
                    "lblUploadDateTime": "lblUploadDateTime",
                    "lblUploadDateTimeVal": "lblUploadDateTimeVal",
                    "lblUserNameValue": "lblUserNameValue",
                    "lblUserRoleValue": "lblUserRoleValue"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoRecords.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "height": "40dp",
                "id": "imgInfoIcon",
                "isVisible": false,
                "left": "30dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "35dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoRecords = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNoRecords",
                "isVisible": true,
                "skin": "bbsknLbl94949415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.NoRecordsareavailable\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoRecords.add(imgInfoIcon, lblNoRecords);
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPagination",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var flxPaginationLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "24dp",
                "id": "flxPaginationLast",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "width": "24dp",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationLast.setDefaultUnit(kony.flex.DP);
            var imgPaginationLast = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.nextPage\")"
                },
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationLast",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "slImage",
                "src": "pagination_last_active.png",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Last"
            });
            flxPaginationLast.add(imgPaginationLast);
            var flxPaginationNext = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationNext",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationNext.setDefaultUnit(kony.flex.DP);
            var imgPaginationNext = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.nextPage\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationNext",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_next_active.png",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Next"
            });
            flxPaginationNext.add(imgPaginationNext);
            var lblPagination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "1-20 Transactions"
                },
                "centerY": "50%",
                "id": "lblPagination",
                "isVisible": true,
                "left": "3%",
                "right": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "10-20 Records",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaginationPrevious = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationPrevious",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationPrevious.setDefaultUnit(kony.flex.DP);
            var imgPaginationPrevious = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.previousPage\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationPrevious",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_back_inactive.png",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Previous"
            });
            flxPaginationPrevious.add(imgPaginationPrevious);
            var flxPaginationFirst = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "24dp",
                "id": "flxPaginationFirst",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "24dp",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationFirst.setDefaultUnit(kony.flex.DP);
            var imgPaginationFirst = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.previousPage\")"
                },
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationFirst",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": 0,
                "right": "0dp",
                "skin": "slImage",
                "src": "pagination_inactive.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "First"
            });
            flxPaginationFirst.add(imgPaginationFirst);
            flxPagination.add(flxPaginationLast, flxPaginationNext, lblPagination, flxPaginationPrevious, flxPaginationFirst);
            var flxSearchRoleButton = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "90px",
                "id": "flxSearchRoleButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchRoleButton.setDefaultUnit(kony.flex.DP);
            var flxSeperatorBtm2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBtm2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0e66b99d4b9eb42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBtm2.setDefaultUnit(kony.flex.DP);
            flxSeperatorBtm2.add();
            var flxSelectRoleControl = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectRoleControl",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectRoleControl.setDefaultUnit(kony.flex.DP);
            var btnConfirmAndCreate = new kony.ui.Button({
                "centerY": "50%",
                "height": "45dp",
                "id": "btnConfirmAndCreate",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknbtnEnabed003e7536px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.confirmAndCreate\")",
                "width": "180dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "ICSknbtnEnabed003e7536px",
                "toolTip": "Continue"
            });
            var btnModify = new kony.ui.Button({
                "centerY": "50%",
                "height": "45dp",
                "id": "btnModify",
                "isVisible": true,
                "left": "2%",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Modify\")",
                "width": "180dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            var btnCancelVerify = new kony.ui.Button({
                "centerY": "50%",
                "height": "45dp",
                "id": "btnCancelVerify",
                "isVisible": true,
                "left": "2%",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "180dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxSelectRoleControl.add(btnConfirmAndCreate, btnModify, btnCancelVerify);
            flxSearchRoleButton.add(flxSeperatorBtm2, flxSelectRoleControl);
            flxSegment.add(flxCreateSignatoryValues, segmentFileTransactions, flxNoRecords, flxPagination, flxSearchRoleButton);
            flxBottom.add(flxSearch, flxSegment);
            var NoTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "NoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            NoTransactions.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.noTransactions\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transfer Money"
                },
                "id": "lblScheduleAPayment",
                "isVisible": false,
                "left": "12.60%",
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")",
                "top": "107dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "MAKE TRANSFER"
            });
            NoTransactions.add(imgInfo, rtxNoPaymentMessage, lblScheduleAPayment);
            var tablePagination = new com.InfinityOLB.ApprovalMatrixMA.tablePagination({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "60dp",
                "id": "tablePagination",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA",
                "overrides": {
                    "tablePagination": {
                        "isVisible": false,
                        "left": "0%",
                        "top": "10dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSelectPermissionsBulk.add(flxEditRecipientsHeader, flxSeparatorHeader, flxSelectAccounts, flxSearchSortSeparator, flxConfirmAck, flxSearchSortSeparatorVerify, flxRowSeperator, flxBottom, NoTransactions, tablePagination);
            flxSelectPermissions.add(flxCustomer, flxSelectPermissionsBulk);
            flxContent.add(flxSelectPermissions);
            flxContentContainer.add(flxContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxFooterMenu": {
                        "left": "0%",
                        "minWidth": "viz.val_cleared"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "0dp",
                        "minHeight": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer, flxFooter);
            var InfoIconPopup = new com.InfinityOLB.BillPay.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "InfoIconPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0.00%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "150dp",
                "width": "270dp",
                "zIndex": 10,
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "0.00%",
                        "top": "150dp",
                        "width": "270dp",
                        "zIndex": 10
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.availableBalance\")",
                        "isVisible": false
                    },
                    "flxAccountType": {
                        "isVisible": true,
                        "top": "-2dp"
                    },
                    "flxCross": {
                        "centerY": "31.54%",
                        "right": "5.55%"
                    },
                    "flxInformation": {
                        "clipBounds": false,
                        "height": "135dp",
                        "left": "1dp",
                        "top": "0dp"
                    },
                    "flxInformationText": {
                        "left": "0dp"
                    },
                    "imgCross": {
                        "src": "icon_close_grey.png"
                    },
                    "imgToolTip": {
                        "left": "125px",
                        "src": "tool_tip.png"
                    },
                    "lblInfo": {
                        "centerY": "viz.val_cleared",
                        "text": "Account Access defines whether the user will have access to <br> view accounts and create transactions for these accounts",
                        "width": "70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox4",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox4",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading_2.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey_2.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Terms and condition Checkbox"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "CopysknBtnffffffBorder4",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSave = new kony.ui.Button({
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var PopupHeaderUM = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomFeedbackPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "260px",
                "id": "PopupHeaderUM",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "width": "60%",
                "zIndex": 10010,
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomFeedbackPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "top": "viz.val_cleared",
                        "width": "60%",
                        "zIndex": 10010
                    },
                    "btnNo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                        "zIndex": 10020
                    },
                    "btnYes": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                        "zIndex": 10020
                    },
                    "imgCross": {
                        "src": "icon_close_grey.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "zIndex": 10020
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userMgmt.CancelUserCreation\")",
                        "width": "90%",
                        "zIndex": 10020
                    },
                    "lblPopupmsg": {
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            PopupHeaderUM.btnNo.onClick = controller.AS_Button_bb074dc470d84e12a83292042a476199;
            PopupHeaderUM.btnYes.onClick = controller.AS_Button_i761471aeb114a01af98624ed289e598;
            PopupHeaderUM.flxCross.onClick = controller.AS_FlexContainer_dd91c4ccd394418fbe2ba488bc692ee1;
            flxCancelPopup.add(PopupHeaderUM);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "height": "268dp",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "height": "268dp",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "Cheque Management",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomer": {
                        "segmentProps": []
                    },
                    "flxEditRecipientsHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFilterListBoxFeatures": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxButtons": {
                        "segmentProps": []
                    },
                    "flxListBox": {
                        "centerY": {
                            "type": "string",
                            "value": "50px"
                        },
                        "right": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxActionListBox": {
                        "centerY": {
                            "type": "string",
                            "value": "50px"
                        },
                        "right": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "CopylblDollar0cc0645c227ea49": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.flxButtons": {
                        "segmentProps": []
                    },
                    "flxFiltersListBoxTransaction": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblPerTransaction": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDropdown": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxGrpDescValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblDollar": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxDenyContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblDollar2": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "btnApply": {
                        "segmentProps": []
                    },
                    "flxConfirmAck": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxGroupNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblGroupNameValue": {
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalSeelectedUsersVerifyKey": {
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyKey": {
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyValue": {
                        "segmentProps": []
                    },
                    "flxCustomerIdVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIdKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonCustomerId": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerIdValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIdVerifyValue": {
                        "segmentProps": []
                    },
                    "flxContractVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxContractKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblsemicolon6": {
                        "segmentProps": []
                    },
                    "flxContractValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblContractVerifyValue": {
                        "segmentProps": []
                    },
                    "flxDriversLicence": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxLicenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSemiColon9": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDriverLicenceNumber": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblDriverLicenceNumber": {
                        "segmentProps": []
                    },
                    "flxAllUsersListBox": {
                        "centerY": {
                            "type": "string",
                            "value": "50px"
                        },
                        "right": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxDropDownBtns": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "btnApplyDropDown": {
                        "segmentProps": []
                    },
                    "btnCancelDropDown": {
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator1": {
                        "segmentProps": []
                    },
                    "flxSegment": {
                        "segmentProps": []
                    },
                    "flxSearchRoleButton": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "btnConfirmAndCreate": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelVerify": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "InfoIconPopup": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.imgCross": {
                        "src": "bbcloseicon_1.png",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1024dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1024dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50.61%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblEmail": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCustomer": {
                        "segmentProps": []
                    },
                    "flxEditRecipientsHeader": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnViewNEdit": {
                        "left": {
                            "type": "string",
                            "value": "84%"
                        },
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxSeparatorHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCompany": {
                        "segmentProps": []
                    },
                    "lblCompanyName": {
                        "segmentProps": []
                    },
                    "imgArrow": {
                        "left": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxFeatures": {
                        "segmentProps": []
                    },
                    "flxListBox": {
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "ListBox1": {
                        "isVisible": false,
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "CopycompanyListAllFeatures": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer1": {
                        "right": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "segmentProps": []
                    },
                    "lblShowAllFeatures": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown1": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeader1": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxActionListBox": {
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "ActionListBox": {
                        "segmentProps": []
                    },
                    "companyListAllFeatures2": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer2": {
                        "right": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "segmentProps": []
                    },
                    "lblShowAllFeatures2": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown2": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnCheckAvailability": {
                        "segmentProps": []
                    },
                    "flxSelectAccountBottom": {
                        "segmentProps": []
                    },
                    "flxFiltersListBoxTransaction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDeny": {
                        "segmentProps": []
                    },
                    "btnApply": {
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmAck": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblGroupNameKey": {
                        "i18n_text": "i18n.approvals.groupName",
                        "text": "Group Name",
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxGroupNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "bottom": {
                            "type": "number",
                            "value": "15"
                        },
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalSeelectedUsersKey": {
                        "i18n_text": "i18n.approvals.totalSelectedUsers",
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyKey": {
                        "i18n_text": "kony.i18n.approvalMatrix.customerName",
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIdVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIdKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIdKey": {
                        "i18n_text": "kony.18n.approvalMatrix.lblCustomerID",
                        "segmentProps": []
                    },
                    "lblsemicolonCustomerId": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerIdValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxContractVerify": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxContractKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblContractKey": {
                        "i18n_text": "kony.i18n.approvalMatrix.contract",
                        "segmentProps": []
                    },
                    "lblsemicolon6": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContractValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxDriversLicence": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLicenceNumber": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblSemiColon9": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDriverLicenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparatorVerify": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxUsersSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "Search": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "Search.btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "Search.flxtxtSearchandClearbtn": {
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "View only selected",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "segmentProps": []
                    },
                    "lblLoan2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flxAllUsers": {
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "CopylblHeader0f7d0ec4d3d8c42": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxAllUsersListBox": {
                        "segmentProps": []
                    },
                    "CopyActionListBox0b6d43a10490642": {
                        "segmentProps": []
                    },
                    "flxAllUsersList": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDropDownBtns": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "75px"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBottom": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBtn": {
                        "height": {
                            "type": "string",
                            "value": "60%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "btnApplyDropDown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "9%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelDropDown": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "flxShowAllUsers": {
                        "right": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "segmentProps": []
                    },
                    "lblAllUsers": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "i18n_text": "i18n.approvals.ViewAllUsers",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "View : All Users",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxAllUsersDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator1": {
                        "segmentProps": []
                    },
                    "flxSegment": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeparatorApprove": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUserName": {
                        "i18n_text": "Kony.mb.userdetail.Username",
                        "segmentProps": []
                    },
                    "btnUserRole": {
                        "i18n_text": "Kony.mb.userdetail.UserRole",
                        "segmentProps": []
                    },
                    "flxBootomSeparatorApprovePending": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSearchRoleButton": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBtm2": {
                        "isVisible": false,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnConfirmAndCreate": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnCancelVerify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.imgCross": {
                        "src": "bbcloseicon_1.png",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxskncontainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblEmail": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomer": {
                        "segmentProps": []
                    },
                    "btnViewNEdit": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxSeparatorHeader": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccounts": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "zIndex": 7,
                        "segmentProps": []
                    },
                    "lblSelectAccounts": {
                        "segmentProps": []
                    },
                    "imgArrow": {
                        "left": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSelectSeperator": {
                        "segmentProps": []
                    },
                    "flxFeatureContainer": {
                        "segmentProps": []
                    },
                    "lblSelectFeature": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxFeatures": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxIphoneDropdown": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxTimePeriod": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.lblView": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.lblViewType": {
                        "text": "All Features",
                        "segmentProps": []
                    },
                    "flxListBox": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CopycompanyListAllFeatures": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "segAccountListActions1": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxffffff2pxe3e3e3border",
                        "zIndex": 51,
                        "segmentProps": []
                    },
                    "lblShowAllFeatures": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDropDown1": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgDropdown1": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "segmentProps": []
                    },
                    "flxActionListBox": {
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "companyListAllFeatures2": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "segAccountListActions2": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblShowAllFeatures2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDropDown2": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgDropdown2": {
                        "skin": "bbSknLblFontIcon",
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxGroupName": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblGroupName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameValue": {
                        "segmentProps": []
                    },
                    "CopylblDollar0cc0645c227ea49": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "tbxGroupNameValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnCheckAvailability": {
                        "segmentProps": []
                    },
                    "flxSelectAccountBottom": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTransactionType": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblTransactiobType": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.flxTimePeriod": {
                        "segmentProps": []
                    },
                    "flxFiltersListBoxTransaction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPerTransaction": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Per Transaction",
                        "segmentProps": []
                    },
                    "flxTransactionDropdown": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblTransactionDropdownArrow": {
                        "segmentProps": []
                    },
                    "flxGroupDesc": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblGroupDesc": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxGrpDescValue": {
                        "segmentProps": []
                    },
                    "lblDollar": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "tbxGroupDescValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDeny": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblDenyAbove": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDenyContainer": {
                        "segmentProps": []
                    },
                    "lblDollar2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "tbxDenyLimit": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnApply": {
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmAck": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerIdVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIdKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonCustomerId": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxContractVerify": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxContractKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblsemicolon6": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDriversLicence": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLicenceNumber": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblSemiColon9": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparatorVerify": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxUsersSeparator": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "Search": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "Search.flxtxtSearchandClearbtn": {
                        "segmentProps": []
                    },
                    "Search.txtSearch": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "View only selected",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "segmentProps": []
                    },
                    "CopylblHeader0f7d0ec4d3d8c42": {
                        "segmentProps": []
                    },
                    "flxAllUsersListBox": {
                        "segmentProps": []
                    },
                    "flxAllUsersList": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "lblFilterByFeatures": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "segAllUsersLIst": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDropDownBtns": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBottom": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnApplyDropDown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxShowAllUsers": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblAllUsers": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAllUsersDropdown": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgAllUsersDropdown": {
                        "skin": "bbSknLblFontIcon",
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator1": {
                        "segmentProps": []
                    },
                    "flxSearchRoleButton": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBtm2": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnConfirmAndCreate": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnCancelVerify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "NoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "tablePagination.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "122dp"
                        },
                        "segmentProps": []
                    },
                    "tablePagination": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": []
                    },
                    "InfoIconPopup": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblEmail": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxSelectPermissions": {
                        "segmentProps": []
                    },
                    "lblRecipientsHeader": {
                        "segmentProps": []
                    },
                    "btnViewNEdit": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxSelectAccounts": {
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblCompany": {
                        "segmentProps": []
                    },
                    "lblCompanyName": {
                        "segmentProps": []
                    },
                    "imgArrow": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "97%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxFeatures": {
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdown": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxImage": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.flxIphoneDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.imgDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.lblView": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.lblViewType": {
                        "text": "All Features",
                        "segmentProps": []
                    },
                    "MobileCustomDropdown.segViewTypes": {
                        "segmentProps": []
                    },
                    "flxListBox": {
                        "isVisible": true,
                        "skin": "sknFlxffffff2pxe3e3e3border",
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "ListBox1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CopycompanyListAllFeatures": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "lblShowAllFeatures": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDropDown1": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgDropdown1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeader1": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flxActionListBox": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "ActionListBox": {
                        "segmentProps": []
                    },
                    "companyListAllFeatures2": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountsRightContainer2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblShowAllFeatures2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDropDown2": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgDropdown2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "CopylblDollar0cc0645c227ea49": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "tbxGroupNameValue": {
                        "segmentProps": []
                    },
                    "btnCheckAvailability": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.flxDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.flxImage": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.flxIphoneDropdown": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.imgDropdown": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.lblView": {
                        "segmentProps": []
                    },
                    "MobileCustomDropdownTransaction.lblViewType": {
                        "segmentProps": []
                    },
                    "flxFiltersListBoxTransaction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblDollar": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "tbxGroupDescValue": {
                        "segmentProps": []
                    },
                    "flxDeny": {
                        "segmentProps": []
                    },
                    "flxDenyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblDollar2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "tbxDenyLimit": {
                        "segmentProps": []
                    },
                    "btnApply": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmAck": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblGroupNameKey": {
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxGroupNameVerifyValue": {
                        "segmentProps": []
                    },
                    "lblGroupNameValue": {
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalSeelectedUsersKey": {
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersValue": {
                        "segmentProps": []
                    },
                    "lblTotalSeelectedUsersVerifyKey": {
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyKey": {
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyValue": {
                        "segmentProps": []
                    },
                    "flxCustomerIdVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerIdKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIdKey": {
                        "segmentProps": []
                    },
                    "lblsemicolonCustomerId": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerIdValue": {
                        "segmentProps": []
                    },
                    "lblCustomerIdVerifyValue": {
                        "segmentProps": []
                    },
                    "flxContractVerify": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxContractKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblContractKey": {
                        "segmentProps": []
                    },
                    "lblsemicolon6": {
                        "segmentProps": []
                    },
                    "flxContractValue": {
                        "segmentProps": []
                    },
                    "lblContractVerifyValue": {
                        "segmentProps": []
                    },
                    "flxDriversLicence": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLicenceNumber": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblLicenceNumber": {
                        "text": "Driver's Licence Number",
                        "segmentProps": []
                    },
                    "lblSemiColon9": {
                        "segmentProps": []
                    },
                    "flxDriverLicenceNumber": {
                        "segmentProps": []
                    },
                    "lblDriverLicenceNumber": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblSelectAccntsHeader": {
                        "segmentProps": []
                    },
                    "Search": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "Search.flxtxtSearchandClearbtn": {
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "View only selected",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "segmentProps": []
                    },
                    "lblLoan2": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "segmentProps": []
                    },
                    "CopylblHeader0f7d0ec4d3d8c42": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flxAllUsersListBox": {
                        "isVisible": true,
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "CopyActionListBox0b6d43a10490642": {
                        "segmentProps": []
                    },
                    "flxAllUsersList": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDropDownBtns": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBottom": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnApplyDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.00%"
                        },
                        "segmentProps": []
                    },
                    "flxShowAllUsers": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblAllUsers": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxAllUsersDropdown": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgAllUsersDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator1": {
                        "segmentProps": []
                    },
                    "flxSearchRoleButton": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBtm2": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnConfirmAndCreate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.00%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "btnCancelVerify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.00%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "tablePagination.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "122dp"
                        },
                        "segmentProps": []
                    },
                    "InfoIconPopup.flxInformation": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTCContentsCheckbox": {
                        "segmentProps": []
                    },
                    "lblTCContentsCheckBox": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblHeading": {
                        "text": "",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupMessage": {
                        "text": "",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": "121px",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "customheadernew.flxLogoAndActionsWrapper": {
                    "minWidth": "",
                    "width": "1366dp"
                },
                "customheadernew.flxMenuLeft": {
                    "left": "83dp",
                    "top": "0dp"
                },
                "customheadernew.flxMenuWrapper": {
                    "minWidth": "",
                    "width": "1366dp"
                },
                "customheadernew.imgKony": {
                    "left": "83dp",
                    "src": "kony_logo.png",
                    "top": "15dp"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customheadernew.lblHeaderMobile": {
                    "centerX": "50%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "MobileCustomDropdown": {
                    "left": "0dp",
                    "minWidth": "",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 1
                },
                "MobileCustomDropdown.flxDropdown": {
                    "left": "0%",
                    "top": "80dp",
                    "width": "100%",
                    "zIndex": 10
                },
                "MobileCustomDropdown.flxImage": {
                    "left": "87%"
                },
                "MobileCustomDropdown.flxIphoneDropdown": {
                    "left": "0%",
                    "top": "40dp",
                    "width": "100%"
                },
                "MobileCustomDropdown.imgDropdown": {
                    "src": "listboxuparrow.png"
                },
                "MobileCustomDropdown.lblViewType": {
                    "text": "All Transactions"
                },
                "MobileCustomDropdown.segViewTypes": {
                    "zIndex": 5
                },
                "MobileCustomDropdownTransaction": {
                    "minWidth": "",
                    "top": "0dp",
                    "width": "100%"
                },
                "MobileCustomDropdownTransaction.flxDropdown": {
                    "left": "0dp",
                    "top": "80dp",
                    "width": "100%"
                },
                "MobileCustomDropdownTransaction.flxImage": {
                    "left": "87%"
                },
                "MobileCustomDropdownTransaction.flxIphoneDropdown": {
                    "left": "0dp",
                    "top": "40dp",
                    "width": "100%"
                },
                "MobileCustomDropdownTransaction.imgDropdown": {
                    "src": "listboxuparrow.png"
                },
                "MobileCustomDropdownTransaction.lblViewType": {
                    "text": "All Transaction"
                },
                "Search": {
                    "bottom": "",
                    "height": "50dp",
                    "left": "20dp",
                    "minWidth": "",
                    "top": "45dp",
                    "width": "100%",
                    "zIndex": 1
                },
                "Search.btnConfirm": {
                    "centerX": "",
                    "left": "15px",
                    "top": "0dp",
                    "width": "25dp"
                },
                "Search.flxClearBtn": {
                    "width": "40dp"
                },
                "Search.flxtxtSearchandClearbtn": {
                    "centerY": "",
                    "height": "45dp",
                    "left": "0dp",
                    "maxHeight": "",
                    "right": "2%",
                    "top": "20dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "Search.imgCross": {
                    "src": "search_close.png"
                },
                "Search.lblSearch": {
                    "height": "100%",
                    "width": "100%"
                },
                "Search.txtSearch": {
                    "left": "42px",
                    "right": "40px",
                    "width": ""
                },
                "tablePagination": {
                    "left": "0%",
                    "top": "10dp",
                    "width": "100%"
                },
                "customfooternew": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "customfooternew.flxFooterMenu": {
                    "left": "0%",
                    "minWidth": ""
                },
                "customfooternew.lblCopyright": {
                    "centerX": "",
                    "left": "0dp",
                    "minHeight": ""
                },
                "InfoIconPopup": {
                    "left": "0.00%",
                    "top": "150dp",
                    "width": "270dp",
                    "zIndex": 10
                },
                "InfoIconPopup.flxAccountType": {
                    "top": "-2dp"
                },
                "InfoIconPopup.flxCross": {
                    "centerY": "31.54%",
                    "right": "5.55%"
                },
                "InfoIconPopup.flxInformation": {
                    "height": "135dp",
                    "left": "1dp",
                    "top": "0dp"
                },
                "InfoIconPopup.flxInformationText": {
                    "left": "0dp"
                },
                "InfoIconPopup.imgCross": {
                    "src": "icon_close_grey.png"
                },
                "InfoIconPopup.imgToolTip": {
                    "left": "125px",
                    "src": "tool_tip.png"
                },
                "InfoIconPopup.lblInfo": {
                    "centerY": "",
                    "text": "Account Access defines whether the user will have access to <br> view accounts and create transactions for these accounts",
                    "width": "70%"
                },
                "PopupHeaderUM": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "top": "",
                    "width": "60%",
                    "zIndex": 10010
                },
                "PopupHeaderUM.btnNo": {
                    "zIndex": 10020
                },
                "PopupHeaderUM.btnYes": {
                    "zIndex": 10020
                },
                "PopupHeaderUM.imgCross": {
                    "src": "icon_close_grey.png"
                },
                "PopupHeaderUM.lblHeading": {
                    "zIndex": 10020
                },
                "PopupHeaderUM.lblPopupMessage": {
                    "width": "90%",
                    "zIndex": 10020
                },
                "PopupHeaderUM.lblPopupmsg": {
                    "width": "90%"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "height": "268dp",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp"
                }
            }
            this.add(flxHeader, flxMain, InfoIconPopup, flxLoading, flxTermsAndConditions, flxCancelPopup, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateSignatoryGroupVerifyAndConfirm,
            "enabledForIdleTimeout": true,
            "id": "frmCreateSignatoryGroupVerifyAndConfirm",
            "init": controller.AS_Form_i9afce1097074ced845849f448d75a78,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_dde5dc8f34b04ef39a0b46b7c858c8b0,
            "postShow": controller.AS_Form_ge1faa989f944549b9b5a32dce16c528,
            "preShow": function(eventobject) {
                controller.AS_Form_g16288b87368420a8d5529b4a4381fe7(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_f435288726704eafa9ad721b03f68f85,
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});