define("SavingsPotMA/SavingsPotUIModule/frmEditGoal", function() {
    return function(controller) {
        function addWidgetsfrmEditGoal() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxMenuWrapper": {
                        "width": "1366dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "87.84%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabel42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.editGoal\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentHeader.add(lblContentHeader);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxCreateSavingsGoals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxCreateSavingsGoals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.84%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateSavingsGoals.setDefaultUnit(kony.flex.DP);
            var flxGoalsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGoalsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalsContent.setDefaultUnit(kony.flex.DP);
            var lblWarningNameExists = new kony.ui.Label({
                "id": "lblWarningNameExists",
                "isVisible": false,
                "left": "0%",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.warningGoalNameExists\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxGoalDets = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGoalDets",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalDets.setDefaultUnit(kony.flex.DP);
            var flxGoalType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65dp",
                "id": "flxGoalType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalType.setDefaultUnit(kony.flex.DP);
            var lblGoalType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblGoalType",
                "isVisible": true,
                "left": 0,
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalType\")",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstGoalType = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstGoalType",
                "isVisible": true,
                "left": "0%",
                "right": "15dp",
                "skin": "sknLbxSSP42424215PxBorder727272",
                "top": "5dp",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxGoalType.add(lblGoalType, lstGoalType);
            var flxGoalName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65dp",
                "id": "flxGoalName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalName.setDefaultUnit(kony.flex.DP);
            var flxGoalNameAndCnt = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGoalNameAndCnt",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalNameAndCnt.setDefaultUnit(kony.flex.DP);
            var lblGoalName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblGoalName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNameCharCount = new kony.ui.Label({
                "height": "18px",
                "id": "lblNameCharCount",
                "isVisible": true,
                "left": "78%",
                "right": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": "15/30",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoalNameAndCnt.add(lblGoalName, lblNameCharCount);
            var tbxGoalName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxGoalName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": 0,
                "maxTextLength": 30,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.savingsPot.typeYourGoalName\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP0withborder",
                "text": "Tesla Electric Car",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxGoalName.add(flxGoalNameAndCnt, tbxGoalName);
            flxGoalDets.add(flxGoalType, flxGoalName);
            var flxOptimizeGoals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOptimizeGoals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBBFlexBGf9f9f9",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptimizeGoals.setDefaultUnit(kony.flex.DP);
            var flxOptGoalsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOptGoalsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "96%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptGoalsHeader.setDefaultUnit(kony.flex.DP);
            var lblOptimizeGoalsHeader = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOptimizeGoalsHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl424242SSP17pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.optimizeGoal\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknBBFlexBGf9f9f9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var lblAlertsWarningImageNew = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "height": "30dp",
                "id": "lblAlertsWarningImageNew",
                "isVisible": true,
                "left": "1dp",
                "skin": "sknlbl4a90e221OLBFontIconsPx",
                "text": "K",
                "top": "2dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Please activate the Wire Transfer service to send or receive money."
                },
                "id": "lblWarning",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.thankYouGoalAccInfo\")",
                "top": "0",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(lblAlertsWarningImageNew, lblWarning);
            flxOptGoalsHeader.add(lblOptimizeGoalsHeader, flxWarning);
            var flxGoalAmounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxGoalAmounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "96%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalAmounts.setDefaultUnit(kony.flex.DP);
            var flxAmountSliders = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmountSliders",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountSliders.setDefaultUnit(kony.flex.DP);
            var flxGoalAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65dp",
                "id": "flxGoalAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalAmount.setDefaultUnit(kony.flex.DP);
            var lblGoalAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblGoalAmount",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalAmount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "5dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountValue.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrency",
                "isVisible": true,
                "left": "13dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "$",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxGoalAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "id": "tbxGoalAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 16,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.lblAmount\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": 20,
                "width": "80%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxAmountValue.add(lblCurrency, tbxGoalAmount);
            flxGoalAmount.add(lblGoalAmount, flxAmountValue);
            var flxSlider = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSlider",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSlider.setDefaultUnit(kony.flex.DP);
            var flxMonthlyAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMonthlyAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMonthlyAmount.setDefaultUnit(kony.flex.DP);
            var lblMonthlyAmountKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblMonthlyAmountKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.monthlyDebitAmount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMonthlyAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblMonthlyAmount",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbla0a0a015px",
                "text": "4500",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMonthlyAmount.add(lblMonthlyAmountKey, lblMonthlyAmount);
            var slider = new com.InfinityOLB.SavingsPotMA.slider({
                "centerX": "50%",
                "height": "60dp",
                "id": "slider",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "99%",
                "appName": "SavingsPotMA",
                "overrides": {
                    "flxHolder": {
                        "width": "95%"
                    },
                    "flxMainKA": {
                        "left": "0dp"
                    },
                    "flxValuesHolder": {
                        "left": "viz.val_cleared",
                        "top": "15dp",
                        "width": "100%"
                    },
                    "slider": {
                        "centerX": "50%",
                        "height": "60dp",
                        "left": "viz.val_cleared",
                        "width": "99%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxMonthDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMonthDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMonthDetails.setDefaultUnit(kony.flex.DP);
            var lblMonthKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblMonthKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.periodOfMonths\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMonthValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblMonthValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbla0a0a015px",
                "text": "45",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMonthDetails.add(lblMonthKey, lblMonthValue);
            var slider1 = new com.InfinityOLB.SavingsPotMA.slider({
                "centerX": "50%",
                "height": "60dp",
                "id": "slider1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "99%",
                "appName": "SavingsPotMA",
                "overrides": {
                    "flxHolder": {
                        "width": "95%"
                    },
                    "flxMainKA": {
                        "left": "0dp"
                    },
                    "flxValuesHolder": {
                        "left": "viz.val_cleared",
                        "top": "15dp",
                        "width": "100%"
                    },
                    "slider": {
                        "centerX": "50%",
                        "height": "60dp",
                        "left": "viz.val_cleared",
                        "width": "99%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSlider.add(flxMonthlyAmount, slider, flxMonthDetails, slider1);
            flxAmountSliders.add(flxGoalAmount, flxSlider);
            var flxAmountResult = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmountResult",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountResult.setDefaultUnit(kony.flex.DP);
            var flxAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "94%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var flxGoalAmounttext = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGoalAmounttext",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalAmounttext.setDefaultUnit(kony.flex.DP);
            var lblTitleGoalAmt = new kony.ui.Label({
                "id": "lblTitleGoalAmt",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalAmount\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGoalAmtResult = new kony.ui.Label({
                "bottom": "45dp",
                "id": "lblGoalAmtResult",
                "isVisible": true,
                "left": 0,
                "skin": "sknSSPBold42424220Px",
                "text": "$90,000",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoalAmounttext.add(lblTitleGoalAmt, lblGoalAmtResult);
            var flxVSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxVSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "minHeight": "90dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVSeperator1.setDefaultUnit(kony.flex.DP);
            flxVSeperator1.add();
            var flxCurrentBalance = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCurrentBalance",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrentBalance.setDefaultUnit(kony.flex.DP);
            var lblCurrentBalance = new kony.ui.Label({
                "id": "lblCurrentBalance",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.currentBalance\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentAmount = new kony.ui.Label({
                "bottom": "45dp",
                "id": "lblCurrentAmount",
                "isVisible": true,
                "left": 0,
                "skin": "sknSSPBold42424220Px",
                "text": "$90,000",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrentBalance.add(lblCurrentBalance, lblCurrentAmount);
            flxAmount.add(flxGoalAmounttext, flxVSeperator1, flxCurrentBalance);
            var flxHSeperator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHSeperator.setDefaultUnit(kony.flex.DP);
            flxHSeperator.add();
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "94%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var flxRemaining = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRemaining",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRemaining.setDefaultUnit(kony.flex.DP);
            var lblRemaining = new kony.ui.Label({
                "id": "lblRemaining",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.remainingSavings\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRemainingAmount = new kony.ui.Label({
                "bottom": "45dp",
                "id": "lblRemainingAmount",
                "isVisible": true,
                "left": 0,
                "skin": "sknSSPBold42424220Px",
                "text": "$90,000",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRemaining.add(lblRemaining, lblRemainingAmount);
            var flxVSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxVSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "minHeight": "90dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVSeperator.setDefaultUnit(kony.flex.DP);
            flxVSeperator.add();
            var flxDateToAchieve = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDateToAchieve",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-1dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateToAchieve.setDefaultUnit(kony.flex.DP);
            var lblTitleDate = new kony.ui.Label({
                "id": "lblTitleDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.dateToAchieve\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDateToAchieve = new kony.ui.Label({
                "bottom": "45dp",
                "id": "lblDateToAchieve",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPBold42424220Px",
                "text": "20 May 2025",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDateToAchieve.add(lblTitleDate, lblDateToAchieve);
            flxDate.add(flxRemaining, flxVSeperator, flxDateToAchieve);
            flxAmountResult.add(flxAmount, flxHSeperator, flxDate);
            flxGoalAmounts.add(flxAmountSliders, flxAmountResult);
            flxOptimizeGoals.add(flxOptGoalsHeader, flxGoalAmounts);
            var flxFrequency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFrequency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "minHeight": "120dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency.setDefaultUnit(kony.flex.DP);
            var flxSelectFreq = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSelectFreq",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectFreq.setDefaultUnit(kony.flex.DP);
            var lblTitleFreq = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "id": "lblTitleFreq",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayPerson.frequency\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxR1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxR1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxR1.setDefaultUnit(kony.flex.DP);
            var flxRadioBtn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxRadioBtn1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxRadioBtn1.setDefaultUnit(kony.flex.DP);
            var imgRadioBtn12 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgRadioBtn12",
                "isVisible": true,
                "skin": "sknFontIconDisabled",
                "text": "M",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRadioBtn1.add(imgRadioBtn12);
            var lblMonthly = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Single/Multiple Checks"
                },
                "centerY": "51.11%",
                "height": "20px",
                "id": "lblMonthly",
                "isVisible": true,
                "left": "10px",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Monthly",
                "width": "90px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRadioBtn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxRadioBtn2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxRadioBtn2.setDefaultUnit(kony.flex.DP);
            var imgRadioBtn21 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgRadioBtn21",
                "isVisible": true,
                "skin": "sknFontIconDisabled",
                "text": "L",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRadioBtn2.add(imgRadioBtn21);
            var lblBiweekly = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Series of Checks"
                },
                "centerY": "50%",
                "height": "20px",
                "id": "lblBiweekly",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Bi-Weekly",
                "width": "111px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxR1.add(flxRadioBtn1, lblMonthly, flxRadioBtn2, lblBiweekly);
            var tbxFreqAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxFreqAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": 0,
                "secureTextEntry": false,
                "skin": "sknTbxBdre3e3e3Bckgrndf6f6f6op100",
                "text": "$1000.00",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSelectFreq.add(lblTitleFreq, flxR1, tbxFreqAmount);
            var flxFreqDay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFreqDay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "minHeight": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFreqDay.setDefaultUnit(kony.flex.DP);
            var flxFreqDayDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxFreqDayDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFreqDayDetails.setDefaultUnit(kony.flex.DP);
            var lblFreqDay = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Loan Payoff Amount"
                },
                "height": "18px",
                "id": "lblFreqDay",
                "isVisible": true,
                "left": 0,
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.frequencyDay\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWhatisFreqDay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxWhatisFreqDay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "100dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWhatisFreqDay.setDefaultUnit(kony.flex.DP);
            var imgWhatisFreqDay = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgWhatisFreqDay",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWhatisFreqDay.add(imgWhatisFreqDay);
            var lblInfoFreqDay = new kony.ui.Label({
                "centerX": "64%",
                "id": "lblInfoFreqDay",
                "isVisible": true,
                "left": "55.70%",
                "right": "1%",
                "skin": "bbSknLbl424242SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFreqDayDetails.add(lblFreqDay, flxWhatisFreqDay, lblInfoFreqDay);
            var CalenderPayOffDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": ["4", "7", "2017"],
                "dateFormat": "MM/dd/yyyy",
                "day": 4,
                "focusSkin": "sknCalNormal",
                "formattedDate": "07/04/2017",
                "height": "40dp",
                "hour": 18,
                "id": "CalenderPayOffDate",
                "isVisible": false,
                "left": "0%",
                "minutes": 3,
                "month": 7,
                "seconds": 45,
                "skin": "sknCalNormal",
                "top": "43dp",
                "viewConfig": {
                    "gridConfig": {
                        "allowWeekendSelectable": true,
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2017,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 3, 0, 3],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var lstDates = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "39dp",
                "id": "lstDates",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLstDisable424242",
                "top": "43dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var AllForms = new com.InfinityOLB.WireTransfer.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-5dp",
                "width": "270dp",
                "zIndex": 20,
                "appName": "WireTransferMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "20%",
                        "top": "250dp",
                        "width": "270dp",
                        "zIndex": 20
                    },
                    "RichTextInfo": {
                        "text": "This number will be considered as your preferred communication number. "
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "left": "51%",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFreqDay.add(flxFreqDayDetails, CalenderPayOffDate, lstDates, AllForms);
            flxFrequency.add(flxSelectFreq, flxFreqDay);
            var flxHorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorSeperator.setDefaultUnit(kony.flex.DP);
            flxHorSeperator.add();
            var flxSubmitBtnWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSubmitBtnWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmitBtnWrapper.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Yes"
                },
                "centerX": "92%",
                "centerY": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.Update\")",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Continue"
            });
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "No"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP4A90E215Px",
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "17%",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Back"
            });
            flxSubmitBtnWrapper.add(btnContinue, btnBack);
            flxGoalsContent.add(lblWarningNameExists, flxGoalDets, flxOptimizeGoals, flxFrequency, flxHorSeperator, flxSubmitBtnWrapper);
            flxCreateSavingsGoals.add(flxGoalsContent);
            flxContent.add(flxCreateSavingsGoals);
            flxMain.add(flxContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblCopyright": {
                        "left": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "250dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "250dp",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "flxCross": {
                        "height": "30dp",
                        "right": "16dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "centerX": "52%",
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            flxDialogs.add(flxPopup, flxLoading, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "minHeight": {
                            "type": "string",
                            "value": "1400dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxContent": {
                        "minHeight": {
                            "type": "string",
                            "value": "1400dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateSavingsGoals": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "1300dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalsContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "1290dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarningNameExists": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoalDets": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoalType": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lstGoalType": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalName": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalNameAndCnt": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxOptimizeGoals": {
                        "segmentProps": []
                    },
                    "flxOptGoalsHeader": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarningImageNew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalAmounts": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAmountSliders": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalAmount": {
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSlider": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMonthlyAmount": {
                        "segmentProps": []
                    },
                    "lblMonthlyAmount": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "slider.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "slider.flxValuesHolder": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "slider": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "slider"
                    },
                    "flxMonthDetails": {
                        "segmentProps": []
                    },
                    "lblMonthValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "slider1.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxValuesHolder": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "slider1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "slider1"
                    },
                    "flxAmountResult": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalAmounttext": {
                        "segmentProps": []
                    },
                    "lblGoalAmtResult": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVSeperator1": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCurrentBalance": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrentBalance": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrentAmount": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxHSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRemaining": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRemaining": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblRemainingAmount": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDateToAchieve": {
                        "segmentProps": []
                    },
                    "lblTitleDate": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblDateToAchieve": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectFreq": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRadioBtn2": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxFreqDay": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFreqDayDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblFreqDay": {
                        "segmentProps": []
                    },
                    "flxWhatisFreqDay": {
                        "segmentProps": []
                    },
                    "lblInfoFreqDay": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "CalenderPayOffDate": {
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "lstDates": {
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-8dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms.RichTextInfo": {
                        "text": "Set a start date in which you want to start a transfer. This date will be taken for every month.\n",
                        "segmentProps": []
                    },
                    "flxHorSeperator": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMain": {
                        "minHeight": {
                            "type": "string",
                            "value": "995dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateSavingsGoals": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "825dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxGoalsContent": {
                        "minHeight": {
                            "type": "string",
                            "value": "805dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalName": {
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "tbxGoalName": {
                        "segmentProps": []
                    },
                    "flxOptGoalsHeader": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarningImageNew": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalAmount": {
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSlider": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblMonthlyAmountKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblMonthlyAmount": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "slider.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "lblMonthKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblMonthValue": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblTitleGoalAmt": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalAmtResult": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxVSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCurrentBalance": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrentBalance": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrentAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxHSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDate": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxRemaining": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRemaining": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblRemainingAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxVSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDateToAchieve": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblTitleDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblDateToAchieve": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "tbxFreqAmount": {
                        "padding": [3, 0, 0, 0],
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": []
                    },
                    "flxFreqDayDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblFreqDay": {
                        "segmentProps": []
                    },
                    "flxWhatisFreqDay": {
                        "segmentProps": []
                    },
                    "lblInfoFreqDay": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lstDates": {
                        "top": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms.RichTextInfo": {
                        "text": "Set a start date in which you want to start a transfer. This date will be taken for every month.",
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxGoalNameAndCnt": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "tbxGoalName": {
                        "segmentProps": []
                    },
                    "flxOptGoalsHeader": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarningImageNew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxGoalAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSlider": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMonthlyAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "slider.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "slider.flxMainKA": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxMonthDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxMainKA": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxRemaining": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRemainingAmount": {
                        "segmentProps": []
                    },
                    "flxDateToAchieve": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "tbxFreqAmount": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "flxFreqDayDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblFreqDay": {
                        "segmentProps": []
                    },
                    "flxWhatisFreqDay": {
                        "segmentProps": []
                    },
                    "lblInfoFreqDay": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms.RichTextInfo": {
                        "text": "Set a start date in which you want to start a transfer. This date will be taken for every month.",
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCreateSavingsGoals": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoalNameAndCnt": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxGoalName": {
                        "segmentProps": []
                    },
                    "flxOptGoalsHeader": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarningImageNew": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxGoalAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSlider": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMonthlyAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "slider.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "slider.flxMainKA": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxMonthDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxHolder": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "slider1.flxMainKA": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxCurrentBalance": {
                        "segmentProps": []
                    },
                    "flxRemaining": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRemainingAmount": {
                        "segmentProps": []
                    },
                    "flxDateToAchieve": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "tbxFreqAmount": {
                        "segmentProps": []
                    },
                    "flxFreqDayDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxWhatisFreqDay": {
                        "segmentProps": []
                    },
                    "lblInfoFreqDay": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lstDates": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-8dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms.RichTextInfo": {
                        "text": "Set a start date in which you want to start a transfer. This date will be taken for every month.",
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "centerX": "",
                    "width": "100%"
                },
                "customheadernew.flxMenuWrapper": {
                    "width": "1366dp"
                },
                "slider.flxHolder": {
                    "width": "95%"
                },
                "slider.flxMainKA": {
                    "left": "0dp"
                },
                "slider.flxValuesHolder": {
                    "left": "",
                    "top": "15dp",
                    "width": "100%"
                },
                "slider": {
                    "centerX": "50%",
                    "height": "60dp",
                    "left": "",
                    "width": "99%"
                },
                "slider1.flxHolder": {
                    "width": "95%"
                },
                "slider1.flxMainKA": {
                    "left": "0dp"
                },
                "slider1.flxValuesHolder": {
                    "left": "",
                    "top": "15dp",
                    "width": "100%"
                },
                "slider1": {
                    "centerX": "50%",
                    "height": "60dp",
                    "left": "",
                    "width": "99%"
                },
                "AllForms": {
                    "left": "20%",
                    "top": "250dp",
                    "width": "270dp",
                    "zIndex": 20
                },
                "AllForms.RichTextInfo": {
                    "text": "This number will be considered as your preferred communication number. "
                },
                "AllForms.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AllForms.imgToolTip": {
                    "left": "51%",
                    "src": "tool_tip.png"
                },
                "customfooter.lblCopyright": {
                    "left": ""
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "250dp",
                    "width": "43%"
                },
                "CustomPopup.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "CustomPopup.btnYes": {
                    "right": "4.89%"
                },
                "CustomPopup.flxCross": {
                    "height": "30dp",
                    "right": "16dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopup.imgCross": {
                    "centerX": "52%",
                    "height": "15dp"
                },
                "CustomPopup.lblPopupMessage": {
                    "width": "80%"
                },
                "CustomPopupLogout": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopupLogout.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmEditGoal,
            "enabledForIdleTimeout": true,
            "id": "frmEditGoal",
            "init": controller.AS_Form_ib16de36d7474cc2b18b648a16716144,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "SavingsPotMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});