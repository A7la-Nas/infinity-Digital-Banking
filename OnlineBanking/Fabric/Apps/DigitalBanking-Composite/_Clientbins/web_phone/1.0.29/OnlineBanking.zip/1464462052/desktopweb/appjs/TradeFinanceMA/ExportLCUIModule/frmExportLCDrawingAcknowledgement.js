define("TradeFinanceMA/ExportLCUIModule/frmExportLCDrawingAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmExportLCDrawingAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "121dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003e75Bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKonyHamburger": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "99.94%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "155dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblExportLCAck = new kony.ui.Label({
                "id": "lblExportLCAck",
                "isVisible": true,
                "left": "82dp",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Export LC - Drawing - Acknowledgement",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSubHeader.add(lblExportLCAck);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAck.setDefaultUnit(kony.flex.DP);
            var flxExportSuccess = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "90dp",
                "id": "flxExportSuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExportSuccess.setDefaultUnit(kony.flex.DP);
            var imgSuccessIcon = new kony.ui.Image2({
                "bottom": "20dp",
                "height": "50dp",
                "id": "imgSuccessIcon",
                "isVisible": true,
                "left": "20dp",
                "src": "success_icon.png",
                "top": "20dp",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExportSuccess = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExportSuccess",
                "isVisible": true,
                "left": "91dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ExportLCSuccessMessage\")",
                "top": "43dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseBtn = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "29dp",
                "id": "flxCloseBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "61%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "29dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseBtn.setDefaultUnit(kony.flex.DP);
            var imgbtnClose = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgbtnClose",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseBtn.add(imgbtnClose);
            flxExportSuccess.add(imgSuccessIcon, lblExportSuccess, flxCloseBtn);
            flxAck.add(flxExportSuccess);
            flxMain.add(flxAck);
            var flxDrawingSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "201dp",
                "id": "flxDrawingSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummary.setDefaultUnit(kony.flex.DP);
            var flxDrawingSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDrawingSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxDrawingSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDrawingSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblDrawingSummary = new kony.ui.Label({
                "id": "lblDrawingSummary",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingSummarylbl.add(lblDrawingSummary);
            var flxBottomSeparatorDrawing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparatorDrawing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparatorDrawing.setDefaultUnit(kony.flex.DP);
            flxBottomSeparatorDrawing.add();
            var flxDrawingDetailsDropdown1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "36dp",
                "id": "flxDrawingDetailsDropdown1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "96.02%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "45dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown1.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown1 = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDrawingDetailsDropdown1",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown1.add(imgDrawingDetailsDropdown1);
            flxDrawingSummaryHeader.add(flxDrawingSummarylbl, flxBottomSeparatorDrawing, flxDrawingDetailsDropdown1);
            var flxBodyContentSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "67dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary.setDefaultUnit(kony.flex.DP);
            var lblDrawingStatus = new kony.ui.Label({
                "id": "lblDrawingStatus",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingStatus\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingStatusValue = new kony.ui.Label({
                "id": "lblDrawingStatusValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary.add(lblDrawingStatus, lblDrawingStatusValue);
            var flxBodyContentSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "105dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary2.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefNo = new kony.ui.Label({
                "id": "lblDrawingRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingRefNo\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefNoValue = new kony.ui.Label({
                "id": "lblDrawingRefNoValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary2.add(lblDrawingRefNo, lblDrawingRefNoValue);
            var flxBodyContentSummary3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "140dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary3.setDefaultUnit(kony.flex.DP);
            var lblDrawingDate = new kony.ui.Label({
                "id": "lblDrawingDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingCreatedDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingDateValue = new kony.ui.Label({
                "id": "lblDrawingDateValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary3.add(lblDrawingDate, lblDrawingDateValue);
            flxDrawingSummary.add(flxDrawingSummaryHeader, flxBodyContentSummary, flxBodyContentSummary2, flxBodyContentSummary3);
            var flxDiscrepanciesandResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesandResponse",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponse.setDefaultUnit(kony.flex.DP);
            var flxDiscrepanciesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDiscrepanciesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxDiscrepanciesandResponseLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDiscrepanciesandResponseLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesandResponseValue = new kony.ui.Label({
                "id": "lblDiscrepanciesandResponseValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DiscrepanciesandResponse\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.add(lblDiscrepanciesandResponseValue);
            var flxBottomSeparater02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparater02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparater02.setDefaultUnit(kony.flex.DP);
            flxBottomSeparater02.add();
            var flxDiscrepancyDropdown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "31dp",
                "id": "flxDiscrepancyDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95.96%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyDropdown.setDefaultUnit(kony.flex.DP);
            var imgDiscrepancyDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDiscrepancyDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyDropdown.add(imgDiscrepancyDropdown);
            flxDiscrepanciesHeader.add(flxTopSeperator, flxDiscrepanciesandResponseLabel, flxBottomSeparater02, flxDiscrepancyDropdown);
            var flxDiscrepanciesMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesMain.setDefaultUnit(kony.flex.DP);
            var flxTotalDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocuments.setDefaultUnit(kony.flex.DP);
            var lblTotalDocuments = new kony.ui.Label({
                "id": "lblTotalDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TotalDocuments\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxtotoalDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxtotoalDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalDocumentsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalDocumentsValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.add(lblTotalDocumentsValue);
            flxTotalDocumentsValue.add(flxtotoalDocumentsValueContainer);
            flxTotalDocuments.add(lblTotalDocuments, flxTotalDocumentsValue);
            var flxDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocuments.setDefaultUnit(kony.flex.DP);
            var lblDocuments = new kony.ui.Label({
                "id": "lblDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Documents\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var segDocumentsValueContainer = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblHeading": "Clearance Statement.pdf"
                }, {
                    "lblHeading": "Invoices.pdf"
                }, {
                    "lblHeading": "Statement1.pdf"
                }, {
                    "lblHeading": "Statement2.pdf"
                }],
                "groupCells": false,
                "id": "segDocumentsValueContainer",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSectionHeaderTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSectionHeaderTemplate": "flxSectionHeaderTemplate",
                    "lblHeading": "lblHeading"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.add(segDocumentsValueContainer);
            flxDocumentsValue.add(flxDocumentsValueContainer);
            flxDocuments.add(lblDocuments, flxDocumentsValue);
            var flxDocStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatus.setDefaultUnit(kony.flex.DP);
            var lblDocStatus = new kony.ui.Label({
                "id": "lblDocStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DocumentStatus\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValue.setDefaultUnit(kony.flex.DP);
            var flxDocStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblDocStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblDocStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Discrepant",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.add(lblDocStatusValue);
            flxDocStatusValue.add(flxDocStatusValueContainer);
            flxDocStatus.add(lblDocStatus, flxDocStatusValue);
            var flxDiscrepancyResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancyResponse",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.setDefaultUnit(kony.flex.DP);
            var segDiscrepancyResponse = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReasonforReturn\")",
                    "lblRight1": "Check the Packing list and Shipping Advise and clear this",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Discrepancy1\")",
                    "lblRight1": "Packing list not signed",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D1UserResponse\")",
                    "lblRight1": "I Accept this discrepancy, I will submit a revised document",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Discrepancy2\")",
                    "lblRight1": "Shipping Advise stamp is missing",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D2UserResponse\")",
                    "lblRight1": "I Accept this discrepancy, Please proceed with the existing document",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D2UserComment\")",
                    "lblRight1": "Shipping has started",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReturnMessagetoBank\")",
                    "lblRight1": "Kindly forward this with revised packing list",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }],
                "groupCells": false,
                "id": "segDiscrepancyResponse",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingDetailsExport"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                    "flxRight1": "flxRight1",
                    "lblLeft1": "lblLeft1",
                    "lblRight1": "lblRight1",
                    "lblRight2": "lblRight2",
                    "lblRight3": "lblRight3",
                    "lblRight4": "lblRight4"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.add(segDiscrepancyResponse);
            flxDiscrepanciesMain.add(flxTotalDocuments, flxDocuments, flxDocStatus, flxDiscrepancyResponse);
            flxDiscrepanciesandResponse.add(flxDiscrepanciesHeader, flxDiscrepanciesMain);
            var flxAcknowledgementBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgementBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox1",
                "top": "30dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementBody.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "99.99%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxDrawingDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "99.42%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingDetails = new kony.ui.Label({
                "height": "33dp",
                "id": "lblDrawingDetails",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.RevisedDrawingDetails\")",
                "top": "0dp",
                "width": "190dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingDetailsDropdown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "31dp",
                "id": "flxDrawingDetailsDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95.30%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDrawingDetailsDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.add(imgDrawingDetailsDropdown);
            flxDrawingDetailsHeader.add(lblDrawingDetails, flxDrawingDetailsDropdown);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var segDrawingDetailsExport = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblLeft1": "Drawing Amount:",
                    "lblRight1": "$1,567.99",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Amount to be Credited to:",
                    "lblRight1": "Assignment of Proceeds",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Finance Us:",
                    "lblRight1": "Selected",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Uploaded Documents:",
                    "lblRight1": "Clearance Statement.pdf",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Physical Document Details:",
                    "lblRight1": "Invoices (2 originals, 3 copies)",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Forward despite any discrepancies:",
                    "lblRight1": "Selected",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Charges debit Account:",
                    "lblRight1": "Company's Checking Acc...3421",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "Message to Bank:",
                    "lblRight1": "Packing list revised",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }],
                "groupCells": false,
                "id": "segDrawingDetailsExport",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingDetailsExport"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "25dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                    "flxRight1": "flxRight1",
                    "lblLeft1": "lblLeft1",
                    "lblRight1": "lblRight1",
                    "lblRight2": "lblRight2",
                    "lblRight3": "lblRight3",
                    "lblRight4": "lblRight4"
                },
                "width": "80%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingContent.setDefaultUnit(kony.flex.DP);
            var flxDrawingRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingRef.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingRefKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DrawingAmount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefValue = new kony.ui.Label({
                "id": "lblDrawingRefValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingRef.add(lblDrawingRefKey, lblDrawingRefValue);
            var flxAmountCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCredited",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCredited.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblAmountCreditedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmounttobeCreditedto\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountCrediredValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCrediredValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedValue = new kony.ui.Label({
                "id": "lblAmountCreditedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountCreditedValueInfo = new kony.ui.Label({
                "id": "lblAmountCreditedValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.OtherBeneficiaryName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.add(lblAmountCreditedValue, lblAmountCreditedValueInfo);
            flxAmountCredited.add(lblAmountCreditedKey, flxAmountCrediredValue);
            var flxFinanceUS = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUS",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUS.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblFinanceUSKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Financeus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFinanceUSValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUSValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSValue = new kony.ui.Label({
                "id": "lblFinanceUSValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFinanceUSInfo = new kony.ui.Label({
                "id": "lblFinanceUSInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PleaseFinanceUs\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.add(lblFinanceUSValue, lblFinanceUSInfo);
            flxFinanceUS.add(lblFinanceUSKey, flxFinanceUSValue);
            var flxUploadDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocs.setDefaultUnit(kony.flex.DP);
            var lblUploadDocsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblUploadDocsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.UploadDocuments\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadDocsValue = new kony.ui.Label({
                "id": "lblUploadDocsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segUploadDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}],
                "groupCells": false,
                "id": "segUploadDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValue"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDocs.add(lblUploadDocsKey, lblUploadDocsValue, segUploadDocuments);
            var flxPhysicalDocDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalDocDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocDetailsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPhysicalDocDetailsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PhysicalDocumentDetails\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhysicalDocDetailsValue = new kony.ui.Label({
                "id": "lblPhysicalDocDetailsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segPhysicalDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}],
                "groupCells": false,
                "id": "segPhysicalDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValue"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.add(lblPhysicalDocDetailsKey, lblPhysicalDocDetailsValue, segPhysicalDocuments);
            var flxDiscrepancies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancies.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDiscrepanciesKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Forwarddespiteanydiscrepancies\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDiscrepanciesValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesValue = new kony.ui.Label({
                "id": "lblDiscrepanciesValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDiscrepanciesValueInfo = new kony.ui.Label({
                "id": "lblDiscrepanciesValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.KindlyForwardDoc\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.add(lblDiscrepanciesValue, lblDiscrepanciesValueInfo);
            flxDiscrepancies.add(lblDiscrepanciesKey, flxDiscrepanciesValue);
            var flxChargesDebit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChargesDebit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesDebit.setDefaultUnit(kony.flex.DP);
            var lblChargesDebitKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblChargesDebitKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ChargesDebitAccount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChargesDebitValue = new kony.ui.Label({
                "id": "lblChargesDebitValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChargesDebit.add(lblChargesDebitKey, lblChargesDebitValue);
            var flxMsgToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMsgToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.30%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsgToBank.setDefaultUnit(kony.flex.DP);
            var lblMsgToBankKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblMsgToBankKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBank\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMsgToBankValue = new kony.ui.Label({
                "id": "lblMsgToBankValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsgToBank.add(lblMsgToBankKey, lblMsgToBankValue);
            flxDrawingContent.add(flxDrawingRef, flxAmountCredited, flxFinanceUS, flxUploadDocs, flxPhysicalDocDetails, flxDiscrepancies, flxChargesDebit, flxMsgToBank);
            flxDrawingDetails.add(flxDrawingDetailsHeader, flxSeparator, segDrawingDetailsExport, flxDrawingContent);
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "100.03%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.add(lblLCSummary);
            var flxBottomSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator1.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator1.add();
            flxLCSummaryHeader.add(flxLCSummarylbl, flxBottomSeparator1);
            var flxLCSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxLCSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummary1.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "id": "lblApplicant",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantValue = new kony.ui.Label({
                "id": "lblApplicantValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummary1.add(lblApplicant, lblApplicantValue);
            var flxLCSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxLCSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummary2.setDefaultUnit(kony.flex.DP);
            var lblAdvisingRefNo = new kony.ui.Label({
                "id": "lblAdvisingRefNo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AdvisingLCRefNo\")",
                "top": "1.44%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdvisingRefValue = new kony.ui.Label({
                "id": "lblAdvisingRefValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummary2.add(lblAdvisingRefNo, lblAdvisingRefValue);
            var flxLCAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxLCAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCAmount.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCAmount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmoutValue = new kony.ui.Label({
                "id": "lblLCAmoutValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCAmount.add(lblLCAmount, lblLCAmoutValue);
            var flxExpiryDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxExpiryDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpiryDate.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ExpiryDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "293dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpiryDate.add(lblExpiryDate, lblExpiryDateValue);
            flxLCSummaryBody.add(flxLCSummaryHeader, flxLCSummary1, flxLCSummary2, flxLCAmount, flxExpiryDate);
            var flxAcknowledgementActions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxAcknowledgementActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementActions.setDefaultUnit(kony.flex.DP);
            var btnActionsDrawings = new kony.ui.Button({
                "height": "40dp",
                "id": "btnActionsDrawings",
                "isVisible": true,
                "right": "0",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewAllDrawings\")",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnActionsExportLC = new kony.ui.Button({
                "height": "40dp",
                "id": "btnActionsExportLC",
                "isVisible": true,
                "right": 280,
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewAllExportLC\")",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewLCReport = new kony.ui.Button({
                "height": "40dp",
                "id": "btnViewLCReport",
                "isVisible": true,
                "right": 280,
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgementActions.add(btnActionsDrawings, btnActionsExportLC, btnViewLCReport);
            flxAcknowledgementBody.add(flxDrawingDetails, flxLCSummaryBody, flxAcknowledgementActions);
            flxMainContainer.add(flxSubHeader, flxMain, flxDrawingSummary, flxDiscrepanciesandResponse, flxAcknowledgementBody);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "121dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblCopyright": {
                        "left": "110dp",
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMainContainer, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "215dp",
                "clipBounds": false,
                "height": "268dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.imgKonyHamburger": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Import LC",
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "skin": "s8b9c3471e9f4cdcb3133f2cb3fec6fa",
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "src": "success_green.png",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12.00%"
                        },
                        "right": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDrawing": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown1": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesandResponseValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": []
                    },
                    "flxBottomSeparater02": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepancyDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDiscrepancyDropdown": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxtotoalDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader": {
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxBottomSeparator1": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknFlxBordere3e3e3Radius3Px",
                        "segmentProps": []
                    },
                    "btnActionsDrawings": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnActionsExportLC": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnViewLCReport": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "View LC Detail",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "segmentProps": []
                    },
                    "lblExportLCAck": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "height": {
                            "type": "string",
                            "value": "36.94%"
                        },
                        "left": {
                            "type": "string",
                            "value": "95%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "29.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.78%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingSummary": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDrawing": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown1": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "94.91%"
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "lblDrawingStatusValue": {
                        "segmentProps": []
                    },
                    "lblDrawingRefNoValue": {
                        "segmentProps": []
                    },
                    "lblDrawingDateValue": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparater02": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepancyDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.82%"
                        },
                        "segmentProps": []
                    },
                    "imgDiscrepancyDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementBody": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "width": {
                            "type": "string",
                            "value": "96.98%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.82%"
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator1": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "lblApplicantValue": {
                        "segmentProps": []
                    },
                    "lblAdvisingRefValue": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCAmoutValue": {
                        "segmentProps": []
                    },
                    "lblExpiryDateValue": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementActions": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnActionsDrawings": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnActionsExportLC": {
                        "right": {
                            "type": "string",
                            "value": "19.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnViewLCReport": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "38.10%"
                        },
                        "text": "View LC Report",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "zIndex": 5000,
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementBody": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "segDrawingDetailsExport": {
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementActions": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnViewLCReport": {
                        "right": {
                            "type": "string",
                            "value": "557dp"
                        },
                        "text": "View LC Details",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxExportSuccess": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "imgSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblExportSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular42424224px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseBtn": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "imgbtnClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementBody": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segDrawingDetailsExport": {
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "btnActionsDrawings": {
                        "segmentProps": []
                    },
                    "btnViewLCReport": {
                        "right": {
                            "type": "number",
                            "value": "560"
                        },
                        "text": "View LC Details",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customfooternew.lblCopyright": {
                    "left": "110dp",
                    "top": "75dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCDrawingAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCDrawingAcknowledgement",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_df7eb21b3cc14eb39efe0430c4507f6d,
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});