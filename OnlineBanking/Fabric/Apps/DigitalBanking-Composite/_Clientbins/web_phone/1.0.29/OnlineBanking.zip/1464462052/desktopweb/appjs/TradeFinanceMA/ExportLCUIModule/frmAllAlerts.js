define("TradeFinanceMA/ExportLCUIModule/frmAllAlerts", function() {
    return function(controller) {
        function addWidgetsfrmAllAlerts() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var FlexContainer0h0675e601b8649 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexContainer0h0675e601b8649",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0h0675e601b8649.setDefaultUnit(kony.flex.DP);
            var NewDrawingPopup = new com.InfinityOLB.ExportLC.NewDrawingPopup({
                "height": "100%",
                "id": "NewDrawingPopup",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA",
                "viewType": "NewDrawingPopup",
                "overrides": {
                    "NewDrawingPopup": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var NewDrawingPopup_data = (appConfig.componentMetadata && appConfig.componentMetadata["TradeFinanceMA"] && appConfig.componentMetadata["TradeFinanceMA"]["frmAllAlerts"] && appConfig.componentMetadata["TradeFinanceMA"]["frmAllAlerts"]["NewDrawingPopup"]) || {};
            FlexContainer0h0675e601b8649.add(NewDrawingPopup);
            flxMainContainer.add(FlexContainer0h0675e601b8649);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "1366": {
                    "NewDrawingPopup": {
                        "height": {
                            "type": "string",
                            "value": "1185dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "NewDrawingPopup": {
                        "height": {
                            "type": "string",
                            "value": "1185dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "NewDrawingPopup": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmAllAlerts,
            "enabledForIdleTimeout": true,
            "id": "frmAllAlerts",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});