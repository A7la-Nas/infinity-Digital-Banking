define("AboutUsMA/SurveyUIModule/frmCustomerFeedbackSurvey", function() {
    return function(controller) {
        function addWidgetsfrmCustomerFeedbackSurvey() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderPreLogin = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "70dp",
                "id": "flxHeaderPreLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPreLogin.setDefaultUnit(kony.flex.DP);
            var flxMainHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "70px",
                "id": "flxMainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 3,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainHeader.setDefaultUnit(kony.flex.DP);
            var btnSkip = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSkip",
                "isVisible": true,
                "left": "280dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to Main Content",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgKony = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "42dp",
                "id": "flxImgKony",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "width": "160dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgKony.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "kony_logo.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgKony.add(imgKony);
            var imgReminder = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "28dp",
                "id": "imgReminder",
                "isVisible": true,
                "left": "75.30%",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "28dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "13%",
                "skin": "sknLblSSP33333315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.YouHaveNotLoggedIn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": 37,
                "height": "25dp",
                "id": "lblSeperator",
                "isVisible": true,
                "right": "10.90%",
                "skin": "sknLabelD8D8D8bg",
                "text": "-",
                "width": "1dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLogin = new kony.ui.Button({
                "height": "50dp",
                "id": "btnLogin",
                "isVisible": false,
                "left": "1227dp",
                "skin": "sknButtonLogin3343a8",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "top": "10dp",
                "width": "90dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Login"
            });
            var flxPreLogout = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Sign In"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "51.40%",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxPreLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "30dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPreLogout.setDefaultUnit(kony.flex.DP);
            var imgLogout = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLogout",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "login_icon_locateus.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sign In"
            });
            flxPreLogout.add(imgLogout);
            flxMainHeader.add(btnSkip, flxImgKony, imgReminder, lblKonyBank, lblSeperator, btnLogin, flxPreLogout);
            var flxLeftContainers = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxLeftContainers",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknc6daf3",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainers.setDefaultUnit(kony.flex.DP);
            flxLeftContainers.add();
            var flxRightContainers = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxRightContainers",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainers.setDefaultUnit(kony.flex.DP);
            flxRightContainers.add();
            var flxSeperatorHor2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8dp",
                "id": "flxSeperatorHor2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxBlueShadow",
                "top": "70dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxMouseIndication"
            });
            flxSeperatorHor2.setDefaultUnit(kony.flex.DP);
            flxSeperatorHor2.add();
            flxHeaderPreLogin.add(flxMainHeader, flxLeftContainers, flxRightContainers, flxSeperatorHor2);
            var flxHeaderPostLogin = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPostLogin.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customhamburger.imgCollapseAccounts": {
                        "src": "arrow_down.png"
                    },
                    "customhamburger.imgKony": {
                        "src": "kony_logo_white.png"
                    },
                    "customhamburger.imgLogout": {
                        "src": "menu_logout.png"
                    },
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxTopmenu": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu.imgDropdown": {
                        "src": "profile_dropdown_arrow.png"
                    },
                    "headermenu.imgLogout": {
                        "right": "5dp",
                        "src": "logout.png"
                    },
                    "headermenu.imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "headermenu.imgUserBoundary": {
                        "src": "verify_user.png"
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "headermenu.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "headermenu.imgheaderdefault": {
                        "src": "default_username.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Survey\")",
                        "isVisible": true
                    },
                    "lblHeaderMobileView": {
                        "isVisible": false
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "isVisible": true,
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxLoginMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoginMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-52dp",
                "width": "10%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMobile.setDefaultUnit(kony.flex.DP);
            var lblLoginMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblLoginMobile",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblffffff15pxSSP",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "width": "65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Help"
            });
            flxLoginMobile.add(lblLoginMobile);
            flxHeaderPostLogin.add(customheader, flxLoginMobile);
            var flxMainScroll = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMainScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainScroll.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "right": "6%",
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "89%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxFeedbackSurveyContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackSurveyContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackSurveyContainer.setDefaultUnit(kony.flex.DP);
            var flxFSSurvey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "75dp",
                "id": "flxFSSurvey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFSSurvey.setDefaultUnit(kony.flex.DP);
            var lblFSSurvey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerX": "50%",
                "id": "lblFSSurvey",
                "isVisible": true,
                "skin": "sknSupportedFileTypes",
                "text": "Survey",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFSSurvey.add(lblFSSurvey);
            var flxFeedbackSurvey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackSurvey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackSurvey.setDefaultUnit(kony.flex.DP);
            var FeedbackSurvey = new com.InfinityMB.AboutUs.FeedbackSurveymod({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "FeedbackSurvey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "FeedbackSurveymod": {
                        "top": "0dp"
                    },
                    "confirmButtons": {
                        "left": "0dp"
                    },
                    "confirmButtons.btnCancel": {
                        "isVisible": false
                    },
                    "confirmButtons.btnConfirm": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Submit\")",
                        "right": "2.20%",
                        "width": "21.41%"
                    },
                    "confirmButtons.btnModify": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")"
                    },
                    "flxHeader": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "width": "110%"
                    },
                    "flxHorizontalLine": {
                        "isVisible": false
                    },
                    "flxMain": {
                        "width": "100%"
                    },
                    "segSurveyQuestion1": {
                        "left": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFeedbackSurvey.add(FeedbackSurvey);
            flxFeedbackSurveyContainer.add(flxFSSurvey, flxFeedbackSurvey);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "605dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "410dp",
                "id": "flxAcknowledgementMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "68dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementMain.setDefaultUnit(kony.flex.DP);
            var acknowledgment = new com.InfinityOLB.AboutUs.acknowledgment({
                "height": "410dp",
                "id": "acknowledgment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9noshadow",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "ImgAcknowledged": {
                        "src": "success_green.png",
                        "top": "136dp"
                    },
                    "confirmHeaders.lblHeading": {
                        "left": "5%"
                    },
                    "lblRefrenceNumber": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.WoulduLikeToTakeATwoMinuteSurvey\")",
                        "top": "224dp"
                    },
                    "lblRefrenceNumberValue": {
                        "top": "330dp"
                    },
                    "lblTransactionMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.ThankuForSubmittingYourFeedback\")",
                        "top": "90px"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementMain.add(acknowledgment);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "410dp",
                "id": "flxTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50.59%",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "68dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var CustomerFeedbackDetails = new com.InfinityOLB.AboutUs.CustomerFeedbackDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CustomerFeedbackDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransactionDetails.add(CustomerFeedbackDetails);
            var btnAddAnotherAccount = new kony.ui.Button({
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "50dp",
                "id": "btnAddAnotherAccount",
                "isVisible": true,
                "left": "72.91%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "Button",
                "top": "516dp",
                "width": "20.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "DONE"
            });
            var flxSpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "36dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "667dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            flxAcknowledgementContainer.add(flxAcknowledgementMain, flxTransactionDetails, btnAddAnotherAccount, flxSpace);
            var flxFeedbackAcknowledgement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackAcknowledgement",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxSurveyHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "75dp",
                "id": "flxSurveyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 20,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSurveyHeader.setDefaultUnit(kony.flex.DP);
            var lblSurvey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerX": "50%",
                "id": "lblSurvey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSupportedFileTypes",
                "text": "Survey",
                "top": "30dp",
                "width": "100%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSurveyHeader.add(lblSurvey);
            var flxFeedbackAcknowledgementSurvey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFeedbackAcknowledgementSurvey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackAcknowledgementSurvey.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementThankyouMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgementThankyouMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "0dp",
                "width": "99.10%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementThankyouMessage.setDefaultUnit(kony.flex.DP);
            var flxThankyouWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxThankyouWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxThankyouWrapper.setDefaultUnit(kony.flex.DP);
            var flxHeaderAck = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxHeaderAck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "53dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderAck.setDefaultUnit(kony.flex.DP);
            var lblAck = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblAck",
                "isVisible": true,
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Acknowledgement\")",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "6dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            flxHeaderAck.add(lblAck, flxHorizontalLine2);
            var imgSuccessGreen = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgSuccessGreen",
                "isVisible": true,
                "left": "2.35%",
                "skin": "slImage",
                "src": "success_green.png",
                "top": "50dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWeValue",
                "isVisible": false,
                "left": "9%",
                "skin": "sknSSP42424215Px",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxThankyouMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxThankyouMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxThankyouMsg.setDefaultUnit(kony.flex.DP);
            var lblThankYouMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblThankYouMsg",
                "isVisible": true,
                "left": "9%",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.CustomerFeedback.ThankyouForCompletingTheSurvey\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxThankyouMsg.add(lblThankYouMsg);
            var flxSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "2dp",
                "width": "100%",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxThankyouWrapper.add(flxHeaderAck, imgSuccessGreen, lblWeValue, flxThankyouMsg, flxSeperator3);
            flxAcknowledgementThankyouMessage.add(flxThankyouWrapper);
            var flxFeedbackDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "20dp",
                "width": "99.10%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackDetails.setDefaultUnit(kony.flex.DP);
            var confirmHeaders = new com.InfinityOLB.BillPay.PayDueAmount.confirmHeaders({
                "height": "60dp",
                "id": "confirmHeaders",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA",
                "overrides": {
                    "confirmHeaders": {
                        "left": "0dp",
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.FeedbackDetails\")",
                        "left": "2.10%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "1dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxaddress = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxaddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxaddress.setDefaultUnit(kony.flex.DP);
            var segSurveyQuestion = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgRating1": "circle_blue_filled.png",
                    "imgRating2": "circle_blue_filled.png",
                    "imgRating3": "circle_blue_filled.png",
                    "imgRating4": "circle_blue_filled.png",
                    "imgRating5": "circle_unfilled.png",
                    "lblRateYourExpeience": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.HowEasyWasTheMoneyTransferProcess?\")",
                    "lblVeryEasy": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.VERYEASY\")",
                    "lblVeryHard": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.VeryHard\")"
                }, {
                    "imgRating1": "circle_blue_filled.png",
                    "imgRating2": "circle_blue_filled.png",
                    "imgRating3": "circle_blue_filled.png",
                    "imgRating4": "circle_blue_filled.png",
                    "imgRating5": "circle_unfilled.png",
                    "lblRateYourExpeience": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.HowEasyWasTheMoneyTransferProcess?\")",
                    "lblVeryEasy": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.VERYEASY\")",
                    "lblVeryHard": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.VeryHard\")"
                }],
                "groupCells": false,
                "id": "segSurveyQuestion",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AboutUsMA",
                    "friendlyName": "flxRowSurvey"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRating1": "flxRating1",
                    "flxRating2": "flxRating2",
                    "flxRating3": "flxRating3",
                    "flxRating4": "flxRating4",
                    "flxRating5": "flxRating5",
                    "flxRatingimg": "flxRatingimg",
                    "flxRowSurvey": "flxRowSurvey",
                    "flxSurveyQuestion1Wrapper": "flxSurveyQuestion1Wrapper",
                    "flxaddress": "flxaddress",
                    "imgRating1": "imgRating1",
                    "imgRating2": "imgRating2",
                    "imgRating3": "imgRating3",
                    "imgRating4": "imgRating4",
                    "imgRating5": "imgRating5",
                    "lblRateYourExpeience": "lblRateYourExpeience",
                    "lblVeryEasy": "lblVeryEasy",
                    "lblVeryHard": "lblVeryHard"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxaddress.add(segSurveyQuestion);
            var flxSeperatorhor = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorhor",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "40dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorhor.setDefaultUnit(kony.flex.DP);
            flxSeperatorhor.add();
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "110dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnDone = new kony.ui.Button({
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "50dp",
                "id": "btnDone",
                "isVisible": true,
                "onClick": controller.AS_Button_j912d2860bbd4e7ebac09789ccdd101c,
                "right": "2.70%",
                "skin": "sknBtnHoverSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Done\")",
                "top": "30dp",
                "width": "24%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Done"
            });
            flxButtons.add(btnDone);
            flxFeedbackDetails.add(confirmHeaders, flxSeperator2, flxaddress, flxSeperatorhor, flxButtons);
            flxFeedbackAcknowledgementSurvey.add(flxAcknowledgementThankyouMessage, flxFeedbackDetails);
            flxFeedbackAcknowledgement.add(flxSurveyHeader, flxFeedbackAcknowledgementSurvey);
            flxMainContainer.add(flxFeedbackSurveyContainer, flxAcknowledgementContainer, flxFeedbackAcknowledgement);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooternew({
                "centerY": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerY": "50%",
                        "top": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxMainScroll.add(flxMainContainer, flxFooter);
            var flxPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "500dp",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0i94559a2949d45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "height": "30dp",
                        "isVisible": true,
                        "right": "10dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmCustomerFeedbackSurvey": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxHeaderPreLogin": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBlueGradientHeader",
                        "segmentProps": []
                    },
                    "flxMainHeader": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnSkip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "64%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Feedback",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "534dp"
                        },
                        "text": "LOGIN",
                        "segmentProps": []
                    },
                    "flxPreLogout": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.customhamburger.flxMenuWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomBlue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Survey",
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobileView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblLoginMobile": {
                        "text": "Log in",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxMainScroll": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurveyContainer": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFSSurvey": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFeedbackSurvey": {
                        "segmentProps": []
                    },
                    "FeedbackSurvey": {
                        "segmentProps": [],
                        "instanceId": "FeedbackSurvey"
                    },
                    "FeedbackSurvey.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.flxHorizontalLine": {
                        "segmentProps": []
                    },
                    "FeedbackSurvey.segSurveyQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.ImgAcknowledged": {
                        "height": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.flxSeperator": {
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblTransactionMessage": {
                        "top": {
                            "type": "string",
                            "value": "47px"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "865dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementThankyouMessage": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98.70%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Survey",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgSuccessGreen": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackDetails": {
                        "width": {
                            "type": "string",
                            "value": "98.70%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "btnDone": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxCross": {
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMainHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": "61%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": "8.90%"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "segmentProps": []
                    },
                    "flxPreLogout": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.imgLogout": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainScroll": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurveyContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFSSurvey": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFSSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "Survey",
                        "segmentProps": []
                    },
                    "flxFeedbackSurvey": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "FeedbackSurvey"
                    },
                    "FeedbackSurvey.confirmButtons.btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.flxHorizontalLine": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.lblHeading": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.segSurveyQuestion1": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.ImgAcknowledged": {
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblTransactionMessage": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Survey",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementThankyouMessage": {
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknSSP42424213Px",
                        "text": "Acknowledgement",
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgSuccessGreen": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP42424215Px",
                        "text": "We value your feedback.",
                        "segmentProps": []
                    },
                    "flxThankyouMsg": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSupportedFileTypes",
                        "segmentProps": []
                    },
                    "confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmHeaders"
                    },
                    "confirmHeaders.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnDone": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeaderPreLogin": {
                        "segmentProps": []
                    },
                    "flxMainHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": "69.50%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "1227dp"
                        },
                        "text": "LOGIN",
                        "segmentProps": []
                    },
                    "flxPreLogout": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.imgLogout": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainScroll": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "89.80%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurveyContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFSSurvey": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblFSSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurvey": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "147px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "200px"
                        },
                        "width": {
                            "type": "string",
                            "value": "147px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.segSurveyQuestion1": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "left": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxThankyouWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgSuccessGreen": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "segmentProps": []
                    },
                    "flxThankyouMsg": {
                        "top": {
                            "type": "string",
                            "value": "-60dp"
                        },
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "skin": "sknLabel42424224px",
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorhor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnDone": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnHoverSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeaderPreLogin": {
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": "69.20%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxPreLogout": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "90px"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "353dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "86.80%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurveyContainer": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxFSSurvey": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblFSSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackSurvey": {
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "147px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "200px"
                        },
                        "width": {
                            "type": "string",
                            "value": "147px"
                        },
                        "segmentProps": []
                    },
                    "FeedbackSurvey.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgSuccessGreen": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "segmentProps": []
                    },
                    "flxThankyouMsg": {
                        "top": {
                            "type": "string",
                            "value": "-60dp"
                        },
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "skin": "sknLabel42424224px",
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorhor": {
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "btnDone": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnHoverSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": "147dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.customhamburger.imgCollapseAccounts": {
                    "src": "arrow_down.png"
                },
                "customheader.customhamburger.imgKony": {
                    "src": "kony_logo_white.png"
                },
                "customheader.customhamburger.imgLogout": {
                    "src": "menu_logout.png"
                },
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.headermenu.imgDropdown": {
                    "src": "profile_dropdown_arrow.png"
                },
                "customheader.headermenu.imgLogout": {
                    "right": "5dp",
                    "src": "logout.png"
                },
                "customheader.headermenu.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheader.headermenu.imgUserBoundary": {
                    "src": "verify_user.png"
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.headermenu.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customheader.headermenu.imgheaderdefault": {
                    "src": "default_username.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "FeedbackSurvey": {
                    "top": "0dp"
                },
                "FeedbackSurvey.confirmButtons": {
                    "left": "0dp"
                },
                "FeedbackSurvey.confirmButtons.btnConfirm": {
                    "right": "2.20%",
                    "width": "21.41%"
                },
                "FeedbackSurvey.flxHeader": {
                    "centerX": "",
                    "left": "0dp",
                    "width": "110%"
                },
                "FeedbackSurvey.flxMain": {
                    "width": "100%"
                },
                "FeedbackSurvey.segSurveyQuestion1": {
                    "left": "0dp",
                    "width": "100%"
                },
                "acknowledgment.ImgAcknowledged": {
                    "src": "success_green.png",
                    "top": "136dp"
                },
                "acknowledgment.confirmHeaders.lblHeading": {
                    "left": "5%"
                },
                "acknowledgment.lblRefrenceNumber": {
                    "top": "224dp"
                },
                "acknowledgment.lblRefrenceNumberValue": {
                    "top": "330dp"
                },
                "acknowledgment.lblTransactionMessage": {
                    "top": "90px"
                },
                "confirmHeaders": {
                    "left": "0dp",
                    "top": "0dp",
                    "zIndex": 1
                },
                "confirmHeaders.lblHeading": {
                    "left": "2.10%"
                },
                "CustomFooterMain": {
                    "centerY": "50%",
                    "top": ""
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "width": "43%"
                },
                "CustomPopup.btnNo": {
                    "left": "",
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "height": "30dp",
                    "right": "10dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeaderPreLogin, flxHeaderPostLogin, flxMainScroll, flxPopup, flxLogout, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmCustomerFeedbackSurvey,
            "enabledForIdleTimeout": true,
            "id": "frmCustomerFeedbackSurvey",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_acc658fee64f4e6e885e132742097d23,
            "preShow": function(eventobject) {
                controller.AS_Form_ac690e6844694c50ad78fdfc95f09c7f(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.common.FeedbackSurvey\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AboutUsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_cff6396449ed4cc2b41260d8f6c11c19,
            "retainScrollPosition": false
        }]
    }
});