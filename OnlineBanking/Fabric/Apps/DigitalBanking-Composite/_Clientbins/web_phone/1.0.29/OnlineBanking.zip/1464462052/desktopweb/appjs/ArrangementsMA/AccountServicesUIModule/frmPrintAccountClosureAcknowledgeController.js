define("ArrangementsMA/AccountServicesUIModule/userfrmPrintAccountClosureAcknowledgeController", ['CommonUtilities', 'OLBConstants'], function(CommonUtilities, OLBConstants) {
    return {
        accountList: {},
        payLoad: {},
        account: {},
        preShow: function() {
            var navMan = applicationManager.getNavigationManager();
            var scopeObj = this;
            this.accountList = navMan.getCustomInfo("frmPrintAccountClosureAcknowledge");
            this.payLoad = navMan.getCustomInfo("frmPrintAccountClosureAcknowledge");
            this.account = navMan.getCustomInfo("frmPrintAccountClosureAcknowledge");
            this.setUpFormData();
        },
        setUpFormData: function() {
            var navMan = applicationManager.getNavigationManager();
            account = navMan.getCustomInfo("frmConfirmClosure");
            this.view.lblMyCheckingAccount.text = account.accountName + " ... " + account.account_id.slice(-4);
            this.view.lblKonyBank.text = account.accountName + " ... " + account.account_id.slice(-4);
            this.view.lblReferenceValue.text = account.arrangementId;
            this.view.lblValAccountName.text = account.accountName;
            this.view.lblValAccountNumber.text = "**" + account.account_id.slice(-4);
            this.view.lblValAccountType.text = account.accountType;
            //       this.view.lblValSwiftCode.text = scopeObj.payLoad.requestDetails[2].newValue;
            this.view.lblValCurrentBalance.text = account.currentBalance;
            this.view.lblValIBAN.text = account.IBAN;
        },
        postShow: function() {
            //this.printCall();
            scope = this;
            setTimeout(function() {
                scope.printCall();
            }, "17ms");
            applicationManager.getNavigationManager().applyUpdates(this);
        },
        printCall: function() {
            var scope = this;
            //kony.os.print();
            kony.os.print();
            //timeout is required to allow print popup to be visible.
            setTimeout(function() {
                scope.loadAccountsDetails();
            }, "17ms");
        },
        /**
         * loadAccountsDetails : Method to accounts details
         * @member of {frmPrintTransactionController}
         * @param {}
         * @return {}
         * @throws {}
         */
        loadAccountsDetails: function() {
            var navMan = applicationManager.getNavigationManager();
            navMan.navigateTo({
                "appName": "ArrangementsMA",
                "friendlyName": "AccountServicesUIModule/frmAcClosureAcknowledge"
            });
            kony.application.dismissLoadingScreen();
        }
    }
});
define("ArrangementsMA/AccountServicesUIModule/frmPrintAccountClosureAcknowledgeControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmPrintAccountClosureAcknowledge **/
    AS_Form_d4e6273cc59349bfb68aa8664e009324: function AS_Form_d4e6273cc59349bfb68aa8664e009324(eventobject) {
        var self = this;
        this.preShow();
    },
    /** postShow defined for frmPrintAccountClosureAcknowledge **/
    AS_Form_fa9f7924ee804562b233a9f72333878b: function AS_Form_fa9f7924ee804562b233a9f72333878b(eventobject) {
        var self = this;
        this.postShow();
    }
});
define("ArrangementsMA/AccountServicesUIModule/frmPrintAccountClosureAcknowledgeController", ["ArrangementsMA/AccountServicesUIModule/userfrmPrintAccountClosureAcknowledgeController", "ArrangementsMA/AccountServicesUIModule/frmPrintAccountClosureAcknowledgeControllerActions"], function() {
    var controller = require("ArrangementsMA/AccountServicesUIModule/userfrmPrintAccountClosureAcknowledgeController");
    var controllerActions = ["ArrangementsMA/AccountServicesUIModule/frmPrintAccountClosureAcknowledgeControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
