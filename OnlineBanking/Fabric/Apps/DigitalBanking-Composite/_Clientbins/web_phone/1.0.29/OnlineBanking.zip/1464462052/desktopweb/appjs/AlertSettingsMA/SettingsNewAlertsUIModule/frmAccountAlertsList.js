define("AlertSettingsMA/SettingsNewAlertsUIModule/frmAccountAlertsList", function() {
    return function(controller) {
        function addWidgetsfrmAccountAlertsList() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "sknLblSSP42424215px",
                "text": "ACCOUNT SETTINGS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblAccountSettingsMobile",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    },
                    "profileMenu": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxAccountAlertsWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountAlertsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountAlertsWrapper.setDefaultUnit(kony.flex.DP);
            var accountAlerts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "accountAlerts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            accountAlerts.setDefaultUnit(kony.flex.DP);
            var flxAlertsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAlertsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsHeader.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator.add();
            var lblAlertsHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAlertsHeading",
                "isVisible": true,
                "left": "0px",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnModifyAlerts = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "id": "btnModifyAlerts",
                "isVisible": false,
                "right": "0px",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Modify\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Modify"
            });
            flxAlertsHeader.add(flxAlertsSeperator, lblAlertsHeading, btnModifyAlerts);
            var flxScrollAlertsBody = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "600dp",
                "horizontalScrollIndicator": true,
                "id": "flxScrollAlertsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "50dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollAlertsBody.setDefaultUnit(kony.flex.DP);
            var flxAlertsWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertsWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarning.setDefaultUnit(kony.flex.DP);
            var flxAlertsWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxAlertsWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0px",
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.setDefaultUnit(kony.flex.DP);
            var imgAlertsWarningImage = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgAlertsWarningImage",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAlertsWarningImage",
                "isVisible": false,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAlertsWarning",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profilemanagement.lblAlertsWarningNew\")",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.add(imgAlertsWarningImage, lblAlertsWarningImage, lblAlertsWarning);
            flxAlertsWarning.add(flxAlertsWarningWrapper);
            var flxNoAlertsFound = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoAlertsFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAlertsFound.setDefaultUnit(kony.flex.DP);
            var flxMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70px",
                "id": "flxMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.77%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3border",
                "top": "30px",
                "width": "92.44%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessage.setDefaultUnit(kony.flex.DP);
            var CopyimgError0afb44e1d41c948 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40px",
                "id": "CopyimgError0afb44e1d41c948",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2.18%",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "22dp",
                "width": "40px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblNoAlertsWarning",
                "isVisible": true,
                "left": "3.77%",
                "skin": "skntxtSSPff000015pxlbl",
                "text": "No alerts to display",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMessage.add(CopyimgError0afb44e1d41c948, lblNoAlertsWarning);
            flxNoAlertsFound.add(flxMessage);
            var flxAlertsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxe3e3e3bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator2.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator2.add();
            var segAlerts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segAlerts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountTypeAlerts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnModifyAlerts": "btnModifyAlerts",
                    "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                    "flxAlertsRow1": "flxAlertsRow1",
                    "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                    "flxRow2": "flxRow2",
                    "flxSeperator": "flxSeperator",
                    "lblAccountType": "lblAccountType",
                    "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                    "lblAlertsStatus": "lblAlertsStatus",
                    "lblSeperator": "lblSeperator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.add(flxAlertsSeperator2, segAlerts);
            var flxClickBlocker = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "id": "flxClickBlocker",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClickBlocker.setDefaultUnit(kony.flex.DP);
            flxClickBlocker.add();
            flxScrollAlertsBody.add(flxAlertsWarning, flxNoAlertsFound, flxAlertsSegment, flxClickBlocker);
            accountAlerts.add(flxAlertsHeader, flxScrollAlertsBody);
            flxAccountAlertsWrapper.add(accountAlerts);
            flxRight.add(flxAccountAlertsWrapper);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "height": "100dp"
                    },
                    "flxFooterMenu": {
                        "top": "26.60%"
                    },
                    "lblCopyright": {
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknLblSSP42424215px",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknSupportedFileTypes",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxProfileDeleteButtons.add(btnDeletePopupYes, btnDeletePopupNo);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAccountAlertsList": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Alerts Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxf8f7f8",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "text": "Account Alerts",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "620dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "skin": "CopysknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.20%"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeperator": "lblSeperator"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "20.60%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeperator": "lblSeperator"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknSupportedFileTypes",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [
                            [{
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblUsers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
                            ],
                            [{
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblUsers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
                            ]
                        ],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAccountTypes": "flxAccountTypes",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeparator": "lblSeparator",
                            "lblSeperator": "lblSeperator",
                            "lblUsers": "lblUsers"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAccountAlertsList": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [
                            [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }]
                            ],
                            [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }]
                            ]
                        ],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountIdAlerts": "flxAccountIdAlerts",
                            "flxAccountTypes": "flxAccountTypes",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountIcon": "lblAccountIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNumber": "lblAccountNumber",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeparator": "lblSeparator",
                            "lblSeperator": "lblSeperator",
                            "lblUsers": "lblUsers"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "profileMenu": {
                    "centerX": "",
                    "width": "100%"
                },
                "customfooternew": {
                    "height": "100dp"
                },
                "customfooternew.flxFooterMenu": {
                    "top": "26.60%"
                },
                "customfooternew.lblCopyright": {
                    "top": "75dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountAlertsList,
            "enabledForIdleTimeout": true,
            "id": "frmAccountAlertsList",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_b9331c44b3014563bf4a6cbcdf6038f1(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Account Alerts List",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AlertSettingsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});