define("BulkPaymentsMA/BulkPaymentsUIModule/frmBulkPaymentsUploadFile", function() {
    return function(controller) {
        function addWidgetsfrmBulkPaymentsUploadFile() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu.imgLogout": {
                        "src": "logout.png"
                    },
                    "headermenu.imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "text": "Help"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.BulkPayemntUploadFile\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentHeader.add(lblContentHeader);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxBPUploadFileContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxBPUploadFileContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadFileContainer.setDefaultUnit(kony.flex.DP);
            var flxBPUploadFile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBPUploadFile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadFile.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "10%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "60dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": 0,
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BulkPayments.successfulUpload\")",
                "top": 0,
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRightContainerInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRightContainerInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.setDefaultUnit(kony.flex.DP);
            var lblReferenceHeader = new kony.ui.Label({
                "centerY": "35%",
                "id": "lblReferenceHeader",
                "isVisible": true,
                "left": "332dp",
                "right": "10%",
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.bulkpayments.uploadID\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "centerY": "65%",
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "480dp",
                "right": "10%",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Label",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.add(lblReferenceHeader, lblReferenceNumber);
            flxAcknowledgement.add(flxImgContainer, lblSuccessMessage, flxRightContainerInfo);
            var flxBPFileUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxBPFileUpload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPFileUpload.setDefaultUnit(kony.flex.DP);
            var flxBPUploadHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBPUploadHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadHeader.setDefaultUnit(kony.flex.DP);
            var lblUploadFilesHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUploadFilesHeader",
                "isVisible": true,
                "left": "2.50%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.selectPaymentFile\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBPUploadHeader.add(lblUploadFilesHeader);
            var flxBPUploadSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBPUploadSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadSeperator1.setDefaultUnit(kony.flex.DP);
            flxBPUploadSeperator1.add();
            var flxErrorFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxErrorFlow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "94.97%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorFlow.setDefaultUnit(kony.flex.DP);
            var flxErrorUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorUpload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorUpload.setDefaultUnit(kony.flex.DP);
            var lblUploadFailMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "You have already added all the accounts you have with us."
                },
                "centerY": "50%",
                "id": "lblUploadFailMessage",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Unable to upload the file, verify the file and please try again.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorUpload.add(lblUploadFailMessage);
            flxErrorFlow.add(flxErrorUpload);
            var flxBPUpload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "255dp",
                "id": "flxBPUpload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUpload.setDefaultUnit(kony.flex.DP);
            var flxProcessingMode = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "flxProcessingMode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProcessingMode.setDefaultUnit(kony.flex.DP);
            var lblProcessingMode = new kony.ui.Label({
                "id": "lblProcessingMode",
                "isVisible": true,
                "left": 0,
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.ProcessingMode\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "17px",
                "id": "flxInfo1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "17px",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo1.setDefaultUnit(kony.flex.DP);
            var ingBatchModeInfo = new kony.ui.Image2({
                "height": "17px",
                "id": "ingBatchModeInfo",
                "isVisible": true,
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "17px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo1.add(ingBatchModeInfo);
            flxProcessingMode.add(lblProcessingMode, flxInfo1);
            var lbxBatchMode = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40px",
                "id": "lbxBatchMode",
                "isVisible": true,
                "left": 0,
                "masterData": [
                    ["SINGLE", "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.batchModeSingle\")"],
                    ["MULTI", "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.batchModeMulti\")"]
                ],
                "onSelection": controller.AS_ListBox_a6cdd796abe94d0a85cce0b054f7cb8c,
                "selectedKey": "SINGLE",
                "skin": "sknlbxffffffSourceSansPro15Px",
                "top": "10px",
                "width": "30%",
                "zIndex": 1,
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var txtBatchMode = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtBatchMode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "slTextBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var imgPlusSign = new kony.ui.Image2({
                "centerX": "50%",
                "height": "80dp",
                "id": "imgPlusSign",
                "isVisible": true,
                "skin": "slImage",
                "src": "bulk_upload_icon.png",
                "top": "7%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblClickUpload = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblClickUpload",
                "isVisible": true,
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.BulkPayments.UploadFileType\")",
                "top": "5%",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupportedFileTypes = new kony.ui.Label({
                "centerX": "60%",
                "id": "lblSupportedFileTypes",
                "isVisible": true,
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.BulkPayments.SupportedFileType\")",
                "top": "1%",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2%",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDownload",
                "isVisible": true,
                "right": "0dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWireFiles.donwLoadFileInfo\")",
                "width": "54%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff",
                "width": "25dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "centerY": "50%",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_grey.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Info"
            });
            flxInfo.add(imgInfoIcon);
            flxDownload.add(lblDownload, flxInfo);
            var lblNote = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblNote",
                "isVisible": true,
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.BulkPayments.maxFileSize\")",
                "top": "3.50%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBPUpload.add(flxProcessingMode, lbxBatchMode, txtBatchMode, imgPlusSign, lblClickUpload, lblSupportedFileTypes, flxDownload, lblNote);
            var flxAckContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "255dp",
                "id": "flxAckContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckContainer.setDefaultUnit(kony.flex.DP);
            var flxTickImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.04%",
                "centerY": "23.53%",
                "clipBounds": true,
                "height": "74dp",
                "id": "flxTickImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4.23%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "14.44%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTickImage.setDefaultUnit(kony.flex.DP);
            var imgTick = new kony.ui.Image2({
                "height": "100%",
                "id": "imgTick",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTickImage.add(imgTick);
            var rTextSuccess = new kony.ui.RichText({
                "centerY": "59.48%",
                "id": "rTextSuccess",
                "isVisible": true,
                "left": "27.93%",
                "linkSkin": "defRichTextLink",
                "skin": "bbSknRText45574Lato20Px",
                "text": "<body> Your file has been uploaded successfully</body>",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedFileDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUploadedFileDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "180dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileDetails.setDefaultUnit(kony.flex.DP);
            var flxUploadedFile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50dp",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "50dp",
                "id": "flxUploadedFile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.52%",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "513dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFile.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.setDefaultUnit(kony.flex.DP);
            var imgFileType = new kony.ui.Image2({
                "height": "100%",
                "id": "imgFileType",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "xls_image.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.add(imgFileType);
            var lblFIleName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFIleName",
                "isVisible": true,
                "left": "60dp",
                "text": "FileName.XLS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnOpenFile = new kony.ui.Button({
                "centerX": "30%",
                "centerY": "49.97%",
                "height": "50dp",
                "id": "btnOpenFile",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWire.openfile\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFile.add(flxFileTypeImage, lblFIleName, btnOpenFile);
            flxUploadedFileDetails.add(flxUploadedFile);
            flxAckContainer.add(flxTickImage, rTextSuccess, flxUploadedFileDetails);
            var flxBPVerifyDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "270dp",
                "id": "flxBPVerifyDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPVerifyDetails.setDefaultUnit(kony.flex.DP);
            var flxFileNameVerify = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxFileNameVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": 20,
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileNameVerify.setDefaultUnit(kony.flex.DP);
            var lblFileNameVerify = new kony.ui.Label({
                "id": "lblFileNameVerify",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.uploadFileNameWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var flxImgFileType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxImgFileType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgFileType.setDefaultUnit(kony.flex.DP);
            var imgXLSType = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgXLSType",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCSVType = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCSVType",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgFileType.add(imgXLSType, imgCSVType);
            var lblFileNameVerifyValue = new kony.ui.Label({
                "id": "lblFileNameVerifyValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Nacha",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileNameVerify.add(lblFileNameVerify, flxImgFileType, lblFileNameVerifyValue);
            var flxVerifyUploadDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxVerifyUploadDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": 20,
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyUploadDate.setDefaultUnit(kony.flex.DP);
            var lblVerifyUploadDate = new kony.ui.Label({
                "id": "lblVerifyUploadDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.uploadDateTitle\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblVerifyUploadDateValue = new kony.ui.Label({
                "id": "lblVerifyUploadDateValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerifyUploadDate.add(lblVerifyUploadDate, lblVerifyUploadDateValue);
            var flxFileSize = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxFileSize",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": 20,
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileSize.setDefaultUnit(kony.flex.DP);
            var lblFileSize = new kony.ui.Label({
                "id": "lblFileSize",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.fileSize\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblFileSizeValue = new kony.ui.Label({
                "id": "lblFileSizeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileSize.add(lblFileSize, lblFileSizeValue);
            var flxVerifyProcessingMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50.65%",
                "clipBounds": true,
                "id": "flxVerifyProcessingMode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "157dp",
                "width": "95.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerifyProcessingMode.setDefaultUnit(kony.flex.DP);
            var lblVerifyProcessingMode = new kony.ui.Label({
                "id": "lblVerifyProcessingMode",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.ProcessingMode\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVerifyProcessingModeValue = new kony.ui.Label({
                "id": "lblVerifyProcessingModeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerifyProcessingMode.add(lblVerifyProcessingMode, lblVerifyProcessingModeValue);
            var flxDescription = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxDescription",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "201dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDescription.setDefaultUnit(kony.flex.DP);
            var lblVerifyDescription = new kony.ui.Label({
                "id": "lblVerifyDescription",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BulkPayments.FileDescription\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var txtFieldDescription = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtFieldDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.payments.enterMinimum50characters\")",
                "secureTextEntry": false,
                "skin": "ICSknsknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknNormalTxtDescription"
            });
            flxDescription.add(lblVerifyDescription, txtFieldDescription);
            flxBPVerifyDetails.add(flxFileNameVerify, flxVerifyUploadDate, flxFileSize, flxVerifyProcessingMode, flxDescription);
            var flxBPFileUploadDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "270dp",
                "id": "flxBPFileUploadDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPFileUploadDetails.setDefaultUnit(kony.flex.DP);
            var flxFileNameAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxFileNameAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5%",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileNameAck.setDefaultUnit(kony.flex.DP);
            var lblFileNameAck = new kony.ui.Label({
                "id": "lblFileNameAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.uploadFileNameWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblImageTypeAck = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "lblImageTypeAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            lblImageTypeAck.setDefaultUnit(kony.flex.DP);
            var imgXSLAck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgXSLAck",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCSVAck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCSVAck",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgXLSTypeAck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgXLSTypeAck",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            lblImageTypeAck.add(imgXSLAck, imgCSVAck, imgXLSTypeAck);
            var lblFileNameValueAck = new kony.ui.Label({
                "id": "lblFileNameValueAck",
                "isVisible": true,
                "left": "24%",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileNameAck.add(lblFileNameAck, lblImageTypeAck, lblFileNameValueAck);
            var flxUploadDateAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxUploadDateAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5%",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDateAck.setDefaultUnit(kony.flex.DP);
            var lblUploadDateAck = new kony.ui.Label({
                "id": "lblUploadDateAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.uploadDateTitle\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblUploadDateAckValue = new kony.ui.Label({
                "id": "lblUploadDateAckValue",
                "isVisible": true,
                "left": "21%",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDateAck.add(lblUploadDateAck, lblUploadDateAckValue);
            var flxFileSizeAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxFileSizeAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5%",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileSizeAck.setDefaultUnit(kony.flex.DP);
            var lblFileSizeAck = new kony.ui.Label({
                "id": "lblFileSizeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.fileSize\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblFileSizeValueAck = new kony.ui.Label({
                "id": "lblFileSizeValueAck",
                "isVisible": true,
                "left": "21%",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileSizeAck.add(lblFileSizeAck, lblFileSizeValueAck);
            var flxDescriptionAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxDescriptionAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5%",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDescriptionAck.setDefaultUnit(kony.flex.DP);
            var lblDescriptionAck = new kony.ui.Label({
                "id": "lblDescriptionAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopPayments.Description\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblDescriptionValueAck = new kony.ui.Label({
                "id": "lblDescriptionValueAck",
                "isVisible": true,
                "left": "21%",
                "skin": "bbSknLbl455574SSP15Px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDescriptionAck.add(lblDescriptionAck, lblDescriptionValueAck);
            var flxStatusAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "bbSKnFlxffffff",
                "id": "flxStatusAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "5%",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatusAck.setDefaultUnit(kony.flex.DP);
            var lblStatusAck = new kony.ui.Label({
                "id": "lblStatusAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl727272SSP15Px"
            });
            var lblStatusValueAck = new kony.ui.Label({
                "id": "lblStatusValueAck",
                "isVisible": true,
                "left": "21%",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Nacha",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl455574SSP15Px"
            });
            flxStatusAck.add(lblStatusAck, lblStatusValueAck);
            flxBPFileUploadDetails.add(flxFileNameAck, flxUploadDateAck, flxFileSizeAck, flxDescriptionAck, flxStatusAck);
            var flxBPUploadSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBPUploadSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": 90,
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadSeperator2.setDefaultUnit(kony.flex.DP);
            flxBPUploadSeperator2.add();
            var flxBPUploadFormActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBPUploadFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadFormActions.setDefaultUnit(kony.flex.DP);
            var filesFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "80dp",
                "id": "filesFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "top": "0px",
                        "width": "150dp"
                    },
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "top": "0px",
                        "width": "150dp"
                    },
                    "btnNext": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wireTemplate.selectFile\")",
                        "left": "viz.val_cleared",
                        "right": "0px",
                        "top": "0px",
                        "width": "150dp"
                    },
                    "btnOption": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "top": "0px",
                        "width": "150dp"
                    },
                    "flxButtons": {
                        "left": "2.50%",
                        "right": "viz.val_cleared",
                        "top": "20dp",
                        "width": "95%"
                    },
                    "flxMain": {
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "formActionsNew": {
                        "height": "80dp",
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBPUploadFormActions.add(filesFormActionsNew);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "-160dp",
                "clipBounds": true,
                "height": "800dp",
                "id": "flxCancelPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CancelPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "centerY": "50%",
                "height": "268px",
                "id": "CancelPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "50%",
                        "height": "268px",
                        "isVisible": true,
                        "left": 0,
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1
                    },
                    "flxCross": {
                        "isVisible": true
                    },
                    "imgCross": {
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.cancelUpload\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.cancelAlert\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(CancelPopup);
            flxBPFileUpload.add(flxBPUploadHeader, flxBPUploadSeperator1, flxErrorFlow, flxBPUpload, flxAckContainer, flxBPVerifyDetails, flxBPFileUploadDetails, flxBPUploadSeperator2, flxBPUploadFormActions, flxCancelPopup);
            flxBPUploadFile.add(flxAcknowledgement, flxBPFileUpload);
            var flxInformationText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "id": "flxInformationText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "-60dp",
                "width": "260dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText.setDefaultUnit(kony.flex.DP);
            var flxInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var lblInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Information"
                },
                "centerY": "50%",
                "id": "lblInformation",
                "isVisible": true,
                "left": "4.44%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.SupportInfo.Title\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.55%",
                "skin": "skncursor",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "12dp",
                "id": "imgCross",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross.add(imgCross);
            flxInformation.add(lblInformation, flxCross);
            var flxModeTypeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxModeTypeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxModeTypeInfo.setDefaultUnit(kony.flex.DP);
            var RichTextSingleInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "RichTextSingleInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.SINGLE\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextMultipleInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "RichTextMultipleInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.MULTIPLE\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxModeTypeInfo.add(RichTextSingleInfo, RichTextMultipleInfo);
            flxInformationText.add(flxInformation, flxModeTypeInfo);
            flxBPUploadFileContainer.add(flxBPUploadFile, flxInformationText);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            var flxBPUploadFileActions = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxBPUploadFileActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBPUploadFileActions.setDefaultUnit(kony.flex.DP);
            var btnBackAck = new kony.ui.Button({
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnBackAck",
                "isVisible": true,
                "left": "0",
                "skin": "slButtonGlossBlue",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.backToUploadedFiles\")",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnUploadAck = new kony.ui.Button({
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnUploadAck",
                "isVisible": true,
                "left": "0",
                "skin": "slButtonGlossBlue",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.uploadNewFile\")",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBPUploadFileActions.add(btnBackAck, btnUploadAck);
            flxContentContainer.add(flxContentHeader, flxDisplayErrorMessage, flxBPUploadFileContainer, flxTerms, flxBPUploadFileActions);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "13dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "icon_close_grey.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopupConfirmation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopupConfirmation",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknflxPopupBg",
                "top": "0",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupConfirmation.setDefaultUnit(kony.flex.DP);
            var flxPopupNew = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "flxPopupNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopupConfirmation.add(flxPopupNew);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPUploadFile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "segmentProps": []
                    },
                    "flxErrorFlow": {
                        "segmentProps": []
                    },
                    "lblDownload": {
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "segmentProps": []
                    },
                    "lblNote": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAckContainer": {
                        "segmentProps": []
                    },
                    "imgTick": {
                        "segmentProps": []
                    },
                    "rTextSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "59.48%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15.10%"
                        },
                        "segmentProps": []
                    },
                    "flxUploadedFileDetails": {
                        "segmentProps": []
                    },
                    "lblFIleName": {
                        "skin": "sb8893d61f294db38ca0567cbecfbaa9",
                        "segmentProps": []
                    },
                    "btnOpenFile": {
                        "skin": "bbSknBtn4176A4SSP15px",
                        "segmentProps": []
                    },
                    "filesFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "CancelPopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CancelPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "CancelPopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "CancelPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPUploadFileContainer": {
                        "segmentProps": []
                    },
                    "flxBPUploadFile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSP42424217px",
                        "text": "23467686990",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblUploadFilesHeader": {
                        "segmentProps": []
                    },
                    "flxBPUploadSeperator1": {
                        "segmentProps": []
                    },
                    "flxBPUpload": {
                        "height": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblProcessingMode": {
                        "segmentProps": []
                    },
                    "ingBatchModeInfo": {
                        "segmentProps": []
                    },
                    "lbxBatchMode": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "txtBatchMode": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "skin": "CopyslTextBox0b8f036a4265846",
                        "text": "Single",
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "imgPlusSign": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14%"
                        },
                        "segmentProps": []
                    },
                    "lblClickUpload": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSupportedFileTypes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDownload": {
                        "i18n_text": "i18n.bulkWireFiles.donwLoadFileInfo",
                        "isVisible": true,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl0e73d8SSP15Px",
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblNote": {
                        "height": {
                            "type": "string",
                            "value": "5%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAckContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgTick": {
                        "segmentProps": []
                    },
                    "flxUploadedFile": {
                        "segmentProps": []
                    },
                    "lblFIleName": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sb8893d61f294db38ca0567cbecfbaa9",
                        "width": {
                            "type": "string",
                            "value": "186dp"
                        },
                        "segmentProps": []
                    },
                    "btnOpenFile": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPVerifyDetails": {
                        "height": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFileNameVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.63%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameVerify": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgFileType": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXLSType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "src": "csv_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "33%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxVerifyUploadDate": {
                        "centerX": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "top": {
                            "type": "number",
                            "value": "60"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.63%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyUploadDateValue": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxFileSize": {
                        "centerX": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "top": {
                            "type": "number",
                            "value": "100"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.63%"
                        },
                        "segmentProps": []
                    },
                    "lblFileSize": {
                        "segmentProps": []
                    },
                    "lblFileSizeValue": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxVerifyProcessingMode": {
                        "centerX": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.63%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyProcessingModeValue": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.63%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyDescription": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "txtFieldDescription": {
                        "focusSkin": "s32d8e5f72de4959b70c4600cc6a923f",
                        "height": {
                            "type": "string",
                            "value": "113px"
                        },
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "padding": [2, 2, 0, 9],
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxBPFileUploadDetails": {
                        "height": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFileNameAck": {
                        "segmentProps": []
                    },
                    "lblFileNameAck": {
                        "segmentProps": []
                    },
                    "lblImageTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXSLAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "csv_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgXLSTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "hoverSkin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxUploadDateAck": {
                        "segmentProps": []
                    },
                    "lblUploadDateAckValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "hoverSkin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxFileSizeAck": {
                        "segmentProps": []
                    },
                    "lblFileSizeValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxDescriptionAck": {
                        "segmentProps": []
                    },
                    "lblDescriptionAck": {
                        "segmentProps": []
                    },
                    "lblDescriptionValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxStatusAck": {
                        "segmentProps": []
                    },
                    "lblStatusAck": {
                        "segmentProps": []
                    },
                    "lblStatusValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Uploaded",
                        "segmentProps": []
                    },
                    "flxBPUploadSeperator2": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CancelPopup.lblHeading": {
                        "text": "Cancel Upload",
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxBPUploadFileActions": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnBackAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "btnUploadAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Back to Uploading Files",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPUploadFile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknlbl424242SSPRegular24px",
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP20Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "23467686990",
                        "segmentProps": []
                    },
                    "flxBPFileUpload": {
                        "segmentProps": []
                    },
                    "flxBPUploadHeader": {
                        "segmentProps": []
                    },
                    "flxBPUploadSeperator1": {
                        "segmentProps": []
                    },
                    "flxErrorFlow": {
                        "segmentProps": []
                    },
                    "flxBPUpload": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "94.97%"
                        },
                        "segmentProps": []
                    },
                    "flxProcessingMode": {
                        "segmentProps": []
                    },
                    "lbxBatchMode": {
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "imgPlusSign": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14%"
                        },
                        "segmentProps": []
                    },
                    "lblClickUpload": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSupportedFileTypes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDownload": {
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "49.86%"
                        },
                        "segmentProps": []
                    },
                    "lblNote": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAckContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgTick": {
                        "segmentProps": []
                    },
                    "lblFIleName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sb8893d61f294db38ca0567cbecfbaa9",
                        "width": {
                            "type": "string",
                            "value": "186dp"
                        },
                        "segmentProps": []
                    },
                    "btnOpenFile": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPVerifyDetails": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.97%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxFileNameVerify": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "48.34%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.67%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFileNameVerify": {
                        "segmentProps": []
                    },
                    "flxImgFileType": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXLSType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVType": {
                        "isVisible": false,
                        "src": "csv_image.png",
                        "segmentProps": []
                    },
                    "lblFileNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxVerifyUploadDate": {
                        "centerX": {
                            "type": "string",
                            "value": "48.34%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "69dp"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyUploadDate": {
                        "segmentProps": []
                    },
                    "lblVerifyUploadDateValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxFileSize": {
                        "centerX": {
                            "type": "string",
                            "value": "48.31%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "113dp"
                        },
                        "segmentProps": []
                    },
                    "lblFileSize": {
                        "segmentProps": []
                    },
                    "lblFileSizeValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxVerifyProcessingMode": {
                        "centerX": {
                            "type": "string",
                            "value": "48.31%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.67%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyProcessingModeValue": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "48.37%"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblVerifyDescription": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "txtFieldDescription": {
                        "focusSkin": "s32d8e5f72de4959b70c4600cc6a923f",
                        "height": {
                            "type": "string",
                            "value": "113dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "270"
                        },
                        "padding": [1, 0, 0, 6],
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": [],
                        "placeholderSkin": ""
                    },
                    "flxBPFileUploadDetails": {
                        "height": {
                            "type": "string",
                            "value": "410dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxFileNameAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFileNameAck": {
                        "segmentProps": []
                    },
                    "lblImageTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXSLAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVAck": {
                        "isVisible": false,
                        "src": "csv_image.png",
                        "segmentProps": []
                    },
                    "imgXLSTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxUploadDateAck": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblUploadDateAckValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxFileSizeAck": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblFileSizeValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxDescriptionAck": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblDescriptionAck": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxStatusAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblStatusAck": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblStatusValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Uploaded",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxBPUploadSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPUploadFormActions": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "centerY": {
                            "type": "string",
                            "value": "-200dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxBPUploadFileActions": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnBackAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                        "segmentProps": []
                    },
                    "btnUploadAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Upload New File",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeaderMain": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366px"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPUploadFileContainer": {
                        "segmentProps": []
                    },
                    "flxBPUploadFile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green_2.png",
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknLabel42424224px",
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP20Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP20Px",
                        "text": "43331575819",
                        "segmentProps": []
                    },
                    "flxBPFileUpload": {
                        "segmentProps": []
                    },
                    "lblUploadFilesHeader": {
                        "segmentProps": []
                    },
                    "flxErrorFlow": {
                        "segmentProps": []
                    },
                    "lblUploadFailMessage": {
                        "text": "Unable to upload the file, verify the file and please try again.",
                        "segmentProps": []
                    },
                    "flxBPUpload": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxProcessingMode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblProcessingMode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "ingBatchModeInfo": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxBatchMode": {
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "imgPlusSign": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14%"
                        },
                        "segmentProps": []
                    },
                    "lblClickUpload": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSupportedFileTypes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDownload": {
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "lblNote": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAckContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgTick": {
                        "segmentProps": []
                    },
                    "flxFileTypeImage": {
                        "segmentProps": []
                    },
                    "lblFIleName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sb8893d61f294db38ca0567cbecfbaa9",
                        "width": {
                            "type": "string",
                            "value": "186dp"
                        },
                        "segmentProps": []
                    },
                    "btnOpenFile": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxBPVerifyDetails": {
                        "height": {
                            "type": "string",
                            "value": "410dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFileNameVerify": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.76%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.97%"
                        },
                        "segmentProps": []
                    },
                    "flxImgFileType": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXLSType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "csv_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxVerifyUploadDate": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.59%"
                        },
                        "top": {
                            "type": "string",
                            "value": "69dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.97%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyUploadDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyUploadDateValue": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxFileSize": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.65%"
                        },
                        "top": {
                            "type": "string",
                            "value": "113dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.97%"
                        },
                        "segmentProps": []
                    },
                    "lblFileSize": {
                        "segmentProps": []
                    },
                    "lblFileSizeValue": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "hoverSkin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxVerifyProcessingMode": {
                        "isVisible": true,
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "lblVerifyProcessingMode": {
                        "segmentProps": []
                    },
                    "lblVerifyProcessingModeValue": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDescription": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.65%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.97%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifyDescription": {
                        "segmentProps": []
                    },
                    "txtFieldDescription": {
                        "focusSkin": "s32d8e5f72de4959b70c4600cc6a923f",
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "padding": [1, 1, 0, 7],
                        "width": {
                            "type": "string",
                            "value": "25.62%"
                        },
                        "segmentProps": []
                    },
                    "flxBPFileUploadDetails": {
                        "height": {
                            "type": "string",
                            "value": "410dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFileNameAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblImageTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgXSLAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCSVAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "csv_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgXLSTypeAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "src": "xls_image.png",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFileNameValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxUploadDateAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblUploadDateAckValue": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxFileSizeAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblFileSizeValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxDescriptionAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxStatusAck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblStatusAck": {
                        "segmentProps": []
                    },
                    "lblStatusValueAck": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Uploaded",
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "centerY": {
                            "type": "string",
                            "value": "-200dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxBPUploadFileActions": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnBackAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                        "segmentProps": []
                    },
                    "btnUploadAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Upload New File",
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "segmentProps": []
                    },
                    "flxPopupConfirmation": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu.imgLogout": {
                    "src": "logout.png"
                },
                "customheader.headermenu.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "text": "Help"
                },
                "filesFormActionsNew.btnBack": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "20px",
                    "top": "0px",
                    "width": "150dp"
                },
                "filesFormActionsNew.btnCancel": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "20px",
                    "top": "0px",
                    "width": "150dp"
                },
                "filesFormActionsNew.btnNext": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "0px",
                    "top": "0px",
                    "width": "150dp"
                },
                "filesFormActionsNew.btnOption": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "20px",
                    "top": "0px",
                    "width": "150dp"
                },
                "filesFormActionsNew.flxButtons": {
                    "left": "2.50%",
                    "right": "",
                    "top": "20dp",
                    "width": "95%"
                },
                "filesFormActionsNew.flxMain": {
                    "centerY": "",
                    "left": "0dp",
                    "top": "0dp"
                },
                "filesFormActionsNew": {
                    "height": "80dp"
                },
                "CancelPopup": {
                    "centerX": "50.00%",
                    "centerY": "50%",
                    "height": "268px",
                    "left": 0,
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1
                },
                "CancelPopup.imgCross": {
                    "height": "15dp"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "13dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "icon_close_grey.png"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxLogout, flxLoading, flxPopupConfirmation);
        };
        return [{
            "addWidgets": addWidgetsfrmBulkPaymentsUploadFile,
            "enabledForIdleTimeout": true,
            "id": "frmBulkPaymentsUploadFile",
            "init": controller.AS_Form_d6a7396990c74ee784d72166bc9dc4bd,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_jf02d943c0574a1fb42b1dfb1304a91d,
            "postShow": controller.AS_Form_hc01c15c7b9c46a0ae080e47f401f16b,
            "preShow": function(eventobject) {
                controller.AS_Form_h5d767e0849944aa98ba037ddd6c1385(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BulkPaymentsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c724b4439f244033b7d23e32387bcd71,
            "retainScrollPosition": true
        }]
    }
});