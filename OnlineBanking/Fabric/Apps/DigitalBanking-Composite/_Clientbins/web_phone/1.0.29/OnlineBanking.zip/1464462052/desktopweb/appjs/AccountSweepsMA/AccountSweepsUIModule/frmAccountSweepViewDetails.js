define("AccountSweepsMA/AccountSweepsUIModule/frmAccountSweepViewDetails", function() {
    return function(controller) {
        function addWidgetsfrmAccountSweepViewDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountSweepViewDetails"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountSweepViewDetails"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.accountSweeps.ViewAccountSweep";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || true;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.accountSweeps.backtoAccountOverview}}",
                "btnBacka11yLabel": "${i18n{i18n.accountSweeps.backtoAccountOverview}}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {
                "maxLength": "100"
            };
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back to Account Overview"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45%",
                "id": "flAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "-27dp",
                "width": "250dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flAccount.setDefaultUnit(kony.flex.DP);
            var lblBackIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBackIcon",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblFontIcon4176A415px",
                "text": "R",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackoption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBackoption",
                "isVisible": true,
                "left": "8%",
                "skin": "sknSSP4176a415px",
                "text": "Back to Account Overview",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flAccount.add(lblBackIcon, lblBackoption);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblHeader",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknLabelSSPBold42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.accountSweepDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(flAccount, lblHeader);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeparator.add();
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxConfirmDetail1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail1.setDefaultUnit(kony.flex.DP);
            var flxKey1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "22%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey1.setDefaultUnit(kony.flex.DP);
            var lblKey1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.primaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey1.add(lblKey1);
            var flxValue1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue1.setDefaultUnit(kony.flex.DP);
            var lblValue1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue1.add(lblValue1);
            flxConfirmDetail1.add(flxKey1, flxValue1);
            var flxConfirmDetail2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail2.setDefaultUnit(kony.flex.DP);
            var flxKey2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey2.setDefaultUnit(kony.flex.DP);
            var lblKey2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.secondaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey2.add(lblKey2);
            var flxValue2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue2.setDefaultUnit(kony.flex.DP);
            var lblValue2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue2.add(lblValue2);
            flxConfirmDetail2.add(flxKey2, flxValue2);
            var flxConfirmDetail3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail3.setDefaultUnit(kony.flex.DP);
            var flxKey3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey3.setDefaultUnit(kony.flex.DP);
            var lblKey3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey3",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.sweepConditionWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey3.add(lblKey3);
            var flxValue3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue3.setDefaultUnit(kony.flex.DP);
            var lblValue3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue3",
                "isVisible": true,
                "left": "0",
                "skin": "bblblskn424242Bold",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxCondition = new kony.ui.RichText({
                "id": "rtxCondition",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoth = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBoth",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoth.setDefaultUnit(kony.flex.DP);
            var flxConditionBelow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionBelow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionBelow.setDefaultUnit(kony.flex.DP);
            var flxPoint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPoint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint.setDefaultUnit(kony.flex.DP);
            flxPoint.add();
            var rtxSweepCond = new kony.ui.RichText({
                "id": "rtxSweepCond",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionBelow.add(flxPoint, rtxSweepCond);
            var flxConditionAbove = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionAbove.setDefaultUnit(kony.flex.DP);
            var flxPointAbove = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPointAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPointAbove.setDefaultUnit(kony.flex.DP);
            flxPointAbove.add();
            var rtxSweepCondAbove = new kony.ui.RichText({
                "id": "rtxSweepCondAbove",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionAbove.add(flxPointAbove, rtxSweepCondAbove);
            flxBoth.add(flxConditionBelow, flxConditionAbove);
            flxValue3.add(lblValue3, rtxCondition, flxBoth);
            flxConfirmDetail3.add(flxKey3, flxValue3);
            var flxConfirmDetail7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail7.setDefaultUnit(kony.flex.DP);
            var flxKey7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey7.setDefaultUnit(kony.flex.DP);
            var lblKey7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey7",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "text": "Status:",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey7.add(lblKey7);
            var flxValue7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue7",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "24.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue7.setDefaultUnit(kony.flex.DP);
            var lblDot = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "8dp",
                "id": "lblDot",
                "isVisible": true,
                "left": "0%",
                "skin": "lbldotgreen",
                "text": "O",
                "top": "9dp",
                "width": "8dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValue7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue7",
                "isVisible": true,
                "left": "1%",
                "skin": "ICSknLblSSP72727215px",
                "text": "Active",
                "top": "2dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue7.add(lblDot, lblValue7);
            flxConfirmDetail7.add(flxKey7, flxValue7);
            var flxConfirmDetail4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail4.setDefaultUnit(kony.flex.DP);
            var flxKey4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey4.setDefaultUnit(kony.flex.DP);
            var lblKey4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey4",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.frequency\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey4.add(lblKey4);
            var flxValue4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue4.setDefaultUnit(kony.flex.DP);
            var lblValue4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue4",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue4.add(lblValue4);
            flxConfirmDetail4.add(flxKey4, flxValue4);
            var flxConfirmDetail5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail5.setDefaultUnit(kony.flex.DP);
            var flxKey5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey5.setDefaultUnit(kony.flex.DP);
            var lblKey5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey5",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey5.add(lblKey5);
            var flxValue5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue5.setDefaultUnit(kony.flex.DP);
            var lblValue5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue5",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue5.add(lblValue5);
            flxConfirmDetail5.add(flxKey5, flxValue5);
            var flxConfirmDetail6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail6.setDefaultUnit(kony.flex.DP);
            var flxKey6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey6.setDefaultUnit(kony.flex.DP);
            var lblKey6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblKey6",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endDateWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey6.add(lblKey6);
            var flxValue6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue6.setDefaultUnit(kony.flex.DP);
            var lblValue6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblValue6",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue6.add(lblValue6);
            flxConfirmDetail6.add(flxKey6, flxValue6);
            flxMainContent.add(flxConfirmDetail1, flxConfirmDetail2, flxConfirmDetail3, flxConfirmDetail7, flxConfirmDetail4, flxConfirmDetail5, flxConfirmDetail6);
            var flxSectionSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSectionSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "50dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSectionSeparator.setDefaultUnit(kony.flex.DP);
            flxSectionSeparator.add();
            var flxActions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var btnEdit = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Edit account sweep"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "btnEdit",
                "isVisible": true,
                "left": "0",
                "right": "30dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "text": "Edit",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFF4vs"
            });
            var btnDelete = new kony.ui.Button({
                "focusSkin": "sknBtnffffffBorder0273e31pxRadius2px",
                "height": 40,
                "id": "btnDelete",
                "isVisible": true,
                "left": "0",
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountSweep.CancelSweep\")",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder0273e31pxRadius2px"
            });
            flxActions.add(btnEdit, btnDelete);
            flxMainContainer.add(flxHeader, flxHeaderSeparator, flxMainContent, flxSectionSeparator, flxActions);
            formTemplate12.flxContentTCCenter.add(flxMainContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "lblBackoption": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxHeader", "flAccount"]
                    },
                    "flxConfirmDetail1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxConfirmDetail2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxConfirmDetail3": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxConfirmDetail7": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey7": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "flxValue7": {
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "flxConfirmDetail4": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxConfirmDetail5": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxConfirmDetail6": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer"]
                    },
                    "btnEdit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    },
                    "btnDelete": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    }
                },
                "1024": {
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "lblKey7": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7", "flxKey7"]
                    },
                    "flxValue7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "flxKey4": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxActions": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer"]
                    },
                    "btnEdit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    },
                    "btnDelete": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxKey1": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblValue1": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxValue1"]
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "lblKey7": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7", "flxKey7"]
                    },
                    "flxValue7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxActions": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer"]
                    },
                    "btnEdit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    },
                    "btnDelete": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    }
                },
                "1380": {
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "lblKey7": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7", "flxKey7"]
                    },
                    "flxValue7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail7"]
                    },
                    "flxKey4": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxActions": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer"]
                    },
                    "btnEdit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    },
                    "btnDelete": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContainer", "flxActions"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountSweepViewDetails,
            "enabledForIdleTimeout": true,
            "id": "frmAccountSweepViewDetails",
            "init": controller.AS_Form_f10c740843404aaa889b2e10a5912a67,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "View Account Sweep",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AccountSweepsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});