define(function() {
    return function(controller) {
        var PaginationContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "PaginationContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_g9e3ea04a5da40edae9b2988022b7b4d(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ResourcesMA"
        }, controller.args[0], "PaginationContainer"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "PaginationContainer"), extendConfig({}, controller.args[2], "PaginationContainer"));
        PaginationContainer.setDefaultUnit(kony.flex.DP);
        var flxPagination = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "flxPagination",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "top": "0dp",
            "width": "100%",
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPagination"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPagination"), extendConfig({}, controller.args[2], "flxPagination"));
        flxPagination.setDefaultUnit(kony.flex.DP);
        var flxPaginationWrapper = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxPaginationWrapper",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "reverseLayoutDirection": false,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "400dp",
            "zIndex": 1,
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPaginationWrapper"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPaginationWrapper"), extendConfig({}, controller.args[2], "flxPaginationWrapper"));
        flxPaginationWrapper.setDefaultUnit(kony.flex.DP);
        var flxPaginationFirst = new kony.ui.FlexContainer(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "button"
                }
            },
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxPaginationFirst",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "70dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "24dp",
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPaginationFirst"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPaginationFirst"), extendConfig({}, controller.args[2], "flxPaginationFirst"));
        flxPaginationFirst.setDefaultUnit(kony.flex.DP);
        var imgPaginationFirst = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "presentation",
                    "tabindex": -1
                },
                "a11yHidden": true,
                "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.previousPage\")"
            },
            "centerY": "50%",
            "height": "24dp",
            "id": "imgPaginationFirst",
            "imageWhileDownloading": "img_transparent.png",
            "isVisible": true,
            "left": 0,
            "right": "0dp",
            "skin": "slImage",
            "src": "pagination_inactive.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgPaginationFirst"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPaginationFirst"), extendConfig({}, controller.args[2], "imgPaginationFirst"));
        flxPaginationFirst.add(imgPaginationFirst);
        var flxPaginationPrevious = new kony.ui.FlexContainer(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "button"
                }
            },
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "40dp",
            "id": "flxPaginationPrevious",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "40dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0bce4084455184e",
            "top": "0dp",
            "width": "40dp",
            "zIndex": 1,
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPaginationPrevious"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPaginationPrevious"), extendConfig({}, controller.args[2], "flxPaginationPrevious"));
        flxPaginationPrevious.setDefaultUnit(kony.flex.DP);
        var imgPaginationPrevious = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "presentation",
                    "tabindex": -1
                },
                "a11yHidden": true,
                "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.previousPage\")"
            },
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "imgPaginationPrevious",
            "imageWhileDownloading": "img_transparent.png",
            "isVisible": true,
            "skin": "slImage",
            "src": "pagination_back_inactive.png",
            "width": "60%",
            "zIndex": 1
        }, controller.args[0], "imgPaginationPrevious"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPaginationPrevious"), extendConfig({}, controller.args[2], "imgPaginationPrevious"));
        flxPaginationPrevious.add(imgPaginationPrevious);
        var lblPagination = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "1-20 Transactions",
                "tagName": "span"
            },
            "centerY": "50%",
            "height": "20dp",
            "id": "lblPagination",
            "isVisible": true,
            "skin": "bbSknLblSSP15px",
            "text": "10-20 records",
            "width": "30%",
            "zIndex": 1
        }, controller.args[0], "lblPagination"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPagination"), extendConfig({}, controller.args[2], "lblPagination"));
        var flxPaginationNext = new kony.ui.FlexContainer(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "button"
                }
            },
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "40dp",
            "id": "flxPaginationNext",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyslFbox0bce4084455184e",
            "top": "0dp",
            "width": "40dp",
            "zIndex": 1,
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPaginationNext"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPaginationNext"), extendConfig({}, controller.args[2], "flxPaginationNext"));
        flxPaginationNext.setDefaultUnit(kony.flex.DP);
        var imgPaginationNext = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "presentation",
                    "tabindex": -1
                },
                "a11yHidden": true,
                "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.nextPage\")"
            },
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "imgPaginationNext",
            "imageWhileDownloading": "img_transparent.png",
            "isVisible": true,
            "skin": "slImage",
            "src": "pagination_next_active_container.png",
            "width": "60%",
            "zIndex": 1
        }, controller.args[0], "imgPaginationNext"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPaginationNext"), extendConfig({}, controller.args[2], "imgPaginationNext"));
        flxPaginationNext.add(imgPaginationNext);
        var flxPaginationLast = new kony.ui.FlexContainer(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "button"
                }
            },
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxPaginationLast",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "10dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "24dp",
            "appName": "ResourcesMA"
        }, controller.args[0], "flxPaginationLast"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPaginationLast"), extendConfig({}, controller.args[2], "flxPaginationLast"));
        flxPaginationLast.setDefaultUnit(kony.flex.DP);
        var imgPaginationLast = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "presentation",
                    "tabindex": -1
                },
                "a11yHidden": true,
                "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.nextPage\")"
            },
            "centerY": "50%",
            "height": "24dp",
            "id": "imgPaginationLast",
            "imageWhileDownloading": "img_transparent.png",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "pagination_last_active.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgPaginationLast"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPaginationLast"), extendConfig({}, controller.args[2], "imgPaginationLast"));
        flxPaginationLast.add(imgPaginationLast);
        flxPaginationWrapper.add(flxPaginationFirst, flxPaginationPrevious, lblPagination, flxPaginationNext, flxPaginationLast);
        flxPagination.add(flxPaginationWrapper);
        PaginationContainer.add(flxPagination);
        PaginationContainer.breakpointResetData = {};
        PaginationContainer.breakpointData = {
            maxBreakpointWidth: 1366,
            "640": {
                "flxPaginationFirst": {
                    "left": {
                        "type": "string",
                        "value": "92dp"
                    },
                    "segmentProps": []
                },
                "flxPaginationPrevious": {
                    "left": {
                        "type": "string",
                        "value": "26dp"
                    },
                    "segmentProps": []
                }
            }
        }
        PaginationContainer.compInstData = {}
        return PaginationContainer;
    }
})