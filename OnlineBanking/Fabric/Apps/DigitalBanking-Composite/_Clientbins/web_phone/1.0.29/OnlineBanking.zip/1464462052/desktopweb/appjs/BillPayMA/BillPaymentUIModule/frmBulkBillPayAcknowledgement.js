define("BillPayMA/BillPaymentUIModule/frmBulkBillPayAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmBulkBillPayAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnSkipNav": {
                        "text": "Skip to Main Content"
                    },
                    "lblHeaderMobile": {
                        "text": "T"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxConfirmContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxConfirmContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "right": "6.20%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmContainer.setDefaultUnit(kony.flex.DP);
            var flxSubConfirmation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubConfirmation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubConfirmation.setDefaultUnit(kony.flex.DP);
            var flxMainBulkPay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainBulkPay",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainBulkPay.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "67px",
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var lblBulkBillPayAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerY": "60%",
                "id": "lblBulkBillPayAcknowledgement",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AcknowledgementBillPay\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxPrintBulkPay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Print details of all transactions"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPrintBulkPay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3.50%",
                "skin": "slFbox",
                "top": "21dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxPrintBulkPay.setDefaultUnit(kony.flex.DP);
            var lblPrintfontIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Print"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "lblPrintfontIcon",
                "isVisible": true,
                "skin": "sknPrintFonticon0273e3",
                "text": "p",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxPrintBulkPay.add(lblPrintfontIcon);
            var flxDownloadBukPay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25dp",
                "id": "flxDownloadBukPay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "21dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxDownloadBukPay.setDefaultUnit(kony.flex.DP);
            var imgDownloadBulk = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Download"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDownloadBulk",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "download_blue.png",
                "width": "18dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Download"
            });
            flxDownloadBukPay.add(imgDownloadBulk);
            flxTop.add(lblBulkBillPayAcknowledgement, flxPrintBulkPay, flxDownloadBukPay);
            var flxSuccessMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50.03%",
                "clipBounds": false,
                "height": "100px",
                "id": "flxSuccessMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuccessMessage.setDefaultUnit(kony.flex.DP);
            var imgAcknowledged = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "47dp",
                "id": "imgAcknowledged",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2.65%",
                "skin": "sknbg2a9e05",
                "src": "success_green.png",
                "top": "15dp",
                "width": "47dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSuccessAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Success! You have paid your bills."
                },
                "centerY": "50%",
                "id": "lblSuccessAcknowledgement",
                "isVisible": true,
                "left": "8.33%",
                "skin": "sknlbl424242SSPRegular24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AcknowledgementMessage\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRefrenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Reference Number"
                },
                "id": "lblRefrenceNumber",
                "isVisible": true,
                "right": "2.25%",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.RefrenceNumber\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRefrenceNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "45423792753"
                },
                "bottom": "18dp",
                "id": "lblRefrenceNumberValue",
                "isVisible": true,
                "right": "2.25%",
                "skin": "sknSSPLight42424228px",
                "text": "45423792753",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuccessMessage.add(imgAcknowledged, lblSuccessAcknowledgement, lblRefrenceNumber, lblRefrenceNumberValue);
            var flxBulkPayContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxBulkPayContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBulkPayContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderbulkpay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxHeaderbulkpay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderbulkpay.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transaction Details",
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblHeading",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TransactionDetails\")",
                "top": "21dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Search"
                },
                "centerY": "50%",
                "height": "47dp",
                "id": "imgSearch",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "30dp",
                "skin": "slImage",
                "src": "search_blue.png",
                "top": "0dp",
                "width": "47dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderbulkpay.add(lblHeading, imgSearch);
            var flxHorizontalLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxd3d3d380op",
                "top": "0",
                "width": "88%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine.add();
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "sknflxF4F4F4shadowd9d9d9",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var CopylblPayee0c25e79c2245546 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Reference Number",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblPayee0c25e79c2245546",
                "isVisible": true,
                "left": "7.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CopylblPaymentAccount0gdfc55e92e1140 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payee",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblPaymentAccount0gdfc55e92e1140",
                "isVisible": true,
                "left": "20%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Payee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CopylblSendOn0ef452faf7aae48 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payment Account",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblSendOn0ef452faf7aae48",
                "isVisible": true,
                "left": "45.30%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CopylblDeliverBy0g589ce171f8942 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Send On",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblDeliverBy0g589ce171f8942",
                "isVisible": true,
                "left": "67.40%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.send_on\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAmount0j19cfcdf7f294a = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Deliver By",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblAmount0j19cfcdf7f294a",
                "isVisible": true,
                "left": "67.40%",
                "right": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DeliverBy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAction0dbf513fb21434f = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblAction0dbf513fb21434f",
                "isVisible": true,
                "right": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.amountlabel\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSubHeader.add(CopylblPayee0c25e79c2245546, CopylblPaymentAccount0gdfc55e92e1140, CopylblSendOn0ef452faf7aae48, CopylblDeliverBy0g589ce171f8942, CopylblAmount0j19cfcdf7f294a, CopylblAction0dbf513fb21434f);
            var flxSubHeaderConfirm = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSubHeaderConfirm",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "sknflxF4F4F4shadowd9d9d9",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeaderConfirm.setDefaultUnit(kony.flex.DP);
            var lblPayeeConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payee"
                },
                "centerY": "50%",
                "id": "lblPayeeConfirm",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Payee\")",
                "top": "21dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblPaymentAccountConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payment Account"
                },
                "centerY": "50%",
                "id": "lblPaymentAccountConfirm",
                "isVisible": true,
                "left": "33.75%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblSendOnConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Send On"
                },
                "centerY": "50%",
                "id": "lblSendOnConfirm",
                "isVisible": true,
                "left": "60.30%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.send_on\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliverByConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Deliver By"
                },
                "centerY": "50%",
                "id": "lblDeliverByConfirm",
                "isVisible": true,
                "left": "76.23%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DeliverBy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount"
                },
                "centerY": "50%",
                "id": "lblAmountConfirm",
                "isVisible": true,
                "right": "0.60%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.amountlabel\")",
                "top": "21dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxSubHeaderConfirm.add(lblPayeeConfirm, lblPaymentAccountConfirm, lblSendOnConfirm, lblDeliverByConfirm, lblAmountConfirm);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxd3d3d380op",
                "top": "0",
                "width": "88%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var segBill = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{
                    "imgAcknowledgement": "",
                    "lblAction": "",
                    "lblAmount": "",
                    "lblDeliverBy": "",
                    "lblEndingBalanceAccount": "",
                    "lblPayee": "",
                    "lblPayeeAddress": "",
                    "lblPayeeIcon": "",
                    "lblPaymentAccount": "",
                    "lblRefernceNumber": "",
                    "lblSendOn": ""
                }],
                "groupCells": false,
                "id": "segBill",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "sknSegfffff",
                "rowSkin": "sknSegfffffshadowfcfcfc",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxHeader"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "d3d3d300",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxHeader": "flxHeader",
                    "flxPayee": "flxPayee",
                    "flxPayeeDetails": "flxPayeeDetails",
                    "flxPayeeIcon": "flxPayeeIcon",
                    "imgAcknowledgement": "imgAcknowledgement",
                    "lblAction": "lblAction",
                    "lblAmount": "lblAmount",
                    "lblDeliverBy": "lblDeliverBy",
                    "lblEndingBalanceAccount": "lblEndingBalanceAccount",
                    "lblPayee": "lblPayee",
                    "lblPayeeAddress": "lblPayeeAddress",
                    "lblPayeeIcon": "lblPayeeIcon",
                    "lblPaymentAccount": "lblPaymentAccount",
                    "lblRefernceNumber": "lblRefernceNumber",
                    "lblSendOn": "lblSendOn"
                },
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHorizontalLine3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxd3d3d380op",
                "top": "0",
                "width": "88%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine3.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine3.add();
            var flxTotalAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxTotalAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknflxf4f4f4br3pxshadowd9d9d9",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmount.setDefaultUnit(kony.flex.DP);
            var lblTotalAmountPaidNVDA = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Total Amount Paid",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblTotalAmountPaidNVDA",
                "isVisible": true,
                "right": "-2dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalAmountPaid\")",
                "width": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHint": "Total Amount Paid",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAmountValue",
                "isVisible": true,
                "right": "30dp",
                "skin": "sknlblSSP42424220px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": ":"
                },
                "centerY": "50%",
                "id": "lblColon",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknSSP72727220Px",
                "text": ":",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalAmountPaid = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "Total Amount Paid"
                },
                "centerY": "50%",
                "id": "lblTotalAmountPaid",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalAmountPaid\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalAmount.add(lblTotalAmountPaidNVDA, lblAmountValue, lblColon, lblTotalAmountPaid);
            var flxHorizontalLine4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxd3d3d380op",
                "top": "0",
                "width": "88%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine4.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine4.add();
            flxBulkPayContainer.add(flxHeaderbulkpay, flxHorizontalLine, flxSubHeader, flxSubHeaderConfirm, flxHorizontalLine2, segBill, flxHorizontalLine3, flxTotalAmount, flxHorizontalLine4);
            var flxbutttons = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "136dp",
                "id": "flxbutttons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxbutttons.setDefaultUnit(kony.flex.DP);
            var btnViewPaymentActivity = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnViewPaymentActivity",
                "isVisible": true,
                "right": "0%",
                "skin": "sknBtnSSPBg0273e3Border0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ViewPaymentActivity\")",
                "width": "18.81%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "View Payment Activity"
            });
            var btnMakeAnotherPayment = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnMakeAnotherPayment",
                "isVisible": true,
                "right": "21.20%",
                "skin": "sknBtnSSPBg0273e3Border0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.MakeAnotherPayment\")",
                "width": "18.81%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Make Another Payment"
            });
            flxbutttons.add(btnViewPaymentActivity, btnMakeAnotherPayment);
            flxMainBulkPay.add(flxTop, flxSuccessMessage, flxBulkPayContainer, flxbutttons);
            flxSubConfirmation.add(flxMainBulkPay);
            flxConfirmContainer.add(flxSubConfirmation);
            flxMain.add(flxConfirmContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1100,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.Quit\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.Areyousureyouwanttoundo\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CustomPopupCancel.btnNo.onClick = controller.AS_Button_e942c681083748d28d0484fd077be946;
            CustomPopupCancel.btnYes.onClick = controller.AS_Button_f1b4fd40fb7b44dfa521340ea6a7f5ad;
            flxCancelPopup.add(CustomPopupCancel);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditionsPopUp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTermsAndConditionsPopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsPopUp.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "650dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Terms & Conditions"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>"
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxTCArabic = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>"
                },
                "bottom": "10dp",
                "id": "rtxTCArabic",
                "isVisible": false,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\n    بالموافقة على أنك قد قرأت هذه الشروط والأحكام واستمرار التسجيل في البيانات الإلكترونية / الإشعارات الإلكترونية ، فإنك تشير إلى موافقتك على جميع الشروط والأحكام والإشعارات الواردة أو المشار إليها في هذا المستند وتقبل المسؤولية عن استخدامك للخدمة. إذا اخترت عدم الموافقة على قراءتك لهذه الشروط والأحكام ، فلن يتم تسجيلك في الخدمة ولن تتحمل أي مسؤولية أخرى تجاه البنك. يخضع الوصول إلى الخدمة واستخدام الخدمة لجميع الدول الفيدرالية المعمول بها. والقوانين واللوائح المحلية. يُحظر تمامًا الاستخدام غير المصرح به للخدمة أو المعلومات التي يتم الوصول إليها عبر الخدمة.\n    <br/>\n    <b> وصف الكشوف الإلكترونية </ b>\n    <br/>\n    يتم تقديم البيانات الإلكترونية لحسابات الإيداع المؤهلة ، مما يسمح لك باستبدال كشف الحساب المرسل (الورقي) بالبريد بإصدار إلكتروني (PDF) يمكنك عرضه أو حفظه على جهاز الكمبيوتر الخاص بك أو طباعته على راحتك. سيتم تسليم أي إشعارات قانونية عادة ما تصاحب البيان المرسل إليك إلكترونيًا. فيما يلي وصف موجز لمختلف ميزات الخدمة ومتطلبات استخدام الخدمة. من وقت لآخر ، يجوز لنا إضافة أو تعديل أو حذف أي ميزة في الخدمة وفقًا لتقديرنا الخاص. يرجى ملاحظة أنه بالتسجيل في كشوفات الحساب الإلكترونية ، لن تتلقى بعد ذلك كشف حساب ورقي بالبريد. ومع ذلك ، سيتاح لك كشف حساب ورقي شهري عند الطلب عن طريق الاتصال بالبنك.\n    <br/>\n    <b> التسجيل في كشوف الحسابات الإلكترونية </ b>\n    <br/>\n    يجب عليك التسجيل أولاً وتصبح عميلاً للخدمات المصرفية عبر الإنترنت لاستخدام الخدمة. يجب عليك قبول هذه الشروط والأحكام لتصبح مستخدمًا مسجلاً في الخدمة. سيتم توفير كشوفاتك الإلكترونية لك عند تسجيل الدخول إلى الخدمة المصرفية عبر الإنترنت الخاصة بالبنك. عند التسجيل للحصول على كشوفات الحساب الإلكترونية:\n    <br/>\nأنت توافق على استلام كشف حسابك المصرفي بصيغة إلكترونية وتفوضنا بتسليم كشف حسابك إلكترونيًا في دورة كشف حساب شهرية. قد لا تتوفر كشوف حسابات العملاء المجمعة.\nسيتم تقديم البيان الخاص بك بتنسيق يمكن قراءته وطباعته وتنزيله. سيكون كشف حسابك الإلكتروني متاحًا للعرض لمدة تصل إلى 12 شهرًا بدءًا من شهر التسجيل. أنت توافق أيضًا على التنازل عن إرسال بيان ورقي بالبريد اعتبارًا من هذا الوقت فصاعدًا. ومع ذلك ، يمكنك رفض الخدمة في أي وقت وتلقي كشوف ورقية بالبريد عن طريق الاتصال بنا لإبلاغنا بطلب الإنهاء الخاص بك. في جميع الأوقات ، سيتاح لك كشف حساب شهري في البنك عند الطلب.\n<br/>\n<b> الحسابات المؤهلة للحصول على كشوف الحسابات الإلكترونية </ b>\n<br/>\nتشمل الحسابات المؤهلة أنواع الحسابات الشخصية أو غير الشخصية التالية: الحسابات الجارية والادخار وحسابات سوق المال التي تحتوي على كشوف حسابات دورية متكررة. سيتم تسجيل جميع الحسابات الجارية وحسابات سوق المال وحسابات التوفير المرتبطة برقم الضمان الاجتماعي أو رقم التعريف الضريبي لصاحب الحساب الأساسي أو الثانوي تلقائيًا في الكشوف الإلكترونية. ستتلقى كشوفات حساب إلكترونية للحسابات التي تختارها عند التسجيل. إذا لم تختر حسابًا ، فستستمر في تلقي كشوف ورقية لهذا الحساب.\n<br/>\nنحتفظ بموجب هذا بالحق وفقًا لتقديرنا المطلق في تقييد الموافقة على الخدمات المنصوص عليها في هذه الاتفاقية أو توفرها والوصول إليها على أي حساب موضوع يتم تقديمه بموجب هذه الاتفاقية إلى الفرد المدرج في سجلات البنك باعتباره الحساب الأساسي فقط. صاحب مثل هذه الحسابات.\nإذا كان أي حساب قمت بتقديم طلب للحصول عليه ووافق عليه البنك لتلقي كشوف الحسابات الإلكترونية هو حساب مشترك ، فيرجى العلم بأن المالك الأساسي أو صاحب الحساب الثانوي فقط كما هو موضح في مستند كشف الحساب هو الذي سيتلقى ويكون قادرًا على الوصول إليه. البيان الإلكتروني لهذا الحساب.\n<br/>\n<b> التسجيل لتسليم كشوف الحسابات الإلكترونية </ b>\n<br/>\nللوصول إلى الخدمة ، يجب عليك تسجيل الدخول إلى خدمتنا المصرفية عبر الإنترنت واختيار ملف التعريف ، ثم ESTATEMENT-EDIT. اتبع التعليمات التي تظهر على الشاشة للتسجيل في كشوف الحسابات الإلكترونية. بالنسبة للحسابات ذات المالكين المتعددين ، يحتاج مالك حساب واحد فقط إلى تسجيل الحساب في الخدمة. قد لا يكون كشف الشهر الحالي متاحًا حتى تاريخ الدورة التالية.\n<br/>\n<b> تغيير في البنود والشروط </ b>\n<br/>\nيحتفظ البنك بالحق في تعديل هذه الاتفاقية في أي وقت. يجب أن تكون أي تعديلات فعالة عندما يتم نشرها على الخدمة. سيتم إخطارك في أقرب وقت ممكن عند إجراء أي تغييرات تؤثر بشكل جوهري على حقوقك ، مثل التغييرات المتعلقة بكيفية الحفاظ على معلوماتك أو استخدامها. تقع على عاتقك مسؤولية مراجعة هذه الاتفاقية بما في ذلك سياسة الخصوصية الخاصة بالبنك لتكون على دراية بأي من هذه التغييرات.\n<br/>\n<b> الإنهاء </ b>\n<br/>\nستكون هذه الاتفاقية سارية المفعول من تاريخ تقديم التسجيل الخاص بك وقبوله من قبل البنك وفي جميع الأوقات أثناء استخدامك للخدمة. يجوز لك أو للبنك إنهاء هذه الاتفاقية واستخدامك للخدمة في أي وقت. بصفتك أحد عملاء البنك ، يحق لك إرسال كشف حساب ورقي إليك عبر البريد بدلاً من كشف الحساب الإلكتروني (eStatement). لإلغاء الاشتراك في خدمة كشف الحساب الإلكتروني للبنك والبدء في استلام كشف حسابك الورقي مرة أخرى ، سوف تتصل بنا على الرقم (605) 698-7621.\n<br/>\n<br/>\n<b> متنوعة </ b>\n<br/>\nإذا تم اعتبار أي بند من أحكام هذه الاتفاقية غير صالح أو غير قابل للتنفيذ بأي شكل من الأشكال ، تظل بقية الأحكام سارية المفعول والتأثير الكامل ولن يتم إبطالها أو تأثرها بأي حال من الأحوال. العناوين هي للإشارة فقط ولا تحدد بأي حال من الأحوال أو تحدد أو تفسر أو تصف نطاق أو مدى هذا القسم. إن فشلنا في التصرف فيما يتعلق بخرق من قبلك أو من قبل الآخرين لا يتنازل عن حقنا في التصرف فيما يتعلق بالانتهاكات اللاحقة أو المماثلة. تمثل هذه الاتفاقية الاتفاقية الوحيدة والحصرية بينك وبين البنك فيما يتعلق بالخدمة وتدمج وتحل محل جميع الاتفاقيات والتفاهمات السابقة والمعاصرة المكتوبة أو الشفهية فيما يتعلق بموضوع هذه الاتفاقية. يجوز للبنك التنازل عن الخدمة ، بما في ذلك هذه الاتفاقية كليًا أو جزئيًا ؛ ومع ذلك ، لا يجوز لك التنازل عن هذه الاتفاقية أو نقلها. في حالة وجود تعارض بين أي بند أو شرط بين هذه الاتفاقية وأي مستند مدرج هنا بالإشارة إلى هذه الاتفاقية ، يجب أن تكون الاتفاقية هي الحاكمة.\nإذا كانت لديك أي أسئلة بخصوص هذه الاتفاقية أو الخدمة ، فيرجى الاتصال بمصرفنا.\nتخضع هذه الخدمة لجميع الشروط والأحكام المنصوص عليها في شروط وأحكام الخدمات المصرفية عبر الإنترنت التي تم توفيرها لك مسبقًا.\n<br/>\n. </style> </p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC, rtxTCArabic);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0a7b5b9eb258749 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0a7b5b9eb258749",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0a7b5b9eb258749.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0a7b5b9eb258749.add();
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0a7b5b9eb258749, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditionsPopUp.add(flxTC);
            flxDialogs.add(flxLogout, flxCancelPopup, flxLoading, flxTermsAndConditionsPopUp);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1388,
                "640": {
                    "customheadernew.btnSkipNav": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "i18n.transfers.Acknowledgement",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubConfirmation": {
                        "segmentProps": []
                    },
                    "flxMainBulkPay": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTop": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBulkPayContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CopylblPayee0c25e79c2245546": {
                        "left": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "segmentProps": []
                    },
                    "CopylblAmount0j19cfcdf7f294a": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CopylblAction0dbf513fb21434f": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "segBill": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountPaidNVDA": {
                        "segmentProps": []
                    },
                    "lblTotalAmountPaid": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxbutttons": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBody": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.btnSkipNav": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSubConfirmation": {
                        "segmentProps": []
                    },
                    "flxMainBulkPay": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTop": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblBulkBillPayAcknowledgement": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrintBulkPay": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxDownloadBukPay": {
                        "right": {
                            "type": "string",
                            "value": "50px"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "11.33%"
                        },
                        "segmentProps": []
                    },
                    "flxBulkPayContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderbulkpay": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopylblPayee0c25e79c2245546": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "text": "Reference #",
                        "segmentProps": []
                    },
                    "CopylblPaymentAccount0gdfc55e92e1140": {
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CopylblSendOn0ef452faf7aae48": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "45.30%"
                        },
                        "segmentProps": []
                    },
                    "CopylblDeliverBy0g589ce171f8942": {
                        "left": {
                            "type": "string",
                            "value": "47.50%"
                        },
                        "segmentProps": []
                    },
                    "CopylblAmount0j19cfcdf7f294a": {
                        "left": {
                            "type": "string",
                            "value": "68.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CopylblAction0dbf513fb21434f": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeaderConfirm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine3": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountPaidNVDA": {
                        "segmentProps": []
                    },
                    "lblAmountValue": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountPaid": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine4": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxbutttons": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnViewPaymentActivity": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "btnMakeAnotherPayment": {
                        "right": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmContainer": {
                        "segmentProps": []
                    },
                    "flxSubConfirmation": {
                        "segmentProps": []
                    },
                    "flxMainBulkPay": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTop": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblBulkBillPayAcknowledgement": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrintBulkPay": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxDownloadBukPay": {
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBulkPayContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderbulkpay": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopylblPayee0c25e79c2245546": {
                        "left": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "text": "Reference #",
                        "segmentProps": []
                    },
                    "CopylblPaymentAccount0gdfc55e92e1140": {
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CopylblSendOn0ef452faf7aae48": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "45.30%"
                        },
                        "segmentProps": []
                    },
                    "CopylblDeliverBy0g589ce171f8942": {
                        "left": {
                            "type": "string",
                            "value": "47.50%"
                        },
                        "segmentProps": []
                    },
                    "CopylblAmount0j19cfcdf7f294a": {
                        "left": {
                            "type": "string",
                            "value": "68.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CopylblAction0dbf513fb21434f": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeaderConfirm": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine3": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountPaidNVDA": {
                        "segmentProps": []
                    },
                    "lblTotalAmountPaid": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine4": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxbutttons": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1388": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmContainer": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxMainBulkPay": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxTop": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblBulkBillPayAcknowledgement": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrintBulkPay": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownloadBukPay": {
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxBulkPayContainer": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderbulkpay": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopylblPayee0c25e79c2245546": {
                        "left": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "text": "Reference #",
                        "segmentProps": []
                    },
                    "CopylblPaymentAccount0gdfc55e92e1140": {
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CopylblSendOn0ef452faf7aae48": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "45.30%"
                        },
                        "segmentProps": []
                    },
                    "CopylblDeliverBy0g589ce171f8942": {
                        "left": {
                            "type": "string",
                            "value": "47.50%"
                        },
                        "segmentProps": []
                    },
                    "CopylblAmount0j19cfcdf7f294a": {
                        "left": {
                            "type": "string",
                            "value": "68.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CopylblAction0dbf513fb21434f": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeaderConfirm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine3": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalAmount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountPaidNVDA": {
                        "segmentProps": []
                    },
                    "lblTotalAmountPaid": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine4": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.btnSkipNav": {
                    "text": "Skip to Main Content"
                },
                "customheadernew.lblHeaderMobile": {
                    "text": "T"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmBulkBillPayAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmBulkBillPayAcknowledgement",
            "init": controller.AS_Form_e8b32a890c3a4f7e940edc614d9607e1,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1388],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});