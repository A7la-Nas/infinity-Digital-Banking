define("SBAdvisoryMA/AcIntelligenceDashboardUIModule/frmCashSimulation", function() {
    return function(controller) {
        function addWidgetsfrmCashSimulation() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmCashSimulation"] && appConfig.componentMetadata["ResourcesMA"]["frmCashSimulation"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.SBAdvisory.smartBankingAdvisor";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxDriverViewDetailsPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDriverViewDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverViewDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxDriverDetailsMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "525dp",
                "id": "flxDriverDetailsMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": 0,
                "width": "700dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverDetailsMain.setDefaultUnit(kony.flex.DP);
            var flxDriverDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDriverDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDriverDetailsHeader = new kony.ui.Label({
                "height": "100%",
                "id": "lblDriverDetailsHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.factorsAffectingYourCashFlow\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "0",
                "width": "20dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var lblClose = new kony.ui.Label({
                "height": "100%",
                "id": "lblClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(lblClose);
            var flxDriverDetailsHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxDriverDetailsHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverDetailsHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxDriverDetailsHeaderSeparator.add();
            flxDriverDetailsHeader.add(lblDriverDetailsHeader, flxClose, flxDriverDetailsHeaderSeparator);
            var flxDriverViewDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "460dp",
                "id": "flxDriverViewDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverViewDetails.setDefaultUnit(kony.flex.DP);
            var segDriverViewDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "data": [
                    [{
                            "imgHeading": "like.png",
                            "lblHeader": "Label"
                        },
                        [{
                            "imgDriver": "",
                            "lblField": "",
                            "lblIndicator": "",
                            "lblPercentage": "",
                            "lblValue": ""
                        }]
                    ],
                    [{
                            "imgHeading": "like.png",
                            "lblHeader": "Label"
                        },
                        [{
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Percentage",
                            "lblValue": "Value"
                        }]
                    ]
                ],
                "groupCells": false,
                "height": "460dp",
                "id": "segDriverViewDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBAdvisoryMA",
                    "friendlyName": "flxDrivers"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBAdvisoryMA",
                    "friendlyName": "flxDriversHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContent": "flxContent",
                    "flxDrivers": "flxDrivers",
                    "flxDriversHeader": "flxDriversHeader",
                    "flxHeading": "flxHeading",
                    "flxIndicator": "flxIndicator",
                    "flxMain": "flxMain",
                    "flxMainContent": "flxMainContent",
                    "imgDriver": "imgDriver",
                    "imgHeading": "imgHeading",
                    "lblField": "lblField",
                    "lblHeader": "lblHeader",
                    "lblIndicator": "lblIndicator",
                    "lblPercentage": "lblPercentage",
                    "lblValue": "lblValue"
                },
                "width": "96%",
                "appName": "SBAdvisoryMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDriverViewDetails.add(segDriverViewDetails);
            flxDriverDetailsMain.add(flxDriverDetailsHeader, flxDriverViewDetails);
            var flxSbaDriversMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "520dp",
                "id": "flxSbaDriversMain",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": 0,
                "width": "700dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSbaDriversMain.setDefaultUnit(kony.flex.DP);
            var flxSbaBusinessHealthDrivers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSbaBusinessHealthDrivers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSbaBusinessHealthDrivers.setDefaultUnit(kony.flex.DP);
            var flxSbaBusinessHealth = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSbaBusinessHealth",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSbaBusinessHealth.setDefaultUnit(kony.flex.DP);
            var flxPopupBusinessHealth = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "160dp",
                "id": "flxPopupBusinessHealth",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "160dp",
                "zIndex": 1,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBusinessHealth.setDefaultUnit(kony.flex.DP);
            var popUpBusinessHealth = new kony.ui.CustomWidget({
                "id": "popUpBusinessHealth",
                "isVisible": true,
                "left": "0dp",
                "top": "0dp",
                "width": "100%",
                "height": "100%",
                "zIndex": 1,
                "clipBounds": false
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "widgetName": "DoughnutChart",
                "customContainerID": "",
                "data": ""
            });
            flxPopupBusinessHealth.add(popUpBusinessHealth);
            var flxBusinessHealthinfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBusinessHealthinfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessHealthinfo.setDefaultUnit(kony.flex.DP);
            var imgBusinessHealth = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgBusinessHealth",
                "imageWhenFailed": "graduation.png",
                "imageWhileDownloading": "graduation.png",
                "isVisible": true,
                "left": "0dp",
                "src": "graduation.png",
                "top": "0dp",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var IblBusinessHealthinfo = new kony.ui.Label({
                "id": "IblBusinessHealthinfo",
                "isVisible": true,
                "left": "35dp",
                "skin": "ICSknLabelSSPBold42424213px",
                "text": "Improve your score by working on things that need improvement (orange capsules). The bar shows the impact of that item so focus on ones that have a long bar.",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBusinessHealthinfo.add(imgBusinessHealth, IblBusinessHealthinfo);
            flxSbaBusinessHealth.add(flxPopupBusinessHealth, flxBusinessHealthinfo);
            flxSbaBusinessHealthDrivers.add(flxSbaBusinessHealth);
            flxSbaDriversMain.add(flxSbaBusinessHealthDrivers);
            flxDriverViewDetailsPopup.add(flxDriverDetailsMain, flxSbaDriversMain);
            formTemplate12.flxContentPopup.add(flxDriverViewDetailsPopup);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxCashFlowInsights = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashFlowInsights",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowInsights.setDefaultUnit(kony.flex.DP);
            var flxTabs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxTabs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabs.setDefaultUnit(kony.flex.DP);
            var btnCashflowPrediction = new kony.ui.Button({
                "height": "50dp",
                "id": "btnCashflowPrediction",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnAccountSummarySelectedmod",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashFlowAndPrediction\")",
                "top": "0",
                "width": "170dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAcReceivable = new kony.ui.Button({
                "height": "50dp",
                "id": "btnAcReceivable",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnAccountSummaryUnselectedTransferFocus",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.accountsReceivable\")",
                "top": "0",
                "width": "170dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAcPayable = new kony.ui.Button({
                "height": "50dp",
                "id": "btnAcPayable",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnAccountSummaryUnselectedTransferFocus",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.accountsPayable\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTabs.add(btnCashflowPrediction, btnAcReceivable, btnAcPayable);
            var flxTabSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTabSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabSeparator.setDefaultUnit(kony.flex.DP);
            flxTabSeparator.add();
            var flxCashFlowContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashFlowContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowContent.setDefaultUnit(kony.flex.DP);
            var flxCashFlowGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "620dp",
                "id": "flxCashFlowGraph",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "20dp",
                "width": "48%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowGraph.setDefaultUnit(kony.flex.DP);
            var flxCashFlowGraphHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxCashFlowGraphHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "5dp",
                "width": "96%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowGraphHeader.setDefaultUnit(kony.flex.DP);
            var lblGraphHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblGraphHeader",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknSSP15pxsemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashFlow\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownLoad = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDownLoad",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "30dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownLoad.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblDownload",
                "isVisible": true,
                "skin": "sknLblOlbFontIcon29327620px",
                "text": "D",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownLoad.add(lblDownload);
            flxCashFlowGraphHeader.add(lblGraphHeader, flxDownLoad);
            var flxCashFlowSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxCashFlowSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowSep.setDefaultUnit(kony.flex.DP);
            flxCashFlowSep.add();
            var flxCashFlowValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxCashFlowValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "98%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowValues.setDefaultUnit(kony.flex.DP);
            var flxMainCashInFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxMainCashInFlow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "width": "30%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainCashInFlow.setDefaultUnit(kony.flex.DP);
            var lblCashInFlowValue = new kony.ui.Label({
                "id": "lblCashInFlowValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$90,124",
                "top": 0,
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCashInFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashInFlow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashInFlow.setDefaultUnit(kony.flex.DP);
            var imgCashInflow = new kony.ui.Image2({
                "height": "12dp",
                "id": "imgCashInflow",
                "isVisible": true,
                "left": "5dp",
                "src": "cashinflow.png",
                "top": "12dp",
                "width": "12dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCashInFlow = new kony.ui.Label({
                "id": "lblCashInFlow",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknSSPRegular72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashInflow\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCashInFlow.add(imgCashInflow, lblCashInFlow);
            flxMainCashInFlow.add(lblCashInFlowValue, flxCashInFlow);
            var flxCashInFlowSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "34dp",
                "id": "flxCashInFlowSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "1dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashInFlowSep.setDefaultUnit(kony.flex.DP);
            flxCashInFlowSep.add();
            var flxMainCashOutFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxMainCashOutFlow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "width": "30%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainCashOutFlow.setDefaultUnit(kony.flex.DP);
            var lblCashOutFlowValue = new kony.ui.Label({
                "id": "lblCashOutFlowValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$ 51,741",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCashOutFow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashOutFow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashOutFow.setDefaultUnit(kony.flex.DP);
            var imgCashOutFlow = new kony.ui.Image2({
                "height": "12dp",
                "id": "imgCashOutFlow",
                "isVisible": true,
                "left": "5dp",
                "src": "cashoutflow.png",
                "top": "12dp",
                "width": "12dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCashOutFlow = new kony.ui.Label({
                "id": "lblCashOutFlow",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknSSPRegular72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOutflow\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCashOutFow.add(imgCashOutFlow, lblCashOutFlow);
            flxMainCashOutFlow.add(lblCashOutFlowValue, flxCashOutFow);
            var flxCashOutFlowSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "34dp",
                "id": "flxCashOutFlowSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "1dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashOutFlowSep.setDefaultUnit(kony.flex.DP);
            flxCashOutFlowSep.add();
            var flxMainCashOnHand = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxMainCashOnHand",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "width": "30%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainCashOnHand.setDefaultUnit(kony.flex.DP);
            var lblCashOnHandValue = new kony.ui.Label({
                "id": "lblCashOnHandValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$ 9,102.58",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCashOnHand = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashOnHand",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashOnHand.setDefaultUnit(kony.flex.DP);
            var imgCashOnHand = new kony.ui.Image2({
                "height": "12dp",
                "id": "imgCashOnHand",
                "isVisible": true,
                "left": "5dp",
                "src": "cfonhandhand.png",
                "top": "12dp",
                "width": "12dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCashOnHand = new kony.ui.Label({
                "id": "lblCashOnHand",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknSSPRegular72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOnHand\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCashOnHand.add(imgCashOnHand, lblCashOnHand);
            flxMainCashOnHand.add(lblCashOnHandValue, flxCashOnHand);
            flxCashFlowValues.add(flxMainCashInFlow, flxCashInFlowSep, flxMainCashOutFlow, flxCashOutFlowSep, flxMainCashOnHand);
            var flxSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20px",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "92%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep.setDefaultUnit(kony.flex.DP);
            flxSep.add();
            var flxPredictiveGraphTimeFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPredictiveGraphTimeFilter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "150dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPredictiveGraphTimeFilter.setDefaultUnit(kony.flex.DP);
            var btnSixMonths = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSixMonths",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBtnAccountSummaryUnselected13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.6Months\")",
                "top": "0",
                "width": "70dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnOneYear = new kony.ui.Button({
                "height": "50dp",
                "id": "btnOneYear",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknBtnAccountSummarySelected13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.1Year\")",
                "top": 0,
                "width": "50dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPredictiveGraphTimeFilter.add(btnSixMonths, btnOneYear);
            var flxCashFlowPredGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "320dp",
                "id": "flxCashFlowPredGraph",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowPredGraph.setDefaultUnit(kony.flex.DP);
            var chartCashFlowPrediction = new com.SBAdvisory.CashFlow.chartCashFlowPrediction({
                "height": "100%",
                "id": "chartCashFlowPrediction",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA",
                "viewType": "chartCashFlowPrediction",
                "overrides": {
                    "chartCashFlowPrediction": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var chartCashFlowPrediction_data = (appConfig.componentMetadata && appConfig.componentMetadata["SBAdvisoryMA"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmCashSimulation"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmCashSimulation"]["chartCashFlowPrediction"]) || {};
            flxCashFlowPredGraph.add(chartCashFlowPrediction);
            var flxCashFlowPredGraphLegend = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashFlowPredGraphLegend",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowPredGraphLegend.setDefaultUnit(kony.flex.DP);
            var flxLegendContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLegendContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendContent.setDefaultUnit(kony.flex.DP);
            var flxLegend = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLegend",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegend.setDefaultUnit(kony.flex.DP);
            var flxPrediction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPrediction",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0",
                "width": "40%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrediction.setDefaultUnit(kony.flex.DP);
            var imgPrediction = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgPrediction",
                "isVisible": true,
                "left": "10dp",
                "src": "prediction.png",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrediction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPrediction",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknSSP15pxsemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashFlowPrediction\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrediction.add(imgPrediction, lblPrediction);
            var flxClosingBal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxClosingBal",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0",
                "width": "40%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClosingBal.setDefaultUnit(kony.flex.DP);
            var imgClosingBal = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgClosingBal",
                "isVisible": true,
                "left": "0",
                "src": "closingbalance.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPredictionCashOnHand = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPredictionCashOnHand",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOnHand\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClosingBal.add(imgClosingBal, lblPredictionCashOnHand);
            flxLegend.add(flxPrediction, flxClosingBal);
            var flxLegendPredSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLegendPredSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "30dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegendPredSeparator.setDefaultUnit(kony.flex.DP);
            flxLegendPredSeparator.add();
            var flxPredictionValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxPredictionValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "15dp",
                "width": "96%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPredictionValues.setDefaultUnit(kony.flex.DP);
            var flxCurrentCashOnHand = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCurrentCashOnHand",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0",
                "width": "150dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrentCashOnHand.setDefaultUnit(kony.flex.DP);
            var lblCurrentCashValue = new kony.ui.Label({
                "id": "lblCurrentCashValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "$ 32,365",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentCashHeading = new kony.ui.Label({
                "id": "lblCurrentCashHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.currentCashHand\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrentCashOnHand.add(lblCurrentCashValue, lblCurrentCashHeading);
            var flxValuesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "27dp",
                "id": "flxValuesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "7dp",
                "width": "1dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValuesSeparator.setDefaultUnit(kony.flex.DP);
            flxValuesSeparator.add();
            var flxProjChange = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxProjChange",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0",
                "width": "170dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProjChange.setDefaultUnit(kony.flex.DP);
            var lblProjChangeValue = new kony.ui.Label({
                "id": "lblProjChangeValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "-$8,045",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblProjChangeHeading = new kony.ui.Label({
                "id": "lblProjChangeHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.projectedChangeIn3Months\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProjChange.add(lblProjChangeValue, lblProjChangeHeading);
            var flxChangeIn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChangeIn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0",
                "width": "140dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeIn.setDefaultUnit(kony.flex.DP);
            var lblChangeInValue = new kony.ui.Label({
                "id": "lblChangeInValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "-33.7%",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChangeInHeading = new kony.ui.Label({
                "id": "lblChangeInHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.changeIn%\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChangeIn.add(lblChangeInValue, lblChangeInHeading);
            flxPredictionValues.add(flxCurrentCashOnHand, flxValuesSeparator, flxProjChange, flxChangeIn);
            flxLegendContent.add(flxLegend, flxLegendPredSeparator, flxPredictionValues);
            flxCashFlowPredGraphLegend.add(flxLegendContent);
            flxCashFlowGraph.add(flxCashFlowGraphHeader, flxCashFlowSep, flxCashFlowValues, flxSep, flxPredictiveGraphTimeFilter, flxCashFlowPredGraph, flxCashFlowPredGraphLegend);
            var flxCashFlowDrivers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "620dp",
                "id": "flxCashFlowDrivers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "20dp",
                "width": "47%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashFlowDrivers.setDefaultUnit(kony.flex.DP);
            var flxDriverHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDriverHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "5dp",
                "width": "96%",
                "zIndex": 2,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverHeader.setDefaultUnit(kony.flex.DP);
            var flxDriverHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxDriverHeading",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDriverHeading.setDefaultUnit(kony.flex.DP);
            var lblDriversHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDriversHeader",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP15pxsemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.factorsAffectingYourCashFlow\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFactorsInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxFactorsInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "width": "20dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFactorsInfo.setDefaultUnit(kony.flex.DP);
            var imgDriversInfo = new kony.ui.Image2({
                "height": "100%",
                "id": "imgDriversInfo",
                "isVisible": true,
                "src": "info_293276.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFactorsInfo.add(imgDriversInfo);
            flxDriverHeading.add(lblDriversHeader, flxFactorsInfo);
            var btnShowAll = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "ICSknBtn0i42ed7ea22994813px",
                "id": "btnShowAll",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknBtn0i42ed7ea22994813px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Notifications&Messages.ShowAll\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFactorInfoMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "220dp",
                "id": "flxFactorInfoMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "35dp",
                "width": "460dp",
                "zIndex": 10,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFactorInfoMsg.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblParameters = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblParameters",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl42424215pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.howToReadTheParameters\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFactorInfoClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxFactorInfoClose",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "5dp",
                "top": "10dp",
                "width": "30dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFactorInfoClose.setDefaultUnit(kony.flex.DP);
            var lblFactorInfoClose = new kony.ui.Label({
                "height": "100%",
                "id": "lblFactorInfoClose",
                "isVisible": true,
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFactorInfoClose.add(lblFactorInfoClose);
            var flxSepOne = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSepOne",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSepOne.setDefaultUnit(kony.flex.DP);
            flxSepOne.add();
            flxHeader.add(lblParameters, flxFactorInfoClose, flxSepOne);
            var imgFactorAffecting = new kony.ui.Image2({
                "height": "172dp",
                "id": "imgFactorAffecting",
                "imageWhenFailed": "factorsaffectinginfo.png",
                "imageWhileDownloading": "factorsaffectinginfo.png",
                "isVisible": true,
                "left": "0dp",
                "src": "factorsaffectinginfo.png",
                "top": "47dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFactorInfoMsg.add(flxHeader, imgFactorAffecting);
            flxDriverHeader.add(flxDriverHeading, btnShowAll, flxFactorInfoMsg);
            var flxSegDrivers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegDrivers",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "15dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegDrivers.setDefaultUnit(kony.flex.DP);
            var segDrivers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgHeading": "like.png",
                            "lblHeader": "Label"
                        },
                        [{
                            "imgDriver": "",
                            "lblField": "",
                            "lblIndicator": "",
                            "lblPercentage": "Label",
                            "lblValue": ""
                        }]
                    ],
                    [{
                            "imgHeading": "like.png",
                            "lblHeader": "Label"
                        },
                        [{
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }, {
                            "imgDriver": "like.png",
                            "lblField": "Field-",
                            "lblPercentage": "Label",
                            "lblValue": "Value"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segDrivers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBAdvisoryMA",
                    "friendlyName": "flxDrivers"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBAdvisoryMA",
                    "friendlyName": "flxDriversHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContent": "flxContent",
                    "flxDrivers": "flxDrivers",
                    "flxDriversHeader": "flxDriversHeader",
                    "flxHeading": "flxHeading",
                    "flxIndicator": "flxIndicator",
                    "flxMain": "flxMain",
                    "flxMainContent": "flxMainContent",
                    "imgDriver": "imgDriver",
                    "imgHeading": "imgHeading",
                    "lblField": "lblField",
                    "lblHeader": "lblHeader",
                    "lblIndicator": "lblIndicator",
                    "lblPercentage": "lblPercentage",
                    "lblValue": "lblValue"
                },
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegDrivers.add(segDrivers);
            flxCashFlowDrivers.add(flxDriverHeader, flxSegDrivers);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "10dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "650dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            flxCashFlowContent.add(flxCashFlowGraph, flxCashFlowDrivers, flxDummy);
            flxCashFlowInsights.add(flxTabs, flxTabSeparator, flxCashFlowContent);
            var btnShowSimulation = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtn0278eeborder1px",
                "height": "40dp",
                "id": "btnShowSimulation",
                "isVisible": false,
                "skin": "sknBtn0278eeborder1px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.simulateCashFlow\")",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSimulation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulation",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulation.setDefaultUnit(kony.flex.DP);
            var flxSimulationHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSimulationHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationHeader.setDefaultUnit(kony.flex.DP);
            var lblSimulationHeading = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSimulationHeading",
                "isVisible": true,
                "left": "20dp",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.simulateActionPlan\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSimulationHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSimulationHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknflxe3e3e3",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxSimulationHeaderSeparator.add();
            flxSimulationHeader.add(lblSimulationHeading, flxSimulationHeaderSeparator);
            var flxSimulationContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationContent.setDefaultUnit(kony.flex.DP);
            var flxSimulationGraphContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationGraphContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "48%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationGraphContent.setDefaultUnit(kony.flex.DP);
            var flxSimulationGraphValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxSimulationGraphValues",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationGraphValues.setDefaultUnit(kony.flex.DP);
            var flxSimulationValuesContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationValuesContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationValuesContent.setDefaultUnit(kony.flex.DP);
            var flxSimulationValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxSimulationValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationValues.setDefaultUnit(kony.flex.DP);
            var flxSimulationCurrentCashOnHand = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationCurrentCashOnHand",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "161dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationCurrentCashOnHand.setDefaultUnit(kony.flex.DP);
            var lblSimulationCurrentCashValue = new kony.ui.Label({
                "id": "lblSimulationCurrentCashValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "$ 32,365",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulationCurrentCashHeading = new kony.ui.Label({
                "id": "lblSimulationCurrentCashHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.currentCashHand\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulationCurrentCashOnHand.add(lblSimulationCurrentCashValue, lblSimulationCurrentCashHeading);
            var flxSimulationValuesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "27dp",
                "id": "flxSimulationValuesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "7dp",
                "width": "1dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationValuesSeparator.setDefaultUnit(kony.flex.DP);
            flxSimulationValuesSeparator.add();
            var flxSimulationPredBal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationPredBal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0",
                "width": "170dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationPredBal.setDefaultUnit(kony.flex.DP);
            var lblSimulationPredBalValue = new kony.ui.Label({
                "id": "lblSimulationPredBalValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "-$8,045",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulationPredBalHeading = new kony.ui.Label({
                "id": "lblSimulationPredBalHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.predictedBalanceIn3Months\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulationPredBal.add(lblSimulationPredBalValue, lblSimulationPredBalHeading);
            var flxSimulationChangeIn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationChangeIn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0",
                "width": "140dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationChangeIn.setDefaultUnit(kony.flex.DP);
            var lblSimulationChangeInValue = new kony.ui.Label({
                "id": "lblSimulationChangeInValue",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "-33.7%",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulationChangeInHeading = new kony.ui.Label({
                "id": "lblSimulationChangeInHeading",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.changeIn%\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulationChangeIn.add(lblSimulationChangeInValue, lblSimulationChangeInHeading);
            flxSimulationValues.add(flxSimulationCurrentCashOnHand, flxSimulationValuesSeparator, flxSimulationPredBal, flxSimulationChangeIn);
            flxSimulationValuesContent.add(flxSimulationValues);
            flxSimulationGraphValues.add(flxSimulationValuesContent);
            var flxSimulationGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "320dp",
                "id": "flxSimulationGraph",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationGraph.setDefaultUnit(kony.flex.DP);
            var chartCashFlowSimulation = new com.SBAdvisory.CashFlow.chartCashFlowPrediction({
                "height": "100%",
                "id": "chartCashFlowSimulation",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA",
                "viewType": "chartCashFlowSimulation",
                "overrides": {
                    "chartCashFlowPrediction": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {
                    "linechartCashFlowPrediction": {
                        "customContainerID": "cashFlowSimulation"
                    }
                }
            });
            var chartCashFlowSimulation_data = (appConfig.componentMetadata && appConfig.componentMetadata["SBAdvisoryMA"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmCashSimulation"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmCashSimulation"]["chartCashFlowSimulation"]) || {};
            flxSimulationGraph.add(chartCashFlowSimulation);
            var flxSimulationGraphLegend = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxSimulationGraphLegend",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationGraphLegend.setDefaultUnit(kony.flex.DP);
            var flxSimulationLegendContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationLegendContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationLegendContent.setDefaultUnit(kony.flex.DP);
            var flxSimulationLegend = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationLegend",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "185dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationLegend.setDefaultUnit(kony.flex.DP);
            var flxSimulationClosingBal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSimulationClosingBal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0",
                "width": "150dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationClosingBal.setDefaultUnit(kony.flex.DP);
            var imgSimulationClosingBal = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgSimulationClosingBal",
                "isVisible": true,
                "left": "0",
                "src": "closingbalance.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulationCashOnHand = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSimulationCashOnHand",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.closingBalance\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulationClosingBal.add(imgSimulationClosingBal, lblSimulationCashOnHand);
            var flxSimulationPrediction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSimulationPrediction",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationPrediction.setDefaultUnit(kony.flex.DP);
            var imgSimulationPrediction = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgSimulationPrediction",
                "isVisible": true,
                "left": "0",
                "src": "prediction.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulationPrediction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSimulationPrediction",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLabel72727215PxNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.prediction\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulationPrediction.add(imgSimulationPrediction, lblSimulationPrediction);
            flxSimulationLegend.add(flxSimulationClosingBal, flxSimulationPrediction);
            flxSimulationLegendContent.add(flxSimulationLegend);
            flxSimulationGraphLegend.add(flxSimulationLegendContent);
            flxSimulationGraphContent.add(flxSimulationGraphValues, flxSimulationGraph, flxSimulationGraphLegend);
            var flxSimulationParameter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulationParameter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "20dp",
                "top": "20dp",
                "width": "45%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationParameter.setDefaultUnit(kony.flex.DP);
            var flxParameterHeaderContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxParameterHeaderContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameterHeaderContent.setDefaultUnit(kony.flex.DP);
            var flxParameterHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxParameterHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameterHeading.setDefaultUnit(kony.flex.DP);
            var flxParameterMainHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxParameterMainHeading",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameterMainHeading.setDefaultUnit(kony.flex.DP);
            var imgParameterHeading = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgParameterHeading",
                "isVisible": true,
                "src": "warning.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblParameterHeading = new kony.ui.Label({
                "id": "lblParameterHeading",
                "isVisible": true,
                "left": "10dp",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.parametersAffecting\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxParameterMainHeading.add(imgParameterHeading, lblParameterHeading);
            var btnParameterReset = new kony.ui.Button({
                "focusSkin": "ICSknBtn0i42ed7ea22994813px",
                "id": "btnParameterReset",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknBtn0i42ed7ea22994813px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.reset\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxParameterHeading.add(flxParameterMainHeading, btnParameterReset);
            var lblParameterDesc = new kony.ui.Label({
                "id": "lblParameterDesc",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.adjustYourIncome\")",
                "top": "10dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxParameterHeaderContent.add(flxParameterHeading, lblParameterDesc);
            var flxParameterMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxParameterMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameterMainContent.setDefaultUnit(kony.flex.DP);
            var flxParameter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxParameter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameter.setDefaultUnit(kony.flex.DP);
            var flxMainTotalIncome = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainTotalIncome",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainTotalIncome.setDefaultUnit(kony.flex.DP);
            var lblTotalIncome = new kony.ui.Label({
                "id": "lblTotalIncome",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.changeInTheIncome\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputTotalIncome = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputTotalIncome",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputTotalIncome.setDefaultUnit(kony.flex.DP);
            var txtTotalIncome = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtTotalIncome",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxTotalIncomeActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTotalIncomeActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "80dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalIncomeActions.setDefaultUnit(kony.flex.DP);
            var flxTotalIncomeSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTotalIncomeSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalIncomeSub.setDefaultUnit(kony.flex.DP);
            var imgTotalIncomeSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgTotalIncomeSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalIncomeSub.add(imgTotalIncomeSub);
            var flxTotalIncomeAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTotalIncomeAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalIncomeAdd.setDefaultUnit(kony.flex.DP);
            var imgTotalIncomeAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgTotalIncomeAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalIncomeAdd.add(imgTotalIncomeAdd);
            flxTotalIncomeActions.add(flxTotalIncomeSub, flxTotalIncomeAdd);
            flxInputTotalIncome.add(txtTotalIncome, flxTotalIncomeActions);
            flxMainTotalIncome.add(lblTotalIncome, flxInputTotalIncome);
            var flxSubIncome = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubIncome",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubIncome.setDefaultUnit(kony.flex.DP);
            var flxOverTheCounter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOverTheCounter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverTheCounter.setDefaultUnit(kony.flex.DP);
            var lblOverTheCounter = new kony.ui.Label({
                "id": "lblOverTheCounter",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Over the Counter",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputOverTheCounter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputOverTheCounter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputOverTheCounter.setDefaultUnit(kony.flex.DP);
            var txtOverTheCounter = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtOverTheCounter",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxInputOverTheCounterSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputOverTheCounterSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputOverTheCounterSub.setDefaultUnit(kony.flex.DP);
            var imgInputOverTheCounterSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgInputOverTheCounterSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInputOverTheCounterSub.add(imgInputOverTheCounterSub);
            var flxInputOverTheCounterAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputOverTheCounterAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputOverTheCounterAdd.setDefaultUnit(kony.flex.DP);
            var imgInputOverTheCounterAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgInputOverTheCounterAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInputOverTheCounterAdd.add(imgInputOverTheCounterAdd);
            flxInputOverTheCounter.add(txtOverTheCounter, flxInputOverTheCounterSub, flxInputOverTheCounterAdd);
            flxOverTheCounter.add(lblOverTheCounter, flxInputOverTheCounter);
            var flxOnlineSales = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOnlineSales",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOnlineSales.setDefaultUnit(kony.flex.DP);
            var lblOnlineSales = new kony.ui.Label({
                "id": "lblOnlineSales",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Online Sales",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputOnlineSales = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputOnlineSales",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputOnlineSales.setDefaultUnit(kony.flex.DP);
            var txtOnlineSales = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtOnlineSales",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxOnlineSalesSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxOnlineSalesSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOnlineSalesSub.setDefaultUnit(kony.flex.DP);
            var imgOnlineSalesSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgOnlineSalesSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOnlineSalesSub.add(imgOnlineSalesSub);
            var flxOnlineSalesAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxOnlineSalesAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOnlineSalesAdd.setDefaultUnit(kony.flex.DP);
            var imgOnlineSalesAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgOnlineSalesAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOnlineSalesAdd.add(imgOnlineSalesAdd);
            flxInputOnlineSales.add(txtOnlineSales, flxOnlineSalesSub, flxOnlineSalesAdd);
            flxOnlineSales.add(lblOnlineSales, flxInputOnlineSales);
            var flxRent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRent.setDefaultUnit(kony.flex.DP);
            var lblRent = new kony.ui.Label({
                "id": "lblRent",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Rent (sub-let)",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputRent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputRent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputRent.setDefaultUnit(kony.flex.DP);
            var txtRent = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtRent",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxRentSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRentSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRentSub.setDefaultUnit(kony.flex.DP);
            var imgRentSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgRentSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRentSub.add(imgRentSub);
            var flxRentAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRentAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRentAdd.setDefaultUnit(kony.flex.DP);
            var imgRentAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgRentAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRentAdd.add(imgRentAdd);
            flxInputRent.add(txtRent, flxRentSub, flxRentAdd);
            flxRent.add(lblRent, flxInputRent);
            var flxDerivatives = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDerivatives",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDerivatives.setDefaultUnit(kony.flex.DP);
            var lblDerivatives = new kony.ui.Label({
                "id": "lblDerivatives",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Derivatives",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputDerivatives = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputDerivatives",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputDerivatives.setDefaultUnit(kony.flex.DP);
            var txtDerivatives = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtDerivatives",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxDerivativesSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDerivativesSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDerivativesSub.setDefaultUnit(kony.flex.DP);
            var imgDerivativesSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgDerivativesSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDerivativesSub.add(imgDerivativesSub);
            var flxDerivativesAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDerivativesAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDerivativesAdd.setDefaultUnit(kony.flex.DP);
            var imgDerivativesAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgDerivativesAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDerivativesAdd.add(imgDerivativesAdd);
            flxInputDerivatives.add(txtDerivatives, flxDerivativesSub, flxDerivativesAdd);
            flxDerivatives.add(lblDerivatives, flxInputDerivatives);
            flxSubIncome.add(flxOverTheCounter, flxOnlineSales, flxRent, flxDerivatives);
            var btnIncomeShowAll = new kony.ui.Button({
                "focusSkin": "ICSknBtn4176A413PX",
                "height": "20dp",
                "id": "btnIncomeShowAll",
                "isVisible": false,
                "left": "0",
                "skin": "ICSknBtn4176A413PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.showMore\")",
                "top": "20dp",
                "width": "61dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxParameter.add(flxMainTotalIncome, flxSubIncome, btnIncomeShowAll);
            var flxParameterSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxParameterSep",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "20dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxParameterSep.setDefaultUnit(kony.flex.DP);
            flxParameterSep.add();
            var flxTotalExpense = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalExpense",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalExpense.setDefaultUnit(kony.flex.DP);
            var flxMainTotalExpense = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainTotalExpense",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainTotalExpense.setDefaultUnit(kony.flex.DP);
            var lblTotalExpense = new kony.ui.Label({
                "id": "lblTotalExpense",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.changeInTheExpense\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputTotalExpense = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputTotalExpense",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputTotalExpense.setDefaultUnit(kony.flex.DP);
            var txtTotalExpense = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtTotalExpense",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxTotalExpenseSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTotalExpenseSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalExpenseSub.setDefaultUnit(kony.flex.DP);
            var imgTotalExpenseSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgTotalExpenseSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalExpenseSub.add(imgTotalExpenseSub);
            var flxTotalExpenseAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTotalExpenseAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalExpenseAdd.setDefaultUnit(kony.flex.DP);
            var imgTotalExpenseAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgTotalExpenseAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalExpenseAdd.add(imgTotalExpenseAdd);
            flxInputTotalExpense.add(txtTotalExpense, flxTotalExpenseSub, flxTotalExpenseAdd);
            flxMainTotalExpense.add(lblTotalExpense, flxInputTotalExpense);
            var flxSubExpense = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubExpense",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubExpense.setDefaultUnit(kony.flex.DP);
            var flxPayroll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayroll.setDefaultUnit(kony.flex.DP);
            var lblPayroll = new kony.ui.Label({
                "id": "lblPayroll",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Payroll",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputPayroll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputPayroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputPayroll.setDefaultUnit(kony.flex.DP);
            var txtPayroll = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtPayroll",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxPayrollSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPayrollSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayrollSub.setDefaultUnit(kony.flex.DP);
            var imgPayrollSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgPayrollSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayrollSub.add(imgPayrollSub);
            var flxPayrollAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPayrollAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayrollAdd.setDefaultUnit(kony.flex.DP);
            var imgPayrollAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgPayrollAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayrollAdd.add(imgPayrollAdd);
            flxInputPayroll.add(txtPayroll, flxPayrollSub, flxPayrollAdd);
            flxPayroll.add(lblPayroll, flxInputPayroll);
            var flxOfficeLease = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOfficeLease",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOfficeLease.setDefaultUnit(kony.flex.DP);
            var lblOfficeLease = new kony.ui.Label({
                "id": "lblOfficeLease",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Office Lease",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputOfficeLease = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputOfficeLease",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputOfficeLease.setDefaultUnit(kony.flex.DP);
            var txtOfficeLease = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtOfficeLease",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxOfficeLeaseSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxOfficeLeaseSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOfficeLeaseSub.setDefaultUnit(kony.flex.DP);
            var imgOfficeLeaseSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgOfficeLeaseSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOfficeLeaseSub.add(imgOfficeLeaseSub);
            var flxOfficeLeaseAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxOfficeLeaseAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOfficeLeaseAdd.setDefaultUnit(kony.flex.DP);
            var imgOfficeLeaseAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgOfficeLeaseAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOfficeLeaseAdd.add(imgOfficeLeaseAdd);
            flxInputOfficeLease.add(txtOfficeLease, flxOfficeLeaseSub, flxOfficeLeaseAdd);
            flxOfficeLease.add(lblOfficeLease, flxInputOfficeLease);
            var flxStock = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStock",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStock.setDefaultUnit(kony.flex.DP);
            var lblStock = new kony.ui.Label({
                "id": "lblStock",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Stock",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputStock = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputStock",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputStock.setDefaultUnit(kony.flex.DP);
            var txtStock = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtStock",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxStockSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxStockSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStockSub.setDefaultUnit(kony.flex.DP);
            var imgStockSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgStockSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStockSub.add(imgStockSub);
            var flxStockAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxStockAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStockAdd.setDefaultUnit(kony.flex.DP);
            var imgStockAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgStockAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStockAdd.add(imgStockAdd);
            flxInputStock.add(txtStock, flxStockSub, flxStockAdd);
            flxStock.add(lblStock, flxInputStock);
            var flxAdvertising = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvertising",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": 10,
                "width": "349dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvertising.setDefaultUnit(kony.flex.DP);
            var lblAdvertising = new kony.ui.Label({
                "id": "lblAdvertising",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Advertising",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInputAdvertising = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInputAdvertising",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "5dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInputAdvertising.setDefaultUnit(kony.flex.DP);
            var txtAdvertising = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtAdvertising",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "269dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxAdvertisingSub = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAdvertisingSub",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvertisingSub.setDefaultUnit(kony.flex.DP);
            var imgAdvertisingSub = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgAdvertisingSub",
                "isVisible": true,
                "left": "0",
                "src": "minus.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvertisingSub.add(imgAdvertisingSub);
            var flxAdvertisingAdd = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAdvertisingAdd",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "0",
                "width": "40dp",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvertisingAdd.setDefaultUnit(kony.flex.DP);
            var imgAdvertisingAdd = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgAdvertisingAdd",
                "isVisible": true,
                "left": "0",
                "src": "plusicon.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAdvertisingAdd.add(imgAdvertisingAdd);
            flxInputAdvertising.add(txtAdvertising, flxAdvertisingSub, flxAdvertisingAdd);
            flxAdvertising.add(lblAdvertising, flxInputAdvertising);
            flxSubExpense.add(flxPayroll, flxOfficeLease, flxStock, flxAdvertising);
            var btnExpenseShowMore = new kony.ui.Button({
                "focusSkin": "ICSknBtn4176A413PX",
                "height": "20dp",
                "id": "btnExpenseShowMore",
                "isVisible": false,
                "left": "0",
                "skin": "ICSknBtn4176A413PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.showMore\")",
                "top": "20dp",
                "width": "61dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalExpense.add(flxMainTotalExpense, flxSubExpense, btnExpenseShowMore);
            flxParameterMainContent.add(flxParameter, flxParameterSep, flxTotalExpense);
            flxSimulationParameter.add(flxParameterHeaderContent, flxParameterMainContent);
            flxSimulationContent.add(flxSimulationGraphContent, flxSimulationParameter);
            var flxSimulationEndSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSimulationEndSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "10dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationEndSep.setDefaultUnit(kony.flex.DP);
            flxSimulationEndSep.add();
            var flxButtonSimulate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxButtonSimulate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonSimulate.setDefaultUnit(kony.flex.DP);
            var btnSimulateCashFlow = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "ICSknsknBtnSSPffffff15pxBg0273e3",
                "height": "40dp",
                "id": "btnSimulateCashFlow",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknbtnDisablede2e9f036px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.simulateCashFlow\")",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtonSimulate.add(btnSimulateCashFlow);
            flxSimulation.add(flxSimulationHeader, flxSimulationContent, flxSimulationEndSep, flxButtonSimulate);
            flxContainer.add(flxCashFlowInsights, btnShowSimulation, flxSimulation);
            var flxOverview = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxOverview",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverview.setDefaultUnit(kony.flex.DP);
            var segOverview = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "btnLViewBusinessHealth": "View Business Health",
                    "btnLViewDetailedCF": "View Detailed Cash Flow",
                    "btnRViewBusinessHealth": "View Business Health",
                    "btnRViewDetailedCF": "View Detailed Cash Flow",
                    "imgLCashInflow": "cashinflow.png",
                    "imgLCashOnHand": "cfonhandhand.png",
                    "imgLCashOutFlow": "cashoutflow.png",
                    "imgRCashInflow": "cashinflow.png",
                    "imgRCashOnHand": "cfonhandhand.png",
                    "imgRCashOutFlow": "cashoutflow.png",
                    "lblLCashInFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashInflow\")",
                    "lblLCashInFlowValue": "$90,124",
                    "lblLCashOnHand": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOnHand\")",
                    "lblLCashOnHandValue": "$ 9,102.58",
                    "lblLCashOutFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOutflow\")",
                    "lblLCashOutFlowValue": "$ 51,741",
                    "lblLeftBusiness": "Visual Deluxe Inc.",
                    "lblRCashInFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashInflow\")",
                    "lblRCashInFlowValue": "$90,124",
                    "lblRCashOnHand": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOnHand\")",
                    "lblRCashOnHandValue": "$ 9,102.58",
                    "lblRCashOutFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOutflow\")",
                    "lblRCashOutFlowValue": "$ 51,741",
                    "lblRightBusiness": "BM & Associates Graphic Design"
                }, {
                    "btnLViewBusinessHealth": "View Business Health",
                    "btnLViewDetailedCF": "View Detailed Cash Flow",
                    "btnRViewBusinessHealth": "",
                    "btnRViewDetailedCF": "",
                    "imgLCashInflow": "cashinflow.png",
                    "imgLCashOnHand": "cfonhandhand.png",
                    "imgLCashOutFlow": "cashoutflow.png",
                    "imgRCashInflow": "",
                    "imgRCashOnHand": "",
                    "imgRCashOutFlow": "",
                    "lblLCashInFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashInflow\")",
                    "lblLCashInFlowValue": "$90,124",
                    "lblLCashOnHand": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOnHand\")",
                    "lblLCashOnHandValue": "$ 9,102.58",
                    "lblLCashOutFlow": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.cashOutflow\")",
                    "lblLCashOutFlowValue": "$ 51,741",
                    "lblLeftBusiness": "Visual Deluxe Inc.",
                    "lblRCashInFlowValue": "",
                    "lblRCashOnHandValue": "",
                    "lblRCashOutFlowValue": "",
                    "lblRightBusiness": ""
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segOverview",
                "isVisible": true,
                "left": "1%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "segNormalNoBg",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBAdvisoryMA",
                    "friendlyName": "flxOverview"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnLViewBusinessHealth": "btnLViewBusinessHealth",
                    "btnLViewDetailedCF": "btnLViewDetailedCF",
                    "btnRViewBusinessHealth": "btnRViewBusinessHealth",
                    "btnRViewDetailedCF": "btnRViewDetailedCF",
                    "flxCashFlowValues": "flxCashFlowValues",
                    "flxLButtonSep": "flxLButtonSep",
                    "flxLButtons": "flxLButtons",
                    "flxLCashInFlow": "flxLCashInFlow",
                    "flxLCashOnHand": "flxLCashOnHand",
                    "flxLCashOutFow": "flxLCashOutFow",
                    "flxLMainCashInFlow": "flxLMainCashInFlow",
                    "flxLMainCashOnHand": "flxLMainCashOnHand",
                    "flxLMainCashOutFlow": "flxLMainCashOutFlow",
                    "flxLeftBusiness": "flxLeftBusiness",
                    "flxLeftSep": "flxLeftSep",
                    "flxOverview": "flxOverview",
                    "flxOverviewLeft": "flxOverviewLeft",
                    "flxOverviewRight": "flxOverviewRight",
                    "flxRButtonSep": "flxRButtonSep",
                    "flxRCashFlowValues": "flxRCashFlowValues",
                    "flxRCashInFlow": "flxRCashInFlow",
                    "flxRCashOnHand": "flxRCashOnHand",
                    "flxRCashOutFlow": "flxRCashOutFlow",
                    "flxRMainCashInFlow": "flxRMainCashInFlow",
                    "flxRMainCashOnHand": "flxRMainCashOnHand",
                    "flxRMainCashOutFlow": "flxRMainCashOutFlow",
                    "flxRightBusiness": "flxRightBusiness",
                    "flxRightSep": "flxRightSep",
                    "flxTButtons": "flxTButtons",
                    "imgLCashInflow": "imgLCashInflow",
                    "imgLCashOnHand": "imgLCashOnHand",
                    "imgLCashOutFlow": "imgLCashOutFlow",
                    "imgRCashInflow": "imgRCashInflow",
                    "imgRCashOnHand": "imgRCashOnHand",
                    "imgRCashOutFlow": "imgRCashOutFlow",
                    "lblLCashInFlow": "lblLCashInFlow",
                    "lblLCashInFlowValue": "lblLCashInFlowValue",
                    "lblLCashOnHand": "lblLCashOnHand",
                    "lblLCashOnHandValue": "lblLCashOnHandValue",
                    "lblLCashOutFlow": "lblLCashOutFlow",
                    "lblLCashOutFlowValue": "lblLCashOutFlowValue",
                    "lblLeftBusiness": "lblLeftBusiness",
                    "lblRCashInFlow": "lblRCashInFlow",
                    "lblRCashInFlowValue": "lblRCashInFlowValue",
                    "lblRCashOnHand": "lblRCashOnHand",
                    "lblRCashOnHandValue": "lblRCashOnHandValue",
                    "lblRCashOutFlow": "lblRCashOutFlow",
                    "lblRCashOutFlowValue": "lblRCashOutFlowValue",
                    "lblRightBusiness": "lblRightBusiness"
                },
                "width": "98%",
                "appName": "SBAdvisoryMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOverview.add(segOverview);
            flxMainContainer.add(flxContainer, flxOverview);
            formTemplate12.flxContentTCCenter.add(flxMainContainer);
            var flxGoBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxGoBack",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "120dp",
                "zIndex": 9,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoBack.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "20dp",
                "zIndex": 10,
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBack",
                "isVisible": true,
                "left": "0",
                "src": "back_icon_blue.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack);
            var btnGoBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "id": "btnGoBack",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.goBack\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoBack.add(flxBack, btnGoBack);
            var btnEnrol = new kony.ui.Button({
                "focusSkin": "sknBtnSSP0273E314Px",
                "id": "btnEnrol",
                "isVisible": false,
                "right": "25dp",
                "skin": "sknBtnSSP0273E314Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.enrol\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            formTemplate12.flxTCButtons.add(flxGoBack, btnEnrol);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formTemplate12.flxContentTCCenter.flxMainContainer.flxContainer.flxCashFlowInsights.flxCashFlowContent.flxCashFlowGraph.flxCashFlowPredGraph.chartCashFlowPrediction": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formTemplate12.flxContentTCCenter.flxMainContainer.flxContainer.flxSimulation.flxSimulationContent.flxSimulationGraphContent.flxSimulationGraph.chartCashFlowSimulation": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmCashSimulation,
            "enabledForIdleTimeout": true,
            "id": "frmCashSimulation",
            "init": controller.AS_Form_b16fa8140d304ab0a7c86a050c0d21f7,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "SBAdvisoryMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});