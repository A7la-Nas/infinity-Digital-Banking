define("AccountSweepsMA/AccountSweepsUIModule/userfrmPrintController", ["OLBConstants", "FormControllerUtility"], function(OLBConstants, FormControllerUtility) {
    return {
        init: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow;
            this.view.onDeviceBack = function() {};
            this.view.onBreakpointChange = this.onBreakpointChange;
            this.presenter = applicationManager.getModulesPresentationController({
                appName: 'AccountSweepsMA',
                moduleName: 'AccountSweepsUIModule'
            });
        },
        preShow: function() {
            this.constructPrintData()
        },
        postShow: function() {
            var scope = this;
            kony.os.print();
            setTimeout(function() {
                scope.presenter.showView('frmAccountSweepAcknowledgement');
            }, "17ms");
        },
        constructPrintData: function() {
            let data = this.presenter.printData;
            this.view.lblPrimaryAccountValue.text = data.formattedprimaryAccountNumber;
            this.view.lblSecondaryAccountValue.text = data.formattedsecondaryAccountNumber;
            this.view.lblSweepConditionValue.text = data.sweepType;
            this.view.flxBoth.isVisible = data.sweepcondition.visibility;
            this.view.rtxCondition.text = data.sweepcondition.rtxCondition;
            this.view.rtxSweepCond.text = data.sweepcondition.content2;
            this.view.rtxSweepCondAbove.text = data.sweepcondition.content1;
            this.view.lblFrequencyValue.text = data.frequency;
            this.view.lblStartDateValue.text = data.startDate;
            this.view.lblEndDateValue.text = data.endDate;
            this.view.lblReferenceNumberValue.text = data.confirmationNumber;
        },
    };
});
define("AccountSweepsMA/AccountSweepsUIModule/frmPrintControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmPrint **/
    AS_Form_h7a2e8590a184bc8972f8a123b5d8f56: function AS_Form_h7a2e8590a184bc8972f8a123b5d8f56(eventobject) {
        var self = this;
        this.init();
    }
});
define("AccountSweepsMA/AccountSweepsUIModule/frmPrintController", ["AccountSweepsMA/AccountSweepsUIModule/userfrmPrintController", "AccountSweepsMA/AccountSweepsUIModule/frmPrintControllerActions"], function() {
    var controller = require("AccountSweepsMA/AccountSweepsUIModule/userfrmPrintController");
    var controllerActions = ["AccountSweepsMA/AccountSweepsUIModule/frmPrintControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
