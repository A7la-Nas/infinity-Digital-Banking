define(function() {
    return function(controller) {
        var rememberMe = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "rememberMe",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_b8412af146464514be1c58b56c159ba3(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1400],
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "rememberMe"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "rememberMe"), extendConfig({}, controller.args[2], "rememberMe"));
        rememberMe.setDefaultUnit(kony.flex.DP);
        var flxRememberMe = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRememberMe",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "right": "0%",
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxRememberMe"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxRememberMe"), extendConfig({}, controller.args[2], "flxRememberMe"));
        flxRememberMe.setDefaultUnit(kony.flex.DP);
        var flxRemember = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRemember",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": 0,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxRemember"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxRemember"), extendConfig({}, controller.args[2], "flxRemember"));
        flxRemember.setDefaultUnit(kony.flex.DP);
        var lblRememberMe = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Remember Me"
            },
            "id": "lblRememberMe",
            "isVisible": false,
            "left": 0,
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.RememberMe\")",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblRememberMe"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRememberMe"), extendConfig({
            "toolTip": "Remember Me"
        }, controller.args[2], "lblRememberMe"));
        var flexcheckuncheck = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flexcheckuncheck",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "5%",
            "isModalContainer": false,
            "top": "0dp",
            "width": "25dp",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flexcheckuncheck"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flexcheckuncheck"), extendConfig({}, controller.args[2], "flexcheckuncheck"));
        flexcheckuncheck.setDefaultUnit(kony.flex.DP);
        var imgRememberMe = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Checkbox"
            },
            "height": "20dp",
            "id": "imgRememberMe",
            "imageWhileDownloading": "img_transparent_8.png",
            "isVisible": false,
            "left": "0%",
            "skin": "slImage",
            "src": "unchecked_box_2.png",
            "top": "0%",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgRememberMe"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgRememberMe"), extendConfig({}, controller.args[2], "imgRememberMe"));
        var lblFavoriteEmailCheckBox = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Remember me Checkbox"
            },
            "centerX": "50%",
            "id": "lblFavoriteEmailCheckBox",
            "isVisible": true,
            "text": "C",
            "top": 0,
            "width": "25dp",
            "zIndex": 1
        }, controller.args[0], "lblFavoriteEmailCheckBox"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblFavoriteEmailCheckBox"), extendConfig({}, controller.args[2], "lblFavoriteEmailCheckBox"));
        flexcheckuncheck.add(imgRememberMe, lblFavoriteEmailCheckBox);
        flxRemember.add(lblRememberMe, flexcheckuncheck);
        var btnForgotPassword = new kony.ui.Button(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Cant log in?"
            },
            "id": "btnForgotPassword",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknBtnSSP0273E314Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.CantLogin\")",
            "top": "0dp",
            "width": "50%",
            "zIndex": 1
        }, controller.args[0], "btnForgotPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnForgotPassword"), extendConfig({
            "toolTip": "Cant Sign in"
        }, controller.args[2], "btnForgotPassword"));
        flxRememberMe.add(flxRemember, btnForgotPassword);
        rememberMe.add(flxRememberMe);
        rememberMe.compInstData = {}
        return rememberMe;
    }
})