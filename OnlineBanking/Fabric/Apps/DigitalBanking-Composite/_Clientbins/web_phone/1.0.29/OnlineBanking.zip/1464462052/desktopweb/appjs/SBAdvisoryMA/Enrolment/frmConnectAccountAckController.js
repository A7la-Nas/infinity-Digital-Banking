define("SBAdvisoryMA/Enrolment/userfrmConnectAccountAckController", {
    //Type your controller code here 
});
define("SBAdvisoryMA/Enrolment/frmConnectAccountAckControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("SBAdvisoryMA/Enrolment/frmConnectAccountAckController", ["SBAdvisoryMA/Enrolment/userfrmConnectAccountAckController", "SBAdvisoryMA/Enrolment/frmConnectAccountAckControllerActions"], function() {
    var controller = require("SBAdvisoryMA/Enrolment/userfrmConnectAccountAckController");
    var controllerActions = ["SBAdvisoryMA/Enrolment/frmConnectAccountAckControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
