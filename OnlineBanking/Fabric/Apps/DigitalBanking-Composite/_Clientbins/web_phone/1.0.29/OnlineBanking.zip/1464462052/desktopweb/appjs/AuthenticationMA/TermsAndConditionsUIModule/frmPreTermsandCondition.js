define("AuthenticationMA/TermsAndConditionsUIModule/frmPreTermsandCondition", function() {
    return function(controller) {
        function addWidgetsfrmPreTermsandCondition() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxMainLoginBackground0a78d1008cff",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxCloseFontIconParent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "clipBounds": true,
                "height": "45dp",
                "id": "flxCloseFontIconParent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15%",
                "skin": "slFbox",
                "top": "60dp",
                "width": "45dp",
                "zIndex": 20,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseFontIconParent.setDefaultUnit(kony.flex.DP);
            var flxCloseFontIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseFontIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseFontIcon.setDefaultUnit(kony.flex.DP);
            var lblCloseFontIconCommon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "lblCloseFontIconCommon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseFontIcon.add(lblCloseFontIconCommon);
            flxCloseFontIconParent.add(flxCloseFontIcon);
            var flxTandC = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": false,
                "height": "100%",
                "id": "flxTandC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 6,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTandC.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "14%",
                "height": "64dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "80dp",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "13dp",
                "width": "102dp",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWelcome = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "h1"
                },
                "centerX": "50%",
                "id": "lblWelcome",
                "isVisible": true,
                "skin": "sknlblSSP42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.loan.termsandconditions\")",
                "top": "15%",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblWrongInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "It seems that the information you've provided does not match with our records."
                },
                "centerX": "50%",
                "id": "lblWrongInformation",
                "isVisible": false,
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.wrongInfo\")",
                "top": "59.8%",
                "width": "84%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder1",
                "top": "2.21%",
                "width": "68%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "bottom": "10dp",
                "height": "20dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "info.png",
                "top": "15dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "bottom": "15dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "4%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TnC.PleaseAcceptTnC\")",
                "top": "15dp",
                "width": "83%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContent.add(imgDowntimeWarning, lblDowntimeWarning);
            var flxAgree = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAgree",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "68%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAgree.setDefaultUnit(kony.flex.DP);
            var flxLblFontIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "32dp",
                "id": "flxLblFontIcon",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "-1dp",
                "isModalContainer": false,
                "width": "32dp",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblFontIcon.setDefaultUnit(kony.flex.DP);
            var lblFavoriteEmailCheckBox = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblFavoriteEmailCheckBox",
                "isVisible": true,
                "skin": "sknOlbFontsIconse3e3e3",
                "text": "C",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblFontIcon.add(lblFavoriteEmailCheckBox);
            var lblIAccept = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblIAccept",
                "isVisible": true,
                "left": "1%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAccept\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTandC = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnTandC",
                "isVisible": true,
                "left": "1%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": "130dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAgree.add(flxLblFontIcon, lblIAccept, btnTandC);
            var flxGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15%",
                "width": "68%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroup.setDefaultUnit(kony.flex.DP);
            var btnUseMobileApp = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnUseMobileApp",
                "isVisible": false,
                "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.DownloadApp\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnProceed = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnProceed",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            flxGroup.add(btnUseMobileApp, btnProceed);
            flxTandC.add(imgKony, lblWelcome, lblWrongInformation, flxContent, flxAgree, flxGroup);
            var lblCopyrightTab1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "\\u00a9 Copyright Kony Retail Banking. All rights reserved."
                },
                "id": "lblCopyrightTab1",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyrightTab2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Your savings are federally insured to at least $250,000 and backed by the full faith and credit of the Government."
                },
                "id": "lblCopyrightTab2",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab2\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBeyondBanking = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblBeyondBanking",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknSSPLblFFFFFF30Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BeyondBanking\")",
                "top": "250dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBeyondBankingDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "80dp",
                "id": "lblBeyondBankingDesc",
                "isVisible": true,
                "left": "594dp",
                "skin": "sknSSPLblFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BeyondBankingDesc\")",
                "top": "295dp",
                "width": "50%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewMore = new kony.ui.Button({
                "focusSkin": "sknbtn0a78d1viewmoreFocus",
                "height": "40dp",
                "id": "btnViewMore",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknbtn0273e3Viewmore",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.viewMore\")",
                "top": "344dp",
                "width": "130dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooterMenu = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "25dp",
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "42.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "84%",
                "width": "148dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var flxFooterContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxFooterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterContainer.setDefaultUnit(kony.flex.DP);
            var btnLocateUs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnLocateUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxVBar1 = new kony.ui.FlexContainer({
                "centerY": "55%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar1.setDefaultUnit(kony.flex.DP);
            flxVBar1.add();
            var btnContactUs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnContactUs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVBar2 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar2.setDefaultUnit(kony.flex.DP);
            flxVBar2.add();
            var btnPrivacy = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnPrivacy",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.privacy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            var flxVBar3 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 35,
                "isModalContainer": false,
                "right": 1,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar3.setDefaultUnit(kony.flex.DP);
            flxVBar3.add();
            var btnTermsAndConditions = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnTermsAndConditions",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            var flxVBar4 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar4.setDefaultUnit(kony.flex.DP);
            flxVBar4.add();
            var btnFaqs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnFaqs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.faqs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            flxFooterContainer.add(btnLocateUs, flxVBar1, btnContactUs, flxVBar2, btnPrivacy, flxVBar3, btnTermsAndConditions, flxVBar4, btnFaqs);
            flxFooterMenu.add(flxFooterContainer);
            var lblCopyright = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCopyright",
                "isVisible": true,
                "left": "42.50%",
                "skin": "sknLblSSPNormalB5D7F412px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                "top": "90.56%",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxCloseFontIconParent, flxTandC, lblCopyrightTab1, lblCopyrightTab2, lblBeyondBanking, lblBeyondBankingDesc, btnViewMore, flxFooterMenu, lblCopyright);
            var flxLoading = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "300dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnClose = new kony.ui.Button({
                "centerY": "50%",
                "height": "15dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "btnClose",
                "top": "0",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, btnClose, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(rtxTC);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "85%",
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "CopyslFbox0e7e706a6ed2544",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwScroll = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "95%",
                "id": "brwScroll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            brwScroll.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            brwScroll.add(brwBodyTnC);
            flxBody.add(brwScroll);
            var flxSpacing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(flxDummy, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditions.add(flxTC);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1400,
                "640": {
                    "flxCloseFontIconParent": {
                        "right": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxTandC": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcome": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "top": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "2.21%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxAgree": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnTandC": {
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnViewMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "715dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "90%"
                        },
                        "top": {
                            "type": "string",
                            "value": "745dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDummy": {
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "brwScroll": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "768": {
                    "flxCloseFontIconParent": {
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxTandC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcome": {
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "text": "Label fhfhalkhflakfhweifhlf fafhalkfha falfkh",
                        "top": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxAgree": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "855dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnViewMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "820dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "855dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDummy": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "brwScroll": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxTandC": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcome": {
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "top": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "95.5%"
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnViewMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "820dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "brwScroll": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1400": {
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": "455dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "skin": "sknSSPLblFFFFFF30Px",
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "btnViewMore": {
                        "focusSkin": "sknbtn0a78d1viewmoreFocus",
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "skin": "sknbtn0273e3Viewmore",
                        "top": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "hoverSkin": "sknbtn41a0edviewmoreHover",
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "bottom": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "65px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "brwScroll": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxMain, flxLoading, flxTermsAndConditions);
        };
        return [{
            "addWidgets": addWidgetsfrmPreTermsandCondition,
            "enabledForIdleTimeout": true,
            "id": "frmPreTermsandCondition",
            "init": controller.AS_Form_a2c80a0c962840709c0517b19a515bd2,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_idb9387f7fe1448682e71d408a179e32,
            "preShow": function(eventobject) {
                controller.AS_Form_h7b08cec5f0d406eb6f34cc60b4c206e(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "title": "Terms and Conditions",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 768, 1024, 1400],
            "appName": "AuthenticationMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});