define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAddRulesSignatoryGrp", function() {
    return function(controller) {
        function addWidgetsfrmAddRulesSignatoryGrp() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "79%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Settings.ApprovalMatrix.approvalMatrix\")",
                "top": "20dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bulk_billpay_success.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP24px",
                "text": "Approval Rule has been successfully created. ",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgWarningClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgWarningClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "100dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgWarningClose);
            var flxContractContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalMatrixContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "801dp",
                "id": "flxApprovalMatrixContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaxLimitValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblMaxLimitValue",
                "isVisible": true,
                "left": "170dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.add(lblCustomerLevelHeader, lblMaxLimitValue);
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSubDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "110dp",
                "id": "flxSubDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubDetails.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20%",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblErrorMsg = new kony.ui.Label({
                "height": "20dp",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlblff000015px",
                "text": "Value Should be Greater than ",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorValue = new kony.ui.Label({
                "height": "20dp",
                "id": "lblErrorValue",
                "isVisible": true,
                "left": "17.30%",
                "skin": "sknlblff000015px",
                "text": "$ 500",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblErrorMsg, lblErrorValue);
            var flxWarning = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30%",
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var imgWarningImp = new kony.ui.Image2({
                "centerY": "50%",
                "height": "150dp",
                "id": "imgWarningImp",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningImp = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblWarningImp",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(imgWarningImp, lblWarningImp);
            var flxlblDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80%",
                "id": "flxlblDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxlblDetails.setDefaultUnit(kony.flex.DP);
            var flxFeature = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "31.20%",
                "id": "flxFeature",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeature.setDefaultUnit(kony.flex.DP);
            var lblFeatureLabel = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFeatureLabel",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.feature\")",
                "width": "10%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFeatureValue",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeature.add(lblFeatureLabel, lblFeatureValue);
            var flxType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40%",
                "id": "flxType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxType.setDefaultUnit(kony.flex.DP);
            var lblTypeValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTypeValue",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTypeLabel = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTypeLabel",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Type\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxType.add(lblTypeValue, lblTypeLabel);
            var flxAction = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40%",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var lblActionLabel = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblActionLabel",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.actionLevel\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblActionValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblActionValue",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAction.add(lblActionLabel, lblActionValue);
            flxlblDetails.add(flxFeature, flxType, flxAction);
            flxSubDetails.add(flxError, flxWarning, flxlblDetails);
            var lblViewEditHeaderSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblViewEditHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "45dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddRulesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxAddRulesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRulesHeader.setDefaultUnit(kony.flex.DP);
            var lblRange = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transaction Date"
                },
                "centerY": "50%",
                "id": "lblRange",
                "isVisible": true,
                "left": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.range\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRangeLimit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transaction Date"
                },
                "centerY": "50%",
                "id": "lblRangeLimit",
                "isVisible": true,
                "left": "255dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.rangeLimit\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAppRequired = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount"
                },
                "centerY": "50%",
                "id": "lblAppRequired",
                "isVisible": true,
                "right": "420dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAppConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount"
                },
                "centerY": "50%",
                "id": "lblAppConditions",
                "isVisible": true,
                "right": "210dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalcondition\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAction = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Recipients Name"
                },
                "centerY": "50%",
                "id": "lblAction",
                "isVisible": true,
                "right": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblAction\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddRulesHeader.add(lblRange, lblRangeLimit, lblAppRequired, lblAppConditions, lblAction);
            var lblseparator2 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblseparator2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "45dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddRulesWrapper = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "60%",
                "horizontalScrollIndicator": true,
                "id": "flxAddRulesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "46dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRulesWrapper.setDefaultUnit(kony.flex.DP);
            var flxDropdownValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDropdownValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow2",
                "top": "80%",
                "width": "170dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownValues.setDefaultUnit(kony.flex.DP);
            var flxUpto = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUpto",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpto.setDefaultUnit(kony.flex.DP);
            var lblUpto = new kony.ui.Label({
                "id": "lblUpto",
                "isVisible": true,
                "left": 15,
                "skin": "ICSknLbl42424218PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.signatory.upto\")",
                "top": "10dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUpto.add(lblUpto);
            var flxAbove = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAbove",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAbove.setDefaultUnit(kony.flex.DP);
            var lblAbove = new kony.ui.Label({
                "id": "lblAbove",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl42424218PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.signatory.above\")",
                "top": "10dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAbove.add(lblAbove);
            var flxBetween = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBetween",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBetween.setDefaultUnit(kony.flex.DP);
            var lblBetwheen = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblBetwheen",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknLbl42424218PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.signatory.between\")",
                "top": "10dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBetween.add(lblBetwheen);
            flxDropdownValues.add(flxUpto, flxAbove, flxBetween);
            var btnAddRange = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnAddRange",
                "isVisible": true,
                "left": "0",
                "skin": "slButtonGlossBlue",
                "text": "Button",
                "top": "0",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segAddRules = new kony.ui.SegmentedUI2({
                "groupCells": false,
                "height": "240dp",
                "id": "segAddRules",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddRulesWrapper.add(flxDropdownValues, btnAddRange, segAddRules);
            var flxBootomSeparatorApprovePending = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBootomSeparatorApprovePending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBootomSeparatorApprovePending.setDefaultUnit(kony.flex.DP);
            var imgApprovePending = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgApprovePending",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBootomSeparatorApprovePending.add(imgApprovePending);
            var flxBackContainer = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteRule = new kony.ui.Button({
                "centerY": "50%",
                "height": "50dp",
                "id": "btnDeleteRule",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.headerDeleteRule\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnCancel\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnConfirm = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnConfirm",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.confirmAndCreate\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnDeleteRule, btnCancel, btnConfirm);
            flxApprovalMatrixContainer.add(flxHeaderContainer, lblHeaderSeparator, flxSubDetails, lblViewEditHeaderSeparator, flxAddRulesHeader, lblseparator2, flxAddRulesWrapper, flxBootomSeparatorApprovePending, flxBackContainer);
            flxContent.add(lblApprovalMatrixHeader, flxDowntimeWarning, flxContractContainer, flxApprovalMatrixContainer);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "50%",
                        "left": "0dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxConfirmPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxConfirmPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPopup.setDefaultUnit(kony.flex.DP);
            var confirmpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "confirmpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": true
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "right": "20dp",
                        "text": "No",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "text": "Save",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblActionLevelLabel": {
                        "isVisible": true
                    },
                    "lblActionLevelValue": {
                        "isVisible": true
                    },
                    "lblCommnets": {
                        "text": "Comments"
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Popup Header"
                    },
                    "lblPopupMsg": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "text": "The changes will apply to all accounts of the customer, do you want to save?",
                        "top": "22dp",
                        "width": "70%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxConfirmPopup.add(confirmpopup);
            var flxDeletePopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDeletePopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopup.setDefaultUnit(kony.flex.DP);
            var deletepopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "deletepopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                        "right": "20dp",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Delete\")",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblActionLevelLabel": {
                        "isVisible": false
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Popup Header"
                    },
                    "lblPopupMsg": {
                        "text": "Popup Message"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopup.add(deletepopup);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var cancelpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "cancelpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.No\")",
                        "right": "20dp",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Yes\")",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblActionLevelLabel": {
                        "isVisible": false
                    },
                    "lblActionLevelValue": {
                        "isVisible": false
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "30dp"
                    },
                    "lblPopupMsg": {
                        "text": "Are you sure you want to cancel and discard your changes?",
                        "width": "90%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(cancelpopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "deletepopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarningClose": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerHeaderValue": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30%"
                        },
                        "left": {
                            "type": "string",
                            "value": "65%"
                        },
                        "right": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIDValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30%"
                        },
                        "left": {
                            "type": "string",
                            "value": "65%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblContractValue": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderContainer": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblCustomerLevelHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "Create Rule",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblMaxLimitValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "(Max Limit : $ 5000)",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxSubDetails": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "21.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "src": "error_yellow.png",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Add Condition to continue",
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxlblDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureValue": {
                        "left": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "International Transaction",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxType": {
                        "height": {
                            "type": "string",
                            "value": "40%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Per Transaction",
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTypeLabel": {
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "flxAction": {
                        "height": {
                            "type": "string",
                            "value": "31.20%"
                        },
                        "segmentProps": []
                    },
                    "lblActionLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "38.30%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblActionValue": {
                        "centerY": {
                            "type": "string",
                            "value": "39.40%"
                        },
                        "left": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "International Transaction",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblViewEditHeaderSeparator": {
                        "isVisible": true,
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblRange": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblRangeLimit": {
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "width": {
                            "type": "string",
                            "value": "13%"
                        },
                        "segmentProps": []
                    },
                    "lblAppRequired": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "right": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "lblAppConditions": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "7%"
                        },
                        "width": {
                            "type": "string",
                            "value": "19%"
                        },
                        "segmentProps": []
                    },
                    "lblAction": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "lblseparator2": {
                        "isVisible": true,
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRulesWrapper": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdownValues": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "flxUpto": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblUpto": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAbove": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAbove": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "lblBetwheen": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "btnAddRange": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "30"
                        },
                        "skin": "ICSknBtnSSPRegular003E7515Px",
                        "text": "+ Add New Range",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 100,
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "segAddRules": {
                        "data": [{
                            "imgAction": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "delete.png"
                            },
                            "imgChevron": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "arrow_down.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "lblAmtSeparator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "lblAppRequired": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "N/A"
                            },
                            "lblCurrency1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblCurrency2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblDropdown": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Select"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "txtAmount1": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "1234"
                            },
                            "txtAmount2": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "1234"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ApprovalMatrixMA",
                            "friendlyName": "flxICSegAddRulesSigGrpTab"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmt1": "flxAmt1",
                            "flxAmt2": "flxAmt2",
                            "flxCheckbox": "flxCheckbox",
                            "flxChevron": "flxChevron",
                            "flxCondition": "flxCondition",
                            "flxDelete": "flxDelete",
                            "flxDropdownLabel": "flxDropdownLabel",
                            "flxICSegAddRulesSigGrpTab": "flxICSegAddRulesSigGrpTab",
                            "imgAction": "imgAction",
                            "imgChevron": "imgChevron",
                            "imgStatus": "imgStatus",
                            "lblAmtSeparator": "lblAmtSeparator",
                            "lblAppRequired": "lblAppRequired",
                            "lblCurrency1": "lblCurrency1",
                            "lblCurrency2": "lblCurrency2",
                            "lblDropdown": "lblDropdown",
                            "lblSeperator": "lblSeperator",
                            "txtAmount1": "txtAmount1",
                            "txtAmount2": "txtAmount2"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ApprovalMatrixMA"
                    },
                    "flxBootomSeparatorApprovePending": {
                        "height": {
                            "type": "string",
                            "value": "0.20%"
                        },
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxBackContainer": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "lblBottomSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeleteRule": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "63%"
                        },
                        "text": "Delete Rule",
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "33%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "ICSknbtnDisablede2e9f013px",
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxFooter": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "text": "Delete Range",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "text": "Are you sure you want to delete the range?",
                        "width": {
                            "type": "string",
                            "value": "59%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameValue": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblContractValue": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "height": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderContainer": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblCustomerLevelHeader": {
                        "text": "Create rule",
                        "segmentProps": []
                    },
                    "lblMaxLimitValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "(Max Limit : $ 5000)",
                        "segmentProps": []
                    },
                    "flxSubDetails": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "segmentProps": []
                    },
                    "lblErrorValue": {
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "src": "error_yellow.png",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Add Condition to continue",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxlblDetails": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "38.30%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "Feature :",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblFeatureValue": {
                        "centerY": {
                            "type": "string",
                            "value": "39.40%"
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "International Transfer",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxType": {
                        "height": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblTypeValue": {
                        "centerY": {
                            "type": "string",
                            "value": "33.40%"
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Type",
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTypeLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "28.80%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "Type :",
                        "segmentProps": []
                    },
                    "flxAction": {
                        "height": {
                            "type": "string",
                            "value": "40%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblActionLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "24.80%"
                        },
                        "i18n_text": "i18n.approvals.actionLevel",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblActionValue": {
                        "centerY": {
                            "type": "string",
                            "value": "18.40%"
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Account",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblViewEditHeaderSeparator": {
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRange": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblRangeLimit": {
                        "left": {
                            "type": "string",
                            "value": "21%"
                        },
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "lblAppRequired": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "right": {
                            "type": "string",
                            "value": "31.50%"
                        },
                        "text": "Approval Required",
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "lblAppConditions": {
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "lblseparator2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRulesWrapper": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdownValues": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13%"
                        },
                        "zIndex": 500,
                        "segmentProps": []
                    },
                    "flxUpto": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblUpto": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAbove": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAbove": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxBetween": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBetwheen": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "btnAddRange": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBtnSSPRegular003E7515Px",
                        "text": "+ Add New Range",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 100,
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "segAddRules": {
                        "data": [{
                            "imgAction": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bin.png"
                            },
                            "imgChevron": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "arrow_down.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "active.png"
                            },
                            "lblAmtSeparator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "lblAppRequired": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "N/A"
                            },
                            "lblCurrency1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblCurrency2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblDropdown": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Select"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "txtAmount1": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "Value"
                            },
                            "txtAmount2": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "1234"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ApprovalMatrixMA",
                            "friendlyName": "flxICSegAddRulesSigGrp"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmt1": "flxAmt1",
                            "flxAmt2": "flxAmt2",
                            "flxCheckbox": "flxCheckbox",
                            "flxChevron": "flxChevron",
                            "flxCondition": "flxCondition",
                            "flxDelete": "flxDelete",
                            "flxDropdownLabel": "flxDropdownLabel",
                            "flxICSegAddRulesSigGrp": "flxICSegAddRulesSigGrp",
                            "imgAction": "imgAction",
                            "imgChevron": "imgChevron",
                            "imgStatus": "imgStatus",
                            "lblAmtSeparator": "lblAmtSeparator",
                            "lblAppRequired": "lblAppRequired",
                            "lblCurrency1": "lblCurrency1",
                            "lblCurrency2": "lblCurrency2",
                            "lblDropdown": "lblDropdown",
                            "lblSeperator": "lblSeperator",
                            "txtAmount1": "txtAmount1",
                            "txtAmount2": "txtAmount2"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ApprovalMatrixMA"
                    },
                    "flxBootomSeparatorApprovePending": {
                        "height": {
                            "type": "string",
                            "value": "0.10%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBackContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.02%"
                        },
                        "segmentProps": []
                    },
                    "lblBottomSeparator": {
                        "height": {
                            "type": "string",
                            "value": "0.40%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeleteRule": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "425dp"
                        },
                        "text": "Delete Rule",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "btnConfirm": {
                        "skin": "ICSknbtnDisablede2e9f036px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblActionLevelLabel": {
                        "segmentProps": []
                    },
                    "confirmpopup.lblActionLevelValue": {
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "39%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "This is an Account level Feature Action. The changes made will apply to only this account.",
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblActionLevelLabel": {
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete Range",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Are you sure you want to delete the range?",
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblActionLevelLabel": {
                        "segmentProps": []
                    },
                    "cancelpopup.lblActionLevelValue": {
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblContractHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderContainer": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblCustomerLevelHeader": {
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "lblMaxLimitValue": {
                        "left": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "(Max Limit : $1500)",
                        "segmentProps": []
                    },
                    "flxSubDetails": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxError": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "width": {
                            "type": "string",
                            "value": "31%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "src": "error_yellow.png",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarningImp": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Add Condition to continue",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxlblDetails": {
                        "height": {
                            "type": "string",
                            "value": "92dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureLabel": {
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "lblFeatureValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "International transfer",
                        "segmentProps": []
                    },
                    "flxType": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Per Transaction",
                        "segmentProps": []
                    },
                    "lblTypeLabel": {
                        "skin": "sknlbla0a0a015px",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblActionLabel": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "lblActionValue": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "International transfer",
                        "segmentProps": []
                    },
                    "lblViewEditHeaderSeparator": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblRange": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblRangeLimit": {
                        "left": {
                            "type": "string",
                            "value": "21%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblAppRequired": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "right": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "text": "Approval Required",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblAppConditions": {
                        "right": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblAction": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblseparator2": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRulesWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdownValues": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "13%"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "flxUpto": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblUpto": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxAbove": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAbove": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxBetween": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAddRange": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBtnSSPRegular003E7515Px",
                        "text": "+ Add New Range",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 100,
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "segAddRules": {
                        "data": [{
                            "imgAction": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bin.png"
                            },
                            "imgChevron": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "arrow_down.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "active.png"
                            },
                            "lblAmtSeparator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "lblAppRequired": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "N/A"
                            },
                            "lblCurrency1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblCurrency2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$"
                            },
                            "lblDropdown": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Select"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "-"
                            },
                            "txtAmount1": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "Value"
                            },
                            "txtAmount2": {
                                "@class": "com.viz.ide.model.segment.ComplexTextSegmentData",
                                "placeholder": "",
                                "text": "1234"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ApprovalMatrixMA",
                            "friendlyName": "flxICSegAddRulesSigGrp"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAmt1": "flxAmt1",
                            "flxAmt2": "flxAmt2",
                            "flxCheckbox": "flxCheckbox",
                            "flxChevron": "flxChevron",
                            "flxCondition": "flxCondition",
                            "flxDelete": "flxDelete",
                            "flxDropdownLabel": "flxDropdownLabel",
                            "flxICSegAddRulesSigGrp": "flxICSegAddRulesSigGrp",
                            "imgAction": "imgAction",
                            "imgChevron": "imgChevron",
                            "imgStatus": "imgStatus",
                            "lblAmtSeparator": "lblAmtSeparator",
                            "lblAppRequired": "lblAppRequired",
                            "lblCurrency1": "lblCurrency1",
                            "lblCurrency2": "lblCurrency2",
                            "lblDropdown": "lblDropdown",
                            "lblSeperator": "lblSeperator",
                            "txtAmount1": "txtAmount1",
                            "txtAmount2": "txtAmount2"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ApprovalMatrixMA"
                    },
                    "flxBootomSeparatorApprovePending": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "btnDeleteRule": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "38%"
                        },
                        "text": "Delete Rule",
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "skin": "ICSknbtnDisablede2e9f013px",
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "This will effect all the accounts of customer,  are you sure you still want to proceed?",
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete Condition",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Are you sure, you want to delete the 'Between $100 - $ 200'?",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew": {
                    "centerX": "50%",
                    "left": "0dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": ""
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                },
                "confirmpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "confirmpopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "confirmpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "confirmpopup.formActionsNew": {
                    "top": "0dp"
                },
                "confirmpopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "text": "No",
                    "top": ""
                },
                "confirmpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "text": "Save",
                    "top": ""
                },
                "confirmpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "confirmpopup.lblCommnets": {
                    "text": "Comments"
                },
                "confirmpopup.lblHeader": {
                    "left": "30dp",
                    "text": "Popup Header"
                },
                "confirmpopup.lblPopupMsg": {
                    "centerX": "",
                    "centerY": "",
                    "text": "The changes will apply to all accounts of the customer, do you want to save?",
                    "top": "22dp",
                    "width": "70%"
                },
                "confirmpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                },
                "deletepopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "deletepopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "deletepopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "deletepopup.formActionsNew": {
                    "top": "0dp"
                },
                "deletepopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "top": ""
                },
                "deletepopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "top": ""
                },
                "deletepopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "deletepopup.lblHeader": {
                    "left": "30dp",
                    "text": "Popup Header"
                },
                "deletepopup.lblPopupMsg": {
                    "text": "Popup Message"
                },
                "deletepopup.trComments": {
                    "right": "",
                    "top": "12dp"
                },
                "cancelpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "cancelpopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "cancelpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "cancelpopup.formActionsNew": {
                    "top": "0dp"
                },
                "cancelpopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "top": ""
                },
                "cancelpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "top": ""
                },
                "cancelpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "cancelpopup.lblHeader": {
                    "left": "30dp"
                },
                "cancelpopup.lblPopupMsg": {
                    "text": "Are you sure you want to cancel and discard your changes?",
                    "width": "90%"
                },
                "cancelpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxConfirmPopup, flxDeletePopup, flxCancelPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmAddRulesSignatoryGrp,
            "enabledForIdleTimeout": true,
            "id": "frmAddRulesSignatoryGrp",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_h84fc8c91bff4aa0aed9bb074055071f,
            "preShow": function(eventobject) {
                controller.AS_Form_fe64e3ed641249d7ad0b8f9a73722de2(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});