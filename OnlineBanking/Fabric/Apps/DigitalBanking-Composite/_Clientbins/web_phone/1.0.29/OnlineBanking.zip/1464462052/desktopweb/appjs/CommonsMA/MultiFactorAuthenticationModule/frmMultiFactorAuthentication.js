define("CommonsMA/MultiFactorAuthenticationModule/frmMultiFactorAuthentication", function() {
    return function(controller) {
        function addWidgetsfrmMultiFactorAuthentication() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var breadcrumb = new com.InfinityOLB.Resources.breadcrumb({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "52dp",
                "id": "breadcrumb",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "breadcrumb": {
                        "height": "52dp",
                        "isVisible": false,
                        "left": "0dp",
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "flxBreadcrumbcontainer": {
                        "centerX": "50%",
                        "height": "50dp",
                        "top": "1dp",
                        "width": "1366dp"
                    },
                    "flxTopBorder": {
                        "top": "0dp"
                    },
                    "imgBreadcrumb": {
                        "src": "breadcrumb_icon.png"
                    },
                    "imgBreadcrumb2": {
                        "src": "breadcrumb_icon.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknRtx424242SSP17Px",
                "text": "There is some error in the server.\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxLetsAuthenticateModule = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLetsAuthenticateModule",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetsAuthenticateModule.setDefaultUnit(kony.flex.DP);
            var lblLetsAuthenticate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Lets authenticate!"
                },
                "centerX": "50%",
                "id": "lblLetsAuthenticate",
                "isVisible": true,
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.LetsAuthenticate\")",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxOptionToRecieveAccessCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxOptionToRecieveAccessCode",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "right": "6.20%",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "87.73%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptionToRecieveAccessCode.setDefaultUnit(kony.flex.DP);
            var LetsAuthenticateSecureAccessCode = new com.InfinityOLB.Resources.mfa.LetsAuthenticate({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "LetsAuthenticateSecureAccessCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "top": "40dp"
                    },
                    "btnProceed": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                        "left": "viz.val_cleared",
                        "top": "40dp"
                    },
                    "flxCheckboxEmailId": {
                        "top": "21dp"
                    },
                    "flxRegisteredEmailId": {
                        "height": "50dp",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "imgCheckBoxPhoneNo": {
                        "src": "checked_box.png"
                    },
                    "imgCheckboxEmailId": {
                        "src": "checked_box.png"
                    },
                    "lblChangeReceivingMedium": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblCloseBrace": {
                        "top": 16
                    },
                    "lblNoteSecureAccessCode": {
                        "top": "60dp"
                    },
                    "lblOpenBrace": {
                        "left": "5%",
                        "top": 16
                    },
                    "lblRegisteredEmailIDs": {
                        "left": "1%",
                        "top": 16
                    },
                    "lblRegisteredEmailId": {
                        "left": "0.10%",
                        "top": 16
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            LetsAuthenticateSecureAccessCode.flxCheckboxEmailId.onClick = controller.AS_FlexContainer_c3b42674f341405d9c3732b50cb784f3;
            flxOptionToRecieveAccessCode.add(LetsAuthenticateSecureAccessCode);
            var flxSecureAccessCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxSecureAccessCode",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "right": "6.20%",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "87.73%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecureAccessCode.setDefaultUnit(kony.flex.DP);
            var SecureAccessCode = new com.InfinityOLB.Resources.mfa.SecureAccessCode({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "SecureAccessCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "height": "40dp",
                        "top": "40dp"
                    },
                    "btnProceed": {
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "top": "40dp"
                    },
                    "flxActions": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "imgWarning": {
                        "left": "16dp",
                        "src": "error_yellow.png"
                    },
                    "lblResendOption2": {
                        "left": "0.70%",
                        "top": "20dp"
                    },
                    "lblResendOption3": {
                        "left": "0.80%"
                    },
                    "lblSecureAccessCode": {
                        "top": 20
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecureAccessCode.add(SecureAccessCode);
            var flxEnterCVVCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxEnterCVVCode",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "right": "6.20%",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "87.73%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnterCVVCode.setDefaultUnit(kony.flex.DP);
            var EnterCVVModule = new com.InfinityOLB.Resources.mfa.EnterCVVModule({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "EnterCVVModule",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "height": "40dp",
                        "top": "40dp"
                    },
                    "btnProceed": {
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "top": "40dp"
                    },
                    "flxDefaultAccountForSendingInfo": {
                        "isVisible": false
                    },
                    "flxEnterCVVCodeInfo": {
                        "top": "21dp"
                    },
                    "flxEnterCVVCodes": {
                        "top": "10dp"
                    },
                    "imgDefaultAccountForSendingInfo": {
                        "src": "info_grey.png"
                    },
                    "imgEnterCVVCodeInfo": {
                        "src": "info_grey.png"
                    },
                    "imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "imgWarningEnterCVV": {
                        "src": "error_yellow.png"
                    },
                    "lblDefaultAccountForSending": {
                        "text": "Select a Card:",
                        "top": 18
                    },
                    "lblEnterCVVCode": {
                        "top": 18
                    },
                    "lblHeader": {
                        "text": "Choose a Card and Enter CVV"
                    },
                    "lblHeading2": {
                        "text": "jsd"
                    },
                    "lblNoteSecureAccessCode": {
                        "text": "gh"
                    },
                    "lbxDefaultAccountForSending": {
                        "left": "6.40%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            EnterCVVModule.imgViewCVVCode.onTouchEnd = controller.AS_Image_g0db6ac9e74540de9db3c0e123f05090;
            EnterCVVModule.imgViewCVVCode.onTouchStart = controller.AS_Image_c57b68e2aaef4b22a4af5e88e7bfd274;
            flxEnterCVVCode.add(EnterCVVModule);
            var flxAnswerSecurityQuestions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxAnswerSecurityQuestions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "right": "6.20%",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "87.73%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAnswerSecurityQuestions.setDefaultUnit(kony.flex.DP);
            var AnswerSecurityQuestionsModule = new com.InfinityOLB.Resources.mfa.AnswerSecurityQuestionsModule({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AnswerSecurityQuestionsModule",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "height": "40dp",
                        "top": "40dp"
                    },
                    "btnProceed": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                        "left": "viz.val_cleared",
                        "top": "40dp"
                    },
                    "flxAnswerSecurityQuestionsQASet2": {
                        "left": "2.29%"
                    },
                    "imgWarningSecurityQuestions": {
                        "src": "error_yellow.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AnswerSecurityQuestionsModule.tbxAnswers1.onEndEditing = controller.AS_TextField_f4a97ba83dad4449a5b06a9cab771b2c;
            AnswerSecurityQuestionsModule.tbxAnswers1.onKeyUp = controller.AS_TextField_g69571ded423405b9dc951ca48f115e1;
            AnswerSecurityQuestionsModule.tbxAnswers2.onEndEditing = controller.AS_TextField_e078a62143e14ffa9b70000f80946fa6;
            AnswerSecurityQuestionsModule.tbxAnswers2.onKeyUp = controller.AS_TextField_c2223a86ea724db7a29054904f7e4c0e;
            flxAnswerSecurityQuestions.add(AnswerSecurityQuestionsModule);
            flxLetsAuthenticateModule.add(lblLetsAuthenticate, flxOptionToRecieveAccessCode, flxSecureAccessCode, flxEnterCVVCode, flxAnswerSecurityQuestions);
            var InfoPopUpIcon = new com.InfinityOLB.Commons.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "InfoPopUpIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "183dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "245dp",
                "width": "270dp",
                "zIndex": 10,
                "appName": "CommonsMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "183dp",
                        "top": "245dp",
                        "width": "270dp",
                        "zIndex": 10
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.msgInfo\")"
                    },
                    "imgCross": {
                        "src": "icon_close_grey.png"
                    },
                    "imgToolTip": {
                        "left": "49%",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainWrapper.add(flxLetsAuthenticateModule, InfoPopUpIcon);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var TermsAndConditions = new com.InfinityOLB.Commons.BillPay.TermsAndConditions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "appName": "CommonsMA",
                "overrides": {
                    "TermsAndConditions": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp"
                    },
                    "lblTermsAndConditions": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTermsAndConditions.add(TermsAndConditions);
            var flxfootercontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxfootercontainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxfootercontainer.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxleftcontainer.setDefaultUnit(kony.flex.DP);
            flxleftcontainer.add();
            var flxrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "75%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxrightcontainer.setDefaultUnit(kony.flex.DP);
            flxrightcontainer.add();
            flxfootercontainer.add(customfooter, flxleftcontainer, flxrightcontainer);
            flxMain.add(breadcrumb, flxDowntimeWarning, flxMainWrapper, flxTermsAndConditions, flxfootercontainer);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var Copyflxleftcontainer0c2717d3a13cb45 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "Copyflxleftcontainer0c2717d3a13cb45",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            Copyflxleftcontainer0c2717d3a13cb45.setDefaultUnit(kony.flex.DP);
            Copyflxleftcontainer0c2717d3a13cb45.add();
            var Copyflxrightcontainer0c249a43c08314b = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "75%",
                "clipBounds": false,
                "height": "150dp",
                "id": "Copyflxrightcontainer0c249a43c08314b",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            Copyflxrightcontainer0c249a43c08314b.setDefaultUnit(kony.flex.DP);
            Copyflxrightcontainer0c249a43c08314b.add();
            flxFooter.add(CustomFooterMain, Copyflxleftcontainer0c2717d3a13cb45, Copyflxrightcontainer0c249a43c08314b);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Multi Factor Authentication",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "breadcrumb.btnBreadcrumb1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb.flxBreadcrumbcontainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOptionToRecieveAccessCode": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxCheckBoxPhoneNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxCheckboxEmailId": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredEmailId": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredPhoneNo": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblChangeReceivingMedium": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblCloseBrace": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblCloseBracePhoneNo": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblOpenBrace": {
                        "left": {
                            "type": "string",
                            "value": "-250dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblOpenBracePhoneNo": {
                        "left": {
                            "type": "string",
                            "value": "-250dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblPhoneNo": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblRegisteredEmailIDs": {
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblRegisteredEmailId": {
                        "left": {
                            "type": "string",
                            "value": "0.10%"
                        },
                        "top": {
                            "type": "number",
                            "value": "60"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblRegisteredPhoneNo": {
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecureAccessCode": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxEnterCVVCodes": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxResendOption": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "SecureAccessCode.imgWarning": {
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblResendOption1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblResendOption2": {
                        "left": {
                            "type": "string",
                            "value": "0.70%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnterCVVCode": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxDefaultAccountForSending": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxDefaultAccountForSendingInfo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxEnterCVVCodes": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxWarningEnterCVV": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblDefaultAccountForSending": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblEnterCVVCode": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lbxDefaultAccountForSending": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblAnswerSecurityQuestion1": {
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblAnswerSecurityQuestion2": {
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblAnswers1": {
                        "width": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblAnswers2": {
                        "width": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblNoteAnswerSecurityQuestions": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblQuestions1": {
                        "width": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblQuestions2": {
                        "width": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.tbxAnswers1": {
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.tbxAnswers2": {
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditions": {
                        "segmentProps": [],
                        "instanceId": "TermsAndConditions"
                    },
                    "TermsAndConditions.lblTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "breadcrumb.btnBreadcrumb1": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb.flxBreadcrumbcontainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOptionToRecieveAccessCode": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.btnProceed": {
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxCheckBoxPhoneNo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxCheckboxEmailId": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblChangeReceivingMedium": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecureAccessCode": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.btnProceed": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxWarning": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblResendOption1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnterCVVCode": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.btnProceed": {
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxEnterCVVCodes": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxWarningEnterCVV": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblDefaultAccountForSending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblEnterCVVCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "EnterCVVModule.lbxDefaultAccountForSending": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.btnProceed": {
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblNoteAnswerSecurityQuestions": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "InfoPopUpIcon": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "InfoPopUpIcon"
                    },
                    "flxTermsAndConditions": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditions": {
                        "segmentProps": [],
                        "instanceId": "TermsAndConditions"
                    },
                    "TermsAndConditions.lblTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxfootercontainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "centerY": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "breadcrumb.flxBreadcrumbcontainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxOptionToRecieveAccessCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.btnProceed": {
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredEmailId": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredPhoneNo": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblChangeReceivingMedium": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecureAccessCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "SecureAccessCode.btnProceed": {
                        "segmentProps": []
                    },
                    "SecureAccessCode.flxEnterCVVCodes": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblResendOption1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnterCVVCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnterCVVModule.btnProceed": {
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxEnterCVVCodes": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblDefaultAccountForSending": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblEnterCVVCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblNoteSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.btnProceed": {
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblNoteAnswerSecurityQuestions": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "InfoPopUpIcon": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "InfoPopUpIcon"
                    },
                    "flxTermsAndConditions": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditions": {
                        "segmentProps": [],
                        "instanceId": "TermsAndConditions"
                    },
                    "TermsAndConditions.lblTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxfootercontainer": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxOptionToRecieveAccessCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredEmailId": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.flxRegisteredPhoneNo": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "LetsAuthenticateSecureAccessCode.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecureAccessCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblResendOption1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SecureAccessCode.lblSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnterCVVCode": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.73%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxDefaultAccountForSendingInfo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxEnterCVVCodeInfo": {
                        "segmentProps": []
                    },
                    "EnterCVVModule.flxEnterCVVCodes": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblDefaultAccountForSending": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblHeading2": {
                        "text": "",
                        "segmentProps": []
                    },
                    "EnterCVVModule.lblNoteSecureAccessCode": {
                        "text": "",
                        "segmentProps": []
                    },
                    "EnterCVVModule.lbxDefaultAccountForSending": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "29.16%"
                        },
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet1": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AnswerSecurityQuestionsModule.lblNoteAnswerSecurityQuestions": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "InfoPopUpIcon": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "InfoPopUpIcon"
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "breadcrumb": {
                    "height": "52dp",
                    "left": "0dp",
                    "top": "0dp",
                    "zIndex": 1
                },
                "breadcrumb.flxBreadcrumbcontainer": {
                    "centerX": "50%",
                    "height": "50dp",
                    "top": "1dp",
                    "width": "1366dp"
                },
                "breadcrumb.flxTopBorder": {
                    "top": "0dp"
                },
                "breadcrumb.imgBreadcrumb": {
                    "src": "breadcrumb_icon.png"
                },
                "breadcrumb.imgBreadcrumb2": {
                    "src": "breadcrumb_icon.png"
                },
                "LetsAuthenticateSecureAccessCode.btnCancel": {
                    "height": "40dp",
                    "top": "40dp"
                },
                "LetsAuthenticateSecureAccessCode.btnProceed": {
                    "height": "40dp",
                    "left": "",
                    "top": "40dp"
                },
                "LetsAuthenticateSecureAccessCode.flxCheckboxEmailId": {
                    "top": "21dp"
                },
                "LetsAuthenticateSecureAccessCode.flxRegisteredEmailId": {
                    "height": "50dp",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "LetsAuthenticateSecureAccessCode.imgCheckBoxPhoneNo": {
                    "src": "checked_box.png"
                },
                "LetsAuthenticateSecureAccessCode.imgCheckboxEmailId": {
                    "src": "checked_box.png"
                },
                "LetsAuthenticateSecureAccessCode.lblChangeReceivingMedium": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "LetsAuthenticateSecureAccessCode.lblCloseBrace": {
                    "top": 16
                },
                "LetsAuthenticateSecureAccessCode.lblNoteSecureAccessCode": {
                    "top": "60dp"
                },
                "LetsAuthenticateSecureAccessCode.lblOpenBrace": {
                    "left": "5%",
                    "top": 16
                },
                "LetsAuthenticateSecureAccessCode.lblRegisteredEmailIDs": {
                    "left": "1%",
                    "top": 16
                },
                "LetsAuthenticateSecureAccessCode.lblRegisteredEmailId": {
                    "left": "0.10%",
                    "top": 16
                },
                "SecureAccessCode.btnCancel": {
                    "height": "40dp",
                    "top": "40dp"
                },
                "SecureAccessCode.btnProceed": {
                    "height": "40dp",
                    "left": "",
                    "top": "40dp"
                },
                "SecureAccessCode.flxActions": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "SecureAccessCode.imgViewCVVCode": {
                    "src": "view.png"
                },
                "SecureAccessCode.imgWarning": {
                    "left": "16dp",
                    "src": "error_yellow.png"
                },
                "SecureAccessCode.lblResendOption2": {
                    "left": "0.70%",
                    "top": "20dp"
                },
                "SecureAccessCode.lblResendOption3": {
                    "left": "0.80%"
                },
                "SecureAccessCode.lblSecureAccessCode": {
                    "top": 20
                },
                "EnterCVVModule.btnCancel": {
                    "height": "40dp",
                    "top": "40dp"
                },
                "EnterCVVModule.btnProceed": {
                    "height": "40dp",
                    "left": "",
                    "top": "40dp"
                },
                "EnterCVVModule.flxEnterCVVCodeInfo": {
                    "top": "21dp"
                },
                "EnterCVVModule.flxEnterCVVCodes": {
                    "top": "10dp"
                },
                "EnterCVVModule.imgDefaultAccountForSendingInfo": {
                    "src": "info_grey.png"
                },
                "EnterCVVModule.imgEnterCVVCodeInfo": {
                    "src": "info_grey.png"
                },
                "EnterCVVModule.imgViewCVVCode": {
                    "src": "view.png"
                },
                "EnterCVVModule.imgWarningEnterCVV": {
                    "src": "error_yellow.png"
                },
                "EnterCVVModule.lblDefaultAccountForSending": {
                    "text": "Select a Card:",
                    "top": 18
                },
                "EnterCVVModule.lblEnterCVVCode": {
                    "top": 18
                },
                "EnterCVVModule.lblHeader": {
                    "text": "Choose a Card and Enter CVV"
                },
                "EnterCVVModule.lblHeading2": {
                    "text": "jsd"
                },
                "EnterCVVModule.lblNoteSecureAccessCode": {
                    "text": "gh"
                },
                "EnterCVVModule.lbxDefaultAccountForSending": {
                    "left": "6.40%"
                },
                "AnswerSecurityQuestionsModule.btnCancel": {
                    "height": "40dp",
                    "top": "40dp"
                },
                "AnswerSecurityQuestionsModule.btnProceed": {
                    "height": "40dp",
                    "left": "",
                    "top": "40dp"
                },
                "AnswerSecurityQuestionsModule.flxAnswerSecurityQuestionsQASet2": {
                    "left": "2.29%"
                },
                "AnswerSecurityQuestionsModule.imgWarningSecurityQuestions": {
                    "src": "error_yellow.png"
                },
                "InfoPopUpIcon": {
                    "left": "183dp",
                    "top": "245dp",
                    "width": "270dp",
                    "zIndex": 10
                },
                "InfoPopUpIcon.imgCross": {
                    "src": "icon_close_grey.png"
                },
                "InfoPopUpIcon.imgToolTip": {
                    "left": "49%",
                    "src": "tool_tip.png"
                },
                "TermsAndConditions": {
                    "left": "0dp"
                },
                "TermsAndConditions.lblTermsAndConditions": {
                    "centerY": "",
                    "top": "0dp"
                },
                "customfooter": {
                    "centerX": "50%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp"
                },
                "CustomFooterMain": {
                    "centerX": "50%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                }
            }
            this.add(flxHeader, flxMain, flxLoading, flxLogout, flxFooter);
        };
        return [{
            "addWidgets": addWidgetsfrmMultiFactorAuthentication,
            "enabledForIdleTimeout": false,
            "id": "frmMultiFactorAuthentication",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_dccf5a07e82b4b41bc2010a08fb4230f,
            "postShow": controller.AS_Form_e09bd01b514f436ca3150388dcf98856,
            "preShow": function(eventobject) {
                controller.AS_Form_c34ae4197f8b4dda9013487685d7c105(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "CommonsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_h2f574851eea4fe380590de49ff513be,
            "retainScrollPosition": false
        }]
    }
});