define("ArrangementsMA/AccountsUIModule/frmPrintTransfer", function() {
    return function(controller) {
        function addWidgetsfrmPrintTransfer() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPrintTransfer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrintTransfer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "1250px",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrintTransfer.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "70dp",
                "width": "80%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "18px",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "centerY": "50%",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "6.66%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgKony, lblKonyBank);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "< Back"
                },
                "focusSkin": "slButtonGlossRed",
                "id": "btnBack",
                "isVisible": false,
                "left": "6.07%",
                "skin": "Copysknbtnffffff",
                "text": "< Back",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var lblTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Payment"
                },
                "id": "lblTitle",
                "isVisible": true,
                "left": "5%",
                "skin": "sknlbl424242bold17px",
                "text": "Bill Payment",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTransfers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTransfers",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "50%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransfers.setDefaultUnit(kony.flex.DP);
            var segTransfers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segTransfers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CommonsMA",
                    "friendlyName": "flxPrintTransfer"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CommonsMA",
                    "friendlyName": "flxPrintTransferHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPrintTransfer": "flxPrintTransfer",
                    "flxPrintTransferHeader": "flxPrintTransferHeader",
                    "lblHeader": "lblHeader",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransfers.add(segTransfers);
            var flxDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Border9797971pxRadius3px",
                "top": "40dp",
                "width": "80%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisclaimer.setDefaultUnit(kony.flex.DP);
            var rtxDisclaimer = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>"
                },
                "bottom": "10dp",
                "id": "rtxDisclaimer",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>",
                "top": "10px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisclaimer.add(rtxDisclaimer);
            var btnBackBottom = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Back"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50px",
                "id": "btnBackBottom",
                "isVisible": false,
                "left": "79dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "40dp",
                "width": "14.60%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "62dp",
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Kony Bank Pvt. Ltd. Copyright 2017. All rightes reserved."
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Kony Bank Pvt. Ltd. Copyright 2019. All rightes reserved.",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Page 1 of 1"
                },
                "id": "lblPage",
                "isVisible": false,
                "right": "0%",
                "skin": "sknlbl424242bold15px",
                "text": "Page 1 of 1",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight, lblPage);
            flxPrintTransfer.add(flxHeader, btnBack, lblTitle, flxTransfers, flxDisclaimer, btnBackBottom, flxBottom);
            this.compInstData = {}
            this.add(flxPrintTransfer);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintTransfer,
            "enabledForIdleTimeout": true,
            "id": "frmPrintTransfer",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_h460b4393db14bf99c2dace104ea9ce7,
            "preShow": function(eventobject) {
                controller.AS_Form_d712afdd9e09416180301ea833eb938b(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});