define("SelfServiceEnrolmentMA/EnrollUIModule/frmEnrollNow", function() {
    return function(controller) {
        function addWidgetsfrmEnrollNow() {
            this.setDefaultUnit(kony.flex.DP);
            var tbxAutopopulateIssueFix = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxAutopopulateIssueFix",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "175dp",
                "secureTextEntry": false,
                "skin": "slTextBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "98dp",
                "width": "300dp",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxMain = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "768dp",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxMainLoginBackground0a78d1008cff",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var imgKonyEnroll = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Login Kony Logo"
                },
                "centerX": "14%",
                "height": "64dp",
                "id": "imgKonyEnroll",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "80dp",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "13dp",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblLanguage",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "50dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "200dp",
                "zIndex": 5,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Language dropdown",
                    "tagName": "span"
                },
                "centerX": "83.77%",
                "centerY": "52%",
                "id": "lblCheckBox",
                "isVisible": true,
                "skin": "sknffffff15pxolbfonticons",
                "text": "O",
                "width": "17dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Product"
            });
            var imgDropdown = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Language Dropdown"
                },
                "centerY": "50%",
                "height": "7dp",
                "id": "imgDropdown",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLanguage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "English",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblLanguage",
                "isVisible": true,
                "right": "26.18%",
                "skin": "sknSSPLblFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.English\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ENGLISH"
            });
            flxDropdown.add(lblCheckBox, imgDropdown, lblLanguage);
            var flxLanguagePicker = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-live": "off",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLanguagePicker",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "73dp",
                "skin": "slFbox",
                "top": "65dp",
                "width": "13.61%",
                "zIndex": 5,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLanguagePicker.setDefaultUnit(kony.flex.DP);
            var imgToolTip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "10dp",
                "id": "imgToolTip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0.50%",
                "skin": "slImage",
                "src": "tool_tip.png",
                "top": "0dp",
                "width": "17dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDifferentLanguagesSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDifferentLanguagesSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "CopyslFbox0cc83560fc9864f",
                "top": "-3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.setDefaultUnit(kony.flex.DP);
            var segLanguagesList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segLanguagesList",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_e50707bd4e63473484ac4cb446dbe93f,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxLangList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxLangList": "flxLangList",
                    "lblLang": "lblLang",
                    "lblSeparator": "lblSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.add(segLanguagesList);
            flxLanguagePicker.add(imgToolTip, flxDifferentLanguagesSegment);
            var flxVerification = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxVerification",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "13%",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerification.setDefaultUnit(kony.flex.DP);
            var letsverify = new com.InfinityOLB.Resources.letsverify({
                "height": "100%",
                "id": "letsverify",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnPhone": {
                        "isVisible": true
                    },
                    "btnProceed": {
                        "left": "viz.val_cleared",
                        "top": "42dp",
                        "width": "100%"
                    },
                    "flexSSN": {
                        "isVisible": true
                    },
                    "flxCaptcha": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxDateInput": {
                        "left": "viz.val_cleared",
                        "top": "5dp",
                        "width": "85%"
                    },
                    "flxLetsVerifyCntr": {
                        "centerX": "viz.val_cleared",
                        "height": "64dp",
                        "left": "0dp",
                        "top": "20dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPhone": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "25dp",
                        "centerX": "49%",
                        "isVisible": false,
                        "left": 0,
                        "top": "viz.val_cleared",
                        "width": "85%"
                    },
                    "flxUserVerify": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "7%",
                        "right": "viz.val_cleared",
                        "top": "0.6600000000000001%"
                    },
                    "imgCaptcha": {
                        "src": "imagedrag.png"
                    },
                    "imgUserVerify": {
                        "height": "52dp",
                        "left": "7%",
                        "src": "user_verify.png",
                        "width": "52dp"
                    },
                    "imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "lblCallUs": {
                        "bottom": "viz.val_cleared",
                        "centerX": "50.00%",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblDOB": {
                        "centerX": "viz.val_cleared",
                        "left": "7.45%",
                        "top": "30dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblLastName": {
                        "centerX": "viz.val_cleared",
                        "left": "7.45%",
                        "top": "40dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblLetsVerify": {
                        "centerX": "45.46%",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "10%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblTaxID": {
                        "isVisible": false,
                        "left": "0%",
                        "top": "0dp",
                        "width": "85%"
                    },
                    "lblWrongInfo": {
                        "isVisible": false,
                        "width": "84%"
                    },
                    "letsverify": {
                        "centerX": "viz.val_cleared",
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "tbxLastName": {
                        "left": "viz.val_cleared",
                        "top": "3dp",
                        "width": "85%"
                    },
                    "tbxSSN": {
                        "isVisible": true
                    },
                    "tbxTaxID": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "top": "4dp",
                        "width": "85%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            letsverify.btnProceed.onClick = controller.AS_Button_ee8bfbf413e041f984cfa55c03dffb65;
            var AllForms = new com.InfinityOLB.WireTransfer.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "19.80%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "265dp",
                "width": "270dp",
                "zIndex": 20,
                "appName": "WireTransferMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "19.80%",
                        "top": "265dp",
                        "width": "270dp",
                        "zIndex": 20
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.msgInfo\")",
                        "width": "83%"
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "left": "39%",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25dp",
                "id": "flxClose",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var lblCloseFontIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close",
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblCloseFontIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(lblCloseFontIcon);
            flxVerification.add(letsverify, AllForms, flxClose);
            var flxWelcomeBack = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "630dp",
                "id": "flxWelcomeBack",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "13%",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeBack.setDefaultUnit(kony.flex.DP);
            var flxWelcome = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxWelcome",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "74dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcome.setDefaultUnit(kony.flex.DP);
            var flxDP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "54dp",
                "id": "flxDP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxDP",
                "top": "0dp",
                "width": "54dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDP.setDefaultUnit(kony.flex.DP);
            var imgDP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "54dp",
                "id": "imgDP",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0dp",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDP.add(imgDP);
            var imgSuccess = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "36dp",
                "id": "imgSuccess",
                "isVisible": true,
                "left": "30dp",
                "skin": "slImage",
                "src": "correct.png",
                "top": "30dp",
                "width": "36dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWelcomeBack = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "height": "25dp",
                "id": "lblWelcomeBack",
                "isVisible": true,
                "left": 85,
                "skin": "sknSSP72727220Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "bottom": "0dp",
                "height": "50dp",
                "id": "lblUserName",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknlbl424242SSPReg17px",
                "text": "UserName",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWelcome.add(flxDP, imgSuccess, lblWelcomeBack, lblUserName);
            var flxCantEnroll = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "220dp",
                "id": "flxCantEnroll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "74dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "140dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCantEnroll.setDefaultUnit(kony.flex.DP);
            var flxCross = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "74dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxCross",
                "top": "0dp",
                "width": "74dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "60dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_cross_1x.png",
                "top": "0dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var lblCantEnroll = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": 0,
                "centerY": "50%",
                "height": "31dp",
                "id": "lblCantEnroll",
                "isVisible": true,
                "left": "75dp",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony,i18n.common.cantEnroll\")",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCantEnroll.add(flxCross, lblCantEnroll);
            var flxAlreadyEnroll = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "220dp",
                "id": "flxAlreadyEnroll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "74dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "140dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlreadyEnroll.setDefaultUnit(kony.flex.DP);
            var imgAlreadyEnroll = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "42dp",
                "id": "imgAlreadyEnroll",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "login_enroll_error.png",
                "top": "0dp",
                "width": "51dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlreadyEnroll = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": 0,
                "centerY": "50%",
                "height": "40dp",
                "id": "lblAlreadyEnroll",
                "isVisible": true,
                "left": "75dp",
                "skin": "sknlbl424242SSPReg17px",
                "text": "Already Enrolled Note",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlreadyEnroll.add(imgAlreadyEnroll, lblAlreadyEnroll);
            var lblNote1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "52px",
                "id": "lblNote1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "text": "Note 1",
                "top": "270dp",
                "width": "68%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNote2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "104px",
                "id": "lblNote2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "text": "Note 2",
                "top": "352dp",
                "width": "68%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnActivateYourProfile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnActivateYourProfile",
                "isVisible": true,
                "left": 0,
                "skin": "CopyslButtonGlossBlue0i1876f1874e649",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ActivateYourProfile\")",
                "top": "50dp",
                "width": "68%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSignInNow = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnSignInNow",
                "isVisible": false,
                "left": 0,
                "skin": "CopyslButtonGlossBlue0i1876f1874e649",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.SignInNow\")",
                "top": "540dp",
                "width": "68%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnContact = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnContact",
                "isVisible": false,
                "left": 0,
                "skin": "CopyslButtonGlossBlue0i1876f1874e649",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "top": "540dp",
                "width": "68%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCallSupport = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCallSupport",
                "isVisible": true,
                "left": "97dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CallSupportTeam\")",
                "top": "37dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWelcomeBack.add(flxWelcome, flxCantEnroll, flxAlreadyEnroll, lblNote1, lblNote2, btnActivateYourProfile, btnSignInNow, btnContact, lblCallSupport);
            var flxVerificationBB = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxVerificationBB",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerificationBB.setDefaultUnit(kony.flex.DP);
            var flxCloseVer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseVer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "25dp",
                "zIndex": 10,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseVer.setDefaultUnit(kony.flex.DP);
            var imgCloseVer = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseVer",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var lblCloseFontIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Close",
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblCloseFontIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseVer.add(imgCloseVer, lblCloseFontIcon2);
            var flxLetsgetStarted = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": true,
                "height": "150dp",
                "id": "flxLetsgetStarted",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "125dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetsgetStarted.setDefaultUnit(kony.flex.DP);
            var flxLetsgetStartedWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "22.00%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxLetsgetStartedWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "60dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetsgetStartedWrapper.setDefaultUnit(kony.flex.DP);
            var imgLetsGetStarted = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "60dp",
                "id": "imgLetsGetStarted",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_verify.png",
                "top": "0%",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLetsgetStartedWrapper.add(imgLetsGetStarted);
            var lblLetsgetStarted = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerX": "44.00%",
                "id": "lblLetsgetStarted",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.LetsVerify\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWrongInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblWrongInformation",
                "isVisible": false,
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.wrongInfo\")",
                "top": "59.8%",
                "width": "84%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLetsgetStarted.add(flxLetsgetStartedWrapper, lblLetsgetStarted, lblWrongInformation);
            var lblEnterLastName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEnterLastName",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Lastname\")",
                "top": "10dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterLastName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEnterLastName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "80dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterLastNameBB\")",
                "secureTextEntry": false,
                "skin": "sknTxtBrodere0e0e0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var lblSSN = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Last Name",
                    "tagName": "span"
                },
                "id": "lblSSN",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.SSN\")",
                "top": "15dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flexSSN = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "18dp",
                "id": "flexSSN",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.519999999999996%",
                "width": "85%",
                "zIndex": 3,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flexSSN.setDefaultUnit(kony.flex.DP);
            var lblSSNNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Social Security Number",
                    "tagName": "span"
                },
                "centerY": "42%",
                "id": "lblSSNNumber",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.SSN\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWhatIsSSN = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxWhatIsSSN",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-1.48%",
                "width": "18dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxWhatIsSSN.setDefaultUnit(kony.flex.DP);
            var imgWhatIsSSN = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Info"
                },
                "height": "15dp",
                "id": "imgWhatIsSSN",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3.03%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": 2,
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var AllFormsBB = new com.InfinityOLB.WireTransfer.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "4dp",
                "id": "AllFormsBB",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "270dp",
                "zIndex": 20,
                "appName": "WireTransferMA",
                "overrides": {
                    "AllForms": {
                        "centerX": "4dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "top": "17dp",
                        "width": "270dp",
                        "zIndex": 20
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.msgInfo\")",
                        "width": "83%"
                    },
                    "flxInformation": {
                        "width": "99%"
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "left": "130dp",
                        "src": "tool_tip.png",
                        "width": "20dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxWhatIsSSN.add(imgWhatIsSSN, AllFormsBB);
            flexSSN.add(lblSSNNumber, flxWhatIsSSN);
            var tbxSSN = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxSSN",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "80dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.NUO.EnterSSN\")",
                "secureTextEntry": false,
                "skin": "sknTxtBrodere0e0e0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var lblDOB = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Date of birth",
                    "tagName": "span"
                },
                "id": "lblDOB",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.DOB\")",
                "top": "20dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var CustomDate = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomDate({
                "height": "30dp",
                "id": "CustomDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "75dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomDate": {
                        "centerX": "viz.val_cleared",
                        "left": "75dp"
                    },
                    "lblLine": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDateInput = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDateInput",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "80%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateInput.setDefaultUnit(kony.flex.DP);
            var DateInput = new com.InfinityOLB.SelfServiceEnrolmentMA.DateInput({
                "centerX": "50%",
                "height": "100%",
                "id": "DateInput",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "DateInput": {
                        "centerX": "50%",
                        "height": "100%",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDateInput.add(DateInput);
            var lblCompanyId = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Company ID",
                    "tagName": "span"
                },
                "id": "lblCompanyId",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.CompanyID\")",
                "top": "20dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var tbxCompanyId = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxCompanyId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "80dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterCompanyId\")",
                "secureTextEntry": false,
                "skin": "sknTxtBrodere0e0e0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknPlaceHolderGrey"
            });
            var btnProceedBB = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yHint": "Click Continue to proceed"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnProceedBB",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "top": "85dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Proceed"
            });
            var flxPhone = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "49%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxPhone",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhone.setDefaultUnit(kony.flex.DP);
            var lblCallUs = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "40%",
                "id": "lblCallUs",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CallSupportTeam\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnPhone = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnPhone",
                "isVisible": true,
                "left": "1.00%",
                "skin": "sknBtnSSP3343A817PxBg0",
                "text": "1004267689",
                "top": "-2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP5C69B917PxBg0"
            });
            flxPhone.add(lblCallUs, btnPhone);
            flxVerificationBB.add(flxCloseVer, flxLetsgetStarted, lblEnterLastName, tbxEnterLastName, lblSSN, flexSSN, tbxSSN, lblDOB, CustomDate, flxDateInput, lblCompanyId, tbxCompanyId, btnProceedBB, flxPhone);
            var flxResetPasswordOptions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxResetPasswordOptions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPasswordOptions.setDefaultUnit(kony.flex.DP);
            var flxCloseResetPassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetPassword.setDefaultUnit(kony.flex.DP);
            var imgCloseResetPassword = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseResetPassword",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetPassword.add(imgCloseResetPassword);
            var lblResetYourPassword = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerX": "50%",
                "id": "lblResetYourPassword",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.AlmostThere\")",
                "top": "3.52%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEnrollResetPass = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxEnrollResetPass",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "69dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollResetPass.setDefaultUnit(kony.flex.DP);
            var flxResetUserImg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "54dp",
                "id": "flxResetUserImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "54dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUserImg.setDefaultUnit(kony.flex.DP);
            var imgUserReset = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "imgUserReset",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_image.png",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUserBoundary = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgUserBoundary",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "verify_user.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResetUserImg.add(imgUserReset, imgUserBoundary);
            var lblVerificationNotice = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerX": "50%",
                "id": "lblVerificationNotice",
                "isVisible": true,
                "skin": "sknlblBrowserCheckMessage",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.VerificationNotice\")",
                "top": "5.28%",
                "width": "77%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            flxEnrollResetPass.add(flxResetUserImg, lblVerificationNotice);
            var flxEnrollPassBtns = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxEnrollPassBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollPassBtns.setDefaultUnit(kony.flex.DP);
            var AlterneteActionsEnterCVV = new com.InfinityOLB.SelfServiceEnrolmentMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "AlterneteActionsEnterCVV",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_cad98eb1a8304f689ee3b40cfa08351f,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "8.80%",
                "width": "85%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "8.80%"
                    },
                    "fontIconOption": {
                        "text": "x"
                    },
                    "imgOptionKA": {
                        "src": "active_cvv_icon.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.EnterCvvCodeInfo\")",
                        "left": "85dp",
                        "width": "61.90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsEnterCVV.onTouchStart = controller.AS_UWI_cad98eb1a8304f689ee3b40cfa08351f;
            var OrLineForCVVandPIN = new com.InfinityOLB.SelfServiceEnrolmentMA.orline({
                "centerX": "50%",
                "height": "30dp",
                "id": "OrLineForCVVandPIN",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "85%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    },
                    "orline": {
                        "centerX": "50%",
                        "height": "30dp",
                        "top": "5.28%",
                        "width": "85%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AlterneteActionsEnterPIN = new com.InfinityOLB.SelfServiceEnrolmentMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "AlterneteActionsEnterPIN",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_c13e044fb512427b8ea7503d5078016c,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "5.28%",
                "width": "85%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "5.28%",
                        "width": "85%"
                    },
                    "fontIconOption": {
                        "text": "y"
                    },
                    "imgOptionKA": {
                        "src": "active_send_pin.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SendPIN\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsEnterPIN.onTouchStart = controller.AS_UWI_c13e044fb512427b8ea7503d5078016c;
            flxEnrollPassBtns.add(AlterneteActionsEnterCVV, OrLineForCVVandPIN, AlterneteActionsEnterPIN);
            flxResetPasswordOptions.add(flxCloseResetPassword, lblResetYourPassword, flxEnrollResetPass, flxEnrollPassBtns);
            var flxSelectProductToEnrollFor = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxSelectProductToEnrollFor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectProductToEnrollFor.setDefaultUnit(kony.flex.DP);
            var flxSelectedEntity = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "70dp",
                "id": "flxSelectedEntity",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "top": "125dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedEntity.setDefaultUnit(kony.flex.DP);
            var lblSelectedEntity = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSelectedEntity",
                "isVisible": true,
                "left": "75px",
                "skin": "sknLbl727272SSPR15px",
                "text": "Selected Entity",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSelectedEntityValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSelectedEntityValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxf7f7f7BorderRadius3px",
                "top": "20dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedEntityValue.setDefaultUnit(kony.flex.DP);
            var lblSelectedEntityValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectedEntityValue",
                "isVisible": true,
                "left": "75px",
                "skin": "sknlbl424242SSPBgf7f7f7",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectedEntityValue.add(lblSelectedEntityValue);
            flxSelectedEntity.add(lblSelectedEntity, flxSelectedEntityValue);
            var lblSelectProductToEnrollFor = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerX": "50%",
                "id": "lblSelectProductToEnrollFor",
                "isVisible": true,
                "left": 75,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.SelectProductyouWantToEnrol\")",
                "top": "225dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSelectProductToEnrollForBtns = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSelectProductToEnrollForBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "274dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectProductToEnrollForBtns.setDefaultUnit(kony.flex.DP);
            var PersonalBanking = new com.InfinityOLB.SelfServiceEnrolmentMA.AlterneteActions({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "centerX": "50.00%",
                "height": "14%",
                "id": "PersonalBanking",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_bd83b55d10a540079acf01fcf82bc5f9,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "8.80%",
                "width": "85%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "8.80%"
                    },
                    "flcVerticalBar": {
                        "isVisible": true
                    },
                    "flxImgContainer": {
                        "height": "95%",
                        "width": "110dp"
                    },
                    "flxImgMain": {
                        "height": "100%",
                        "width": "90%"
                    },
                    "fontIconOption": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "text": "L",
                        "width": "30dp"
                    },
                    "imgOptionKA": {
                        "centerX": "50%",
                        "isVisible": false,
                        "src": "icon_personalbanking_3x.png"
                    },
                    "imgRightTip": {
                        "isVisible": true,
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerY": "50.00%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.PersonalBanking\")",
                        "left": "110dp",
                        "width": "61.90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "hoverSkin": "sknBGFFFFFBdrE3E3E3BdrRadius2PxHover",
                "overrides": {}
            });
            PersonalBanking.onTouchStart = controller.AS_UWI_cad98eb1a8304f689ee3b40cfa08351f;
            var OrLine = new com.InfinityOLB.SelfServiceEnrolmentMA.orline({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "height": "30dp",
                "id": "OrLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "88%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "imgOr": {
                        "isVisible": false,
                        "src": "or_circle.png"
                    },
                    "lblCrossOr": {
                        "height": "2dp"
                    },
                    "orline": {
                        "centerX": "50%",
                        "height": "30dp",
                        "top": "5.28%",
                        "width": "88%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var BusinessBanking = new com.InfinityOLB.SelfServiceEnrolmentMA.AlterneteActions({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "centerX": "50.00%",
                "height": "14%",
                "id": "BusinessBanking",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_h066a101bfc5456aa2178b738b539d4e,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "68%",
                "width": "85%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "68%"
                    },
                    "flcVerticalBar": {
                        "isVisible": true
                    },
                    "flxImgContainer": {
                        "height": "95%",
                        "width": "110dp"
                    },
                    "flxImgMain": {
                        "height": "100%",
                        "width": "90%"
                    },
                    "fontIconOption": {
                        "centerY": "viz.val_cleared",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "text": "t",
                        "top": "16dp",
                        "width": "30dp"
                    },
                    "imgOptionKA": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "32dp",
                        "isVisible": false,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "src": "enrollbb.png",
                        "top": "0dp",
                        "width": "33dp"
                    },
                    "imgRightTip": {
                        "isVisible": true,
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerY": "50.00%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.BusinessBanking\")",
                        "left": "110dp",
                        "width": "61.90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "hoverSkin": "sknBGFFFFFBdrE3E3E3BdrRadius2PxHover",
                "overrides": {}
            });
            BusinessBanking.onTouchStart = controller.AS_UWI_cad98eb1a8304f689ee3b40cfa08351f;
            flxSelectProductToEnrollForBtns.add(PersonalBanking, OrLine, BusinessBanking);
            var flxCloseSelectProduct = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseSelectProduct",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseSelectProduct.setDefaultUnit(kony.flex.DP);
            var imgCloseSelectProduct = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseSelectProduct",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseSelectProduct.add(imgCloseSelectProduct);
            flxSelectProductToEnrollFor.add(flxSelectedEntity, lblSelectProductToEnrollFor, flxSelectProductToEnrollForBtns, flxCloseSelectProduct);
            var flxSendOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "580dp",
                "id": "flxSendOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSendOTP.setDefaultUnit(kony.flex.DP);
            var resetusingOTP = new com.InfinityOLB.SelfServiceEnrolmentMA.resetusingOTP({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "580dp",
                "id": "resetusingOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnNext": {
                        "text": "S"
                    },
                    "btnResendOTP": {
                        "isVisible": false
                    },
                    "flxCVV": {
                        "isVisible": false
                    },
                    "imgCVVOrOTP": {
                        "src": "send_pin.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "src": "view.png"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "resetusingOTP": {
                        "height": "580dp"
                    },
                    "rtxEnterCVVCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WantOTP\")"
                    },
                    "tbxCVV": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            resetusingOTP.btnNext.onClick = controller.AS_Button_h08129946fca478c8d44c0ab65511028;
            resetusingOTP.btnUseCVV.onClick = controller.AS_Button_f3a27dd0c5884e79ba8975b6800e8ea4;
            var flxCloseSendOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseSendOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseSendOTP.setDefaultUnit(kony.flex.DP);
            var imgCloseSendOTP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseSendOTP",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseSendOTP.add(imgCloseSendOTP);
            flxSendOTP.add(resetusingOTP, flxCloseSendOTP);
            var flxResetUsingOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "580dp",
                "id": "flxResetUsingOTP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUsingOTP.setDefaultUnit(kony.flex.DP);
            var resetusingOTPEnterOTP = new com.InfinityOLB.SelfServiceEnrolmentMA.resetusingOTP({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "580dp",
                "id": "resetusingOTPEnterOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnNext": {
                        "zIndex": 1
                    },
                    "flximgtext": {
                        "width": "100%"
                    },
                    "imgCVVOrOTP": {
                        "src": "send_pin.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "src": "view.png"
                    },
                    "lblWrongOTP": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.AskToResendOTPMsg\")"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "resetusingOTP": {
                        "height": "580dp"
                    },
                    "rtxEnterCVVCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.EnterOTP\")"
                    },
                    "tbxCVV": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            resetusingOTPEnterOTP.btnNext.onClick = controller.AS_Button_a4ac98db97304acd816953d2fd45cd6e;
            resetusingOTPEnterOTP.btnResendOTP.onClick = controller.AS_Button_dcd6d43d9f934985991e420eea27c094;
            resetusingOTPEnterOTP.btnUseCVV.onClick = controller.AS_Button_fc10b48d9d1c467690881dd39a1433f3;
            resetusingOTPEnterOTP.imgViewCVV.onTouchStart = controller.AS_Image_e8fd4567261c422d80f7845cc2af7b71;
            resetusingOTPEnterOTP.tbxCVV.onBeginEditing = controller.AS_TextField_h030bc5eb17e47d39cbf07fc304cd8fa;
            resetusingOTPEnterOTP.tbxCVV.onKeyUp = controller.AS_TextField_j8ae877c189f49b8a0524a2e0b52f219;
            var flxCloseResetUsingOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetUsingOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetUsingOTP.setDefaultUnit(kony.flex.DP);
            var imgCloseResetUsingOTP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseResetUsingOTP",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseResetUsingOTP.add(imgCloseResetUsingOTP);
            flxResetUsingOTP.add(resetusingOTPEnterOTP, flxCloseResetUsingOTP);
            var flxResetUsingCVV = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "580dp",
                "id": "flxResetUsingCVV",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUsingCVV.setDefaultUnit(kony.flex.DP);
            var ResetOrEnroll = new com.InfinityOLB.SelfServiceEnrolmentMA.ResetOrEnroll({
                "height": "580dp",
                "id": "ResetOrEnroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "ResetOrEnroll": {
                        "height": "580dp"
                    },
                    "flxCVVHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxHeaderNError": {
                        "height": "55dp"
                    },
                    "imgCVV": {
                        "src": "cvv_icon.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "height": "16dp",
                        "src": "view.png",
                        "width": "22dp"
                    },
                    "lblResendOtp": {
                        "isVisible": false
                    },
                    "lblResetPassword": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.newUsernamepasswordsetting.EnrollingtoOnlineBanking\")",
                        "top": "0dp"
                    },
                    "lblWrongCvv": {
                        "bottom": "0dp",
                        "isVisible": true,
                        "top": "viz.val_cleared"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "rtxEnterCVV": {
                        "text": "Enter the CVV code of your credit or debit card",
                        "top": "5dp"
                    },
                    "tbxCVV": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            ResetOrEnroll.btnNext.onClick = controller.AS_Button_ifacc90ce3d342c5b32da91c7a6c6e42;
            ResetOrEnroll.btnUseOTP.onClick = controller.AS_Button_e1f38c4db7644c9bb10877bb3c1ca82a;
            ResetOrEnroll.flxViewHideCVV.onClick = controller.AS_FlexContainer_fe0be06b9ac64653bf2b2d24a1df08ed;
            ResetOrEnroll.imgViewCVV.onTouchStart = controller.AS_Image_j2acf91c13184a85b4b76aedbed08508;
            ResetOrEnroll.tbxCVV.onBeginEditing = controller.AS_TextField_afab8107f8e446c2b86876e1f394949a;
            ResetOrEnroll.tbxCVV.onKeyUp = controller.AS_TextField_f20dbb4fddca4e45a538f8bf9654a1ca;
            var flxCloseResetUsingCVV = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetUsingCVV",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetUsingCVV.setDefaultUnit(kony.flex.DP);
            var imgCloseResetUsingCVV = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseResetUsingCVV",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseResetUsingCVV.add(imgCloseResetUsingCVV);
            flxResetUsingCVV.add(ResetOrEnroll, flxCloseResetUsingCVV);
            var flxResetPassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxResetPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPassword.setDefaultUnit(kony.flex.DP);
            var newpasswordsetting = new com.InfinityOLB.SelfServiceEnrolmentMA.newpasswordsetting({
                "height": "100%",
                "id": "newpasswordsetting",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "imgPasswordMatched": {
                        "src": "success_icon.png"
                    },
                    "imgRules": {
                        "src": "info.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgValidPassword": {
                        "src": "success_icon.png"
                    },
                    "tbxNewPassword": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.EnterPassword\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseResetPswd = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetPswd",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 10,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetPswd.setDefaultUnit(kony.flex.DP);
            var imgCloseResetPswd = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseResetPswd",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseResetPswd.add(imgCloseResetPswd);
            flxResetPassword.add(newpasswordsetting, flxCloseResetPswd);
            var flxUsernameAndPassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxUsernameAndPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsernameAndPassword.setDefaultUnit(kony.flex.DP);
            var newUsernamepasswordsetting = new com.InfinityOLB.SelfServiceEnrolmentMA.newUsernamepasswordsetting({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "id": "newUsernamepasswordsetting",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnCreate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")"
                    },
                    "flxMain": {
                        "height": "100%"
                    },
                    "flxRulesPassword": {
                        "height": "115dp",
                        "isVisible": false
                    },
                    "flxRulesUsername": {
                        "height": "75dp",
                        "isVisible": false,
                        "minHeight": "20dp"
                    },
                    "imgCorrectUserName": {
                        "src": "success_green.png"
                    },
                    "imgPasswordMatched": {
                        "src": "success_green.png"
                    },
                    "imgRules": {
                        "src": "info.png"
                    },
                    "imgRulesHeader": {
                        "src": "info.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgValidPassword": {
                        "src": "success_green.png"
                    },
                    "lblRulesHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.UsernameRules\")"
                    },
                    "newUsernamepasswordsetting": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "tbxMatchPassword": {
                        "maxTextLength": 20,
                        "secureTextEntry": true
                    },
                    "tbxNewPassword": {
                        "maxTextLength": 20
                    },
                    "tbxNewUserName": {
                        "maxTextLength": 24
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseUsernamePassowrd = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseUsernamePassowrd",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 10,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseUsernamePassowrd.setDefaultUnit(kony.flex.DP);
            var imgCloseUsernamePassowrd = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseUsernamePassowrd",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseUsernamePassowrd.add(imgCloseUsernamePassowrd);
            flxUsernameAndPassword.add(newUsernamepasswordsetting, flxCloseUsernamePassowrd);
            var flxSecurityQuestions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxSecurityQuestions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQuestions.setDefaultUnit(kony.flex.DP);
            var SetSecurityQuestions = new com.InfinityOLB.SelfServiceEnrolmentMA.SetSecurityQuestions({
                "height": "568px",
                "id": "SetSecurityQuestions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnSetSecurityQuestionsCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "width": "43.25%"
                    },
                    "btnSetSecurityQuestionsProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                        "width": "43.25%"
                    },
                    "flxHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxRulesSecurityQuestions": {
                        "width": "85%"
                    },
                    "flxScrollContainerSetSecurityQuestions": {
                        "top": "25dp"
                    },
                    "flxSeparatorHeader": {
                        "top": "20dp"
                    },
                    "imgRule1": {
                        "centerY": "50%",
                        "src": "pageoffdot.png"
                    },
                    "imgRule2": {
                        "src": "pageoffdot.png"
                    },
                    "imgRules": {
                        "src": "info.png"
                    },
                    "lblHeading": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblQuestion1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.Question1\")"
                    },
                    "lblQuestion2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.Question2\")"
                    },
                    "tbxAnswer1": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxAnswer2": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxAnswer3": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxAnswer4": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxAnswer5": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            SetSecurityQuestions.btnSetSecurityQuestionsCancel.onClick = controller.AS_Button_b421538571184a66b388559812a6d86b;
            SetSecurityQuestions.btnSetSecurityQuestionsProceed.onClick = controller.AS_Button_c7b59ffb265244959417dfc45f9b7ffb;
            SetSecurityQuestions.lbxQuestion1.onSelection = controller.AS_ListBox_d19715af59fa4e5691aab2465284e2bf;
            SetSecurityQuestions.lbxQuestion2.onSelection = controller.AS_ListBox_j3b62e329c1b4fa0981ced02b8d6c257;
            SetSecurityQuestions.lbxQuestion3.onSelection = controller.AS_ListBox_g189f4e38a0a49689bfa3ddc2687e0e7;
            SetSecurityQuestions.lbxQuestion4.onSelection = controller.AS_ListBox_af31dd4e16594b71afd33203d7a38413;
            SetSecurityQuestions.lbxQuestion5.onSelection = controller.AS_ListBox_e2882689029844fc9c6286c39a7a2cfc;
            SetSecurityQuestions.tbxAnswer1.onBeginEditing = controller.AS_TextField_e4482e7f2f664429a9315e210712e607;
            SetSecurityQuestions.tbxAnswer1.onEndEditing = controller.AS_TextField_e970ae07757c4e969fb123f8b17d3118;
            SetSecurityQuestions.tbxAnswer1.onKeyUp = controller.AS_TextField_ef5e9a24c5504d90b931a2c24fbd16a0;
            SetSecurityQuestions.tbxAnswer2.onBeginEditing = controller.AS_TextField_ccd36a5b84df4221926ce36f4c8ddba6;
            SetSecurityQuestions.tbxAnswer2.onEndEditing = controller.AS_TextField_c55b57730f0b46b0b9a45f857d35b941;
            SetSecurityQuestions.tbxAnswer2.onKeyUp = controller.AS_TextField_efedb0922453453d95970ae6c3aad6d4;
            SetSecurityQuestions.tbxAnswer3.onBeginEditing = controller.AS_TextField_d1d06aa50cf948de901c477129da4912;
            SetSecurityQuestions.tbxAnswer3.onEndEditing = controller.AS_TextField_ec190dad0597473385edbc20bc8d9a31;
            SetSecurityQuestions.tbxAnswer3.onKeyUp = controller.AS_TextField_cd23a36a257f4fbfad519df3e8f4532a;
            SetSecurityQuestions.tbxAnswer4.onBeginEditing = controller.AS_TextField_ffde4fff69214ab18dc619d7c7367256;
            SetSecurityQuestions.tbxAnswer4.onEndEditing = controller.AS_TextField_b3e04719ffc1405ead6a81ae062ea865;
            SetSecurityQuestions.tbxAnswer4.onKeyUp = controller.AS_TextField_bc7f3173e2734cc0aab8572a6e8a76cc;
            SetSecurityQuestions.tbxAnswer5.onBeginEditing = controller.AS_TextField_cf41c99d9b1e4f398a4246848d08d195;
            SetSecurityQuestions.tbxAnswer5.onEndEditing = controller.AS_TextField_b42641c18e0f4b45a35596c73b2aa689;
            SetSecurityQuestions.tbxAnswer5.onKeyUp = controller.AS_TextField_e9943a8cade846c1962f647500c80d54;
            flxSecurityQuestions.add(SetSecurityQuestions);
            var flxSecurityQuestionsSelectedUsername = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxSecurityQuestionsSelectedUsername",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQuestionsSelectedUsername.setDefaultUnit(kony.flex.DP);
            var flxCloseResetSelectedUsername = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetSelectedUsername",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 10,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetSelectedUsername.setDefaultUnit(kony.flex.DP);
            var imgCloseResetSelectedUsername = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseResetSelectedUsername",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseResetSelectedUsername.add(imgCloseResetSelectedUsername);
            var flxSetSecurityQuesWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSetSecurityQuesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxSetSecurityQuesWrapper.setDefaultUnit(kony.flex.DP);
            var flxLetsVerifyCntr = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100dp",
                "id": "flxLetsVerifyCntr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetsVerifyCntr.setDefaultUnit(kony.flex.DP);
            var flxUserVerify = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "13.24%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxUserVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0.6600000000000001%",
                "width": "60dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserVerify.setDefaultUnit(kony.flex.DP);
            var imgUserVerify = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "52dp",
                "id": "imgUserVerify",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_verify_error.png",
                "top": "0%",
                "width": "52dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserVerify.add(imgUserVerify);
            var lblLetsVerify = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblLetsVerify",
                "isVisible": true,
                "left": "22%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.SetSecurityQuestions\")",
                "top": "9.719999999999999%",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWrongInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "It seems that the information youve provided does not match with our records.",
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblWrongInfo",
                "isVisible": false,
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.wrongInfo\")",
                "top": "59.8%",
                "width": "84%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLetsVerifyCntr.add(flxUserVerify, lblLetsVerify, lblWrongInfo);
            flxSetSecurityQuesWrapper.add(flxLetsVerifyCntr);
            var flxScrollContainerSetSecurityQuestions = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "428px",
                "horizontalScrollIndicator": true,
                "id": "flxScrollContainerSetSecurityQuestions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollContainerSetSecurityQuestions.setDefaultUnit(kony.flex.DP);
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var lblQuestionsHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Select Questions and set your answers:",
                    "tagName": "h3"
                },
                "id": "lblQuestionsHeading",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl565656SSPReg13px",
                "text": "Select Questions and set your answers:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSecurityQASet1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSecurityQASet1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQASet1.setDefaultUnit(kony.flex.DP);
            var lblQuestion1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 1 :",
                    "tagName": "span"
                },
                "id": "lblQuestion1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Question 1 :",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxQuestion1 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxQuestion1",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "In which city were you born?"],
                    ["lb2", "Who is your favourite hollywood actor?"],
                    ["lb3", "What is your favourite holiday destination?"],
                    ["lb4", "Who is your favourite sports man?"],
                    ["lb5", "What is your favourite dish?"]
                ],
                "selectedKey": "lb1",
                "skin": "Copysknlbxalto13px",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblAnswer1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 1 :",
                    "tagName": "span"
                },
                "id": "lblAnswer1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Answer",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAnswer1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Type your answer here"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": 3,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAnswer1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Type your answer here",
                "secureTextEntry": false,
                "skin": "CopyskntbxffffffBordere13px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSecurityQASet1.add(lblQuestion1, lbxQuestion1, lblAnswer1, tbxAnswer1);
            var flxSecurityQASet2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSecurityQASet2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQASet2.setDefaultUnit(kony.flex.DP);
            var lblQuestion2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 2 :",
                    "tagName": "span"
                },
                "id": "lblQuestion2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Question 2 :",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxQuestion2 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxQuestion2",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "In which city were you born?"],
                    ["lb2", "Who is your favourite hollywood actor?"],
                    ["lb3", "What is your favourite holiday destination?"],
                    ["lb4", "Who is your favourite sports man?"],
                    ["lb5", "What is your favourite dish?"]
                ],
                "selectedKey": "lb1",
                "skin": "Copysknlbxalto13px",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblAnswer2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Answer 2 :",
                    "tagName": "span"
                },
                "id": "lblAnswer2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Answer",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAnswer2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": 3,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAnswer2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Type your answer here",
                "secureTextEntry": false,
                "skin": "CopyskntbxffffffBordere13px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSecurityQASet2.add(lblQuestion2, lbxQuestion2, lblAnswer2, tbxAnswer2);
            var flxSecurityQASet3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSecurityQASet3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQASet3.setDefaultUnit(kony.flex.DP);
            var lblQuestion3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 3 :",
                    "tagName": "span"
                },
                "id": "lblQuestion3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Question 3 :",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxQuestion3 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxQuestion3",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "In which city were you born?"],
                    ["lb2", "Who is your favourite hollywood actor?"],
                    ["lb3", "What is your favourite holiday destination?"],
                    ["lb4", "Who is your favourite sports man?"],
                    ["lb5", "What is your favourite dish?"]
                ],
                "selectedKey": "lb1",
                "skin": "Copysknlbxalto13px",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblAnswer3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Answer 3 :",
                    "tagName": "span"
                },
                "id": "lblAnswer3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Answer",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAnswer3 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Type your answer here"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": 3,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAnswer3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Type your answer here",
                "secureTextEntry": false,
                "skin": "CopyskntbxffffffBordere13px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSecurityQASet3.add(lblQuestion3, lbxQuestion3, lblAnswer3, tbxAnswer3);
            var flxSecurityQASet4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSecurityQASet4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQASet4.setDefaultUnit(kony.flex.DP);
            var lblQuestion4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 4 :",
                    "tagName": "span"
                },
                "id": "lblQuestion4",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Question 4 :",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxQuestion4 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxQuestion4",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "In which city were you born?"],
                    ["lb2", "Who is your favourite hollywood actor?"],
                    ["lb3", "What is your favourite holiday destination?"],
                    ["lb4", "Who is your favourite sports man?"],
                    ["lb5", "What is your favourite dish?"]
                ],
                "selectedKey": "lb1",
                "skin": "Copysknlbxalto13px",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblAnswer4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Answer 4 :",
                    "tagName": "span"
                },
                "id": "lblAnswer4",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Answer",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAnswer4 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Type your answer here"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": 3,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAnswer4",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Type your answer here",
                "secureTextEntry": false,
                "skin": "CopyskntbxffffffBordere13px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSecurityQASet4.add(lblQuestion4, lbxQuestion4, lblAnswer4, tbxAnswer4);
            var flxSecurityQASet5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSecurityQASet5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQASet5.setDefaultUnit(kony.flex.DP);
            var lblQuestion5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Question 5 :",
                    "tagName": "span"
                },
                "id": "lblQuestion5",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Question 5 :",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxQuestion5 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxQuestion5",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "In which city were you born?"],
                    ["lb2", "Who is your favourite hollywood actor?"],
                    ["lb3", "What is your favourite holiday destination?"],
                    ["lb4", "Who is your favourite sports man?"],
                    ["lb5", "What is your favourite dish?"]
                ],
                "selectedKey": "lb1",
                "skin": "Copysknlbxalto13px",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblAnswer5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Answer 5 :",
                    "tagName": "span"
                },
                "id": "lblAnswer5",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl727272SSP13px",
                "text": "Answer",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAnswer5 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Type your answer here"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": 3,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAnswer5",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Type your answer here",
                "secureTextEntry": false,
                "skin": "CopyskntbxffffffBordere13px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSecurityQASet5.add(lblQuestion5, lbxQuestion5, lblAnswer5, tbxAnswer5);
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            flxScrollContainerSetSecurityQuestions.add(flxSeparator, lblQuestionsHeading, flxSecurityQASet1, flxSecurityQASet2, flxSecurityQASet3, flxSecurityQASet4, flxSecurityQASet5, flxDummy);
            var flxDocumentSiginText = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDocumentSiginText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentSiginText.setDefaultUnit(kony.flex.DP);
            var rtxDescription = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Hi! You can view account renewal instruction in the Pdf..."
                },
                "id": "rtxDescription",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknRtxSSPLight42424215Px",
                "text": "To avail services related to online banking,you need to submit a signed agreement with the bank.A downloadable copy of the agreement form is attached here.The online bank account will be activated after the submission of this form.<br>Call us at 1-800-XXX-XXXX or contact your nearest branch for further information.",
                "top": "0dp",
                "width": "99%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPDF = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "15dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "50px",
                "id": "flxPDF",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPDF.setDefaultUnit(kony.flex.DP);
            var imgPDF = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgPDF",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "1.33%",
                "skin": "slImage",
                "src": "pdf_image.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDocument = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerY": "49.70%",
                "id": "btnDocument",
                "isVisible": true,
                "left": "14.36%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PlatinumCard\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Platinum Card.pdf"
            });
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Download"
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgDownload",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "2.41%",
                "skin": "sknImgPointer5vs",
                "src": "download_blue.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Download"
            });
            flxPDF.add(imgPDF, btnDocument, imgDownload);
            flxDocumentSiginText.add(rtxDescription, flxPDF);
            var btnProceed = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Proceed"
                },
                "centerX": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnProceed",
                "isVisible": true,
                "onClick": controller.AS_Button_35599789597149a38456f3d69d8af0f1,
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "text": "Proceed",
                "top": "20dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Proceed"
            });
            var btnDoItLaterUsingSecuritySettings = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "DONE"
                },
                "centerX": "50%",
                "id": "btnDoItLaterUsingSecuritySettings",
                "isVisible": true,
                "skin": "sknBtnSSP3343A817PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.DoItLaterUsingSecuritySettings\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A817PxBg0",
                "toolTip": "Do it later using Security Settings"
            });
            flxSecurityQuestionsSelectedUsername.add(flxCloseResetSelectedUsername, flxSetSecurityQuesWrapper, flxScrollContainerSetSecurityQuestions, flxDocumentSiginText, btnProceed, btnDoItLaterUsingSecuritySettings);
            var flxSecurityQuestionsAck = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "390dp",
                "id": "flxSecurityQuestionsAck",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "160dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityQuestionsAck.setDefaultUnit(kony.flex.DP);
            var securityAck = new com.InfinityOLB.SelfServiceEnrolmentMA.securityAck({
                "height": "500dp",
                "id": "securityAck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnLoginLater": {
                        "text": "DONE"
                    },
                    "btnProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")"
                    },
                    "flxBottom": {
                        "height": "60dp"
                    },
                    "lblDone": {
                        "centerX": "50%"
                    },
                    "lblLoginNextTime": {
                        "centerX": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.LoginLater\")",
                        "top": "28dp"
                    },
                    "lblNotYetEnrolledOrError": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.flxSecurityQuestionsAck.Youhavesetyoursecurityquestionssuccessfully\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            securityAck.btnProceed.onClick = controller.AS_Button_feae1769d354440b8d25b5581061d8c7;
            flxSecurityQuestionsAck.add(securityAck);
            var flxUsernameAndPasswordAck = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "420dp",
                "id": "flxUsernameAndPasswordAck",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "180dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsernameAndPasswordAck.setDefaultUnit(kony.flex.DP);
            var UsenamePasswordSuccess = new com.InfinityOLB.SelfServiceEnrolmentMA.UsenamePasswordSuccess({
                "height": "500dp",
                "id": "UsenamePasswordSuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnLoginLater": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Done\")",
                        "isVisible": false
                    },
                    "btnProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")"
                    },
                    "flxUserImagewithTick": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "width": "84.40%"
                    },
                    "imgTickFrame": {
                        "src": "user_verify_success_frame.png"
                    },
                    "imgUserwithoutTick": {
                        "src": "default_username.png"
                    },
                    "lblAcknowledgement": {
                        "centerX": "48.37%",
                        "text": "You have set your  Username & Password",
                        "width": "63.98%"
                    },
                    "lblLoginNextTime": {
                        "isVisible": false
                    },
                    "lblMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.EnrollNow.Pleaseproceedwithsettingupyoursecurityquestions\")",
                        "width": "75%"
                    },
                    "orline": {
                        "isVisible": false
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            UsenamePasswordSuccess.btnLoginLater.onClick = controller.AS_Button_ad9b6bbadb884deca296b8fb15cf8c27;
            UsenamePasswordSuccess.btnProceed.onClick = controller.AS_Button_dcf8539756e4499993bbc38c7718b40b;
            var flxclose1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxclose1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxclose1.setDefaultUnit(kony.flex.DP);
            var imgClose1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgClose1",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxclose1.add(imgClose1);
            flxUsernameAndPasswordAck.add(UsenamePasswordSuccess, flxclose1);
            var flxUsernameAndPasswordAckSelectedUsername = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "420dp",
                "id": "flxUsernameAndPasswordAckSelectedUsername",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsernameAndPasswordAckSelectedUsername.setDefaultUnit(kony.flex.DP);
            var UsenamePasswordSuccessAck = new com.InfinityOLB.SelfServiceEnrolmentMA.UsenamePasswordSuccess({
                "height": "500dp",
                "id": "UsenamePasswordSuccessAck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnLoginLater": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Done\")",
                        "isVisible": false
                    },
                    "btnProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                        "top": "200dp"
                    },
                    "flxUserImagewithTick": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerX": "50%",
                        "isVisible": true,
                        "width": "84.40%"
                    },
                    "imgTickFrame": {
                        "src": "user_verify_success_frame.png"
                    },
                    "imgUserwithoutTick": {
                        "src": "default_username.png"
                    },
                    "lblAcknowledgement": {
                        "centerX": "48.37%",
                        "width": "63.98%"
                    },
                    "lblLoginNextTime": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Enroll.DoItLaterUsingSecuritySettings\")",
                        "isVisible": false,
                        "top": "40dp"
                    },
                    "lblMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.EnrollNow.Pleaseproceedwithsettingupyoursecurityquestions\")",
                        "width": "75%"
                    },
                    "orline": {
                        "isVisible": false
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            UsenamePasswordSuccessAck.btnLoginLater.onClick = controller.AS_Button_ad9b6bbadb884deca296b8fb15cf8c27;
            UsenamePasswordSuccessAck.btnProceed.onClick = controller.AS_Button_dcf8539756e4499993bbc38c7718b40b;
            flxUsernameAndPasswordAckSelectedUsername.add(UsenamePasswordSuccessAck);
            var flxusernamepassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "420dp",
                "id": "flxusernamepassword",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "180dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxusernamepassword.setDefaultUnit(kony.flex.DP);
            var ForgotUsernamePassword = new com.InfinityOLB.SelfServiceEnrolmentMA.ForgotUsernamePassword({
                "height": "420dp",
                "id": "ForgotUsernamePassword",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BackToLogin\")"
                    },
                    "lblMessage": {
                        "text": "If you have forgot your username or password , please use the forgot option."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxusernamepassword.add(ForgotUsernamePassword);
            var flxResetSuccessful = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "398dp",
                "id": "flxResetSuccessful",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "180dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetSuccessful.setDefaultUnit(kony.flex.DP);
            var passwordresetsuccess = new com.InfinityOLB.SelfServiceEnrolmentMA.passwordresetsuccess({
                "height": "550dp",
                "id": "passwordresetsuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "imgTickFrame": {
                        "src": "user_verify_success_frame.png"
                    },
                    "imgUserwithoutTick": {
                        "src": "default_username.png"
                    },
                    "orlineSuccess.imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxResetSuccessful.add(passwordresetsuccess);
            var flxEnrollOrServerError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "440dp",
                "id": "flxEnrollOrServerError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "147dp",
                "width": "389dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollOrServerError.setDefaultUnit(kony.flex.DP);
            var EnrollAlert = new com.InfinityOLB.SelfServiceEnrolmentMA.EnrollAlert({
                "height": "400dp",
                "id": "EnrollAlert",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            EnrollAlert.btnBackToLogin.onClick = controller.AS_Button_a8eef43fd77c4b69b0a0d7354e48117b;
            EnrollAlert.lblHowToEnroll.onTouchStart = controller.AS_Label_i91cb93887364b769b9fd4dce05b1fbd;
            flxEnrollOrServerError.add(EnrollAlert);
            var flxPhoneAndEmail = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxPhoneAndEmail",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "1dp",
                "width": "500dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneAndEmail.setDefaultUnit(kony.flex.DP);
            var OTPModule = new com.InfinityOLB.Resources.mfaold.OTPModule({
                "height": "100%",
                "id": "OTPModule",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAgree": {
                        "top": "30dp"
                    },
                    "flxCVV": {
                        "width": "350dp"
                    },
                    "flxDescription": {
                        "centerX": "viz.val_cleared"
                    },
                    "flxEnterOTP": {
                        "isVisible": true
                    },
                    "flxEnterSecureAccessCode": {
                        "isVisible": false,
                        "left": "7dp"
                    },
                    "flxImgTxt": {
                        "height": "150px",
                        "top": "100dp",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxRememberMe": {
                        "isVisible": false
                    },
                    "flximgrtx": {
                        "height": "160dp",
                        "top": "100dp"
                    },
                    "imgPhoneOTP": {
                        "src": "send_pin.png"
                    },
                    "imgRememberMe": {
                        "src": "unchecked_box.png"
                    },
                    "lblFavoriteEmailCheckBox": {
                        "text": "C"
                    },
                    "lblHeaderOTP": {
                        "width": "91%"
                    },
                    "lblOTP": {
                        "centerX": "viz.val_cleared",
                        "height": "66dp"
                    },
                    "lblPhoneOTP": {
                        "height": "66dp"
                    },
                    "lblResendOTPMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mfa.subheader\")",
                        "isVisible": true
                    },
                    "lblWrongOTP": {
                        "isVisible": false,
                        "text": "Sorry, this secure code is incorrect. Try again.",
                        "top": "245px"
                    },
                    "rtxEnterCVVCode": {
                        "height": "65dp",
                        "top": "0dp",
                        "width": "310dp"
                    },
                    "tbxCVV": {
                        "centerY": "53%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseMFA = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseMFA",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseMFA.setDefaultUnit(kony.flex.DP);
            var imgCloseMFA = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseMFA",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseMFA.add(imgCloseMFA);
            flxPhoneAndEmail.add(OTPModule, flxCloseMFA);
            var flxActivationLinkExpired = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "440dp",
                "id": "flxActivationLinkExpired",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "389dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivationLinkExpired.setDefaultUnit(kony.flex.DP);
            var imgActivationLinkExpired = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50.00%",
                "height": "80dp",
                "id": "imgActivationLinkExpired",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "erroricon.png",
                "top": "260dp",
                "width": "80dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblActivationExpiredLink = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblActivationExpiredLink",
                "isVisible": true,
                "skin": "sknSSP42424222Px",
                "text": "Activation Link Expired!",
                "top": "369dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxActivationLinkExpired = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "rtxActivationLinkExpired",
                "isVisible": true,
                "left": "210dp",
                "linkSkin": "defRichTextLink",
                "skin": "slRichText",
                "text": "Lorem Ipsum fd DolorLorem Ipsum fd Dolor<br>\nLorem Ipsum fd DolorLorem Ipsum fd Dolor\nLorem Ipsum fd DolorLorem Ipsum fd Dolor",
                "top": "439dp",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActivationLinkExpired.add(imgActivationLinkExpired, lblActivationExpiredLink, rtxActivationLinkExpired);
            var flxCloseSendOTPBusinessBanking = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxCloseSendOTPBusinessBanking",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseSendOTPBusinessBanking.setDefaultUnit(kony.flex.DP);
            var flxCloseSendOTPBB = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseSendOTPBB",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseSendOTPBB.setDefaultUnit(kony.flex.DP);
            var imgCloseSendOTPBB = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "height": "100%",
                "id": "imgCloseSendOTPBB",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseSendOTPBB.add(imgCloseSendOTPBB);
            var flxHeaderNError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxHeaderNError",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNError.setDefaultUnit(kony.flex.DP);
            var lblResetPasswordMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Reset with a secure access code",
                    "tagName": "h2"
                },
                "id": "lblResetPasswordMsg",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.enrollBB\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWrongOTP = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "The code you entered is not correct. Please try again.",
                    "tagName": "span"
                },
                "id": "lblWrongOTP",
                "isVisible": false,
                "left": "50dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.incorrectOTP\")",
                "top": "35dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderNError.add(lblResetPasswordMsg, lblWrongOTP);
            var flxResetBySecureCode = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxResetBySecureCode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetBySecureCode.setDefaultUnit(kony.flex.DP);
            var flxImageUser = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "54dp",
                "id": "flxImageUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0.8200000000000003%",
                "width": "54dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageUser.setDefaultUnit(kony.flex.DP);
            var imgUser = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "imgUser",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "default_username.png",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUserOutline = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgUserOutline",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_reset_password_frame.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageUser.add(imgUser, imgUserOutline);
            var lblResetBySecureCodeQuestion = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Reset with a secure access code",
                    "tagName": "h3"
                },
                "id": "lblResetBySecureCodeQuestion",
                "isVisible": true,
                "left": "140dp",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.sendCodeMsg\")",
                "top": "1dp",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResetBySecureCode.add(flxImageUser, lblResetBySecureCodeQuestion);
            var lblOTPQuestion = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Reset with a secure access code",
                    "tagName": "h3"
                },
                "id": "lblOTPQuestion",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollnow.SendecureAccessCode\")",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTP.setDefaultUnit(kony.flex.DP);
            var imgViewOTP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "View"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgViewOTP",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "6%",
                "skin": "slImage",
                "src": "view.png",
                "width": "22dp",
                "zIndex": 20
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxOTP = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Enter Code"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxOTP",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.login.EnterOTPMsg\")",
                "right": "0%",
                "secureTextEntry": true,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxOTP.add(imgViewOTP, tbxOTP);
            var btnNext = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnNext",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.send\")",
                "top": "90dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Send"
            });
            var btnResendOTP = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "focusSkin": "sknBtnSSP3343a815pxhover",
                "id": "btnResendOTP",
                "isVisible": false,
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.ResendOtp\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP0dabb3e467ecc44"
            });
            flxCloseSendOTPBusinessBanking.add(flxCloseSendOTPBB, flxHeaderNError, flxResetBySecureCode, lblOTPQuestion, flxOTP, btnNext, btnResendOTP);
            var flxEnroll = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "451dp",
                "id": "flxEnroll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                "top": "157dp",
                "width": "389dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnroll.setDefaultUnit(kony.flex.DP);
            var EnrollPromptScreen = new com.InfinityOLB.SelfServiceEnrolmentMA.EnrollAlert({
                "height": "380dp",
                "id": "EnrollPromptScreen",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "EnrollAlert": {
                        "height": "380dp"
                    },
                    "btnBackToLogin": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.HowToEnroll\")",
                        "zIndex": 1
                    },
                    "btnEnroll": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.EnrollLabel\")"
                    },
                    "imgEnroll": {
                        "src": "server_error.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEnroll.add(EnrollPromptScreen);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6.07%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "30dp",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyright = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "\\u00a9 Copyright Kony Retail Banking. All rights reserved. Your savings are federally insured to at least $250,000 and backed by the full faith and credit of the Government.",
                    "tagName": "span"
                },
                "id": "lblCopyright",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknSSPLblFFFFFF10Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                "top": "95%",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseFontIconParent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "45dp",
                "id": "flxCloseFontIconParent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "15%",
                "skin": "slFbox",
                "top": "60dp",
                "width": "45dp",
                "zIndex": 20,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseFontIconParent.setDefaultUnit(kony.flex.DP);
            var flxCloseFontIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close and go back to login"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseFontIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseFontIcon.setDefaultUnit(kony.flex.DP);
            var lblCloseFontIconCommon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close",
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblCloseFontIconCommon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseFontIcon.add(lblCloseFontIconCommon);
            flxCloseFontIconParent.add(flxCloseFontIcon);
            var lblBeyondBanking = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Relationships Beyond Banking",
                    "tagName": "span"
                },
                "id": "lblBeyondBanking",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknSSPLblFFFFFF30Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BeyondBanking\")",
                "top": "250dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBeyondBankingDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Integrated, easy-to-use web and mobile applications – built on the leading digital banking platform – to accelerate digital transformation, embrace rapid innovation, drive a frictionless customer experience and take control of your future.",
                    "tagName": "span"
                },
                "id": "lblBeyondBankingDesc",
                "isVisible": true,
                "left": "594dp",
                "skin": "sknSSPLblFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BeyondBankingDesc\")",
                "top": "295dp",
                "width": "50%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVeiwMore = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Learn More",
                    "allyARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnVeiwMore",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknbtn0273e3Viewmore",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.viewMore\")",
                "top": "344dp",
                "width": "130dp",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooterMenu = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "25dp",
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "91%",
                "width": "91.93%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var btnLocateUs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnLocateUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Locate Us"
            });
            var flxVBar1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "1px",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar1.setDefaultUnit(kony.flex.DP);
            flxVBar1.add();
            var btnContactUs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnContactUs",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Contact Us"
            });
            var flxVBar2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "1px",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar2.setDefaultUnit(kony.flex.DP);
            flxVBar2.add();
            var btnPrivacy = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnPrivacy",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.privacy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Privacy Policy"
            });
            var flxVBar3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 20,
                "isModalContainer": false,
                "right": 1,
                "skin": "sknflxe9ebee",
                "width": "1px",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar3.setDefaultUnit(kony.flex.DP);
            flxVBar3.add();
            var btnTermsAndConditions = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnTermsAndConditions",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Terms & Conditions"
            });
            var flxVBar4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "1px",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar4.setDefaultUnit(kony.flex.DP);
            flxVBar4.add();
            var btnFaqs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnFaqs",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.faqs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "FAQ"
            });
            flxFooterMenu.add(btnLocateUs, flxVBar1, btnContactUs, flxVBar2, btnPrivacy, flxVBar3, btnTermsAndConditions, flxVBar4, btnFaqs);
            var lblCopyrightDesktop = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCopyrightDesktop",
                "isVisible": false,
                "left": "581dp",
                "skin": "sknSSPLblFFFFFF12px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                "top": "815dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyrightTab1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "\\u00a9 Copyright Kony Retail Banking. All rights reserved.",
                    "tagName": "span"
                },
                "id": "lblCopyrightTab1",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyrightTab2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Your savings are federally insured to at least $250,000 and backed by the full faith and credit of the Government.",
                    "tagName": "span"
                },
                "id": "lblCopyrightTab2",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab2\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLogoutMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxLogoutMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogoutMsg.setDefaultUnit(kony.flex.DP);
            var imgLogoutSuccess = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "imgLogoutSuccess",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "41%",
                "skin": "slImage",
                "src": "logout_tick_mark.png",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoggedOut = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "You have logged out.",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblLoggedOut",
                "isVisible": true,
                "left": "45.50%",
                "skin": "CopyslLabel0fa183a5bd2a64c",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SuccessfullyLoggedOut\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogoutMsg.add(imgLogoutSuccess, lblLoggedOut);
            flxMain.add(imgKonyEnroll, flxDropdown, flxLanguagePicker, flxVerification, flxWelcomeBack, flxVerificationBB, flxResetPasswordOptions, flxSelectProductToEnrollFor, flxSendOTP, flxResetUsingOTP, flxResetUsingCVV, flxResetPassword, flxUsernameAndPassword, flxSecurityQuestions, flxSecurityQuestionsSelectedUsername, flxSecurityQuestionsAck, flxUsernameAndPasswordAck, flxUsernameAndPasswordAckSelectedUsername, flxusernamepassword, flxResetSuccessful, flxEnrollOrServerError, flxPhoneAndEmail, flxActivationLinkExpired, flxCloseSendOTPBusinessBanking, flxEnroll, imgKony, lblCopyright, flxCloseFontIconParent, lblBeyondBanking, lblBeyondBankingDesc, btnVeiwMore, flxFooterMenu, lblCopyrightDesktop, lblCopyrightTab1, lblCopyrightTab2, flxLogoutMsg);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxChangeLanguage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeLanguage.setDefaultUnit(kony.flex.DP);
            var CustomChangeLanguagePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomChangeLanguagePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "isVisible": true,
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "5%",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "text": "Language"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to change the language?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxChangeLanguage.add(CustomChangeLanguagePopup);
            var flxLoadingChangeLanguage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapperChangeLang = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapperChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapperChangeLang.setDefaultUnit(kony.flex.DP);
            var flxImageContainerChangeLang = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainerChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.setDefaultUnit(kony.flex.DP);
            var imgLoadingChangeLang = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoadingChangeLang",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.add(imgLoadingChangeLang);
            flxLoadingWrapperChangeLang.add(flxImageContainerChangeLang);
            var lblChangeLang = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblChangeLang",
                "isVisible": true,
                "left": "670dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.lblChangeLang\")",
                "top": "421dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1000
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.add(flxLoadingWrapperChangeLang, lblChangeLang);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "650dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Terms & Conditions",
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseTnC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseTnC",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxCloseTnC.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseTnC.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxCloseTnC);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0e928f718cfd143 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0e928f718cfd143",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0e928f718cfd143.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0e928f718cfd143.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(CopyflxDummy0e928f718cfd143, rtxTC);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0bd516b5896c94c = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0bd516b5896c94c",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0bd516b5896c94c.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0bd516b5896c94c.add();
            var flxBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "220dp",
                "htmlString": "Browser",
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "11dp",
                "setAsContent": false,
                "top": "194dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SelfServiceEnrolmentMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0bd516b5896c94c, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditions.add(flxTC);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1400,
                "640": {
                    "frmEnrollNow": {
                        "skin": "sknFrmffffff",
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgKonyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "11.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "segmentProps": []
                    },
                    "segLanguagesList": {
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "690dp"
                        },
                        "isVisible": true,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flexSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.flxCaptcha": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxLetsVerifyCntr": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxPhone": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.imgUserVerify": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7.45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7.45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLetsVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.login.CantSignIn.Letsverifyitsyou",
                        "segmentProps": []
                    },
                    "letsverify.lblTaxID": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblWrongInfo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "letsverify.tbxSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.tbxTaxID": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "26%"
                        },
                        "top": {
                            "type": "string",
                            "value": "369dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.flxInformation": {
                        "segmentProps": []
                    },
                    "AllForms.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "lblCloseFontIcon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxDP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "number",
                            "value": "85"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCantEnroll": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxCross": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "imgCross": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblCantEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "number",
                            "value": "18"
                        },
                        "segmentProps": []
                    },
                    "flxAlreadyEnroll": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgAlreadyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAlreadyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "60"
                        },
                        "segmentProps": []
                    },
                    "lblNote1": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNote2": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnActivateYourProfile": {
                        "skin": "sknBtnBg003e75Rad3pxFont15pxFFF",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnSignInNow": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnContact": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "role": "button",
                                "tabindex": 0
                            }
                        },
                        "isVisible": false,
                        "skin": "sknBtnBg003e75Rad3pxFont15pxFFF",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCallSupport": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVerificationBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "108%"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseVer": {
                        "segmentProps": []
                    },
                    "imgCloseVer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCloseFontIcon2": {
                        "segmentProps": []
                    },
                    "flxLetsgetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsgetStartedWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "imgLetsGetStarted": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "src": "user_verify.png",
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsgetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flexSSN": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblSSNNumber": {
                        "segmentProps": []
                    },
                    "flxWhatIsSSN": {
                        "segmentProps": []
                    },
                    "imgWhatIsSSN": {
                        "segmentProps": []
                    },
                    "AllFormsBB": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AllFormsBB.flxInformation": {
                        "segmentProps": []
                    },
                    "AllFormsBB.imgToolTip": {
                        "segmentProps": []
                    },
                    "tbxSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomDate"
                    },
                    "flxDateInput": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnProceedBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollResetPass": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserReset": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserBoundary": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblVerificationNotice": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterPIN.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntity": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntityValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntityValue": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknlblUserName",
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollForBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "text": "c",
                        "segmentProps": []
                    },
                    "PersonalBanking.imgOptionKA": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "61.90%"
                        },
                        "segmentProps": []
                    },
                    "OrLine.imgOr": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OrLine": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "39%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "BusinessBanking.imgOptionKA": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "56.99%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblWrongOTP": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92.02%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxHeaderNError": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66.18%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.tbxCVV": {
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxViewHideCVV": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgViewCVV": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResendOtp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWelcome": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lstbxCards": {
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.tbxCVV": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxUsernameAndPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImgUserNPassword": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMain": {
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxNewUserName": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgCorrectUserName": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRules": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRulesHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblErrorInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblPasswordDoesnotMatch": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "103dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblResetPasswordTitle": {
                        "top": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "newUsernamepasswordsetting"
                    },
                    "newUsernamepasswordsetting.rtxRulesPassword": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.rtxRulesUsername": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "SetSecurityQuestions"
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsCancel": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "width": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsProceed": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxEditSecuritySettingsButtons": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxPasswordRules": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule2": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRulesSecurityQuestions": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule2": {
                        "left": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRules": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblPleaseNote": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Answers are not case sensitive",
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRules": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSetSecurityQuesWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsVerifyCntr": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsVerify": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer1": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yLabel": "Answer 1 :",
                            "tagName": "span"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentSiginText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "rtxDescription": {
                        "segmentProps": []
                    },
                    "btnDocument": {
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "segmentProps": []
                    },
                    "btnDoItLaterUsingSecuritySettings": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "43dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.flxBottom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "securityAck.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "161dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblDone": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "securityAck.lblNotYetEnrolledOrError": {
                        "top": {
                            "type": "string",
                            "value": "41px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "securityAck"
                    },
                    "flxUsernameAndPasswordAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "UsenamePasswordSuccess"
                    },
                    "UsenamePasswordSuccess.btnProceed": {
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "You have set your Username & Password",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.orline": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxclose1": {
                        "segmentProps": []
                    },
                    "flxUsernameAndPasswordAckSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "680dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnProceed": {
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "56px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.orline": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxusernamepassword": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.flxUserImagewithTick": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "68.56%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "94.5%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "36.2%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47.019999999999996%"
                        },
                        "width": {
                            "type": "string",
                            "value": "54.88%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "top": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "string",
                            "value": "37%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnLogin": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnProceed": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxAgree": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "OTPModule.lblFavoriteEmailCheckBox": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "54%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lbxEmail": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lbxPhone": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "20%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "Enter Secure Access Code sent on\nyour mobile phone.",
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseMFA": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxActivationLinkExpired": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "rtxActivationLinkExpired": {
                        "segmentProps": []
                    },
                    "flxCloseSendOTPBusinessBanking": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderNError": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblResetBySecureCodeQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblOTPQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxOTP": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnNext": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "kony_logo.png",
                        "top": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblFFFFFF10Px",
                        "top": {
                            "type": "string",
                            "value": "763dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "right": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "730dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "148dp"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightDesktop": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "762dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "isVisible": false,
                        "skin": "sknChangeLangBlueGradientTwo",
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "string",
                            "value": "95%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "rtxTC": {
                        "segmentProps": []
                    },
                    "flxBody": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    }
                },
                "768": {
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgKonyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "17%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flexSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.flxCaptcha": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxLetsVerifyCntr": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.imgUserVerify": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblCallUs": {
                        "segmentProps": []
                    },
                    "letsverify.lblDOB": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLastName": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLetsVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "49.96%"
                        },
                        "i18n_text": "i18n.login.CantSignIn.Letsverifyitsyou",
                        "left": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblTaxID": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblWrongInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "letsverify.tbxSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.tbxTaxID": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "29%"
                        },
                        "top": {
                            "type": "string",
                            "value": "342dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "lblCloseFontIcon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "74"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxDP": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "segmentProps": []
                    },
                    "imgSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCantEnroll": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "imgCross": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblCantEnroll": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlreadyEnroll": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgAlreadyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlreadyEnroll": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblNote1": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNote2": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnActivateYourProfile": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnSignInNow": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnContact": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCallSupport": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVerificationBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "710dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseVer": {
                        "segmentProps": []
                    },
                    "imgCloseVer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCloseFontIcon2": {
                        "segmentProps": []
                    },
                    "flxLetsgetStarted": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsgetStartedWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "imgLetsGetStarted": {
                        "src": "user_verify.png",
                        "segmentProps": []
                    },
                    "lblLetsgetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "73dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "isVisible": false,
                        "text": "Label fhfhalkhflakfhweifhlf fafhalkfha falfkh",
                        "top": {
                            "type": "string",
                            "value": "103dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flexSSN": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "AllFormsBB": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AllFormsBB.imgToolTip": {
                        "segmentProps": []
                    },
                    "tbxSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomDate"
                    },
                    "flxDateInput": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnProceedBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "top": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollResetPass": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "lblVerificationNotice": {
                        "top": {
                            "type": "string",
                            "value": "48.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV.rtxCVV": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterPIN.rtxCVV": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntity": {
                        "left": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntityValue": {
                        "segmentProps": []
                    },
                    "lblSelectedEntityValue": {
                        "left": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollForBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "103%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "text": "c",
                        "segmentProps": []
                    },
                    "PersonalBanking.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PersonalBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "OrLine.imgOr": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OrLine": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.2%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "BusinessBanking.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "BusinessBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "resetusingOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "78.07%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.04%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "72.21%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "11px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66.91%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxViewHideCVV": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgViewCVV": {
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWelcome": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxUsernameAndPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImgUserNPassword": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMain": {
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxNewUserName": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgCorrectUserName": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRules": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRulesHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblPasswordDoesnotMatch": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "103dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblResetPasswordTitle": {
                        "text": "Enrolling to Online Banking",
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "newUsernamepasswordsetting"
                    },
                    "newUsernamepasswordsetting.rtxRulesPassword": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.rtxRulesUsername": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "SetSecurityQuestions"
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsCancel": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsProceed": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "right": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxPasswordRules": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule2": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRulesSecurityQuestions": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule2": {
                        "left": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRules": {
                        "height": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblPleaseNote": {
                        "left": {
                            "type": "string",
                            "value": "43dp"
                        },
                        "text": "Please note the following points:",
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRules": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "655dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxSetSecurityQuesWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsVerifyCntr": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsVerify": {
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "segmentProps": []
                    },
                    "btnDoItLaterUsingSecuritySettings": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "161dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblDone": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "securityAck.lblNotYetEnrolledOrError": {
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "securityAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "securityAck"
                    },
                    "flxUsernameAndPasswordAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "UsenamePasswordSuccess"
                    },
                    "UsenamePasswordSuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "72px"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67.57%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.orline": {
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "flxclose1": {
                        "segmentProps": []
                    },
                    "flxUsernameAndPasswordAckSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "680dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnProceed": {
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "72px"
                        },
                        "width": {
                            "type": "string",
                            "value": "51.93%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67.57%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "flxusernamepassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.btnLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "38px"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.flxUserImagewithTick": {
                        "top": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.lblAcknowledgement": {
                        "top": {
                            "type": "string",
                            "value": "14px"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.lblMessage": {
                        "top": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "68.56%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "94.5%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "35.2%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47.019999999999996%"
                        },
                        "width": {
                            "type": "string",
                            "value": "53.90%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "top": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "71.95%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "297dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "OTPModule.lblFavoriteEmailCheckBox": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "54%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "280px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "20%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivationLinkExpired": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSendOTPBusinessBanking": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderNError": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "segmentProps": []
                    },
                    "lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblResetBySecureCodeQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblOTPQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxOTP": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "btnNext": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "kony_logo.png",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "770dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "left": {
                            "type": "number",
                            "value": "12"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblCopyrightDesktop": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "805dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "95%"
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "sknChangeLangBlueGradientTwo",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgKonyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "27%"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "720dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flexSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.flxCaptcha": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxDateInput": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxLetsVerifyCntr": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "189dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.imgUserVerify": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLetsVerify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.login.CantSignIn.Letsverifyitsyou",
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblTaxID": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblWrongInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "letsverify.tbxLastName": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.tbxSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.tbxTaxID": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "28%"
                        },
                        "top": {
                            "type": "string",
                            "value": "342dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "lblCloseFontIcon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxDP": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "imgSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "56%"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "number",
                            "value": "90"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCantEnroll": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblCantEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxAlreadyEnroll": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "imgAlreadyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAlreadyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblNote1": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblNote2": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnActivateYourProfile": {
                        "isVisible": true,
                        "skin": "CopyslButtonGlossBlue0i1876f1874e649",
                        "segmentProps": []
                    },
                    "btnSignInNow": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnContact": {
                        "isVisible": false,
                        "skin": "sknBtnBg003e75Rad3pxFont15pxFFF",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblCallSupport": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVerificationBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "710dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseVer": {
                        "segmentProps": []
                    },
                    "imgCloseVer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCloseFontIcon2": {
                        "segmentProps": []
                    },
                    "flxLetsgetStarted": {
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsgetStartedWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "imgLetsGetStarted": {
                        "src": "user_verify.png",
                        "segmentProps": []
                    },
                    "lblLetsgetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flexSSN": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AllFormsBB": {
                        "segmentProps": []
                    },
                    "AllFormsBB.imgToolTip": {
                        "segmentProps": []
                    },
                    "tbxSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomDate"
                    },
                    "flxDateInput": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "DateInput": {
                        "segmentProps": [],
                        "instanceId": "DateInput"
                    },
                    "lblCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnProceedBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "top": {
                            "type": "string",
                            "value": "86dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollResetPass": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "lblVerificationNotice": {
                        "top": {
                            "type": "string",
                            "value": "46.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "71.66%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntity": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "28.62%"
                        },
                        "left": {
                            "type": "string",
                            "value": "11.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntity": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntityValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntityValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "11px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "16.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollForBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "text": "c",
                        "segmentProps": []
                    },
                    "PersonalBanking.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PersonalBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "OrLine.imgOr": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OrLine": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "BusinessBanking.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "BusinessBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "text": "Send",
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgUserOutline": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68.40%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83.00%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "39dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxEnrollResetOTP": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "29%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "13px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "76.67%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxViewHideCVV": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgViewCVV": {
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWelcome": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxUsernameAndPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImageUser": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImgUserNPassword": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMain": {
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMatchPassword": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxNewUserName": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgCorrectUserName": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRules": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRulesHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblPasswordDoesnotMatch": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblResetPasswordTitle": {
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "newUsernamepasswordsetting"
                    },
                    "newUsernamepasswordsetting.rtxRulesPassword": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.rtxRulesUsername": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "SetSecurityQuestions"
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsCancel": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "width": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsProceed": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxEditSecuritySettingsButtons": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "132dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxPasswordRules": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule2": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRulesSecurityQuestions": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "385px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule2": {
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRules": {
                        "height": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblPleaseNote": {
                        "left": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "text": "Please note the following points:",
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRules": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxSetSecurityQuesWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsVerifyCntr": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsVerify": {
                        "left": {
                            "type": "string",
                            "value": "113dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "340px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "segmentProps": []
                    },
                    "btnDoItLaterUsingSecuritySettings": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.btnLoginLater": {
                        "text": "DONE",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "189dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblDone": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "securityAck.lblNotYetEnrolledOrError": {
                        "top": {
                            "type": "string",
                            "value": "71px"
                        },
                        "segmentProps": []
                    },
                    "securityAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "securityAck"
                    },
                    "flxUsernameAndPasswordAck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "UsenamePasswordSuccess"
                    },
                    "UsenamePasswordSuccess.btnLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblLoginNextTime": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.orline": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxclose1": {
                        "segmentProps": []
                    },
                    "flxUsernameAndPasswordAckSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "660dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxSuccesImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60.26%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxusernamepassword": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.flxUserImagewithTick": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "61.56%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "top": {
                            "type": "string",
                            "value": "87.5%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "192dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47.019999999999996%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70.03%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "string",
                            "value": "39%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.flxServerError": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "width": {
                            "type": "string",
                            "value": "76.37%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "132dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "centerX": {
                            "type": "string",
                            "value": "53%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblFavoriteEmailCheckBox": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "0%"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "text": "Sorry, this secure code is incorrect. Try again.Sorry, this secure code is incorrect. Try again.Sorry, this secure code is incorrect. Try again.",
                        "top": {
                            "type": "string",
                            "value": "260px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "54%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivationLinkExpired": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSendOTPBusinessBanking": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderNError": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblResetBySecureCodeQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblOTPQuestion": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxOTP": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnNext": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "src": "kony_logo.png",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "12"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblCopyrightDesktop": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "835dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "810dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "95%"
                        },
                        "top": {
                            "type": "string",
                            "value": "95.5%"
                        },
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknChangeLangBlueGradientTwo",
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1400": {
                    "tbxAutopopulateIssueFix": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "tbxInvisible",
                        "text": "test",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgKonyEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "src": "digital_banking.png",
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "O",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.btnPhone": {
                        "segmentProps": []
                    },
                    "letsverify.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flexSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.flxCaptcha": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxDateInput": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxLetsVerifyCntr": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "153dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxPhone": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.imgUserVerify": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblCallUs": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblDOB": {
                        "left": {
                            "type": "number",
                            "value": "80"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLastName": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblLetsVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.login.CantSignIn.Letsverifyitsyou",
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Let's verify it's you",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblTaxID": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.lblWrongInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "letsverify.tbxLastName": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "letsverify.tbxSSN": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "letsverify.tbxTaxID": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "365dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "lblCloseFontIcon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "74dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "imgSuccess": {
                        "segmentProps": []
                    },
                    "lblUserName": {
                        "skin": "sknlblUserName",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCantEnroll": {
                        "height": {
                            "type": "string",
                            "value": "74dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxAlreadyEnroll": {
                        "height": {
                            "type": "string",
                            "value": "74dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblNote1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Note 1",
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "segmentProps": []
                    },
                    "lblNote2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "text": "Note 2",
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "btnActivateYourProfile": {
                        "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnSignInNow": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "96dp"
                        },
                        "segmentProps": []
                    },
                    "btnContact": {
                        "isVisible": false,
                        "skin": "sknBtnBg003e75Rad3pxFont15pxFFF",
                        "top": {
                            "type": "string",
                            "value": "96dp"
                        },
                        "segmentProps": []
                    },
                    "lblCallSupport": {
                        "accessibilityConfig": {},
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxVerificationBB": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "108%"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseVer": {
                        "segmentProps": []
                    },
                    "imgCloseVer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCloseFontIcon2": {
                        "segmentProps": []
                    },
                    "flxLetsgetStarted": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsgetStartedWrapper": {
                        "centerX": {
                            "type": "number",
                            "value": "30"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "imgLetsGetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "src": "user_verify.png",
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsgetStarted": {
                        "centerX": {
                            "type": "string",
                            "value": "46%"
                        },
                        "left": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInformation": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterLastName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblSSN": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flexSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblSSNNumber": {
                        "text": "Social Security Number",
                        "segmentProps": []
                    },
                    "AllFormsBB": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AllFormsBB.imgToolTip": {
                        "segmentProps": []
                    },
                    "tbxSSN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblDOB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxDateInput": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "DateInput": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "DateInput"
                    },
                    "lblCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "tbxCompanyId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "btnProceedBB": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblCallUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnPhone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseResetPassword": {
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "80"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollResetPass": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserReset": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserBoundary": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblVerificationNotice": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "63dp"
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "313dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.04%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "text": "x",
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "text": "y",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollFor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntity": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntity": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSelectedEntityValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "356dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedEntityValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectProductToEnrollFor": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "75px"
                        },
                        "skin": "sknlblUserName",
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectProductToEnrollForBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "396dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.040000000000000036%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": true,
                        "text": "c",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.imgOptionKA": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "PersonalBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "OrLine.imgOr": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OrLine": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "36.3%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "61%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flcVerticalBar": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": true,
                        "text": "d",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.imgOptionKA": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "enrollbb.png",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.imgRightTip": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "BusinessBanking.rtxCVV": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSelectProduct": {
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "Send",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxEnrollResetOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "7"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "6.52%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80.56%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "51.94%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "72.75%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.tbxCVV": {
                        "segmentProps": []
                    },
                    "flxCloseSendOTP": {
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnResendOTP": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "39dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxEnrollResetOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flximgtext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "6px"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70.00%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "54.18%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.tbxCVV": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseResetUsingOTP": {
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "112dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "136dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxViewHideCVV": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgViewCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "10"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWelcome": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "73dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.tbxCVV": {
                        "segmentProps": []
                    },
                    "flxCloseResetUsingCVV": {
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseResetPswd": {
                        "segmentProps": []
                    },
                    "flxUsernameAndPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.btnCreate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "78"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxImgUserNPassword": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMain": {
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxNewPassword": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxNewUserName": {
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxPasswordRulesHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.flxRulesUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgCorrectUserName": {
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRules": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgRulesHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblErrorInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "61"
                        },
                        "top": {
                            "type": "string",
                            "value": "113dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblPasswordDoesnotMatch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "81%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.lblResetPasswordTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "newUsernamepasswordsetting"
                    },
                    "newUsernamepasswordsetting.rtxRulesPassword": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.rtxRulesUsername": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "newUsernamepasswordsetting.tbxNewUserName": {
                        "segmentProps": []
                    },
                    "flxCloseUsernamePassowrd": {
                        "segmentProps": []
                    },
                    "flxSecurityQuestions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "SetSecurityQuestions"
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.50%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.btnSetSecurityQuestionsProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "52.75%"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.50%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxEditSecuritySettingsButtons": {
                        "height": {
                            "type": "string",
                            "value": "10%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxPasswordRules": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule1": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRule2": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxRulesSecurityQuestions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet4": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSecurityQASet5": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.flxSeparatorHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "14%"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.imgRule2": {
                        "left": {
                            "type": "string",
                            "value": "14%"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblPleaseNote": {
                        "text": "Please note the following points:",
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRule2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lblRules": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "SetSecurityQuestions.tbxAnswer1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseResetSelectedUsername": {
                        "segmentProps": []
                    },
                    "flxSetSecurityQuesWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxLetsVerifyCntr": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserVerify": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserVerify": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLetsVerify": {
                        "left": {
                            "type": "string",
                            "value": "123dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "lblWrongInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxScrollContainerSetSecurityQuestions": {
                        "height": {
                            "type": "string",
                            "value": "440px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblQuestionsHeading": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet3": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet4": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQASet5": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxQuestion5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblAnswer5": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnDoItLaterUsingSecuritySettings": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecurityQuestionsAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "56px"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.flxBottom": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "19.65%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblDone": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "securityAck.lblNotYetEnrolledOrError": {
                        "top": {
                            "type": "string",
                            "value": "33px"
                        },
                        "width": {
                            "type": "string",
                            "value": "69.02%"
                        },
                        "segmentProps": []
                    },
                    "securityAck.orline": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "securityAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "securityAck"
                    },
                    "flxUsernameAndPasswordAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "UsenamePasswordSuccess"
                    },
                    "UsenamePasswordSuccess.btnLoginLater": {
                        "text": "Done. Login Later",
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblLoginNextTime": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68.20%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccess.orline": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "segmentProps": []
                    },
                    "flxUsernameAndPasswordAckSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnLoginLater": {
                        "text": "DONE",
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblLoginNextTime": {
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.lblMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68.20%"
                        },
                        "segmentProps": []
                    },
                    "UsenamePasswordSuccessAck.orline": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "segmentProps": []
                    },
                    "flxusernamepassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ForgotUsernamePassword"
                    },
                    "ForgotUsernamePassword.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.flxUserImagewithTick": {
                        "top": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.lblAcknowledgement": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "59.62%"
                        },
                        "segmentProps": []
                    },
                    "ForgotUsernamePassword.lblMessage": {
                        "text": "If you have forgot your username or password, please use the forgot option.",
                        "top": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnLoginLater": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "49.56%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "top": {
                            "type": "string",
                            "value": "67.5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "152dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "78"
                        },
                        "top": {
                            "type": "string",
                            "value": "17.93%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "142"
                        },
                        "top": {
                            "type": "string",
                            "value": "19.50%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "35.019999999999996%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.btnEnroll": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnrollAlert.lblHowToEnroll": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnrollAlert.lblNotYetEnrolledOrError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule": {
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "top": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblFavoriteEmailCheckBox": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "text": "D",
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendMessage": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "80%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "29px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivationLinkExpired": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxCloseSendOTPBusinessBanking": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSendOTPBB": {
                        "segmentProps": []
                    },
                    "flxHeaderNError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblWrongOTP": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageUser": {
                        "left": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblResetBySecureCodeQuestion": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblOTPQuestion": {
                        "text": "Do you want us to send the Secure Access Code ?",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxOTP": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnNext": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnResendOTP": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxBgFFFFFFNoBdrShadow104c7d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "src": "kony_logo.png",
                        "top": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "91%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": "455dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "skin": "sknSSPLblFFFFFF30Px",
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "focusSkin": "sknbtn0a78d1viewmoreFocus",
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "skin": "sknbtn0273e3Viewmore",
                        "top": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "zIndex": 20,
                        "hoverSkin": "sknbtn41a0edviewmoreHover",
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "bottom": {
                            "type": "string",
                            "value": "70px"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Contact Us   ",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxVBar1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Contact Us    ",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxVBar2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Contact Us   ",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxVBar3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Contact Us   ",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxVBar4": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Contact Us   ",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "lblCopyrightDesktop": {
                        "bottom": {
                            "type": "string",
                            "value": "20px"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "sknSSPLblFFFFFF12px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "skin": "sknChangeLangBlueGradientTwo",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingWrapperChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxImageContainerChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "letsverify.btnProceed": {
                    "left": "",
                    "top": "42dp",
                    "width": "100%"
                },
                "letsverify.flxCaptcha": {
                    "centerX": "",
                    "left": "0dp",
                    "width": "100%"
                },
                "letsverify.flxDateInput": {
                    "left": "",
                    "top": "5dp",
                    "width": "85%"
                },
                "letsverify.flxLetsVerifyCntr": {
                    "centerX": "",
                    "height": "64dp",
                    "left": "0dp",
                    "top": "20dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "letsverify.flxPhone": {
                    "bottom": "25dp",
                    "centerX": "49%",
                    "left": 0,
                    "top": "",
                    "width": "85%"
                },
                "letsverify.flxUserVerify": {
                    "centerX": "",
                    "centerY": "",
                    "left": "7%",
                    "right": "",
                    "top": "0.6600000000000001%"
                },
                "letsverify.imgCaptcha": {
                    "src": "imagedrag.png"
                },
                "letsverify.imgUserVerify": {
                    "height": "52dp",
                    "left": "7%",
                    "src": "user_verify.png",
                    "width": "52dp"
                },
                "letsverify.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "letsverify.lblCallUs": {
                    "bottom": "",
                    "centerX": "50.00%",
                    "left": "",
                    "right": "",
                    "top": "0dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "letsverify.lblDOB": {
                    "centerX": "",
                    "left": "7.45%",
                    "top": "30dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "letsverify.lblLastName": {
                    "centerX": "",
                    "left": "7.45%",
                    "top": "40dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "letsverify.lblLetsVerify": {
                    "centerX": "45.46%",
                    "left": "",
                    "right": "",
                    "top": "10%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "letsverify.lblTaxID": {
                    "left": "0%",
                    "top": "0dp",
                    "width": "85%"
                },
                "letsverify.lblWrongInfo": {
                    "width": "84%"
                },
                "letsverify": {
                    "centerX": "",
                    "left": "0dp",
                    "top": "0dp"
                },
                "letsverify.tbxLastName": {
                    "left": "",
                    "top": "3dp",
                    "width": "85%"
                },
                "letsverify.tbxTaxID": {
                    "left": "",
                    "top": "4dp",
                    "width": "85%"
                },
                "AllForms": {
                    "left": "19.80%",
                    "top": "265dp",
                    "width": "270dp",
                    "zIndex": 20
                },
                "AllForms.RichTextInfo": {
                    "width": "83%"
                },
                "AllForms.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AllForms.imgToolTip": {
                    "left": "39%",
                    "src": "tool_tip.png"
                },
                "AllFormsBB": {
                    "centerX": "4dp",
                    "left": "",
                    "top": "17dp",
                    "width": "270dp",
                    "zIndex": 20
                },
                "AllFormsBB.RichTextInfo": {
                    "width": "83%"
                },
                "AllFormsBB.flxInformation": {
                    "width": "99%"
                },
                "AllFormsBB.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AllFormsBB.imgToolTip": {
                    "left": "130dp",
                    "src": "tool_tip.png",
                    "width": "20dp"
                },
                "CustomDate": {
                    "centerX": "",
                    "left": "75dp"
                },
                "DateInput": {
                    "centerX": "50%",
                    "height": "100%",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "AlterneteActionsEnterCVV": {
                    "height": "14%",
                    "top": "8.80%"
                },
                "AlterneteActionsEnterCVV.fontIconOption": {
                    "text": "x"
                },
                "AlterneteActionsEnterCVV.imgOptionKA": {
                    "src": "active_cvv_icon.png"
                },
                "AlterneteActionsEnterCVV.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsEnterCVV.rtxCVV": {
                    "left": "85dp",
                    "width": "61.90%"
                },
                "OrLineForCVVandPIN.imgOr": {
                    "src": "or_circle.png"
                },
                "OrLineForCVVandPIN": {
                    "centerX": "50%",
                    "height": "30dp",
                    "top": "5.28%",
                    "width": "85%"
                },
                "AlterneteActionsEnterPIN": {
                    "height": "14%",
                    "top": "5.28%",
                    "width": "85%"
                },
                "AlterneteActionsEnterPIN.fontIconOption": {
                    "text": "y"
                },
                "AlterneteActionsEnterPIN.imgOptionKA": {
                    "src": "active_send_pin.png"
                },
                "AlterneteActionsEnterPIN.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "PersonalBanking": {
                    "height": "14%",
                    "top": "8.80%"
                },
                "PersonalBanking.flxImgContainer": {
                    "height": "95%",
                    "width": "110dp"
                },
                "PersonalBanking.flxImgMain": {
                    "height": "100%",
                    "width": "90%"
                },
                "PersonalBanking.fontIconOption": {
                    "left": "",
                    "right": "0dp",
                    "text": "L",
                    "width": "30dp"
                },
                "PersonalBanking.imgOptionKA": {
                    "centerX": "50%",
                    "src": "icon_personalbanking_3x.png"
                },
                "PersonalBanking.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "PersonalBanking.rtxCVV": {
                    "centerY": "50.00%",
                    "left": "110dp",
                    "width": "61.90%"
                },
                "OrLine.imgOr": {
                    "src": "or_circle.png"
                },
                "OrLine.lblCrossOr": {
                    "height": "2dp"
                },
                "OrLine": {
                    "centerX": "50%",
                    "height": "30dp",
                    "top": "5.28%",
                    "width": "88%"
                },
                "BusinessBanking": {
                    "height": "14%",
                    "top": "68%"
                },
                "BusinessBanking.flxImgContainer": {
                    "height": "95%",
                    "width": "110dp"
                },
                "BusinessBanking.flxImgMain": {
                    "height": "100%",
                    "width": "90%"
                },
                "BusinessBanking.fontIconOption": {
                    "centerY": "",
                    "left": "",
                    "right": "0dp",
                    "text": "t",
                    "top": "16dp",
                    "width": "30dp"
                },
                "BusinessBanking.imgOptionKA": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "32dp",
                    "left": "0dp",
                    "right": "",
                    "src": "enrollbb.png",
                    "top": "0dp",
                    "width": "33dp"
                },
                "BusinessBanking.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "BusinessBanking.rtxCVV": {
                    "centerY": "50.00%",
                    "left": "110dp",
                    "width": "61.90%"
                },
                "resetusingOTP.btnNext": {
                    "text": "S"
                },
                "resetusingOTP.imgCVVOrOTP": {
                    "src": "send_pin.png"
                },
                "resetusingOTP.imgUser": {
                    "src": "default_username.png"
                },
                "resetusingOTP.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "resetusingOTP.imgViewCVV": {
                    "src": "view.png"
                },
                "resetusingOTP.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "resetusingOTP": {
                    "height": "580dp"
                },
                "resetusingOTP.tbxCVV": {
                    "height": "100%"
                },
                "resetusingOTPEnterOTP.btnNext": {
                    "zIndex": 1
                },
                "resetusingOTPEnterOTP.flximgtext": {
                    "width": "100%"
                },
                "resetusingOTPEnterOTP.imgCVVOrOTP": {
                    "src": "send_pin.png"
                },
                "resetusingOTPEnterOTP.imgUser": {
                    "src": "default_username.png"
                },
                "resetusingOTPEnterOTP.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "resetusingOTPEnterOTP.imgViewCVV": {
                    "src": "view.png"
                },
                "resetusingOTPEnterOTP.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "resetusingOTPEnterOTP": {
                    "height": "580dp"
                },
                "resetusingOTPEnterOTP.tbxCVV": {
                    "width": "100%"
                },
                "ResetOrEnroll": {
                    "height": "580dp"
                },
                "ResetOrEnroll.flxHeaderNError": {
                    "height": "55dp"
                },
                "ResetOrEnroll.imgCVV": {
                    "src": "cvv_icon.png"
                },
                "ResetOrEnroll.imgUser": {
                    "src": "default_username.png"
                },
                "ResetOrEnroll.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "ResetOrEnroll.imgViewCVV": {
                    "height": "16dp",
                    "src": "view.png",
                    "width": "22dp"
                },
                "ResetOrEnroll.lblResetPassword": {
                    "top": "0dp"
                },
                "ResetOrEnroll.lblWrongCvv": {
                    "bottom": "0dp",
                    "top": ""
                },
                "ResetOrEnroll.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "ResetOrEnroll.rtxEnterCVV": {
                    "text": "Enter the CVV code of your credit or debit card",
                    "top": "5dp"
                },
                "ResetOrEnroll.tbxCVV": {
                    "width": "100%"
                },
                "newpasswordsetting.imgPasswordMatched": {
                    "src": "success_icon.png"
                },
                "newpasswordsetting.imgRules": {
                    "src": "info.png"
                },
                "newpasswordsetting.imgUser": {
                    "src": "default_username.png"
                },
                "newpasswordsetting.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "newpasswordsetting.imgValidPassword": {
                    "src": "success_icon.png"
                },
                "newUsernamepasswordsetting.flxMain": {
                    "height": "100%"
                },
                "newUsernamepasswordsetting.flxRulesPassword": {
                    "height": "115dp"
                },
                "newUsernamepasswordsetting.flxRulesUsername": {
                    "height": "75dp",
                    "minHeight": "20dp"
                },
                "newUsernamepasswordsetting.imgCorrectUserName": {
                    "src": "success_green.png"
                },
                "newUsernamepasswordsetting.imgPasswordMatched": {
                    "src": "success_green.png"
                },
                "newUsernamepasswordsetting.imgRules": {
                    "src": "info.png"
                },
                "newUsernamepasswordsetting.imgRulesHeader": {
                    "src": "info.png"
                },
                "newUsernamepasswordsetting.imgUser": {
                    "src": "default_username.png"
                },
                "newUsernamepasswordsetting.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "newUsernamepasswordsetting.imgValidPassword": {
                    "src": "success_green.png"
                },
                "SetSecurityQuestions.btnSetSecurityQuestionsCancel": {
                    "width": "43.25%"
                },
                "SetSecurityQuestions.btnSetSecurityQuestionsProceed": {
                    "width": "43.25%"
                },
                "SetSecurityQuestions.flxRulesSecurityQuestions": {
                    "width": "85%"
                },
                "SetSecurityQuestions.flxScrollContainerSetSecurityQuestions": {
                    "top": "25dp"
                },
                "SetSecurityQuestions.flxSeparatorHeader": {
                    "top": "20dp"
                },
                "SetSecurityQuestions.imgRule1": {
                    "centerY": "50%",
                    "src": "pageoffdot.png"
                },
                "SetSecurityQuestions.imgRule2": {
                    "src": "pageoffdot.png"
                },
                "SetSecurityQuestions.imgRules": {
                    "src": "info.png"
                },
                "SetSecurityQuestions.lblHeading": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "securityAck.btnLoginLater": {
                    "text": "DONE"
                },
                "securityAck.flxBottom": {
                    "height": "60dp"
                },
                "securityAck.lblDone": {
                    "centerX": "50%"
                },
                "securityAck.lblLoginNextTime": {
                    "centerX": "50%",
                    "top": "28dp"
                },
                "UsenamePasswordSuccess.flxUserImagewithTick": {
                    "width": "84.40%"
                },
                "UsenamePasswordSuccess.imgTickFrame": {
                    "src": "user_verify_success_frame.png"
                },
                "UsenamePasswordSuccess.imgUserwithoutTick": {
                    "src": "default_username.png"
                },
                "UsenamePasswordSuccess.lblAcknowledgement": {
                    "centerX": "48.37%",
                    "text": "You have set your  Username & Password",
                    "width": "63.98%"
                },
                "UsenamePasswordSuccess.lblMessage": {
                    "width": "75%"
                },
                "UsenamePasswordSuccess.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "UsenamePasswordSuccessAck.btnProceed": {
                    "top": "200dp"
                },
                "UsenamePasswordSuccessAck.flxUserImagewithTick": {
                    "centerX": "50%",
                    "width": "84.40%"
                },
                "UsenamePasswordSuccessAck.imgTickFrame": {
                    "src": "user_verify_success_frame.png"
                },
                "UsenamePasswordSuccessAck.imgUserwithoutTick": {
                    "src": "default_username.png"
                },
                "UsenamePasswordSuccessAck.lblAcknowledgement": {
                    "centerX": "48.37%",
                    "width": "63.98%"
                },
                "UsenamePasswordSuccessAck.lblLoginNextTime": {
                    "top": "40dp"
                },
                "UsenamePasswordSuccessAck.lblMessage": {
                    "width": "75%"
                },
                "UsenamePasswordSuccessAck.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "ForgotUsernamePassword.lblMessage": {
                    "text": "If you have forgot your username or password , please use the forgot option."
                },
                "passwordresetsuccess.imgTickFrame": {
                    "src": "user_verify_success_frame.png"
                },
                "passwordresetsuccess.imgUserwithoutTick": {
                    "src": "default_username.png"
                },
                "passwordresetsuccess.orlineSuccess.imgOr": {
                    "src": "or_circle.png"
                },
                "OTPModule.flxAgree": {
                    "top": "30dp"
                },
                "OTPModule.flxCVV": {
                    "width": "350dp"
                },
                "OTPModule.flxDescription": {
                    "centerX": ""
                },
                "OTPModule.flxEnterSecureAccessCode": {
                    "left": "7dp"
                },
                "OTPModule.flxImgTxt": {
                    "height": "150px",
                    "top": "100dp",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "OTPModule.flximgrtx": {
                    "height": "160dp",
                    "top": "100dp"
                },
                "OTPModule.imgPhoneOTP": {
                    "src": "send_pin.png"
                },
                "OTPModule.imgRememberMe": {
                    "src": "unchecked_box.png"
                },
                "OTPModule.lblFavoriteEmailCheckBox": {
                    "text": "C"
                },
                "OTPModule.lblHeaderOTP": {
                    "width": "91%"
                },
                "OTPModule.lblOTP": {
                    "centerX": "",
                    "height": "66dp"
                },
                "OTPModule.lblPhoneOTP": {
                    "height": "66dp"
                },
                "OTPModule.lblWrongOTP": {
                    "text": "Sorry, this secure code is incorrect. Try again.",
                    "top": "245px"
                },
                "OTPModule.rtxEnterCVVCode": {
                    "height": "65dp",
                    "top": "0dp",
                    "width": "310dp"
                },
                "OTPModule.tbxCVV": {
                    "centerY": "53%"
                },
                "EnrollPromptScreen": {
                    "height": "380dp"
                },
                "EnrollPromptScreen.btnBackToLogin": {
                    "zIndex": 1
                },
                "EnrollPromptScreen.imgEnroll": {
                    "src": "server_error.png"
                },
                "CustomChangeLanguagePopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomChangeLanguagePopup.btnNo": {
                    "width": "150dp"
                },
                "CustomChangeLanguagePopup.btnYes": {
                    "right": "5%",
                    "width": "150dp"
                },
                "CustomChangeLanguagePopup.lblHeading": {
                    "text": "Language"
                },
                "CustomChangeLanguagePopup.lblPopupMessage": {
                    "text": "Are you sure you want to change the language?"
                }
            }
            this.add(tbxAutopopulateIssueFix, flxMain, flxLoading, flxChangeLanguage, flxLoadingChangeLanguage, flxTermsAndConditions);
        };
        return [{
            "addWidgets": addWidgetsfrmEnrollNow,
            "enabledForIdleTimeout": true,
            "id": "frmEnrollNow",
            "init": controller.AS_Form_j2c694db7f3b4081815dbdb9e6669ba0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_g92f0de3822e4f0eaacec0708d95cf05,
            "postShow": controller.AS_Form_a96fba2f050442c6ac1ebee41f29e2b9,
            "preShow": function(eventobject) {
                controller.AS_Form_b4ec7767960e4f978c897f3f29856a8c(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmWhiteBackgroung",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 768, 1024, 1400],
            "onBreakpointChange": controller.AS_Form_ccd28ca812444b5abec806a14c54973d,
            "appName": "SelfServiceEnrolmentMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_i750d7fa3a424782b31515a203b6b1ca,
            "retainScrollPosition": false
        }]
    }
});