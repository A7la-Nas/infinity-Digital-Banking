define(function() {
    return {
        "properties": [{
            "name": "renderMode",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "codeText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "codeWidth",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "codeHeight",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "colorDark",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "colorLight",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "correctLevel",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setContext", "generateQRCode"],
        "events": []
    }
});