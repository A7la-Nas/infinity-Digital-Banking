define("BillPayMA/BillPaymentUIModule/frmPayABill", function() {
    return function(controller) {
        function addWidgetsfrmPayABill() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblPayABill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Pay A Bill",
                    "tagName": "h1"
                },
                "id": "lblPayABill",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.payABill\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnSkipRight = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yValue": "Skip to bill pay options"
                },
                "height": "30dp",
                "id": "btnSkipRight",
                "isVisible": true,
                "left": "20.07%",
                "right": 50,
                "skin": "btnSkipNavigation",
                "top": "-30dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxBillPayeeInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBillPayeeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayeeInfo.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "10dp",
                "width": "95.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxErrorPayBill = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Please verify the payment amount and your account balance."
                },
                "centerY": "50%",
                "id": "rtxErrorPayBill",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billpay.error.invalidAmount\")",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(imgError, rtxErrorPayBill);
            var flxContainerPayeeInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": false,
                "id": "flxContainerPayeeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainerPayeeInfo.setDefaultUnit(kony.flex.DP);
            var flxPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "40%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayee.setDefaultUnit(kony.flex.DP);
            var lblPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Payee"
                },
                "id": "lblPayee",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Payee\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 4, 0],
                "paddingInPixel": false
            }, {});
            var lbxpayee = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxpayee",
                "isVisible": false,
                "left": "30dp",
                "masterData": [
                    ["Key148", "Personal Checking...123"]
                ],
                "skin": "sknlbx15SSPe424242Border3e3e3Radius2px",
                "top": "40dp",
                "width": "30.10%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxPayeeDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPayeeDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "right": "-18dp",
                "skin": "slFbox",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetails.setDefaultUnit(kony.flex.DP);
            var flxPayeeIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxPayeeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "5dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeIcon.setDefaultUnit(kony.flex.DP);
            var lblIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblIcon",
                "isVisible": true,
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeIcon.add(lblIcon);
            var flxPayeeName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPayeeName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeName.setDefaultUnit(kony.flex.DP);
            var lblPayeeName1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblPayeeName1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AT&T Mobile phone",
                "top": "0dp",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayeeName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblPayeeName",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AT&T Mobile phone",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLastPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblLastPayment",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424213pxopahalf",
                "text": "Last payment : $15.00 ",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillActive = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Ebill Active",
                    "tagName": "label"
                },
                "height": "20px",
                "id": "lblEbillActive",
                "isVisible": true,
                "right": "48px",
                "top": "10px",
                "width": "36px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeName.add(lblPayeeName1, lblPayeeName, lblLastPayment, lblEbillActive);
            flxPayeeDetails.add(flxPayeeIcon, flxPayeeName);
            flxPayee.add(lblPayee, lbxpayee, flxPayeeDetails);
            var flxDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var lblDueDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Due Date"
                },
                "id": "lblDueDate",
                "isVisible": true,
                "left": "47.50%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DueDate\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var lblDueDateValue1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblDueDateValue1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "06/01/2017",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var lblDueDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblDueDateValue",
                "isVisible": true,
                "left": "47.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "06/01/2017",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(lblDueDate, lblDueDateValue1, lblDueDateValue);
            var flxBill = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBill",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBill.setDefaultUnit(kony.flex.DP);
            var lblBill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Bill"
                },
                "id": "lblBill",
                "isVisible": true,
                "right": "25%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Bill\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBillValue1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblBillValue1",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$180.0",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBillValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBillValue",
                "isVisible": true,
                "right": "25%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$180.0",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewEbillMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "View E-Bill"
                },
                "height": "18dp",
                "id": "btnViewEbillMobile",
                "isVisible": false,
                "left": "300dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.viewEBill\")",
                "top": "10dp",
                "width": "19.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View E-Bill"
            });
            flxBill.add(lblBill, lblBillValue1, lblBillValue, btnViewEbillMobile);
            var lblPaymentAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Payment Amount"
                },
                "id": "lblPaymentAccount",
                "isVisible": true,
                "right": "2.40%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.PaymentAmount\")",
                "top": "16dp",
                "width": "20.60%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEnterAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35dp",
                "id": "flxEnterAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "2.40%",
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "45dp",
                "width": "20.60%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnterAmount.setDefaultUnit(kony.flex.DP);
            var lblCurrencyType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "$"
                },
                "centerY": "50%",
                "id": "lblCurrencyType",
                "isVisible": true,
                "left": "5px",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var txtSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Enter Amount"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "35dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.EnterAmount\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "91%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxEnterAmount.add(lblCurrencyType, txtSearch);
            flxContainerPayeeInfo.add(flxPayee, flxDate, flxBill, lblPaymentAccount, flxEnterAmount);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3.70%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "5dp",
                "width": "93.80%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetails.setDefaultUnit(kony.flex.DP);
            var flxPayAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxPayAmount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayAmount.setDefaultUnit(kony.flex.DP);
            var lblPayAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Pay From"
                },
                "id": "lblPayAmount",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.PaymentAmount\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEnterPayAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35dp",
                "id": "flxEnterPayAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "45dp",
                "width": "17.60%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnterPayAmount.setDefaultUnit(kony.flex.DP);
            var lblCurrencyPayType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "$"
                },
                "centerY": "50%",
                "id": "lblCurrencyPayType",
                "isVisible": true,
                "left": "10px",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var txtEnterAmount = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Enter Amount"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "35dp",
                "id": "txtEnterAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "20px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.EnterAmount\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "91%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxEnterPayAmount.add(lblCurrencyPayType, txtEnterAmount);
            flxPayAmount.add(lblPayAmount, flxEnterPayAmount);
            var flxPayFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxPayFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayFrom.setDefaultUnit(kony.flex.DP);
            var lblPayFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Pay From"
                },
                "id": "lblPayFrom",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PayFrom\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCategory = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Category"
                },
                "id": "lblCategory",
                "isVisible": false,
                "left": "51.50%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.category\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxPayFromValue = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxPayFromValue",
                "isVisible": false,
                "left": "30dp",
                "masterData": [
                    ["Key148", "Personal Checking...123"]
                ],
                "skin": "sknlbx15SSPe424242Border3e3e3Radius2px",
                "top": "30dp",
                "width": "359dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lbxCategoryValue = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxCategoryValue",
                "isVisible": false,
                "left": "51.50%",
                "masterData": [
                    ["Key148", "Phone Bill"]
                ],
                "skin": "sknlbx15SSPe424242Border3e3e3Radius2px",
                "top": "30dp",
                "width": "360dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "30dp",
                "width": "94%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblSelectAccount",
                "isVisible": false,
                "left": "2%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Pay From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblTypeIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTypeIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "g",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeIcon.add(lblTypeIcon);
            var lblFromAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblFromAmount",
                "isVisible": false,
                "right": "59dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Transfer From",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTransferFrom = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Search by account name or number"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "100%",
                "id": "txtTransferFrom",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.SearchByAccountNameOrNumber\")",
                "secureTextEntry": false,
                "skin": "ICSknTbxSSP42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxCancelFilterFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxCancelFilterFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxCancelFilterFrom.setDefaultUnit(kony.flex.DP);
            var imgCancelFilterFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancelFilterFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "search_close.png",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxCancelFilterFrom.add(imgCancelFilterFrom);
            var flxLoadingContainerFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingContainerFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 10,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingContainerFrom.setDefaultUnit(kony.flex.DP);
            var flxLoadingIndicatorFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorFrom.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Remove"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            flxLoadingIndicatorFrom.add(imgLoadingIndicatorFrom);
            flxLoadingContainerFrom.add(flxLoadingIndicatorFrom);
            var flxDropdownIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxDropdownIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 8,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxDropdownIcon.setDefaultUnit(kony.flex.DP);
            var lblDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblDropdownIcon",
                "isVisible": true,
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownIcon.add(lblDropdownIcon);
            flxFrom.add(lblSelectAccount, flxTypeIcon, lblFromAmount, txtTransferFrom, flxCancelFilterFrom, flxLoadingContainerFrom, flxDropdownIcon);
            var flxFromSegment = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "5dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFromSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxscrollffffffShadowCustom",
                "top": "70dp",
                "verticalScrollIndicator": true,
                "width": "94%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxFromSegment.setDefaultUnit(kony.flex.DP);
            var segTransferFrom = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segTransferFrom",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxFromAccountsList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAccountsFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "172dp",
                "id": "flxNoAccountsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFFFFFF",
                "top": "0dp",
                "width": "94%",
                "zIndex": 10,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoAccountsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "There are no accounts to transfer from. Add a bank account to get started"
                },
                "centerX": "50%",
                "height": "24dp",
                "id": "lblNoAccountsFrom",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.add(lblNoAccountsFrom);
            var flxNoResultsFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoResultsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "No results found"
                },
                "centerX": "50%",
                "id": "lblNoResultsFrom",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.add(lblNoResultsFrom);
            flxFromSegment.add(segTransferFrom, flxNoAccountsFrom, flxNoResultsFrom);
            flxPayFrom.add(lblPayFrom, lblCategory, lbxPayFromValue, lbxCategoryValue, flxFrom, flxFromSegment);
            var flxFrequency = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxFrequency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency.setDefaultUnit(kony.flex.DP);
            var lblFrequency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Frequency"
                },
                "id": "lblFrequency",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblFrequency\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxFrequency = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblFrequency",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxFrequency",
                "isVisible": true,
                "left": "30dp",
                "masterData": [
                    ["Key148", "Personal Checking...123"]
                ],
                "skin": "sknlbx15SSPe424242Border3e3e3Radius2px",
                "top": "30dp",
                "width": "359dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblForHowLong = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "For How Long?"
                },
                "id": "lblForHowLong",
                "isVisible": false,
                "left": "51.50%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblForHowLong\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxForHowLong = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblForHowLong",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxForHowLong",
                "isVisible": false,
                "left": "51.50%",
                "masterData": [
                    ["Key148", "Personal Checking...123"]
                ],
                "skin": "sknlbx15SSPe424242Border3e3e3Radius2px",
                "top": "30dp",
                "width": "359dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency.add(lblFrequency, lbxFrequency, lblForHowLong, lbxForHowLong);
            var flxCal = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCal.setDefaultUnit(kony.flex.DP);
            var flxSendOn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": false,
                "id": "flxSendOn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSendOn.setDefaultUnit(kony.flex.DP);
            var lblSendOn = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Send On"
                },
                "id": "lblSendOn",
                "isVisible": true,
                "left": "23dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.send_on\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calSendOn = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblSendOn",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender.png",
                "dateComponents": ["18", "7", "2017"],
                "dateFormat": "dd/MM/yyyy",
                "day": 18,
                "focusSkin": "sknCalBorder003e751px",
                "formattedDate": "18/07/2017",
                "height": "40dp",
                "hour": 18,
                "id": "calSendOn",
                "isVisible": true,
                "left": "23dp",
                "minutes": 38,
                "month": 7,
                "seconds": 51,
                "skin": "sknCalNormal",
                "top": "10dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "45%",
                "year": 2017,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var flxDeliverBy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxDeliverBy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47%",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "-70dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliverBy.setDefaultUnit(kony.flex.DP);
            var lblDelieverBy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Deliver By"
                },
                "id": "lblDelieverBy",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DeliverBy\")",
                "top": "39dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CalDeliverBy = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblDelieverBy",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender.png",
                "dateComponents": [9, 7, 2017, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "focusSkin": "sknCalBorder003e751px",
                "formattedDate": "09/07/2017",
                "height": "40dp",
                "hour": 0,
                "id": "CalDeliverBy",
                "isVisible": false,
                "left": "30dp",
                "minutes": 0,
                "month": 7,
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "30dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "359dp",
                "year": 2017,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var btnViewEbill = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "View E-Bill details"
                },
                "id": "btnViewEbill",
                "isVisible": false,
                "left": "30dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.viewEBill\")",
                "top": "30px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeliverBy.add(lblDelieverBy, CalDeliverBy, btnViewEbill);
            var lblEndingOn = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Ending On"
                },
                "id": "lblEndingOn",
                "isVisible": false,
                "left": "23dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblendingonPayABill\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calEndingOn = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblEndingOn",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender.png",
                "dateComponents": ["18", "7", "2017"],
                "dateFormat": "dd/MM/yyyy",
                "day": 18,
                "focusSkin": "sknCalBorder003e751px",
                "formattedDate": "18/07/2017",
                "height": "40dp",
                "hour": 18,
                "id": "calEndingOn",
                "isVisible": false,
                "left": "23dp",
                "minutes": 38,
                "month": 7,
                "seconds": 51,
                "skin": "sknCalNormal",
                "top": "10dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "45%",
                "year": 2017,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var txtEndingOn = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Number of Recurrences"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtEndingOn",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "23dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.lblNumberOfRecurrences\")",
                "secureTextEntry": false,
                "skin": "skntxt",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxSendOn.add(lblSendOn, calSendOn, flxDeliverBy, lblEndingOn, calEndingOn, txtEndingOn);
            flxCal.add(flxSendOn);
            var flxNotes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxNotes",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotes.setDefaultUnit(kony.flex.DP);
            var lblNotes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Notes"
                },
                "id": "lblNotes",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Description\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var txtNotes = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblNotes",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtNotes",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "33dp",
                "maxTextLength": 150,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")",
                "secureTextEntry": false,
                "skin": "skntxt",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "30dp",
                "width": "359dp",
                "zIndex": 1,
                "blur": {
                    "enabled": true,
                    "value": 0
                }
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxNotes.add(lblNotes, txtNotes);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": true,
                "height": "92px",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxSeperator0 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator0.setDefaultUnit(kony.flex.DP);
            flxSeperator0.add();
            var btnConfirm = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to Confirmation form"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "50dp",
                "id": "btnConfirm",
                "isVisible": true,
                "right": "2.20%",
                "skin": "sknBtnBlockedSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "32.30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Continue"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel Pay a Bill Process"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "31.50%",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "32.30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxButtons.add(flxSeperator0, btnConfirm, btnCancel);
            flxDetails.add(flxPayAmount, flxPayFrom, flxFrequency, flxCal, flxNotes, flxButtons);
            flxBillPayeeInfo.add(flxError, flxContainerPayeeInfo, flxSeperator2, flxDetails);
            flxLeft.add(flxBillPayeeInfo);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Add External Account"
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Add Payee"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAddPayee.add(lblAddPayee, flxSeperator3);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Make one-time Payment"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMakeOneTimePayment.add(lblMakeOneTimePayment);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxRight);
            var flxNote = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNote",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNote.setDefaultUnit(kony.flex.DP);
            var lblTerms = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Terms & Conditions"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTerms",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNote.add(lblTerms);
            flxContent.add(flxDowntimeWarning, flxMainContainer, flxNote);
            flxMain.add(lblPayABill, btnSkipRight, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxDelete = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxDelete",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var deletePopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "deletePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDelete.add(deletePopup);
            var flxConfirmDefaultAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxConfirmDefaultAccount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDefaultAccount.setDefaultUnit(kony.flex.DP);
            var flxConfirmDefaultAccountPopUp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxConfirmDefaultAccountPopUp",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDefaultAccountPopUp.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "49dp",
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Default Account"
                },
                "centerY": "50%",
                "id": "lblHeading",
                "isVisible": true,
                "left": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.DefaultAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeading.add(lblHeading);
            var flxSeperator6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator6.setDefaultUnit(kony.flex.DP);
            flxSeperator6.add();
            var lblPopupMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Do you want to set Personal Checking…1234 as your default account for all future bill payments? "
                },
                "id": "lblPopupMessage",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlblUserName",
                "text": "Do you want to set Personal Checking…1234 as your default account for all future bill payments? ",
                "top": "73dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPopupMsg2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "This can also be set later in Account settings page."
                },
                "id": "lblPopupMsg2",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlblUserName",
                "text": "This can also be set later in Account settings page.",
                "top": "130dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e346cabb85954d7c9a89dd8ba6376660,
                "skin": "slFbox",
                "top": "182dp",
                "width": "25px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var imgCheckBox = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgCheckBox",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "unchecked_box.png",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(imgCheckBox);
            var lblPopupMsg3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Do not show this again."
                },
                "id": "lblPopupMsg3",
                "isVisible": true,
                "left": "62dp",
                "skin": "sknSSP72727220Px",
                "text": "Do not show this again.",
                "top": "182dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "228dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator7.setDefaultUnit(kony.flex.DP);
            flxSeperator7.add();
            var btnYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Yes"
                },
                "bottom": "20dp",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "top": "250px",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Pxhover",
                "toolTip": "Yes"
            });
            var btnNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Maybe Later"
                },
                "bottom": "20dp",
                "focusSkin": "sknBtnSecondaryFocusSSP4A90E215Px",
                "height": "40dp",
                "id": "btnNo",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnSecondarySSP3343a815Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.MaybeLater\")",
                "top": "250px",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Maybe Later"
            });
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCross",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross.add(imgCross);
            flxConfirmDefaultAccountPopUp.add(flxHeading, flxSeperator6, lblPopupMessage, lblPopupMsg2, flxCheckBox, lblPopupMsg3, flxSeperator7, btnYes, btnNo, flxCross);
            flxConfirmDefaultAccount.add(flxConfirmDefaultAccountPopUp);
            flxDialogs.add(flxLogout, flxDelete, flxConfirmDefaultAccount);
            var flxViewEbill = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewEbill",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbill.setDefaultUnit(kony.flex.DP);
            var flxViewEbillContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": true,
                "enableScrolling": true,
                "height": "550dp",
                "horizontalScrollIndicator": true,
                "id": "flxViewEbillContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "60%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTransactions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "E-Bill",
                    "tagName": "h2"
                },
                "id": "lblTransactions",
                "isVisible": true,
                "left": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.EBill\")",
                "top": "19px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "54dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxImgCancel = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this Pop up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "19dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCancel.setDefaultUnit(kony.flex.DP);
            var imgCancel = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "centerX": "50.00%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancel",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgCancel.add(imgCancel);
            flxTitle.add(lblTransactions, flxSeparator3, flxImgCancel);
            var flxBillDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDetails.setDefaultUnit(kony.flex.DP);
            var flxBillDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDate.setDefaultUnit(kony.flex.DP);
            var lblBillDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Bill Date"
                },
                "id": "lblBillDate",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillDate\")",
                "top": "5px",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": ":"
                },
                "id": "lblColon1",
                "isVisible": true,
                "left": "0px",
                "right": "20px",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPostDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblPostDateValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "01/02/2107",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillDate.add(lblBillDate, lblColon1, lblPostDateValue);
            var flxBillAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBillAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillAmount.setDefaultUnit(kony.flex.DP);
            var lblBillAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Bill Amount"
                },
                "id": "lblBillAmount",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillAmount\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcolon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": ":"
                },
                "id": "lblcolon2",
                "isVisible": true,
                "left": "2px",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAmountValue",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$20.00",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillAmount.add(lblBillAmount, lblcolon2, lblAmountValue);
            var flxMemo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMemo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMemo.setDefaultUnit(kony.flex.DP);
            var lblMemo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Memo"
                },
                "id": "lblMemo",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelMemo\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": ":"
                },
                "id": "lblColon3",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMemoValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Max. 100 charcacters allowed"
                },
                "id": "lblMemoValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "Max. 100 charcacters allowed",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxMemo.add(lblMemo, lblColon3, lblMemoValue);
            flxBillDetails.add(flxBillDate, flxBillAmount, flxMemo);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxImg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Image in ebill"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "217dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgEBill = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "id": "imgEBill",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "billpay_ebill.png",
                "top": "25dp",
                "width": "398dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImageHolder = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImageHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "108dp",
                "width": "66dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageHolder.setDefaultUnit(kony.flex.DP);
            var flxZoom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZoom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZoom.setDefaultUnit(kony.flex.DP);
            var imgZoom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Zoom in"
                },
                "height": "60dp",
                "id": "imgZoom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_zoom_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Zoom"
            });
            flxZoom.add(imgZoom);
            var flxFlip = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFlip",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFlip.setDefaultUnit(kony.flex.DP);
            var imgFlip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Flip"
                },
                "height": "60dp",
                "id": "imgFlip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "iconflip.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Flip"
            });
            flxFlip.add(imgFlip);
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Download"
                },
                "height": "60dp",
                "id": "imgDownload",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_download_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Download"
            });
            flxDownload.add(imgDownload);
            flxImageHolder.add(flxZoom, flxFlip, flxDownload);
            flxImageContainer.add(imgEBill, flxImageHolder);
            flxImg.add(flxImageContainer);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "687dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var lblEbillDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblEbillDetails",
                "isVisible": true,
                "left": "3%",
                "skin": "sknSSPregular42424213Px",
                "text": " Lorem ipsum dolor sit amet, consectetur adipising elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo.Proin sodales pulvinar tempor. Cum sociis antoque penatibus et magnis dis parturient montes, Nam fermentum, nulla luctus pharetra vulputate, fellis tellus mollis orci, sed rhoncus sapien nunc eget. ",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 5, 5],
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.add(flxTitle, flxBillDetails, flxSeparator4, flxImg, flxSeparator5, lblEbillDetails);
            flxViewEbill.add(flxViewEbillContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxErrorPayBill": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxContainerPayeeInfo": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "flxPayee": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblPayee": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lbxpayee": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetails": {
                        "left": {
                            "type": "string",
                            "value": "14%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeIcon": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblDueDate": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblDueDateValue1": {
                        "segmentProps": []
                    },
                    "lblDueDateValue": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxBill": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBill": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillValue1": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillValue": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnViewEbillMobile": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentAccount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxEnterAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxPayAmount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblPayAmount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnterPayAmount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayFrom": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblPayFrom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCategory": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "lbxPayFromValue": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxCategoryValue": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxscrollffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblFrequency": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxFrequency": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "lbxForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCal": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [2, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDelieverBy": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CalDeliverBy": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnViewEbill": {
                        "left": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "lblEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [2, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "txtEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNotes": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "txtNotes": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "deletePopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDefaultAccountPopUp": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "49.50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "616dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "flxBillDate": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBillDate": {
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "lblPostDateValue": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblBillAmount": {
                        "segmentProps": []
                    },
                    "lblAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblMemo": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgEBill": {
                        "width": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBillPayeeInfo": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxContainerPayeeInfo": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxPayee": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblPayee": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxpayee": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLastPayment": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxBill": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblPayFrom": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblCategory": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "segmentProps": []
                    },
                    "lbxPayFromValue": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lbxCategoryValue": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "right": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblFrequency": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lbxFrequency": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "segmentProps": []
                    },
                    "lbxForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxCal": {
                        "segmentProps": []
                    },
                    "flxSendOn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDelieverBy": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "CalDeliverBy": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "btnViewEbill": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "lblEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "txtEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [4, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxNotes": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "txtNotes": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "196px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDefaultAccountPopUp": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "btnSkipRight": {
                        "text": "Skip to bill pay options",
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxContainerPayeeInfo": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxPayee": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblPayee": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxpayee": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLastPayment": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxBill": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblPayFrom": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblCategory": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "lbxPayFromValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lbxCategoryValue": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "lblFrequency": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lbxFrequency": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": []
                    },
                    "lbxForHowLong": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxSendOn": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calSendOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblDelieverBy": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "CalDeliverBy": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "btnViewEbill": {
                        "top": {
                            "type": "string",
                            "value": "39px"
                        },
                        "segmentProps": []
                    },
                    "lblEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "txtEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "txtNotes": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxConfirmDefaultAccountPopUp": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "596dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgCancel": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxBillDetails": {
                        "segmentProps": []
                    },
                    "flxImageContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxContainerPayeeInfo": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxPayee": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbxpayee": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblLastPayment": {
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxBill": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblForHowLong": {
                        "segmentProps": []
                    },
                    "lbxForHowLong": {
                        "segmentProps": []
                    },
                    "lblSendOn": {
                        "left": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "calSendOn": {
                        "left": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblDelieverBy": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnViewEbill": {
                        "top": {
                            "type": "string",
                            "value": "39px"
                        },
                        "segmentProps": []
                    },
                    "lblEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "calEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "txtEndingOn": {
                        "left": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.04%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "height": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "596dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "CustomPopup.imgCross": {
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxViewEbill);
        };
        return [{
            "addWidgets": addWidgetsfrmPayABill,
            "enabledForIdleTimeout": true,
            "id": "frmPayABill",
            "init": controller.AS_Form_bf3f289682bc4f93bb940cbf12671ee0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Pay a Bill",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});