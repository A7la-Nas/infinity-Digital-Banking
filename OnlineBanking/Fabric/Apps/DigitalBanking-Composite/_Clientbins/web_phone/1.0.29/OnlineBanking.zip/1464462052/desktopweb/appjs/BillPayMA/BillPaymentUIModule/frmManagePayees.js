define("BillPayMA/BillPaymentUIModule/frmManagePayees", function() {
    return function(controller) {
        function addWidgetsfrmManagePayees() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblPayABill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblPayABill",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50.00%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTabsChecking = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "tablist",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "50dp",
                "horizontalScrollIndicator": true,
                "id": "flxTabsChecking",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_HORIZONTAL,
                "skin": "slFbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 5
            }, {
                "paddingInPixel": false
            }, {});
            flxTabsChecking.setDefaultUnit(kony.flex.DP);
            var btnLeft = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnLeft",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselectedOld",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnAllPayees = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnAllPayees",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnPaymentDue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnPaymentDue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnScheduled = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnScheduled",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduled\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnHistory = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnHistory",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.History\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnManagePayees = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": true,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnManagePayees",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummarySelected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ManagePayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummarySelectedHover"
            });
            var btnDummy = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnDummy",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselectedOld",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTabsChecking.add(btnLeft, btnAllPayees, btnPaymentDue, btnScheduled, btnHistory, btnManagePayees, btnDummy);
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor0c9e5c72af19e4d",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxtxtSearchandClearbtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtSearchandClearbtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "right": "3.50%",
                "skin": "sknFlxffffffBorder3px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtSearchandClearbtn.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "btnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "10px",
                "skin": "slFbox",
                "top": "0dp",
                "width": "4%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            btnConfirm.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Search "
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            btnConfirm.add(lblSearch);
            var txtSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Search using keywords such as Name, Bank, Account Type …"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "40dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.SearchMessage\")",
                "secureTextEntry": false,
                "skin": "Copyskntxt0b2e1fe36dece41",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "skncursor",
                "width": "4%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClearBtn.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "10dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "10dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearBtn.add(imgCross);
            flxtxtSearchandClearbtn.add(btnConfirm, txtSearch, flxClearBtn);
            var flxFiltersList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFiltersList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "72%",
                "isModalContainer": false,
                "right": "271px",
                "skin": "slFbox",
                "top": "30dp",
                "width": "200px",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersList.setDefaultUnit(kony.flex.DP);
            var flxFiltersWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFiltersWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "0",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersWrapper.setDefaultUnit(kony.flex.DP);
            var flxtxtFilters = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtFilters.setDefaultUnit(kony.flex.DP);
            var txtFilters = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtFilters",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "View: ",
                "secureTextEntry": false,
                "skin": "bbSknTbx455574SSP15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lbltxtFilters = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lbltxtFilters",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtxtFilters.add(txtFilters, lbltxtFilters);
            var flxLblType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLblType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "height": "40dp",
                "id": "lblType",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "All Payees",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblType.add(lblType);
            var flxDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gbb52155891440a4971350aca54624c4,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "top": "0",
                "width": "16dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(lblDropdown);
            flxFiltersWrapper.add(flxtxtFilters, flxLblType, flxDropdown);
            var lstBoxFilters = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "id": "lstBoxFilters",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "All Payees"],
                    ["lb2", "Business Payees"],
                    ["lb3", "Personal Payees"]
                ],
                "skin": "sknlbxaltoffffffB1R2",
                "top": "0",
                "width": "100%",
                "blur": {
                    "enabled": true,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var accountTypesBillPayManagePayees = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "height": "170dp",
                "id": "accountTypesBillPayManagePayees",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "height": "170dp",
                        "isVisible": false,
                        "zIndex": 5
                    },
                    "flxAccountTypesSegment": {
                        "zIndex": 5
                    },
                    "imgToolTip": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFiltersList.add(flxFiltersWrapper, lstBoxFilters, accountTypesBillPayManagePayees);
            flxSearch.add(flxtxtSearchandClearbtn, flxFiltersList);
            var flxHorizontalLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine1.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine1.add();
            var FlxBillpayeeManagePayees = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "FlxBillpayeeManagePayees",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxBillpayeeManagePayees.setDefaultUnit(kony.flex.DP);
            var flxBillPayMangaePayeesWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBillPayMangaePayeesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayMangaePayeesWrapper.setDefaultUnit(kony.flex.DP);
            var flxDropdownManage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDropdownManage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "8%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownManage.setDefaultUnit(kony.flex.DP);
            var imgDropdownManage = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Dropdown"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "7dp",
                "id": "imgDropdownManage",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownManage.add(imgDropdownManage);
            var flxWrapperManage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxWrapperManage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWrapperManage.setDefaultUnit(kony.flex.DP);
            var flxBillerNickname = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBillerNickname",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillerNickname.setDefaultUnit(kony.flex.DP);
            var flxBillerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBillerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillerName.setDefaultUnit(kony.flex.DP);
            var lblBillerName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payee Nickname:"
                },
                "centerY": "50%",
                "id": "lblBillerName",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillerNickName\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgBillerSort = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgBillerSort",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBillerName.add(lblBillerName, imgBillerSort);
            flxBillerNickname.add(flxBillerName);
            var flxLastPayment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLastPayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "42%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "122dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLastPayment.setDefaultUnit(kony.flex.DP);
            var lblLastPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Last Payment"
                },
                "centerY": "50%",
                "id": "lblLastPayment",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.lastPayment\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortLastPayment = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortLastPayment",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLastPayment.add(lblLastPayment, imgSortLastPayment);
            var flxNextBill = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNextBill",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "18%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "125dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNextBill.setDefaultUnit(kony.flex.DP);
            var lblnextBill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Next Bill"
                },
                "centerY": "50%",
                "id": "lblnextBill",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.NextBill\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgNextBillSort = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgNextBillSort",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNextBill.add(lblnextBill, imgNextBillSort);
            var flxActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "120dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var lblActions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Actions"
                },
                "centerY": "50%",
                "id": "lblActions",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActions.add(lblActions);
            flxWrapperManage.add(flxBillerNickname, flxLastPayment, flxNextBill, flxActions);
            flxBillPayMangaePayeesWrapper.add(flxDropdownManage, flxWrapperManage);
            FlxBillpayeeManagePayees.add(flxBillPayMangaePayeesWrapper);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var flxHorizontalLine3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine3",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine3.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine3.add();
            var flxSegmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.setDefaultUnit(kony.flex.DP);
            var segmentBillpay = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segmentBillpay",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegfffff",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPayManagePayeesIC"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "widgetSkin": "sknsegWatchlist",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.add(segmentBillpay);
            var flxNoPayment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoPayment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPayment.setDefaultUnit(kony.flex.DP);
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No payments are scheduled at this time."
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.noPaymentScheduleMessage\")",
                "top": "41dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSchedulePayment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSchedulePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "12.70%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSchedulePayment.setDefaultUnit(kony.flex.DP);
            var lblScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Schedule a Payment"
                },
                "id": "lblScheduleAPayment",
                "isVisible": true,
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ScheduleAPayment\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Schedule a Payment"
            });
            flxSchedulePayment.add(lblScheduleAPayment);
            var flxImginfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImginfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImginfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Info"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImginfo.add(imgInfo);
            flxNoPayment.add(rtxNoPaymentMessage, flxSchedulePayment, flxImginfo);
            flxLeft.add(flxTabsChecking, flxSearch, flxHorizontalLine1, FlxBillpayeeManagePayees, flxHorizontalLine2, flxHorizontalLine3, flxSegmentContainer, flxNoPayment);
            var flxComponent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxComponent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxComponent.setDefaultUnit(kony.flex.DP);
            var manageBiller = new com.InfinityOLB.BillPay.manageBiller({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "manageBiller",
                "isVisible": true,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA",
                "viewType": "manageBiller",
                "overrides": {
                    "manageBiller": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var manageBiller_data = (appConfig.componentMetadata && appConfig.componentMetadata["BillPayMA"] && appConfig.componentMetadata["BillPayMA"]["frmManagePayees"] && appConfig.componentMetadata["BillPayMA"]["frmManagePayees"]["manageBiller"]) || {};
            manageBiller.sknRowExpanded = manageBiller_data.sknRowExpanded || "ICSknFlxfbfbfb";
            manageBiller.dateFormat = manageBiller_data.dateFormat || "{\"format\" : \"d-m-Y\"}";
            manageBiller.amountFormat = manageBiller_data.amountFormat || "{ \"locale\":\"\", \"positiveFormat\" : \"{CS}{D}\", \"negativeFormat\" : \"-({CS}{D})\", \"fractionDigits\":\"2\"}";
            manageBiller.placeHolderSearch = manageBiller_data.placeHolderSearch || "{\"$.BREAKPTS.BP1\":\"{i.i18n.payments.searchUsingkeywords}\",\"default\":\"{i.i18n.payments.searchUsingkeywords}\"}";
            manageBiller.payeeIconVisibility = manageBiller_data.payeeIconVisibility || false;
            manageBiller.iconRowExpand = manageBiller_data.iconRowExpand || "{\"img\": \"arrow_down.png\"}";
            manageBiller.responsePath = manageBiller_data.responsePath || "{$.s1.Payee}";
            manageBiller.additionalDetailsLabel1 = manageBiller_data.additionalDetailsLabel1 || "{i.i18n.payments.lastPaymentWithColon}";
            manageBiller.BREAKPTS = manageBiller_data.BREAKPTS || "{\"BP1\":\"640\",\"BP2\":\"1024\",\"BP3\":\"1366\"}";
            manageBiller.ebillPopupTitle = manageBiller_data.ebillPopupTitle || "{i.kony.tab.Ebill.ActivateEbill}";
            manageBiller.inPlaceHandling = manageBiller_data.inPlaceHandling || false;
            manageBiller.ebillVisibility = manageBiller_data.ebillVisibility || true;
            manageBiller.tab1 = manageBiller_data.tab1 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.billPay.AllPayees}\",\"default\":\"{i.i18n.billPay.AllPayees}\"},\"action\":{\"level\":\"Form\",\"method\":\"onTab1Click\",\"widget\":\"btnTab1\"},\"entitlement\":[]}";
            manageBiller.popupField1 = manageBiller_data.popupField1 || "{i.i18n.BillPay.BillerName}";
            manageBiller.payeeObjectService = manageBiller_data.payeeObjectService || "BillPay";
            manageBiller.sknRowHover = manageBiller_data.sknRowHover || "ICSknsegf7f7f7hover";
            manageBiller.backendDateFormat = manageBiller_data.backendDateFormat || "{\"format\" : \"Y-m-d\"}";
            manageBiller.iconSearch = manageBiller_data.iconSearch || "";
            manageBiller.iconRowCollapse = manageBiller_data.iconRowCollapse || "{\"img\": \"chevron_up.png\"}";
            manageBiller.additionalDetailsValue1 = manageBiller_data.additionalDetailsValue1 || "{$.rootPath.lastPaidAmount}";
            manageBiller.responsePathSearch = manageBiller_data.responsePathSearch || "{$.s3.Payee}";
            manageBiller.tab2 = manageBiller_data.tab2 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.billPay.PaymentDue}\",\"default\":\"{i.i18n.billPay.PaymentDue}\"},\"action\":{\"level\":\"Form\",\"method\":\"onTab2Click\",\"widget\":\"btnTab2\"},\"entitlement\":[]}";
            manageBiller.title = manageBiller_data.title || "i18n.Transactions.displayBillPay";
            manageBiller.dataGridColumn1 = manageBiller_data.dataGridColumn1 || "{\"text\":\"{i.i18n.billPay.BillerNickName}\",\"mapping\":\"{$.rootPath.payeeNickName}\",\"fieldType\":\"Label\",\"sortBy\":\"payeeNickName\",\"sortByType\":\"string\"}";
            manageBiller.popupField1Value = manageBiller_data.popupField1Value || "{$.rootPath.payeeNickName}";
            manageBiller.payeeObject = manageBiller_data.payeeObject || "Payee_BillPay";
            manageBiller.sknRowSeperator = manageBiller_data.sknRowSeperator || "";
            manageBiller.iconPaginationPrevious = manageBiller_data.iconPaginationPrevious || "";
            manageBiller.additionalDetailsType1 = manageBiller_data.additionalDetailsType1 || "{i.i18n.transfers.amountlabel}";
            manageBiller.searchFieldList = manageBiller_data.searchFieldList || "[\"payeeName\", \"payeeNickName\"]";
            manageBiller.tab3 = manageBiller_data.tab3 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.billPay.scheduled}\",\"default\":\"{i.i18n.billPay.scheduled}\"},\"action\":{\"level\":\"Form\",\"method\":\"onTab3Click\",\"widget\":\"btnTab3\"},\"entitlement\":[]}";
            manageBiller.dataGridEbill = manageBiller_data.dataGridEbill || "{\"Condition1\":{\"condition\":{\"{$.rootPath.eBillStatus}\":1},\"status\":\"Activate\"},\"Condition2\":{\"condition\":{\"{$.rootPath.eBillStatus}\":0},\"status\":\"Deactivate\"}}";
            manageBiller.popupField1Type = manageBiller_data.popupField1Type || "Label";
            manageBiller.payeeGETOperation = manageBiller_data.payeeGETOperation || "getBillPayPayees";
            manageBiller.sknValueField = manageBiller_data.sknValueField || "ICSknLblSSP42424215px";
            manageBiller.iconPaginationNext = manageBiller_data.iconPaginationNext || "";
            manageBiller.additionalDetailsLabel2 = manageBiller_data.additionalDetailsLabel2 || "{i.i18n.payments.lastPaymentDateWithColon}";
            manageBiller.tab4 = manageBiller_data.tab4 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.kony.BulkPayments.bulkPaymentHistory}\",\"default\":\"{i.i18n.kony.BulkPayments.bulkPaymentHistory}\"},\"action\":{\"level\":\"Form\",\"method\":\"onTab4Click\",\"widget\":\"btnTab4\"},\"entitlement\":[]}";
            manageBiller.dataGridColumn2 = manageBiller_data.dataGridColumn2 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.payments.accNumWithColon}\",\"default\":\"{i.i18n.common.accountNumber}\"},\"mapping\":\"{$.rootPath.accountNumber}\",\"fieldType\":\"Label\"}";
            manageBiller.popupField2 = manageBiller_data.popupField2 || "{i.i18n.ProfileManagement.AccountNumber}";
            manageBiller.payeeGETCriteria = manageBiller_data.payeeGETCriteria || "{\"offset\":0,\"limit\":10,\"sortBy\":\"payeeNickName\",\"order\":\"asc\",\"paginationRowLimit\":10,\"sortByType\":\"string\"}";
            manageBiller.iconColumnSort = manageBiller_data.iconColumnSort || "{\"img\":\"sorting.png\"}";
            manageBiller.additionalDetailsValue2 = manageBiller_data.additionalDetailsValue2 || "{$.rootPath.lastPaidDate}";
            manageBiller.sknOptionalValueField = manageBiller_data.sknOptionalValueField || "ICSknSSP72727213Px";
            manageBiller.tab5 = manageBiller_data.tab5 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.billPay.ManagePayee}\",\"default\":\"{i.i18n.billPay.ManagePayee}\"},\"action\":{\"level\":\"Component\",\"method\":\"onManagePayeeClick\",\"widget\":\"btnTab5\"},\"entitlement\":[\"BILL_PAY_VIEW_PAYEES\"]}";
            manageBiller.dataGridColumn3 = manageBiller_data.dataGridColumn3 || "{\"text\":{\"$.BREAKPTS.BP1\":\"{i.i18n.payments.nextBillWithColon}\",\"default\":\"{i.i18n.billPay.NextBill}\"},\"mapping\":\"{$.rootPath.dueAmount}\",\"fieldType\":\"Amount\",\"sortBy\":\"dueAmount\",\"sortByType\":\"number\"}";
            manageBiller.popupField2Value = manageBiller_data.popupField2Value || "{$.rootPath.accountNumber}";
            manageBiller.sknActionButtons = manageBiller_data.sknActionButtons || "{\"$.BREAKPTS.BP1\":\"ICSknBtnSSP0273e313Px\",\"default\":\"ICSknBtnSSP0273e315px\"}";
            manageBiller.payeeGETIdentifier = manageBiller_data.payeeGETIdentifier || "s1";
            manageBiller.iconColumnSortAsc = manageBiller_data.iconColumnSortAsc || "{\"img\":\"sorting_previous.png\"}";
            manageBiller.additionalDetailsType2 = manageBiller_data.additionalDetailsType2 || "Date";
            manageBiller.popupField2Type = manageBiller_data.popupField2Type || "Label";
            manageBiller.dataGridColumn2Row2 = manageBiller_data.dataGridColumn2Row2 || "";
            manageBiller.sknAdditionalDetailsLabel = manageBiller_data.sknAdditionalDetailsLabel || "{\"$.BREAKPTS.BP1\":\"ICSknSSP72727213Px\",\"default\":\"ICSknSSP72727213Px\"}";
            manageBiller.payeeDELETEOperation = manageBiller_data.payeeDELETEOperation || "deleteBillPayPayee";
            manageBiller.iconColumnSortDsc = manageBiller_data.iconColumnSortDsc || "{\"img\":\"sorting_next.png\"}";
            manageBiller.additionalDetailsLabel3 = manageBiller_data.additionalDetailsLabel3 || "{i.kony.mb.billPay.LinkedWith}";
            manageBiller.dataGridColumn3Row2 = manageBiller_data.dataGridColumn3Row2 || "{\"text\":\"{i.i18n.payments.dueDateWithColon}\",\"mapping\":\"{$.rootPath.billDueDate}\",\"fieldType\":\"Date\"}";
            manageBiller.popupField3 = manageBiller_data.popupField3 || "";
            manageBiller.sknAdditionalDetailsValue = manageBiller_data.sknAdditionalDetailsValue || "{\"$.BREAKPTS.BP1\":\"ICSknSSP42424213Px\",\"default\":\"ICSknSSP42424213Px\"}";
            manageBiller.additionalDetailsValue3 = manageBiller_data.additionalDetailsValue3 || "{$.rootPath.noOfCustomersLinked}";
            manageBiller.payeeDELETECriteria = manageBiller_data.payeeDELETECriteria || "{\"payeeId\":\"1751\"}";
            manageBiller.activateEbillPopupImage = manageBiller_data.activateEbillPopupImage || "{\"img\":\"error_yellow.png\"}";
            manageBiller.dataGridColumnAction = manageBiller_data.dataGridColumnAction || "{\"title\":{\"$.BREAKPTS.bp1\":\"{i.i18n.konybb.Common.Actions}\",\"default\":\"{i.i18n.konybb.Common.Actions}\"},\"Condition1\":{\"condition\":{\"{$.rootPath.eBillStatus}\":1},\"text\":\"{i.i18n.Pay.PayBill}\",\"action\":{\"level\":\"Form\",\"method\":\"executePayMoney\"},\"entitlement\":[\"BILL_PAY_CREATE\"]},\"Condition2\":{\"condition\":{\"{$.rootPath.eBillStatus}\":0},\"text\":\"{i.i18n.payments.activateEbill}\",\"action\":{\"level\":\"Component\",\"method\":\"ACTIVATE_EBILL\"},\"entitlement\":[\"BILL_PAY_ACTIVATE_OR_DEACTIVATE_EBILL\"]}}";
            manageBiller.popupField3Value = manageBiller_data.popupField3Value || "";
            manageBiller.sknAdditionalDetailsButton = manageBiller_data.sknAdditionalDetailsButton || "{\"$.BREAKPTS.BP1\":\"ICSknBtnSSP0273e313Px\",\"default\":\"ICSknBtnSSP0273e313Px\"}";
            manageBiller.additionalDetailsType3 = manageBiller_data.additionalDetailsType3 || "Label";
            manageBiller.payeeDELETEIdentifier = manageBiller_data.payeeDELETEIdentifier || "s2";
            manageBiller.popupField3Type = manageBiller_data.popupField3Type || "";
            manageBiller.sknSearchTextBox = manageBiller_data.sknSearchTextBox || "";
            manageBiller.additionalDetailsLabel4 = manageBiller_data.additionalDetailsLabel4 || "{i.i18n.payments.payeeAddressWithColon}";
            manageBiller.payeeSearchObjectService = manageBiller_data.payeeSearchObjectService || "BillPay";
            manageBiller.additionalText1 = manageBiller_data.additionalText1 || "{i.i18n.BillPay.YouareActivatingtheEBillfeatureforthisBiller}";
            manageBiller.sknSearchPlaceHolderTextBox = manageBiller_data.sknSearchPlaceHolderTextBox || "{\"$.BREAKPTS.BP1\":\"ICSkntxtPlaceHolder13Px\",\"default\":\"ICSkntxtPlaceHolder\"}";
            manageBiller.additionalDetailsValue4 = manageBiller_data.additionalDetailsValue4 || "{$.rootPath.addressLine1} {$.rootPath.addressLine2} {$.rootPath.cityName}, {$.rootPath.state} {$.rootPath.zipCode}";
            manageBiller.payeeSearchObject = manageBiller_data.payeeSearchObject || "Payee_BillPay";
            manageBiller.additionalText2 = manageBiller_data.additionalText2 || "\"{i.i18n.BillPay.NowonwardyourBillamountwillbeappearinginthelistautomatically}\"";
            manageBiller.sknSearchTextBoxFocus = manageBiller_data.sknSearchTextBoxFocus || "";
            manageBiller.additionalDetailsType4 = manageBiller_data.additionalDetailsType4 || "Label";
            manageBiller.payeeSEARCHOperation = manageBiller_data.payeeSEARCHOperation || "getBillPayPayees";
            manageBiller.additionalText3 = manageBiller_data.additionalText3 || "{i.i18n.BillPay.Doyouwanttocontinue}";
            manageBiller.sknEbillButtonEnabledSkin = manageBiller_data.sknEbillButtonEnabledSkin || "ICSknbtnebillactive";
            manageBiller.additionalDetailsLabel5 = manageBiller_data.additionalDetailsLabel5 || "";
            manageBiller.payeeSEARCHCriteria = manageBiller_data.payeeSEARCHCriteria || "{\"searchString\":\"at\"}";
            manageBiller.sknEbillButtonDisabledSkin = manageBiller_data.sknEbillButtonDisabledSkin || "ICSknBtnImgInactiveEbill";
            manageBiller.additionalDetailsValue5 = manageBiller_data.additionalDetailsValue5 || "";
            manageBiller.payeeSEARCHIdentifier = manageBiller_data.payeeSEARCHIdentifier || "s3";
            manageBiller.additionalDetailsType5 = manageBiller_data.additionalDetailsType5 || "";
            manageBiller.payeeEbillObjectService = manageBiller_data.payeeEbillObjectService || "BillPay";
            manageBiller.sknInactiveTab = manageBiller_data.sknInactiveTab || "{\"$.BREAKPTS.BP1\":\"sknBtnAccountSummaryUnselected\",\"default\":\"ICSknBtnAccountSummaryUnselected\"}";
            manageBiller.additionalDetailsLabel6 = manageBiller_data.additionalDetailsLabel6 || "";
            manageBiller.payeeEbillObject = manageBiller_data.payeeEbillObject || "Payee_BillPay";
            manageBiller.sknActiveTab = manageBiller_data.sknActiveTab || "{\"$.BREAKPTS.BP1\":\"sknBtnAccountSummarySelected\",\"default\":\"ICSknBtnAccountSummarySelected\"}";
            manageBiller.additionalDetailsValue6 = manageBiller_data.additionalDetailsValue6 || "";
            manageBiller.activateEbillOperation = manageBiller_data.activateEbillOperation || "updateBillPayPayee";
            manageBiller.additionalDetailsType6 = manageBiller_data.additionalDetailsType6 || "";
            manageBiller.activateEbillCriteria = manageBiller_data.activateEbillCriteria || "{\"payeeId\":\"1807\",\"EBillEnable\":1}";
            manageBiller.additionalDetailsLabel7 = manageBiller_data.additionalDetailsLabel7 || "";
            manageBiller.activateEbillIdentifier = manageBiller_data.activateEbillIdentifier || "s4";
            manageBiller.additionalDetailsValue7 = manageBiller_data.additionalDetailsValue7 || "";
            manageBiller.deactivateEbillOperation = manageBiller_data.deactivateEbillOperation || "updateBillPayPayee";
            manageBiller.additionalDetailsType7 = manageBiller_data.additionalDetailsType7 || "";
            manageBiller.deactivateEbillCriteria = manageBiller_data.deactivateEbillCriteria || "{\"payeeId\":\"1807\",\"EBillEnable\":0}";
            manageBiller.additionalDetailsLabel8 = manageBiller_data.additionalDetailsLabel8 || "";
            manageBiller.deactivateEbillIdentifier = manageBiller_data.deactivateEbillIdentifier || "s5";
            manageBiller.additionalDetailsValue8 = manageBiller_data.additionalDetailsValue8 || "";
            manageBiller.payeeGETALLCriteria = manageBiller_data.payeeGETALLCriteria || "{\"sortBy\":\"payeeNickName\",\"order\":\"asc\"}";
            manageBiller.additionalDetailsType8 = manageBiller_data.additionalDetailsType8 || "";
            manageBiller.additionalDetailsLabel9 = manageBiller_data.additionalDetailsLabel9 || "";
            manageBiller.additionalDetailsValue9 = manageBiller_data.additionalDetailsValue9 || "";
            manageBiller.additionalDetailsType9 = manageBiller_data.additionalDetailsType9 || "";
            manageBiller.additionalDetailsAction1 = manageBiller_data.additionalDetailsAction1 || "{\"text\":{\"$.BREAKPTS.BP2\":\"{i.i18n.transfers.viewActivity}\",\"default\":\"{i.i18n.transfers.viewActivity}\"},\"action\":{\"level\":\"Form\",\"method\":\"executeViewActivity\"},\"entitlement\":[\"BILL_PAY_VIEW_PAYMENTS\"]}";
            manageBiller.additionalDetailsAction2 = manageBiller_data.additionalDetailsAction2 || "{\"Condition1\":{\"condition\":{\"{$.rootPath.eBillStatus}\":1},\"text\":{\"$.BREAKPTS.BP2\":\"{i.i18n.billpay.deactivate}\",\"default\":\"{i.i18n.billpay.deactivate}\"},\"action\":{\"level\":\"Component\",\"method\":\"DEACTIVATE_EBILL\"},\"entitlement\":[\"BILL_PAY_ACTIVATE_OR_DEACTIVATE_EBILL\"]},\"Condition2\":{\"condition\":{\"{$.rootPath.eBillStatus}\":0},\"text\":\"\",\"action\":\"\",\"entitlement\":[]}}";
            manageBiller.additionalDetailsAction3 = manageBiller_data.additionalDetailsAction3 || "{\"text\":\"{i.i18n.billPay.editBiller}\",\"action\":{\"level\":\"Form\",\"method\":\"executeEditBiller\"},\"entitlement\":[\"BILL_PAY_CREATE_PAYEES\"]}";
            manageBiller.additionalDetailsAction4 = manageBiller_data.additionalDetailsAction4 || "{\"text\":\"{i.i18n.billPay.deleteBiller}\",\"action\":{\"level\":\"Component\",\"method\":\"DELETE_BILLER\"},\"entitlement\":[\"BILL_PAY_DELETE_PAYEES\"]}";
            flxComponent.add(manageBiller);
            var flxEditBiller = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEditBiller",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBiller.setDefaultUnit(kony.flex.DP);
            var flxEditBillerTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxEditBillerTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerTitle.setDefaultUnit(kony.flex.DP);
            var lblEdiBillerTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Pay A Bill"
                },
                "centerY": "50%",
                "id": "lblEdiBillerTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.editBiller\")",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxEditBillerTitle.add(lblEdiBillerTitle);
            var flxEditBillerContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEditBillerContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerContent.setDefaultUnit(kony.flex.DP);
            var flxEnterPayeeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEnterPayeeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnterPayeeInfo.setDefaultUnit(kony.flex.DP);
            var lblHeaderTitle = new kony.ui.Label({
                "id": "lblHeaderTitle",
                "isVisible": true,
                "left": "3.77%",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.billerDetails\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorMain = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxSeparatorMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "68dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "10dp",
                "width": "92.46%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMain.setDefaultUnit(kony.flex.DP);
            flxSeparatorMain.add();
            var flxNoExactMatch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxNoExactMatch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "ICSknsknFlxffffff",
                "top": "30dp",
                "width": "92.70%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoExactMatch.setDefaultUnit(kony.flex.DP);
            var imgNoExactMatch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgNoExactMatch",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoExactMatch = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "We could not find an exact match. Please enter your payee information as it appears on your Bill."
                },
                "centerY": "50%",
                "id": "rtxNoExactMatch",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoExactMatch.add(imgNoExactMatch, rtxNoExactMatch);
            var lblErrorInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Entered account number is not matching"
                },
                "id": "lblErrorInfo",
                "isVisible": false,
                "left": "30dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.accountNumberNotMatching\")",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEnterName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Name"
                },
                "id": "lblEnterName",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PayeeNickName\")",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Company Name"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEnterName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.77%",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.EnterNickName\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "7dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            var lblEnterAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Number"
                },
                "id": "lblEnterAccountNumber",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumber\")",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterAccountNmber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Account Number as it appears on your Statement or Bill"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxEnterAccountNmber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.77%",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.addPayee.RelationshipNumberPlaceholder\")",
                "secureTextEntry": false,
                "skin": "skndisabled",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "7dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblEnterAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Address"
                },
                "id": "lblEnterAddress",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Address\")",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterAddress = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Payees Billing Address as it appears on your Statement or Bill"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEnterAddress",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.77%",
                "maxTextLength": 50,
                "placeholder": "Enter Billing Address",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "7dp",
                "width": "92.44%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            var lblEnterAddressLine2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Address Line 2"
                },
                "id": "lblEnterAddressLine2",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterAddressLine2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Optional"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEnterAddressLine2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.77%",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "7dp",
                "width": "92.44%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            var flxCityState = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCityState",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "26dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCityState.setDefaultUnit(kony.flex.DP);
            var flxCity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3.77%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCity.setDefaultUnit(kony.flex.DP);
            var lblCity = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "City"
                },
                "id": "lblCity",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.city\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxCity = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Payees City"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxCity",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AddPayee.EnterPayeesCity\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            flxCity.add(lblCity, tbxCity);
            var flxState = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxState",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxState.setDefaultUnit(kony.flex.DP);
            var lblState = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "State"
                },
                "id": "lblState",
                "isVisible": true,
                "left": "1.88%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.state\")",
                "top": "0dp",
                "width": "45.34%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxState = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Payees City"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxState",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.88%",
                "maxTextLength": 50,
                "placeholder": "Enter Payee's State",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "45%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            flxState.add(lblState, tbxState);
            flxCityState.add(flxCity, flxState);
            var flxCountryZipCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCountryZipCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "26dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCountryZipCode.setDefaultUnit(kony.flex.DP);
            var flxZipCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZipCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3.77%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZipCode.setDefaultUnit(kony.flex.DP);
            var lblZipCode = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "City"
                },
                "id": "lblZipCode",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.zipcode\")",
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxZipCode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Enter Payees City"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxZipCode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 50,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AddPayee.EnterPayeesZipCode\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2"
            });
            flxZipCode.add(lblZipCode, tbxZipCode);
            flxCountryZipCode.add(flxZipCode);
            flxEnterPayeeInfo.add(lblHeaderTitle, flxSeparatorMain, flxNoExactMatch, lblErrorInfo, lblEnterName, tbxEnterName, lblEnterAccountNumber, tbxEnterAccountNmber, lblEnterAddress, tbxEnterAddress, lblEnterAddressLine2, tbxEnterAddressLine2, flxCityState, flxCountryZipCode);
            var flxEditBillerButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "140dp",
                "id": "flxEditBillerButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerButtons.setDefaultUnit(kony.flex.DP);
            var lblSeparatorLine = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Label"
                },
                "height": "1dp",
                "id": "lblSeparatorLine",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabelD8D8D8",
                "text": "Label",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Next"
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "3.77%",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.Continue\")",
                "top": "60dp",
                "width": "28.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnCancelEditBiller = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Reset"
                },
                "focusSkin": "sknBtnSecondaryFocusSSP4A90E215Px",
                "height": "40dp",
                "id": "btnCancelEditBiller",
                "isVisible": true,
                "right": "34.88%",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "60dp",
                "width": "28.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSecondaryHoverSSP3343a815Px"
            });
            flxEditBillerButtons.add(lblSeparatorLine, btnContinue, btnCancelEditBiller);
            flxEditBillerContent.add(flxEnterPayeeInfo, flxEditBillerButtons);
            flxEditBiller.add(flxEditBillerTitle, flxEditBillerContent);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Add Payee"
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAddPayee.add(lblAddPayee, flxSeperator3);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Make One-Time Payment"
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator6.setDefaultUnit(kony.flex.DP);
            flxSeparator6.add();
            flxMakeOneTimePayment.add(lblMakeOneTimePayment, flxSeparator6);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxComponent, flxEditBiller, flxRight);
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxPagination",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "64.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var flxPaginationWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "30px",
                "width": "220dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationWrapper.setDefaultUnit(kony.flex.DP);
            var flxPaginationPrevious = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationPrevious",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationPrevious.setDefaultUnit(kony.flex.DP);
            var imgPaginationPrevious = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Pagination left"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationPrevious",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_back_inactive.png",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaginationPrevious.add(imgPaginationPrevious);
            var lblPagination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "1 - 10 Payees"
                },
                "centerY": "50%",
                "id": "lblPagination",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "1 - 10 Payees",
                "width": "127dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaginationNext = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationNext",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationNext.setDefaultUnit(kony.flex.DP);
            var imgPaginationNext = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Pagination Right"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationNext",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_next_active.png",
                "width": "24dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaginationNext.add(imgPaginationNext);
            flxPaginationWrapper.add(flxPaginationPrevious, lblPagination, flxPaginationNext);
            flxPagination.add(flxPaginationWrapper);
            var contractList = new com.InfinityOLB.BillPay.contract.contractList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "contractList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA",
                "overrides": {
                    "contractList": {
                        "isVisible": false
                    },
                    "imgCol1": {
                        "src": "sorting_next.png"
                    },
                    "imgCol2": {
                        "src": "sorting.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxEditBillerMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditBillerMobile",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerMobile.setDefaultUnit(kony.flex.DP);
            var flxEditBillerHeaderMobile = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxEditBillerHeaderMobile",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerHeaderMobile.setDefaultUnit(kony.flex.DP);
            var lblAccNumberKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Label"
                },
                "id": "lblAccNumberKey",
                "isVisible": true,
                "left": "106dp",
                "skin": "sknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumber\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccNumberValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccNumberValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "75%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNumberValue.setDefaultUnit(kony.flex.DP);
            var flxTypeIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblTypeIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTypeIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "g",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeIcon.add(lblTypeIcon);
            var lblAccNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Label"
                },
                "id": "lblAccNumberValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccNumberValue.add(flxTypeIcon, lblAccNumberValue);
            var lblBillerAddressKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Label"
                },
                "id": "lblBillerAddressKey",
                "isVisible": true,
                "left": "106dp",
                "skin": "sknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.BillerAddress\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBillerAddressValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Label"
                },
                "id": "lblBillerAddressValue",
                "isVisible": true,
                "left": "106dp",
                "skin": "sknSSPregular42424213Px",
                "text": "Label",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEbill = new kony.ui.Button({
                "height": "25dp",
                "id": "btnEbill",
                "isVisible": false,
                "left": "45.50%",
                "onClick": controller.AS_Button_e5a695de8f5f48ccab30d446a90bbe62,
                "skin": "sknBtnImgInactiveEbill",
                "top": "30px",
                "width": "256dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditBillerHeaderMobile.add(lblAccNumberKey, flxAccNumberValue, lblBillerAddressKey, lblBillerAddressValue, btnEbill);
            var flxEditBillerSegmentMobile = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxEditBillerSegmentMobile",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBillerSegmentMobile.setDefaultUnit(kony.flex.DP);
            var segEditBillerMobile = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segEditBillerMobile",
                "isVisible": true,
                "left": "217dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentManagePayeesEditMobile"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "81dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditBillerSegmentMobile.add(segEditBillerMobile);
            flxEditBillerMobile.add(flxEditBillerHeaderMobile, flxEditBillerSegmentMobile);
            var flxNote = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNote",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNote.setDefaultUnit(kony.flex.DP);
            var lblTerms = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTerms",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNote.add(lblTerms);
            flxContent.add(flxDowntimeWarning, flxMainContainer, flxPagination, contractList, flxEditBillerMobile, flxNote);
            flxMain.add(lblPayABill, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxActivateBiller = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxActivateBiller",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateBiller.setDefaultUnit(kony.flex.DP);
            var flxActivateBillerContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "345dp",
                "id": "flxActivateBillerContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "280dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateBillerContainer.setDefaultUnit(kony.flex.DP);
            var flxActivateHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxActivateHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffffBorder2px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateHeader.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Pay"
                },
                "height": "30px",
                "id": "lblHeader",
                "isVisible": true,
                "left": "3.77%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "13dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCrossIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCrossIcon",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCrossIcon);
            flxActivateHeader.add(lblHeader, flxCross);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0fcc85abdb4b348",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxMiddle = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85px",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var lblBillerNameKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Biller Name:"
                },
                "height": "30px",
                "id": "lblBillerNameKey",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.BillerName\")",
                "top": "10px",
                "width": "21%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBillerNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "AT&T Communication "
                },
                "height": "30px",
                "id": "lblBillerNameValue",
                "isVisible": true,
                "left": "26%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AT&T Communication ",
                "top": "10px",
                "width": "69%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Account Number:"
                },
                "height": "30px",
                "id": "lblAccountNumberKey",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                "top": "45px",
                "width": "21%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "AC23658900200"
                },
                "height": "30px",
                "id": "lblAccountNumberValue",
                "isVisible": true,
                "left": "26%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AC23658900200",
                "top": "45px",
                "width": "20.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMiddle.add(lblBillerNameKey, lblBillerNameValue, lblAccountNumberKey, lblAccountNumberValue);
            var flxWarning = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "117dp",
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "0dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "40dp",
                "id": "imgWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3.77%",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWarningWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblWarningOne = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "You are Activating the E-Bill feature for this Biller. "
                },
                "id": "lblWarningOne",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.YouareActivatingtheEBillfeatureforthisBiller\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningTwo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Now onward, your Bill amount will be appearing in the list automatically. "
                },
                "id": "lblWarningTwo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.NowonwardyourBillamountwillbeappearinginthelistautomatically\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningThree = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Do you want to continue?"
                },
                "id": "lblWarningThree",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.Doyouwanttocontinue\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarningWrapper.add(lblWarningOne, lblWarningTwo, lblWarningThree);
            flxWarning.add(imgWarning, flxWarningWrapper);
            var flxButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknMarketNewsCardComp",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnProceed = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Yes"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "50dp",
                "id": "btnProceed",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "150dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "No"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(btnProceed, btnCancel);
            flxActivateBillerContainer.add(flxActivateHeader, flxSeparator, flxMiddle, flxWarning, flxButtons);
            flxActivateBiller.add(flxActivateBillerContainer);
            var flxDeletePopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDeletePopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopup.setDefaultUnit(kony.flex.DP);
            var DeletePopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "DeletePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billpay.deleteBillerAlert\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopup.add(DeletePopup);
            var flxDeletePopupCompany = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDeletePopupCompany",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopupCompany.setDefaultUnit(kony.flex.DP);
            var CustomPopupDelete = new com.InfinityOLB.BillPay.CustomPopupDelete({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "480dp",
                "id": "CustomPopupDelete",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "segAllCompanies": {
                        "data": [{
                            "lblAccountName": "Label",
                            "lblCheckAccount": "C"
                        }, {
                            "lblAccountName": "Label",
                            "lblCheckAccount": "C"
                        }, {
                            "lblAccountName": "Label",
                            "lblCheckAccount": "C"
                        }, {
                            "lblAccountName": "Label",
                            "lblCheckAccount": "C"
                        }]
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopupCompany.add(CustomPopupDelete);
            var flxViewEbill = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewEbill",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbill.setDefaultUnit(kony.flex.DP);
            var flxViewEbillContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "768dp",
                "id": "flxViewEbillContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "100dp",
                "width": "73%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTransactions1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "E-Bill"
                },
                "id": "lblTransactions1",
                "isVisible": true,
                "left": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.EBill\")",
                "top": "19px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "54dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxImgCancel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "19dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCancel.setDefaultUnit(kony.flex.DP);
            var imgCancel = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50.00%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancel",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgCancel.add(imgCancel);
            flxTitle.add(lblTransactions1, flxSeparator3, flxImgCancel);
            var flxBillDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDetails.setDefaultUnit(kony.flex.DP);
            var flxBillDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDate.setDefaultUnit(kony.flex.DP);
            var lblBillDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Date"
                },
                "id": "lblBillDate",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillDate\")",
                "top": "5px",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblColon1",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPostDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "01/02/2107"
                },
                "id": "lblPostDateValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "01/02/2107",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillDate.add(lblBillDate, lblColon1, lblPostDateValue);
            var flxBillAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBillAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillAmount.setDefaultUnit(kony.flex.DP);
            var lblBillAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Amount"
                },
                "id": "lblBillAmount",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillAmount\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcolon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblcolon2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "$20.00"
                },
                "id": "lblAmountValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$20.00",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillAmount.add(lblBillAmount, lblcolon2, lblAmountValue);
            var flxMemo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMemo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMemo.setDefaultUnit(kony.flex.DP);
            var lblMemo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Memo"
                },
                "id": "lblMemo",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelMemo\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": ":"
                },
                "id": "lblColon3",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMemoValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Max. 100 charcacters allowed"
                },
                "id": "lblMemoValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "Max. 100 charcacters allowed",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxMemo.add(lblMemo, lblColon3, lblMemoValue);
            flxBillDetails.add(flxBillDate, flxBillAmount, flxMemo);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxImg = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var flxImageContainer1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxImageContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "217dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer1.setDefaultUnit(kony.flex.DP);
            var imgEBill = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "391dp",
                "id": "imgEBill",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "billpay_ebill.png",
                "top": "25dp",
                "width": "398dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImageHolder = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": true,
                "id": "flxImageHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "108dp",
                "width": "66dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageHolder.setDefaultUnit(kony.flex.DP);
            var flxZoom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZoom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZoom.setDefaultUnit(kony.flex.DP);
            var imgZoom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Zoom in"
                },
                "height": "60dp",
                "id": "imgZoom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_zoom_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxZoom.add(imgZoom);
            var flxFlip = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFlip",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFlip.setDefaultUnit(kony.flex.DP);
            var imgFlip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Flip"
                },
                "height": "60dp",
                "id": "imgFlip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "iconflip.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFlip.add(imgFlip);
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Download"
                },
                "height": "60dp",
                "id": "imgDownload",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_download_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(imgDownload);
            flxImageHolder.add(flxZoom, flxFlip, flxDownload);
            flxImageContainer1.add(imgEBill, flxImageHolder);
            flxImg.add(flxImageContainer1);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "687dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var lblEbillDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": " Lorem ipsum dolor sit amet, consectetur adipising elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo.Proin sodales pulvinar tempor. Cum sociis antoque penatibus et magnis dis parturient montes, Nam fermentum, nulla luctus pharetra vulputate, fellis tellus mollis orci, sed rhoncus sapien nunc eget. "
                },
                "id": "lblEbillDetails",
                "isVisible": true,
                "left": "3%",
                "skin": "sknSSPregular42424213Px",
                "text": " Lorem ipsum dolor sit amet, consectetur adipising elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo.Proin sodales pulvinar tempor. Cum sociis antoque penatibus et magnis dis parturient montes, Nam fermentum, nulla luctus pharetra vulputate, fellis tellus mollis orci, sed rhoncus sapien nunc eget. ",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 5, 5],
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.add(flxTitle, flxBillDetails, flxSeparator4, flxImg, flxSeparator5, lblEbillDetails);
            flxViewEbill.add(flxViewEbillContainer);
            flxDialogs.add(flxLogout, flxActivateBiller, flxDeletePopup, flxDeletePopupCompany, flxViewEbill);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTabsChecking": {
                        "skin": "sknscrollFlxffffffShadowdddcdcnoradius2vs",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "skin": "sknFlxf7f7f7Shadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "FlxBillpayeeManagePayees": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoPayment": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "manageBiller": {
                        "segmentProps": []
                    },
                    "flxEditBiller": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblEdiBillerTitle": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerContent": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderTitle": {
                        "isVisible": false,
                        "skin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxSeparatorMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorInfo": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterName": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterName": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterAccountNmber": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddress": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterAddress": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxCityState": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxCity": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxCity": {
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "flxState": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCountryZipCode": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxZipCode": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "tbxZipCode": {
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerButtons": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelEditBiller": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerHeaderMobile": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "lblAccNumberKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknSSP72727213Px",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblAccNumberValue": {
                        "isVisible": true,
                        "skin": "sknLblSSP42424213px",
                        "text": "Label",
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerAddressKey": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP72727213Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerAddressValue": {
                        "bottom": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPregular42424213Px",
                        "text": "Label",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "btnEbill": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknBtnImgInactiveEbill",
                        "text": "e Bill",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "36px"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxEditBillerSegmentMobile": {
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "segEditBillerMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateBiller": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateBillerContainer": {
                        "height": {
                            "type": "string",
                            "value": "415dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMiddle": {
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxWarningWrapper": {
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "segmentProps": []
                    },
                    "DeletePopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "DeletePopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopupCompany": {
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "flxBillDate": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBillDate": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblBillAmount": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblMemo": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblPayABill": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnAllPayees": {
                        "segmentProps": []
                    },
                    "btnPaymentDue": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "manageBiller": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxEditBiller": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblEdiBillerTitle": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderTitle": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": []
                    },
                    "flxSeparatorMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterName": {
                        "segmentProps": []
                    },
                    "lblEnterAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "3.78%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterAccountNmber": {
                        "left": {
                            "type": "string",
                            "value": "3.78%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddress": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddressLine2": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxCityState": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxCity": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "tbxCity": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxState": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxState": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCountryZipCode": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxZipCode": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "tbxZipCode": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerButtons": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelEditBiller": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxPaginationWrapper": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerHeaderMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnEbill": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxActivateBiller": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivateBillerContainer": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "DeletePopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "segmentProps": []
                    },
                    "flxEditBiller": {
                        "segmentProps": []
                    },
                    "lblEdiBillerTitle": {
                        "segmentProps": []
                    },
                    "lblHeaderTitle": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": []
                    },
                    "flxSeparatorMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "3.76%"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEnterAccountNmber": {
                        "left": {
                            "type": "string",
                            "value": "3.76%"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddress": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblEnterAddressLine2": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxCityState": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxCity": {
                        "left": {
                            "type": "string",
                            "value": "3.77%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "tbxCity": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxState": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "tbxState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCountryZipCode": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxZipCode": {
                        "left": {
                            "type": "string",
                            "value": "3.77%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "tbxZipCode": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerButtons": {
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "right": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelEditBiller": {
                        "right": {
                            "type": "string",
                            "value": "196dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayee": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblAddPayee": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator6": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerHeaderMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnEbill": {
                        "width": {
                            "type": "string",
                            "value": "18.70%"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxActivateBiller": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivateBillerContainer": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "segmentProps": []
                    },
                    "DeletePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopupCompany": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgCancel": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxBillDetails": {
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "width": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayManagePayees": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPayManagePayees"
                    },
                    "flxDropdownManage": {
                        "width": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerName": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "flxLastPayment": {
                        "segmentProps": []
                    },
                    "flxNextBill": {
                        "segmentProps": []
                    },
                    "flxActions": {
                        "width": {
                            "type": "string",
                            "value": "111dp"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "segmentProps": []
                    },
                    "manageBiller": {
                        "segmentProps": []
                    },
                    "flxEditBiller": {
                        "segmentProps": []
                    },
                    "lblHeaderTitle": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": []
                    },
                    "flxSeparatorMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorInfo": {
                        "segmentProps": []
                    },
                    "lblState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "tbxState": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayee": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblAddPayee": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblMakeOneTimePayment": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator6": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "segmentProps": []
                    },
                    "contractList": {
                        "segmentProps": [],
                        "instanceId": "contractList"
                    },
                    "flxEditBillerHeaderMobile": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "isVisible": true,
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblAccNumberValue": {
                        "segmentProps": []
                    },
                    "lblBillerAddressKey": {
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillerAddressValue": {
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBillerSegmentMobile": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxActivateBiller": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivateBillerContainer": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "DeletePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "accountTypesBillPayManagePayees": {
                    "height": "170dp",
                    "zIndex": 5
                },
                "accountTypesBillPayManagePayees.flxAccountTypesSegment": {
                    "zIndex": 5
                },
                "manageBiller": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "contractList.imgCol1": {
                    "src": "sorting_next.png"
                },
                "contractList.imgCol2": {
                    "src": "sorting.png"
                },
                "DeletePopup.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "CustomPopupDelete.segAllCompanies": {
                    "data": [{
                        "lblAccountName": "Label",
                        "lblCheckAccount": "C"
                    }, {
                        "lblAccountName": "Label",
                        "lblCheckAccount": "C"
                    }, {
                        "lblAccountName": "Label",
                        "lblCheckAccount": "C"
                    }, {
                        "lblAccountName": "Label",
                        "lblCheckAccount": "C"
                    }]
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmManagePayees,
            "enabledForIdleTimeout": true,
            "id": "frmManagePayees",
            "init": controller.AS_Form_fdaadf57a728477baf33fd249369cb29,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});