define("AboutUsMA/LocateUsUIModule/frmLocateUs", function() {
    return function(controller) {
        function addWidgetsfrmLocateUs() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2500,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "120px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxBottomBlue": {
                        "height": "1dp"
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxTopmenu": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu": {
                        "height": "70dp",
                        "zIndex": 1
                    },
                    "headermenu.flxMessages": {
                        "isVisible": false
                    },
                    "headermenu.flxVerticalSeperator3": {
                        "isVisible": false
                    },
                    "headermenu.imgDropdown": {
                        "src": "profile_dropdown_arrow.png"
                    },
                    "headermenu.imgLogout": {
                        "src": "logout.png"
                    },
                    "headermenu.imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "headermenu.imgUserBoundary": {
                        "src": "verify_user.png"
                    },
                    "headermenu.imgUserReset": {
                        "src": "profile_header.png"
                    },
                    "headermenu.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "headermenu.imgheaderdefault": {
                        "src": "default_username.png"
                    },
                    "headermenu.rtxWarning": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.YouHaveNotLoggedIn\")",
                        "isVisible": true
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                        "isVisible": true
                    },
                    "lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Loggedinas\")"
                    },
                    "lblUserEmail1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.usernamekonycom\")"
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxLoginMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Sign In"
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoginMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-52dp",
                "width": "10%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMobile.setDefaultUnit(kony.flex.DP);
            var lblLoginMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblLoginMobile",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblffffff15pxSSP",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "width": "65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginMobile.add(lblLoginMobile);
            flxHeader.add(customheader, flxLoginMobile);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFSbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMapAndListButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80dp",
                "id": "flxMapAndListButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-80dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMapAndListButtons.setDefaultUnit(kony.flex.DP);
            var flxButtonsWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxButtonsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "82dp",
                "isModalContainer": false,
                "skin": "sknflxGradientffffff0273e3",
                "top": "6dp",
                "width": "210dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonsWrapper.setDefaultUnit(kony.flex.DP);
            var flxShowListView = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Show List View"
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxShowListView",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "14dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowListView.setDefaultUnit(kony.flex.DP);
            var lblListViewIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblListViewIcon",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "Label",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblListView = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblListView",
                "isVisible": true,
                "left": "15dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowListView.add(lblListViewIcon, lblListView);
            var flxShowMapView = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Show Map View"
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxShowMapView",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "14dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowMapView.setDefaultUnit(kony.flex.DP);
            var lblMapView = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMapView",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknSSPLblFFFFFF15Px",
                "text": "Label",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMapViewIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMapViewIcon",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblFontIconsffffff17px",
                "text": "Label",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowMapView.add(lblMapView, lblMapViewIcon);
            flxButtonsWrapper.add(flxShowListView, flxShowMapView);
            var imgMyLocationIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "My Location"
                },
                "bottom": "12dp",
                "clipBounds": false,
                "height": "50dp",
                "id": "imgMyLocationIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "width": "50dp",
                "zIndex": 3,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            imgMyLocationIcon.setDefaultUnit(kony.flex.DP);
            var imgLocationIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "95%",
                "id": "imgLocationIcon",
                "isVisible": true,
                "left": "0dp",
                "right": "2.88%",
                "skin": "slImage",
                "src": "centralize_location_blue.png",
                "top": "0dp",
                "width": "95%",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            imgMyLocationIcon.add(imgLocationIcon);
            flxMapAndListButtons.add(flxButtonsWrapper, imgMyLocationIcon);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblLocateUsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "25dp",
                "id": "lblLocateUsHeader",
                "isVisible": true,
                "left": "6.08%",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLocateUsWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxLocateUsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "70dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLocateUsWrapper.setDefaultUnit(kony.flex.DP);
            var LocateUs = new com.InfinityOLB.AboutUs.LocateUs({
                "height": "100%",
                "id": "LocateUs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "LocateUs": {
                        "height": "100%"
                    },
                    "btnATM": {
                        "width": "20%"
                    },
                    "btnAll": {
                        "isVisible": true,
                        "left": "5%",
                        "width": "20%"
                    },
                    "btnApplyFilters": {
                        "centerX": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")",
                        "left": "51.58%",
                        "width": "44.47%"
                    },
                    "btnBackToDetails": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.BackToLogin\")"
                    },
                    "btnBackToMap": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BACKTOMAP\")"
                    },
                    "btnBackToSearch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BACKTOSEARCH\")"
                    },
                    "btnBranch": {
                        "width": "25%"
                    },
                    "btnCancelFilters": {
                        "centerX": "viz.val_cleared",
                        "left": "3.95%",
                        "width": "44.47%"
                    },
                    "btnClearAll": {
                        "bottom": "20px",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.CLEARSEARCH\")"
                    },
                    "btnProceed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.GETDIRECTIONS\")"
                    },
                    "btnShare": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SHARE\")"
                    },
                    "flxBranchDetails": {
                        "clipBounds": false,
                        "height": "100%",
                        "isVisible": false,
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxCloseIcon": {
                        "isVisible": true
                    },
                    "flxContents": {
                        "bottom": "viz.val_cleared",
                        "clipBounds": false,
                        "height": "100%",
                        "isVisible": true
                    },
                    "flxDirections": {
                        "clipBounds": false,
                        "height": "92.50%",
                        "isVisible": false
                    },
                    "flxDirectionsButtons": {
                        "clipBounds": false
                    },
                    "flxDistance": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxDistanceDetails": {
                        "isVisible": false
                    },
                    "flxFiltersRow1": {
                        "left": "0dp",
                        "top": "10dp"
                    },
                    "flxHeaderBackgroundCall": {
                        "isVisible": false
                    },
                    "flxHeaderBackgroundServices": {
                        "isVisible": false,
                        "top": "0dp"
                    },
                    "flxLeft": {
                        "clipBounds": false,
                        "height": "100%",
                        "isVisible": true
                    },
                    "flxLocateUsHeaderSeperator": {
                        "bottom": "0px"
                    },
                    "flxLocateUsWrapper": {
                        "height": "100%"
                    },
                    "flxMap": {
                        "bottom": "viz.val_cleared",
                        "isVisible": true
                    },
                    "flxNearMe": {
                        "isVisible": false
                    },
                    "flxNoSearchResult": {
                        "isVisible": true,
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxOption1": {
                        "isVisible": false
                    },
                    "flxOption2": {
                        "isVisible": false
                    },
                    "flxOption3": {
                        "isVisible": false
                    },
                    "flxOption4": {
                        "isVisible": false
                    },
                    "flxOption5": {
                        "isVisible": false
                    },
                    "flxOptions": {
                        "height": "331px",
                        "top": "60dp"
                    },
                    "flxRedoSearch": {
                        "isVisible": false
                    },
                    "flxRight": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "flxSearch": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": true,
                        "isVisible": false,
                        "top": "47dp"
                    },
                    "flxSearchBar": {
                        "left": "20dp"
                    },
                    "flxSearchBox": {
                        "minHeight": "100px"
                    },
                    "flxSearchImage": {
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "left": "35px",
                        "width": "17px"
                    },
                    "flxSelectedBranchDetails": {
                        "left": "0dp"
                    },
                    "flxSeparatorView": {
                        "height": "220dp",
                        "isVisible": false,
                        "left": "96dp"
                    },
                    "flxService1": {
                        "height": "14dp"
                    },
                    "flxService2": {
                        "height": "14dp"
                    },
                    "flxService3": {
                        "height": "14dp"
                    },
                    "flxService4": {
                        "height": "14dp"
                    },
                    "flxTabs": {
                        "isVisible": false,
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxViewAndFilters": {
                        "left": "87.47%"
                    },
                    "flxViewsAndFilters": {
                        "isVisible": true,
                        "top": "0dp",
                        "zIndex": 2
                    },
                    "flxViewsAndFiltersButtons": {
                        "top": "160dp"
                    },
                    "flxZoom": {
                        "isVisible": true
                    },
                    "imgBackToDetails": {
                        "src": "back_icon_blue.png"
                    },
                    "imgBankImage": {
                        "src": "bank_img_rounded.png"
                    },
                    "imgCancelFilter1": {
                        "src": "search_close.png"
                    },
                    "imgCancelFilter2": {
                        "src": "search_close.png"
                    },
                    "imgCancelFilter3": {
                        "src": "search_close.png"
                    },
                    "imgCancelFilter4": {
                        "src": "search_close.png"
                    },
                    "imgCancelFilter5": {
                        "src": "search_close.png"
                    },
                    "imgCheckBox1": {
                        "src": "checked_box.png"
                    },
                    "imgCheckBox2": {
                        "src": "checked_box.png"
                    },
                    "imgCheckBox3": {
                        "src": "checked_box.png"
                    },
                    "imgCheckBox4": {
                        "src": "checked_box.png"
                    },
                    "imgCheckBox5": {
                        "src": "checked_box.png"
                    },
                    "imgCloseIcon": {
                        "src": "bbcloseicon.png"
                    },
                    "imgGo": {
                        "src": "arrow_left_grey.png"
                    },
                    "imgInfo": {
                        "src": "info_large.png"
                    },
                    "imgMyLocation": {
                        "isVisible": true,
                        "src": "centralize_location_blue.png"
                    },
                    "imgRadioButtonAll": {
                        "src": "radiobtn_active.png"
                    },
                    "imgRadioButtonAtm": {
                        "src": "icon_radiobtn.png"
                    },
                    "imgRadioButtonBranch": {
                        "src": "icon_radiobtn.png"
                    },
                    "imgService1": {
                        "src": "pageoffdot.png"
                    },
                    "imgService2": {
                        "src": "pageoffdot.png"
                    },
                    "imgService3": {
                        "src": "pageoffdot.png"
                    },
                    "imgService4": {
                        "src": "pageoffdot.png"
                    },
                    "imgShare": {
                        "src": "share_blue.png"
                    },
                    "imgTbxSearch": {
                        "isVisible": false,
                        "src": "search_white.png"
                    },
                    "imgToolTip": {
                        "src": "tooltip_arrow_blue.png"
                    },
                    "imgViewsAndFilters": {
                        "src": "sort_icon.png"
                    },
                    "imgViewsAndFiltersClose": {
                        "src": "icon_close_grey.png"
                    },
                    "imgZoomIn": {
                        "src": "plus_blue.png"
                    },
                    "imgZoomOut": {
                        "src": "minus_blue.png"
                    },
                    "lblAddressLine1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.KonyBank\")",
                        "top": "80dp"
                    },
                    "lblAddressLine2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Ausin500061504AustinMarketstreet\")",
                        "top": "100dp"
                    },
                    "lblAll": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ALL\")"
                    },
                    "lblAtm": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.ATM\")"
                    },
                    "lblBranch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BRANCH\")"
                    },
                    "lblBranchAddress2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BranchName\")"
                    },
                    "lblBranchAddressOneLine": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BranchAddressoneline\")"
                    },
                    "lblBranchName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BranchName\")"
                    },
                    "lblBranchName2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.BranchNameOne\")",
                        "top": "30dp"
                    },
                    "lblBranchName3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.BranchNameOne\")",
                        "left": "4.80%"
                    },
                    "lblCallBranch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.CallBranch\")"
                    },
                    "lblClosed": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.CLOSED\")"
                    },
                    "lblDistanceAndTimeFromUser": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.22Miles8Minutes\")"
                    },
                    "lblFilterName1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.filterName\")"
                    },
                    "lblFilterName2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.filterName\")"
                    },
                    "lblFilterName3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.filterName\")"
                    },
                    "lblFilterName4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.filterName\")"
                    },
                    "lblFilterName5": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.filterName\")"
                    },
                    "lblLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "lblMiles": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Miles\")"
                    },
                    "lblNearMe": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.NearMeInMiles\")"
                    },
                    "lblOpen": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.OPEN\")"
                    },
                    "lblOption1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.DriveUpATM\")"
                    },
                    "lblOption2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SurchargeFreeATM\")"
                    },
                    "lblOption3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.DepositTakingATM\")"
                    },
                    "lblOption4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.CoOpSharedBranch\")"
                    },
                    "lblOption5": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SafeDepositBox\")"
                    },
                    "lblRedoSearch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.REDOSEARCHONMAP\")"
                    },
                    "lblSearchImage": {
                        "height": "20px",
                        "text": "e",
                        "width": "17px"
                    },
                    "lblSelectedAddressLine1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.504AustinMarketstreet\")"
                    },
                    "lblSelectedAddressLine2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Austin50001\")"
                    },
                    "lblSelectedBranchName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NUO.BranchNameOne\")"
                    },
                    "lblSelectedDistanceAndTime": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.22Miles8Minutes\")"
                    },
                    "lblService1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.ATM24Hrs\")"
                    },
                    "lblService2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SafeDeposit\")"
                    },
                    "lblService3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Lockers\")"
                    },
                    "lblService4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Loans\")"
                    },
                    "lblServicesAvailable": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.ServicesAvailable\")",
                        "top": "18dp"
                    },
                    "lblShow": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Show\")"
                    },
                    "lblViewType": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.locateUs.VIEWOnlyATMs\")",
                        "isVisible": false
                    },
                    "lblViewsAndFilters": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.VIEWSFILTERS\")",
                        "left": "5.95%"
                    },
                    "mapLocateUs": {
                        "height": "100%"
                    },
                    "rtxNoSearchResults": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.NosearchresultfoundPleasechangethesearchcriteria\")"
                    },
                    "segDayAndTime": {
                        "data": [{
                            "lblTimingsColon1": "",
                            "lblTimingsMondayKey": "",
                            "lblTimingsMondayValue": ""
                        }]
                    },
                    "segDirections": {
                        "height": "100%"
                    },
                    "segResults": {
                        "isVisible": true,
                        "top": "0dp",
                        "width": "100%"
                    },
                    "tbxSearchBox": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.LocateUs.Searchforplacepincodeetc\")",
                        "left": "42px",
                        "right": "40px",
                        "top": "0px",
                        "width": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLocateUsWrapper.add(LocateUs);
            flxMain.add(lblLocateUsHeader, flxLocateUsWrapper);
            flxContainer.add(flxMapAndListButtons, flxMain);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.AboutUs.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "AboutUsMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxHeader, flxContainer, flxFooter);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2600,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Loading Screen"
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 260000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxShareDirection = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxShareDirection",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxShareDirection.setDefaultUnit(kony.flex.DP);
            var flxShare = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    },
                    "a11yLabel": "Share"
                },
                "clipBounds": true,
                "height": "380dp",
                "id": "flxShare",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "334dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShare.setDefaultUnit(kony.flex.DP);
            var flxShareHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxShareHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShareHeader.setDefaultUnit(kony.flex.DP);
            var lblShareHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblShareHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SHARE\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgShareClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "imgShareClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "width": "20dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            imgShareClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            imgShareClose.add(imgClose);
            flxShareHeader.add(lblShareHeader, imgShareClose);
            var flxShareSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxShareSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShareSeperator.setDefaultUnit(kony.flex.DP);
            flxShareSeperator.add();
            var flxShareContents = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "200dp",
                "id": "flxShareContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShareContents.setDefaultUnit(kony.flex.DP);
            var tbxMapUrl = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxMapUrl",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.38%",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "text": "https://www.google.co.in/maps/dir/17.4479494,78.3713151/'' kkkk",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20px",
                "width": "89.85%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblSendMapTo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblSendMapTo",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.SendMapto\")",
                "top": "90px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxSendMapTo = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxSendMapTo",
                "isVisible": true,
                "left": "23.18%",
                "masterData": [
                    ["key1", "Select a device"],
                    ["key2", "Phone"]
                ],
                "selectedKey": "key1",
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "80dp",
                "width": "59.22%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxSendMapTo = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxSendMapTo",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "23.18%",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "text": "0451- 7775504940 ",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "140px",
                "width": "59.22%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxShareContents.add(tbxMapUrl, lblSendMapTo, lbxSendMapTo, tbxSendMapTo);
            var flxShareSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxShareSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShareSeperator2.setDefaultUnit(kony.flex.DP);
            flxShareSeperator2.add();
            var flxEditEmailButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxEditEmailButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditEmailButtons.setDefaultUnit(kony.flex.DP);
            var btnShareSend = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": "25dp",
                "height": "40dp",
                "id": "btnShareSend",
                "isVisible": true,
                "left": "51.58%",
                "skin": "sknBtnSSPBg0273e340PrBorder0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.send\")",
                "width": "44.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnShareCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": "25dp",
                "height": "40dp",
                "id": "btnShareCancel",
                "isVisible": true,
                "left": "3.95%",
                "skin": "sknBtnSSP0273e3Border0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "44.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditEmailButtons.add(btnShareSend, btnShareCancel);
            flxShare.add(flxShareHeader, flxShareSeperator, flxShareContents, flxShareSeperator2, flxEditEmailButtons);
            flxShareDirection.add(flxShare);
            var flxseperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxseperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBordere3e3e3",
                "top": "120dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxseperator.setDefaultUnit(kony.flex.DP);
            flxseperator.add();
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1379,
                "640": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2005,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomBlue": {
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Locate Us",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblLoginMobile": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "slFSbox",
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxMapAndListButtons": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2004,
                        "segmentProps": []
                    },
                    "flxButtonsWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknflxGradientffffff0273e3",
                        "segmentProps": []
                    },
                    "flxShowListView": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblListViewIcon": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknlblfonticon17px0273e3",
                        "text": "Y",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblListView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknLabelSSP0273e315px",
                        "text": "List View",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxShowMapView": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblMapView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknSSPLblFFFFFF15Px",
                        "text": "Map View",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblMapViewIcon": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknLblFontIconsffffff17px",
                        "text": "X",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLocateUsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLocateUsWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "LocateUs"
                    },
                    "LocateUs.btnATM": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnAll": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnApplyFilters": {
                        "bottom": {
                            "type": "number",
                            "value": "80"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToMap": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToSearch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBranch": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnCancelFilters": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnClearAll": {
                        "bottom": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnProceed": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnShare": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxBack": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxBackOrShare": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchNameAndAddress": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchTimings": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchTimingsAndServices": {
                        "height": {
                            "type": "string",
                            "value": "390dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCallBranch": {
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxContents": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxDirections": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxDirectionsButtons": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxDirectionsSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxDirectionsSeperator3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxDistanceDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxEmptySpace": {
                        "height": {
                            "type": "string",
                            "value": "500px"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "-2px"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.flxFilters": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxHeaderBackgroundCall": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxHeaderBackgroundServices": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "-31dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxHeaderBackgroundTimings": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "-31dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxHideMap": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxLeft": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxMap": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxNearMe": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxNoSearchResult": {
                        "height": {
                            "type": "string",
                            "value": "500px"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption5": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioAll": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioAtm": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioBranch": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtons": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtonsWrapper": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRight": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearch": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBar": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBox": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": "80px"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBoxSeperator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "24px"
                        },
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSelectedBranchDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "-110dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeparatorView": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator4": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator5": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxService1": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxService2": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxService3": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxService4": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxServicesAvailable": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxShare": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxTabs": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewAndFilters": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "625dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxZoom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.imgBankImage": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox4": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox5": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgMyLocation": {
                        "bottom": {
                            "type": "string",
                            "value": "120px"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgRadioButtonAll": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgRadioButtonAtm": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgRadioButtonBranch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgShare": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblAddressLine1": {
                        "left": {
                            "type": "string",
                            "value": "145px"
                        },
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "145px"
                        },
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblBranchName2": {
                        "left": {
                            "type": "string",
                            "value": "145px"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblBranchName3": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblCallBranch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblDistanceAndTimeFromUser": {
                        "left": {
                            "type": "string",
                            "value": "145px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblNearMe": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption1": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption2": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption3": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption4": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption5": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblPhoneNumber1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblPhoneNumber2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "55.50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSelectedAddressLine1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSelectedAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSelectedBranchName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSelectedDistanceAndTime": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblServicesAvailable": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblShow": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblViewType": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblViewsAndFilters": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.mapLocateUs": {
                        "segmentProps": []
                    },
                    "LocateUs.rtxNoSearchResults": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.segDirections": {
                        "segmentProps": []
                    },
                    "LocateUs.segResults": {
                        "height": {
                            "type": "string",
                            "value": "410dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.tbxSearchBox": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "zIndex": 2007,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxShareDirection": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxShare": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblShareHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxShareContents": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "tbxMapUrl": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSendMapTo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "83px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lbxSendMapTo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "107dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxSendMapTo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "163px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditEmailButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "btnShareSend": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "segmentProps": []
                    },
                    "btnShareCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "segmentProps": []
                    },
                    "flxseperator": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomBlue": {
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLocateUsHeader": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "sknSupportedFileTypes",
                        "text": "Locate Us",
                        "segmentProps": []
                    },
                    "flxLocateUsWrapper": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "LocateUs"
                    },
                    "LocateUs.btnApplyFilters": {
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToDetails": {
                        "left": {
                            "type": "string",
                            "value": "28.05%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToMap": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnCancelFilters": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnClearAll": {
                        "top": {
                            "type": "string",
                            "value": "80px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnShare": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchTimingsAndServices": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCallBranch": {
                        "top": {
                            "type": "string",
                            "value": "440px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCloseIcon": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxContents": {
                        "segmentProps": []
                    },
                    "LocateUs.flxDirections": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxDistanceDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxFilters": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxHideMap": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxMap": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxNearMe": {
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxNoSearchResult": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOption5": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "321dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtonsWrapper": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRedoSearch": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearch": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBar": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "43dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "24px"
                        },
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator3": {
                        "top": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxTabs": {
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsFriday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsMonday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsSaturday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsThursday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsTuesday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxTimingsWednesday": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewAndFilters": {
                        "left": {
                            "type": "string",
                            "value": "81.47%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "650px"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersButtons": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersClose": {
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgBankImage": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox3": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox4": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCheckBox5": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgMyLocation": {
                        "right": {
                            "type": "string",
                            "value": "12.88%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgRadioButtonAll": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgViewsAndFiltersClose": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblAddressLine1": {
                        "left": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblAddressLine2": {
                        "left": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblBranchName2": {
                        "left": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblDistanceAndTimeFromUser": {
                        "left": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue1": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue2": {
                        "left": {
                            "type": "string",
                            "value": "21.14%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue3": {
                        "left": {
                            "type": "string",
                            "value": "39.49%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue4": {
                        "left": {
                            "type": "string",
                            "value": "56.63%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue5": {
                        "left": {
                            "type": "string",
                            "value": "74.99%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblMileValue6": {
                        "left": {
                            "type": "string",
                            "value": "92.13%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblNearMe": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption1": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption2": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption3": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption4": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblOption5": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblService1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblService2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblService3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblService4": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblShow": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblViewsAndFilters": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.rtxNoSearchResults": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.segDayAndTime": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.segDirections": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.segViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.tbxSearchBox": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "sknFlxf8f7f8",
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxShare": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblShareHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "flxShareContents": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "tbxMapUrl": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSendMapTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lbxSendMapTo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxSendMapTo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditEmailButtons": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "segmentProps": []
                    },
                    "btnShareSend": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    },
                    "btnShareCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "258dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLocateUsHeader": {
                        "segmentProps": []
                    },
                    "flxLocateUsWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.40%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "LocateUs"
                    },
                    "LocateUs.btnApplyFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "51%"
                        },
                        "width": {
                            "type": "string",
                            "value": "35.70%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToMap": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnCancelFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "9.52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "35.70%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnClearAll": {
                        "bottom": {
                            "type": "string",
                            "value": "8px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchDetails": {
                        "isVisible": false,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchTimingsAndServices": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCallBranch": {
                        "top": {
                            "type": "string",
                            "value": "440px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxContents": {
                        "segmentProps": []
                    },
                    "LocateUs.flxDirections": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxDirectionsButtons": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "LocateUs.flxFilters": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxFiltersRow1": {
                        "segmentProps": []
                    },
                    "LocateUs.flxLeft": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsWrapper": {
                        "segmentProps": []
                    },
                    "LocateUs.flxNearMe": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxNoSearchResult": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "331px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtons": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRedoSearch": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRight": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "64.40%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearch": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBar": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchImage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "24px"
                        },
                        "left": {
                            "type": "string",
                            "value": "28px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator3": {
                        "top": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewAndFilters": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFilters": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersButtons": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgMyLocation": {
                        "right": {
                            "type": "string",
                            "value": "7.88%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.segViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "331px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.tbxSearchBox": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxShareDirection": {
                        "segmentProps": []
                    },
                    "lblShareHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "tbxMapUrl": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSendMapTo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnShareSend": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknBtnSSPBg0273e340PrBorder0273e3",
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    },
                    "btnShareCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "258"
                        },
                        "skin": "sknBtnSSP0273e3Border0273e3",
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    }
                },
                "1379": {
                    "frmLocateUs": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flxMapAndListButtons": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsWrapper": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxShowListView": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxShowMapView": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "imgMyLocationIcon": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLocateUsHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "flxLocateUsWrapper": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "1266dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "LocateUs"
                    },
                    "LocateUs.btnApplyFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnBackToMap": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnCancelFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.btnClearAll": {
                        "bottom": {
                            "type": "string",
                            "value": "8px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "560px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchDetails": {
                        "isVisible": true,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "LocateUs.flxBranchTimingsAndServices": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCallBranch": {
                        "height": {
                            "type": "string",
                            "value": "180px"
                        },
                        "top": {
                            "type": "string",
                            "value": "440px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxContents": {
                        "segmentProps": []
                    },
                    "LocateUs.flxDirections": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxDirectionsButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxFilters": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxLeft": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxLocateUsWrapper": {
                        "segmentProps": []
                    },
                    "LocateUs.flxMap": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxNearMe": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxNoSearchResult": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "331px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRadioButtons": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRedoSearch": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxRight": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "64.75%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearch": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchBar": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSearchImage": {
                        "height": {
                            "type": "string",
                            "value": "24px"
                        },
                        "left": {
                            "type": "string",
                            "value": "28px"
                        },
                        "top": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator3": {
                        "top": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxSeperator4": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "560px"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxTabs": {
                        "segmentProps": []
                    },
                    "LocateUs.flxViewAndFilters": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "650px"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "LocateUs.flxViewsAndFiltersButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.imgCloseIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LocateUs.imgMyLocation": {
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.88%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblFilterName4": {
                        "segmentProps": []
                    },
                    "LocateUs.lblNoSearchResults": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblSearchImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LocateUs.lblViewAndFiltersIcon": {
                        "text": "G",
                        "segmentProps": []
                    },
                    "LocateUs.segDirections": {
                        "segmentProps": []
                    },
                    "LocateUs.segViewsAndFilters": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LocateUs.tbxSearchBox": {
                        "left": {
                            "type": "string",
                            "value": "30px"
                        },
                        "right": {
                            "type": "string",
                            "value": "53px"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblShareHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "tbxMapUrl": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSendMapTo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lbxSendMapTo": {
                        "left": {
                            "type": "string",
                            "value": "23.18%"
                        },
                        "segmentProps": []
                    },
                    "btnShareSend": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    },
                    "btnShareCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "258dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    },
                    "flxseperator": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxBottomBlue": {
                    "height": "1dp"
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.headermenu": {
                    "height": "70dp",
                    "zIndex": 1
                },
                "customheader.headermenu.imgDropdown": {
                    "src": "profile_dropdown_arrow.png"
                },
                "customheader.headermenu.imgLogout": {
                    "src": "logout.png"
                },
                "customheader.headermenu.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheader.headermenu.imgUserBoundary": {
                    "src": "verify_user.png"
                },
                "customheader.headermenu.imgUserReset": {
                    "src": "profile_header.png"
                },
                "customheader.headermenu.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customheader.headermenu.imgheaderdefault": {
                    "src": "default_username.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "LocateUs": {
                    "height": "100%"
                },
                "LocateUs.btnATM": {
                    "width": "20%"
                },
                "LocateUs.btnAll": {
                    "left": "5%",
                    "width": "20%"
                },
                "LocateUs.btnApplyFilters": {
                    "centerX": "",
                    "left": "51.58%",
                    "width": "44.47%"
                },
                "LocateUs.btnBranch": {
                    "width": "25%"
                },
                "LocateUs.btnCancelFilters": {
                    "centerX": "",
                    "left": "3.95%",
                    "width": "44.47%"
                },
                "LocateUs.btnClearAll": {
                    "bottom": "20px"
                },
                "LocateUs.flxBranchDetails": {
                    "height": "100%",
                    "left": "0dp",
                    "top": "0dp"
                },
                "LocateUs.flxContents": {
                    "bottom": "",
                    "height": "100%"
                },
                "LocateUs.flxDirections": {
                    "height": "92.50%"
                },
                "LocateUs.flxFiltersRow1": {
                    "left": "0dp",
                    "top": "10dp"
                },
                "LocateUs.flxHeaderBackgroundServices": {
                    "top": "0dp"
                },
                "LocateUs.flxLeft": {
                    "height": "100%"
                },
                "LocateUs.flxLocateUsHeaderSeperator": {
                    "bottom": "0px"
                },
                "LocateUs.flxLocateUsWrapper": {
                    "height": "100%"
                },
                "LocateUs.flxMap": {
                    "bottom": ""
                },
                "LocateUs.flxNoSearchResult": {
                    "top": "0dp",
                    "width": "100%"
                },
                "LocateUs.flxOptions": {
                    "height": "331px",
                    "top": "60dp"
                },
                "LocateUs.flxRight": {
                    "height": "100%"
                },
                "LocateUs.flxSearch": {
                    "top": "47dp"
                },
                "LocateUs.flxSearchBar": {
                    "left": "20dp"
                },
                "LocateUs.flxSearchBox": {
                    "minHeight": "100px"
                },
                "LocateUs.flxSearchImage": {
                    "centerY": "",
                    "height": "40dp",
                    "left": "35px",
                    "width": "17px"
                },
                "LocateUs.flxSelectedBranchDetails": {
                    "left": "0dp"
                },
                "LocateUs.flxSeparatorView": {
                    "height": "220dp",
                    "left": "96dp"
                },
                "LocateUs.flxService1": {
                    "height": "14dp"
                },
                "LocateUs.flxService2": {
                    "height": "14dp"
                },
                "LocateUs.flxService3": {
                    "height": "14dp"
                },
                "LocateUs.flxService4": {
                    "height": "14dp"
                },
                "LocateUs.flxTabs": {
                    "top": "0dp",
                    "width": "100%"
                },
                "LocateUs.flxViewAndFilters": {
                    "left": "87.47%"
                },
                "LocateUs.flxViewsAndFilters": {
                    "top": "0dp",
                    "zIndex": 2
                },
                "LocateUs.flxViewsAndFiltersButtons": {
                    "top": "160dp"
                },
                "LocateUs.imgBackToDetails": {
                    "src": "back_icon_blue.png"
                },
                "LocateUs.imgBankImage": {
                    "src": "bank_img_rounded.png"
                },
                "LocateUs.imgCancelFilter1": {
                    "src": "search_close.png"
                },
                "LocateUs.imgCancelFilter2": {
                    "src": "search_close.png"
                },
                "LocateUs.imgCancelFilter3": {
                    "src": "search_close.png"
                },
                "LocateUs.imgCancelFilter4": {
                    "src": "search_close.png"
                },
                "LocateUs.imgCancelFilter5": {
                    "src": "search_close.png"
                },
                "LocateUs.imgCheckBox1": {
                    "src": "checked_box.png"
                },
                "LocateUs.imgCheckBox2": {
                    "src": "checked_box.png"
                },
                "LocateUs.imgCheckBox3": {
                    "src": "checked_box.png"
                },
                "LocateUs.imgCheckBox4": {
                    "src": "checked_box.png"
                },
                "LocateUs.imgCheckBox5": {
                    "src": "checked_box.png"
                },
                "LocateUs.imgCloseIcon": {
                    "src": "bbcloseicon.png"
                },
                "LocateUs.imgGo": {
                    "src": "arrow_left_grey.png"
                },
                "LocateUs.imgInfo": {
                    "src": "info_large.png"
                },
                "LocateUs.imgMyLocation": {
                    "src": "centralize_location_blue.png"
                },
                "LocateUs.imgRadioButtonAll": {
                    "src": "radiobtn_active.png"
                },
                "LocateUs.imgRadioButtonAtm": {
                    "src": "icon_radiobtn.png"
                },
                "LocateUs.imgRadioButtonBranch": {
                    "src": "icon_radiobtn.png"
                },
                "LocateUs.imgService1": {
                    "src": "pageoffdot.png"
                },
                "LocateUs.imgService2": {
                    "src": "pageoffdot.png"
                },
                "LocateUs.imgService3": {
                    "src": "pageoffdot.png"
                },
                "LocateUs.imgService4": {
                    "src": "pageoffdot.png"
                },
                "LocateUs.imgShare": {
                    "src": "share_blue.png"
                },
                "LocateUs.imgTbxSearch": {
                    "src": "search_white.png"
                },
                "LocateUs.imgToolTip": {
                    "src": "tooltip_arrow_blue.png"
                },
                "LocateUs.imgViewsAndFilters": {
                    "src": "sort_icon.png"
                },
                "LocateUs.imgViewsAndFiltersClose": {
                    "src": "icon_close_grey.png"
                },
                "LocateUs.imgZoomIn": {
                    "src": "plus_blue.png"
                },
                "LocateUs.imgZoomOut": {
                    "src": "minus_blue.png"
                },
                "LocateUs.lblAddressLine1": {
                    "top": "80dp"
                },
                "LocateUs.lblAddressLine2": {
                    "top": "100dp"
                },
                "LocateUs.lblBranchName2": {
                    "top": "30dp"
                },
                "LocateUs.lblBranchName3": {
                    "left": "4.80%"
                },
                "LocateUs.lblSearchImage": {
                    "height": "20px",
                    "text": "e",
                    "width": "17px"
                },
                "LocateUs.lblServicesAvailable": {
                    "top": "18dp"
                },
                "LocateUs.lblViewsAndFilters": {
                    "left": "5.95%"
                },
                "LocateUs.mapLocateUs": {
                    "height": "100%"
                },
                "LocateUs.segDayAndTime": {
                    "data": [{
                        "lblTimingsColon1": "",
                        "lblTimingsMondayKey": "",
                        "lblTimingsMondayValue": ""
                    }]
                },
                "LocateUs.segDirections": {
                    "height": "100%"
                },
                "LocateUs.segResults": {
                    "top": "0dp",
                    "width": "100%"
                },
                "LocateUs.tbxSearchBox": {
                    "left": "42px",
                    "right": "40px",
                    "top": "0px",
                    "width": ""
                },
                "CustomFooterMain": {
                    "centerX": "50%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                }
            }
            this.add(flxFormContent, flxLoading, flxDialogs, flxShareDirection, flxseperator);
        };
        return [{
            "addWidgets": addWidgetsfrmLocateUs,
            "enabledForIdleTimeout": true,
            "id": "frmLocateUs",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_c359f271da264268a61a5e6d1e47746a,
            "postShow": controller.AS_Form_f61793624dac44e2a92a68d8a966552d,
            "preShow": function(eventobject) {
                controller.AS_Form_a53ed9c9cdb645898d1c6a3cbcd07ce6(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Locate Us",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1379],
            "appName": "AboutUsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c726cc5535004e8286163944bcd6c94d,
            "retainScrollPosition": false
        }]
    }
});