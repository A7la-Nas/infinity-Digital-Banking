define("com/temenos/infinity/sca/uniken/topMessage/usertopMessageController", function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/temenos/infinity/sca/uniken/topMessage/topMessageControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/temenos/infinity/sca/uniken/topMessage/topMessageController", ["com/temenos/infinity/sca/uniken/topMessage/usertopMessageController", "com/temenos/infinity/sca/uniken/topMessage/topMessageControllerActions"], function() {
    var controller = require("com/temenos/infinity/sca/uniken/topMessage/usertopMessageController");
    var actions = require("com/temenos/infinity/sca/uniken/topMessage/topMessageControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});
