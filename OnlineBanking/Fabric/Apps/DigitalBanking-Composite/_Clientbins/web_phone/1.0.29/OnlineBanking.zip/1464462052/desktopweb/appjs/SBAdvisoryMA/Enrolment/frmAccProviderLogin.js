define("SBAdvisoryMA/Enrolment/frmAccProviderLogin", function() {
    return function(controller) {
        function addWidgetsfrmAccProviderLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxAccProviderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAccProviderMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccProviderMain.setDefaultUnit(kony.flex.DP);
            var lblGraphicalRep = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblGraphicalRep",
                "isVisible": true,
                "skin": "sknLblREDSSPReg22px",
                "text": "It's just a graphical representation",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAccProv = new kony.ui.Image2({
                "centerX": "50%",
                "height": "430dp",
                "id": "imgAccProv",
                "imageWhenFailed": "accproviderinput.png",
                "imageWhileDownloading": "accproviderinput.png",
                "isVisible": true,
                "src": "accproviderinput.png",
                "top": "15dp",
                "width": "260dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "120dp",
                "id": "flxMainButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainButtons.setDefaultUnit(kony.flex.DP);
            var btnAccProvider = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnAccProvider",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "top": "0dp",
                "width": "260dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.tab.common.CANCEL\")",
                "top": "15dp",
                "width": "260dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMainButtons.add(btnAccProvider, btnCancel);
            flxAccProviderMain.add(lblGraphicalRep, imgAccProv, flxMainButtons);
            this.compInstData = {}
            this.add(flxAccProviderMain);
        };
        return [{
            "addWidgets": addWidgetsfrmAccProviderLogin,
            "enabledForIdleTimeout": false,
            "id": "frmAccProviderLogin",
            "init": controller.AS_Form_ic4c91374d704d279c75fef4c5dd48d6,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "SBAdvisoryMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});