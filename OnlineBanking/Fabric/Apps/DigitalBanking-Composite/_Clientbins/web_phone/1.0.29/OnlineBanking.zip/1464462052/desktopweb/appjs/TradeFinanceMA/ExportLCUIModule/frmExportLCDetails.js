define("TradeFinanceMA/ExportLCUIModule/frmExportLCDetails", function() {
    return function(controller) {
        function addWidgetsfrmExportLCDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmExportLCDetails"] && appConfig.componentMetadata["ResourcesMA"]["frmExportLCDetails"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "TradeFinance";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "Exports";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxSAPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxSAPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxSAPopup.setDefaultUnit(kony.flex.DP);
            var flxSAContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxSAContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "700dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSAContent.setDefaultUnit(kony.flex.DP);
            var flxSAHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSAHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSAHeading.setDefaultUnit(kony.flex.DP);
            var lblSAHeading = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSAHeading",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSAClose = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnSAClose",
                "isVisible": true,
                "right": "2.50%",
                "skin": "btnClose",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSAHeading.add(lblSAHeading, btnSAClose);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxSABody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxSABody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSABody.setDefaultUnit(kony.flex.DP);
            var flxSADownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "26dp",
                "id": "flxSADownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "20dp",
                "width": "25dp",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSADownload.setDefaultUnit(kony.flex.DP);
            var lblSADownloadIcon = new kony.ui.Label({
                "height": "100%",
                "id": "lblSADownloadIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblOlbFonts003E7525Px",
                "text": "D",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSADownload.add(lblSADownloadIcon);
            var flxSAText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSAText",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSAText.setDefaultUnit(kony.flex.DP);
            var rtxSA = new kony.ui.RichText({
                "id": "rtxSA",
                "isVisible": true,
                "left": "0dp",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSAText.add(rtxSA);
            flxSABody.add(flxSADownload, flxSAText);
            flxSAContent.add(flxSAHeading, flxSeparator1, flxSABody);
            var flxBottomGap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBottomGap",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "700dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomGap.setDefaultUnit(kony.flex.DP);
            flxBottomGap.add();
            flxSAPopup.add(flxSAContent, flxBottomGap);
            formTemplate12.flxContentPopup.add(flxSAPopup);
            var flxLCDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxContentSwitch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "55dp",
                "id": "flxContentSwitch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentSwitch.setDefaultUnit(kony.flex.DP);
            var btnTab1 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab1",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknBtnAccountSummarySelected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.letterOfCredit\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [10, 4, 10, 4],
                "paddingInPixel": true
            }, {});
            var btnTab2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBtnAccountSummaryUnselected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Amendments\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [10, 4, 10, 4],
                "paddingInPixel": true
            }, {});
            var btnTab3 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab3",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBtnAccountSummaryUnselected2",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Drawings\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [10, 4, 10, 4],
                "paddingInPixel": true
            }, {});
            flxContentSwitch.add(btnTab1, btnTab2, btnTab3);
            var flxListingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListingContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListingContent.setDefaultUnit(kony.flex.DP);
            var flxSearchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchContainer.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "width": "87%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxBoxSearch = new kony.ui.FlexContainer({
                "centerY": "47.50%",
                "clipBounds": true,
                "focusSkin": "bbSknFlxBordere3e3e3Radius3Px",
                "height": "50dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Label({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgSearch",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "25dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.searchForApplicantLCRef\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [40, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "width": "25dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var lblCross = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "lblCross",
                "isVisible": false,
                "right": "2%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(lblCross);
            flxBoxSearch.add(imgSearch, tbxSearch, flxCross);
            flxSearch.add(flxBoxSearch);
            var btnViewConsolidated = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "50dp",
                "id": "btnViewConsolidated",
                "isVisible": true,
                "left": "2.50%",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.viewConsolidated\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchContainer.add(flxSearch, btnViewConsolidated);
            var flxListing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListing",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListing.setDefaultUnit(kony.flex.DP);
            var flxTabListingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTabListingHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabListingHeader.setDefaultUnit(kony.flex.DP);
            var flxHeaderTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderTopSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderTopSeparator.add();
            var flxDColumnHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDColumnHeader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumnHeader.setDefaultUnit(kony.flex.DP);
            var flxDColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn1.setDefaultUnit(kony.flex.DP);
            var lblDColumn1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDSort1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgDSort1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn1.add(lblDColumn1, imgDSort1);
            var flxDColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn2.setDefaultUnit(kony.flex.DP);
            var lblDColumn2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingReference\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDSort2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgDSort2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn2.add(lblDColumn2, imgDSort2);
            var flxDColumn3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn3.setDefaultUnit(kony.flex.DP);
            var lblDColumn3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn3",
                "isVisible": true,
                "right": "18dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDSort3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgDSort3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn3.add(lblDColumn3, imgDSort3);
            var flxDColumn4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn4.setDefaultUnit(kony.flex.DP);
            var lblDColumn4 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn4",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Date\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDSort4 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgDSort4",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn4.add(lblDColumn4, imgDSort4);
            var flxDColumn5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn5.setDefaultUnit(kony.flex.DP);
            var lblDColumn5 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn5",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDSort5 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgDSort5",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sorting_next.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn5.add(lblDColumn5, imgDSort5);
            var flxDColumn6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDColumn6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDColumn6.setDefaultUnit(kony.flex.DP);
            var lblDColumn6 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDColumn6",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDColumn6.add(lblDColumn6);
            flxDColumnHeader.add(flxDColumn1, flxDColumn2, flxDColumn3, flxDColumn4, flxDColumn5, flxDColumn6);
            var flxAColumnHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAColumnHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumnHeader.setDefaultUnit(kony.flex.DP);
            var flxAColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "13%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn1.setDefaultUnit(kony.flex.DP);
            var lblAColumn1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn1.add(lblAColumn1, imgASort1);
            var flxAColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "17%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn2.setDefaultUnit(kony.flex.DP);
            var lblAColumn2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCReference\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn2.add(lblAColumn2, imgASort2);
            var flxAColumn3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "16.50%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn3.setDefaultUnit(kony.flex.DP);
            var lblAColumn3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn3.add(lblAColumn3, imgASort3);
            var flxAColumn4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn4.setDefaultUnit(kony.flex.DP);
            var lblAColumn4 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn4",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReceivedOn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort4 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort4",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn4.add(lblAColumn4, imgASort4);
            var flxAColumn5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn5.setDefaultUnit(kony.flex.DP);
            var lblAColumn5 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn5",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmendmentNo\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort5 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort5",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn5.add(lblAColumn5, imgASort5);
            var flxAColumn6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn6",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn6.setDefaultUnit(kony.flex.DP);
            var lblAColumn6 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn6",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgASort6 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgASort6",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn6.add(lblAColumn6, imgASort6);
            var flxAColumn7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAColumn7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "8%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAColumn7.setDefaultUnit(kony.flex.DP);
            var lblAColumn7 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAColumn7",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAColumn7.add(lblAColumn7);
            flxAColumnHeader.add(flxAColumn1, flxAColumn2, flxAColumn3, flxAColumn4, flxAColumn5, flxAColumn6, flxAColumn7);
            var flxHeaderBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "ICSknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderBottomSeparator.add();
            flxTabListingHeader.add(flxHeaderTopSeparator, flxDColumnHeader, flxAColumnHeader, flxHeaderBottomSeparator);
            var flxListingSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListingSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListingSegment.setDefaultUnit(kony.flex.DP);
            var segTransactionList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }, {
                    "btnAction": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")",
                    "btnAction1": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                    "btnAction2": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")",
                    "lblBottomSeparator": "",
                    "lblColumn1": "Applicant Name",
                    "lblColumn2": "LC0000000000000",
                    "lblColumn3": "Status",
                    "lblColumn4": "dd/mm/yyyy",
                    "lblColumn5": "Amendment Number",
                    "lblColumn6": "Amendment Number",
                    "lblDropdown": "P",
                    "lblIdentifier": "",
                    "lblRowColumn1Key": "LC Type",
                    "lblRowColumn1Value": "LC Type",
                    "lblRowColumn2Key": "Issue Date",
                    "lblRowColumn2Value": "dd/mm/yyyy",
                    "lblRowColumn3Key": "Expiry Date",
                    "lblRowColumn3Value": "dd/mm/yyyy",
                    "lblSeparator": ""
                }],
                "groupCells": false,
                "id": "segTransactionList",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportAmendmentList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAction": "btnAction",
                    "btnAction1": "btnAction1",
                    "btnAction2": "btnAction2",
                    "flxAction": "flxAction",
                    "flxColumn1": "flxColumn1",
                    "flxColumn2": "flxColumn2",
                    "flxColumn3": "flxColumn3",
                    "flxColumn4": "flxColumn4",
                    "flxColumn5": "flxColumn5",
                    "flxColumn6": "flxColumn6",
                    "flxDetails": "flxDetails",
                    "flxDetailsActions": "flxDetailsActions",
                    "flxDetailsRow1": "flxDetailsRow1",
                    "flxDropdown": "flxDropdown",
                    "flxExportAmendmentList": "flxExportAmendmentList",
                    "flxIdentifier": "flxIdentifier",
                    "flxMain": "flxMain",
                    "flxRowColumn1": "flxRowColumn1",
                    "flxRowColumn2": "flxRowColumn2",
                    "flxRowColumn3": "flxRowColumn3",
                    "flxWrapper": "flxWrapper",
                    "lblBottomSeparator": "lblBottomSeparator",
                    "lblColumn1": "lblColumn1",
                    "lblColumn2": "lblColumn2",
                    "lblColumn3": "lblColumn3",
                    "lblColumn4": "lblColumn4",
                    "lblColumn5": "lblColumn5",
                    "lblColumn6": "lblColumn6",
                    "lblDropdown": "lblDropdown",
                    "lblIdentifier": "lblIdentifier",
                    "lblRowColumn1Key": "lblRowColumn1Key",
                    "lblRowColumn1Value": "lblRowColumn1Value",
                    "lblRowColumn2Key": "lblRowColumn2Key",
                    "lblRowColumn2Value": "lblRowColumn2Value",
                    "lblRowColumn3Key": "lblRowColumn3Key",
                    "lblRowColumn3Value": "lblRowColumn3Value",
                    "lblSeparator": "lblSeparator"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxListingSegment.add(segTransactionList);
            var flxNoTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxNoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactions.setDefaultUnit(kony.flex.DP);
            var imgNoTransaction = new kony.ui.Image2({
                "centerY": "50%",
                "height": "40dp",
                "id": "imgNoTransaction",
                "isVisible": true,
                "src": "info_large.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoTransaction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNoTransaction",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "text": "No transactions available",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoTransactions.add(imgNoTransaction, lblNoTransaction);
            flxListing.add(flxTabListingHeader, flxListingSegment, flxNoTransactions);
            flxListingContent.add(flxSearchContainer, flxListing);
            var flxLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetails.setDefaultUnit(kony.flex.DP);
            var ExportLCDetails = new com.InfinityOLB.TradeFinance.ExportLCDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ExportLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLCDetails.add(ExportLCDetails);
            flxLCDetailsContent.add(flxContentSwitch, flxListingContent, flxLCDetails);
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPagination",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var PaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "PaginationContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPagination.add(PaginationContainer);
            var flxBeneficiaryConsent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxBeneficiaryConsent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffShadowdddcdc",
                "top": "18dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryConsent.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryConsent = new kony.ui.Label({
                "id": "lblBeneficiaryConsent",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLbl424242SSP15pxBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.beneficiaryConsent\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var lblConfirmConsent = new kony.ui.Label({
                "id": "lblConfirmConsent",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.confirmYourConsentOnThisExportLc\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxConsentOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConsentOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentOptions.setDefaultUnit(kony.flex.DP);
            var flxConsentOption1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "21dp",
                "id": "flxConsentOption1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "9%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentOption1.setDefaultUnit(kony.flex.DP);
            var lblConsentOptionIcon1 = new kony.ui.Label({
                "height": "20dp",
                "id": "lblConsentOptionIcon1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnUnelectedFontIcona0a0a020px",
                "text": "L",
                "top": "0dp",
                "width": "21dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConsentOption1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblConsentOption1",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Accept\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentOption1.add(lblConsentOptionIcon1, lblConsentOption1);
            var flxConsentOption2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "21dp",
                "id": "flxConsentOption2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "9%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentOption2.setDefaultUnit(kony.flex.DP);
            var lblConsentOptionIcon2 = new kony.ui.Label({
                "height": "20dp",
                "id": "lblConsentOptionIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnUnelectedFontIcona0a0a020px",
                "text": "L",
                "top": "0dp",
                "width": "21dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConsentOption2 = new kony.ui.Label({
                "id": "lblConsentOption2",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.myApproval.Reject\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentOption2.add(lblConsentOptionIcon2, lblConsentOption2);
            flxConsentOptions.add(flxConsentOption1, flxConsentOption2);
            var flxReasonForRejection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReasonForRejection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReasonForRejection.setDefaultUnit(kony.flex.DP);
            var lblReasonForRejection = new kony.ui.Label({
                "id": "lblReasonForRejection",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.reasonForRejection\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtReasonForRejection = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "75dp",
                "id": "txtReasonForRejection",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 5000,
                "numberOfVisibleLines": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"kony.mb.common.EnterHere\")",
                "skin": "txtAreaResize",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [10, 10, 2, 2],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxReasonForRejection.add(lblReasonForRejection, txtReasonForRejection);
            var flxMessageToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxMessageToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageToBank.setDefaultUnit(kony.flex.DP);
            var lblMessageToBank = new kony.ui.Label({
                "id": "lblMessageToBank",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtMessageToBank = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "75dp",
                "id": "txtMessageToBank",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 5000,
                "numberOfVisibleLines": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"kony.mb.common.EnterHere\")",
                "skin": "txtAreaResize",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [10, 10, 2, 2],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxMessageToBank.add(lblMessageToBank, txtMessageToBank);
            flxBeneficiaryConsent.add(lblBeneficiaryConsent, flxSeparator, lblConfirmConsent, flxConsentOptions, flxReasonForRejection, flxMessageToBank);
            var flxActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var btnCreateDrawing = new kony.ui.Button({
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnCreateDrawing",
                "isVisible": true,
                "left": "2%",
                "right": "0%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.CreateNewDrawing\")",
                "top": "0dp",
                "width": "14%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewAllExportLC = new kony.ui.Button({
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnViewAllExportLC",
                "isVisible": true,
                "left": "2%",
                "right": "0%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewAllExportLC\")",
                "top": "0dp",
                "width": "14%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Export LC"
            });
            var btnSubmit = new kony.ui.Button({
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnSubmit",
                "isVisible": true,
                "left": "2%",
                "right": "0%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Submit\")",
                "top": "0dp",
                "width": "14%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Cancel"
                },
                "focusSkin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "height": "40px",
                "id": "btnBack",
                "isVisible": true,
                "left": "2%",
                "right": "0%",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Back",
                "top": "0dp",
                "width": "14%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActions.add(btnCreateDrawing, btnViewAllExportLC, btnSubmit, btnBack);
            formTemplate12.flxContentTCCenter.add(flxLCDetailsContent, flxPagination, flxBeneficiaryConsent, flxActions);
            var flxHeaderActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHeaderActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderActions.setDefaultUnit(kony.flex.DP);
            var flxPrint = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxPrint",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrint.setDefaultUnit(kony.flex.DP);
            var imgPrint = new kony.ui.Image2({
                "height": "100%",
                "id": "imgPrint",
                "isVisible": true,
                "left": "0dp",
                "src": "print_blue.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(imgPrint);
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "height": "100%",
                "id": "imgDownload",
                "isVisible": true,
                "left": "0dp",
                "src": "download_3x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(imgDownload);
            var flxVerticalEllipsisBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "4%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBody.setDefaultUnit(kony.flex.DP);
            var flxVerticalEllipsis = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsis",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "5.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsis.setDefaultUnit(kony.flex.DP);
            var lblVerticalEllipsis = new kony.ui.Label({
                "centerX": "50%",
                "height": "100%",
                "id": "lblVerticalEllipsis",
                "isVisible": true,
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerticalEllipsisDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "-10dp",
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "250dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.setDefaultUnit(kony.flex.DP);
            var segVerticalDropdownEllipsis = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segVerticalDropdownEllipsis",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCTypeOfAccountsList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListRow": "flxAccountListRow",
                    "flxLCAccountType": "flxLCAccountType",
                    "flxLCType": "flxLCType",
                    "flxLCTypeOfAccountsList": "flxLCTypeOfAccountsList",
                    "imgLCCheckbox": "imgLCCheckbox",
                    "lblLCAccountType": "lblLCAccountType",
                    "lblLCCheckbox": "lblLCCheckbox"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.add(segVerticalDropdownEllipsis);
            flxVerticalEllipsis.add(lblVerticalEllipsis, flxVerticalEllipsisDropdown);
            flxVerticalEllipsisBody.add(flxVerticalEllipsis);
            var flxSwiftAndAdvices = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftAndAdvices",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "45dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftAndAdvices.setDefaultUnit(kony.flex.DP);
            var lblSwiftAndAdvices = new kony.ui.Label({
                "id": "lblSwiftAndAdvices",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSwiftAndAdvicesInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftAndAdvicesInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slfBoxffffffB1R5",
                "top": "28dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftAndAdvicesInfo.setDefaultUnit(kony.flex.DP);
            var segSwiftAndAdvicesInfo = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segSwiftAndAdvicesInfo",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftAndAdvicesInfo.add(segSwiftAndAdvicesInfo);
            flxSwiftAndAdvices.add(lblSwiftAndAdvices, flxSwiftAndAdvicesInfo);
            flxHeaderActions.add(flxPrint, flxDownload, flxVerticalEllipsisBody, flxSwiftAndAdvices);
            formTemplate12.flxTCButtons.add(flxHeaderActions);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxSearchContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer"]
                    },
                    "flxBoxSearch": {
                        "focusSkin": "bbSKnFlxffffff",
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch"]
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "tbxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "focusSkin": "skntbxSSP42424215pxnoborderffffffBG",
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "skntbxSSP42424215pxnoborderffffffBG",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "flxAColumn3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxNoTransactions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing"]
                    },
                    "lblNoTransaction": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxNoTransactions"]
                    },
                    "flxPagination": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "text": "Back",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxSAPopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "flxSearchContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxSearch": {
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer"]
                    },
                    "flxBoxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch"]
                    },
                    "tbxSearch": {
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "flxDColumnHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxDColumn1": {
                        "width": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxDColumn2": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxDColumn3": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxDColumn4": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "24%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxDColumn5": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxDColumn6": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxAColumnHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxAColumn1": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn2": {
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn3": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn4": {
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn5": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn6": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "21.70%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxAColumn7": {
                        "left": {
                            "type": "string",
                            "value": "3.60%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxNoTransactions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing"]
                    },
                    "imgNoTransaction": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxNoTransactions"]
                    },
                    "lblNoTransaction": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxNoTransactions"]
                    },
                    "flxLCDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent"]
                    },
                    "flxPagination": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxConsentOption1": {
                        "width": {
                            "type": "string",
                            "value": "13%"
                        },
                        "segmentProps": []
                    },
                    "txtReasonForRejection": {
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "txtMessageToBank": {
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "segmentProps": []
                    },
                    "btnCreateDrawing": {
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "btnViewAllExportLC": {
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "btnSubmit": {
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderActions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxPrint": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxHeaderActions"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxSearchContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer"]
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "skin": "ICSknlblSearchfonticon19px0273e3",
                        "text": "e",
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "tbxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "flxListing": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxHeaderTopSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknflxe3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxDColumnHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxDColumn1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "imgDSort1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader", "flxDColumn1"]
                    },
                    "flxDColumn2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "imgDSort2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader", "flxDColumn2"]
                    },
                    "flxDColumn3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "imgDSort3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader", "flxDColumn3"]
                    },
                    "flxDColumn4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "imgDSort4": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader", "flxDColumn4"]
                    },
                    "flxDColumn5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "imgDSort5": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader", "flxDColumn5"]
                    },
                    "flxDColumn6": {
                        "width": {
                            "type": "string",
                            "value": "11.70%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxDColumnHeader"]
                    },
                    "flxAColumnHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxAColumn1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn1"]
                    },
                    "flxAColumn2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn2"]
                    },
                    "flxAColumn3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn3"]
                    },
                    "flxAColumn4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort4": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn4"]
                    },
                    "flxAColumn5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort5": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn5"]
                    },
                    "flxAColumn6": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "imgASort6": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader", "flxAColumn6"]
                    },
                    "flxAColumn7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader", "flxAColumnHeader"]
                    },
                    "flxHeaderBottomSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknflxe3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxNoTransactions": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing"]
                    },
                    "imgNoTransaction": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxNoTransactions"]
                    },
                    "lblNoTransaction": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxNoTransactions"]
                    },
                    "flxPagination": {
                        "segmentProps": []
                    },
                    "flxConsentOptions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxConsentOption1": {
                        "segmentProps": []
                    },
                    "flxConsentOption2": {
                        "segmentProps": []
                    },
                    "btnBack": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderActions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxSwiftAndAdvicesInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxHeaderActions", "flxSwiftAndAdvices"]
                    }
                },
                "1380": {
                    "flxSearchContainer": {
                        "zIndex": 5002,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer"]
                    },
                    "imgSearch": {
                        "skin": "ICSknlblSearchfonticon19px0273e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "tbxSearch": {
                        "segmentProps": [],
                        "hoverSkin": "",
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxSearchContainer", "flxSearch", "flxBoxSearch"]
                    },
                    "flxListing": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent"]
                    },
                    "flxHeaderTopSeparator": {
                        "skin": "ICSknflxe3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxHeaderBottomSeparator": {
                        "skin": "ICSknflxe3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxLCDetailsContent", "flxListingContent", "flxListing", "flxTabListingHeader"]
                    },
                    "flxPagination": {
                        "segmentProps": []
                    },
                    "flxConsentOptions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxConsentOption1": {
                        "segmentProps": []
                    },
                    "flxConsentOption2": {
                        "segmentProps": []
                    },
                    "btnBack": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCDetails,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCDetails",
            "init": controller.AS_Form_cf54301b3b89408789d8766c59edbe22,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});