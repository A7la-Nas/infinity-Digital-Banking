define("ArrangementsMA/ServiceRequestsUIModule/frmRepaymentDayRequest", function() {
    return function(controller) {
        function addWidgetsfrmRepaymentDayRequest() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "ICSknFlxF7F8F7Border",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmRepaymentDayRequest"] && appConfig.componentMetadata["ResourcesMA"]["frmRepaymentDayRequest"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "Service Request Overview";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContentMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentMain.setDefaultUnit(kony.flex.DP);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "50dp",
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblRequestDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblRequestDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Request Details",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxFacilityHeader.add(lblRequestDetails, flxSeparator);
            var flxFacilityContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "340dp",
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblRequestType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRequestType",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Request Type:",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestTypeVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRequestTypeVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Reference Number:",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumberVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReferenceNumberVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Facility Name:",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Number Of Loans:",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalance",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Outstanding Balance:",
                "top": "180dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalanceVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalanceVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "180dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Maturity Date :",
                "top": "220dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "220dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStatus = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblStatus",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Status:",
                "top": "260dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStatusVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblStatusVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "260dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblComments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblComments",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Comments:",
                "top": "300dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCommentsVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCommentsVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "300dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblRequestType, lblRequestTypeVal, lblReferenceNumber, lblReferenceNumberVal, lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNoOfLoansVal, lblOutstandingBalance, lblOutstandingBalanceVal, lblMaturityDate, lblMaturityDateVal, lblStatus, lblStatusVal, lblComments, lblCommentsVal);
            flxFacilityDetails.add(flxFacilityHeader, flxFacilityContent);
            var flxLoanDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanAccountsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanAccountsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountsSegment.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Loan Details",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSegLoanDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegLoanDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegLoanDetails.setDefaultUnit(kony.flex.DP);
            var segLoanDetails = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Primary Loan-8760"
                        },
                        [{
                            "imgBankIcon": "imagedrag.png",
                            "imgBankIcon1": "imagedrag.png",
                            "imgChecked": "C",
                            "imgChecked1": "C",
                            "imgFavorite": "F",
                            "imgIcon": "s",
                            "imgIcon1": "s",
                            "lblAccType": "Label",
                            "lblAccType1": "Label",
                            "lblAccountName": "Label",
                            "lblAccountName1": "Label",
                            "lblFavorite1": "F"
                        }]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Secondary Loan -1211"
                        },
                        [{
                            "imgBankIcon": "imagedrag.png",
                            "imgBankIcon1": "imagedrag.png",
                            "imgChecked": "C",
                            "imgChecked1": "C",
                            "imgFavorite": "F",
                            "imgIcon": "s",
                            "imgIcon1": "s",
                            "lblAccType": "Label",
                            "lblAccType1": "Label",
                            "lblAccountName": "Label",
                            "lblAccountName1": "Label",
                            "lblFavorite1": "F"
                        }]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "New Loan -1234"
                        },
                        [{
                            "imgBankIcon": "imagedrag.png",
                            "imgBankIcon1": "imagedrag.png",
                            "imgChecked": "C",
                            "imgChecked1": "C",
                            "imgFavorite": "F",
                            "imgIcon": "s",
                            "imgIcon1": "s",
                            "lblAccType": "Label",
                            "lblAccType1": "Label",
                            "lblAccountName": "Label",
                            "lblAccountName1": "Label",
                            "lblFavorite1": "F"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segLoanDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsListCustomView"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": 0,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListItem": "flxAccountListItem",
                    "flxAccountListItem1": "flxAccountListItem1",
                    "flxAccountsListCustomView": "flxAccountsListCustomView",
                    "flxAccountsListWrapper": "flxAccountsListWrapper",
                    "flxBankIcon": "flxBankIcon",
                    "flxBankIcon1": "flxBankIcon1",
                    "flxChecked": "flxChecked",
                    "flxChecked1": "flxChecked1",
                    "flxDropDown": "flxDropDown",
                    "flxFavorite": "flxFavorite",
                    "flxFavorite1": "flxFavorite1",
                    "flxIcons": "flxIcons",
                    "flxIcons1": "flxIcons1",
                    "flxTransfersFromListHeader": "flxTransfersFromListHeader",
                    "imgBankIcon": "imgBankIcon",
                    "imgBankIcon1": "imgBankIcon1",
                    "imgChecked": "imgChecked",
                    "imgChecked1": "imgChecked1",
                    "imgDropDown": "imgDropDown",
                    "imgFavorite": "imgFavorite",
                    "imgIcon": "imgIcon",
                    "imgIcon1": "imgIcon1",
                    "lblAccType": "lblAccType",
                    "lblAccType1": "lblAccType1",
                    "lblAccountName": "lblAccountName",
                    "lblAccountName1": "lblAccountName1",
                    "lblFavorite1": "lblFavorite1",
                    "lblSeparator": "lblSeparator",
                    "lblTopSeparator": "lblTopSeparator",
                    "lblTransactionHeader": "lblTransactionHeader"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegLoanDetails.add(segLoanDetails);
            var flxAccountDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "184dp",
                "id": "flxAccountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetails.setDefaultUnit(kony.flex.DP);
            var flxHeaderGroup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderGroup.setDefaultUnit(kony.flex.DP);
            var flxGap = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGap",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "0",
                "width": "30%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGap.setDefaultUnit(kony.flex.DP);
            flxGap.add();
            var lblCurrAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblCurrAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Current Account Detail",
                "top": "20dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblNewAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "New Account Detail",
                "top": "20dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderGroup.add(flxGap, lblCurrAccount, lblNewAccount);
            var flxAccountNameGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountNameGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNameGroup.setDefaultUnit(kony.flex.DP);
            var lblAccHoldName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAccHoldName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Repayment Account Holder Name",
                "top": "60dp",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameCV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblHolderNameCV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameNV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblHolderNameNV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameCV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblHolderNameCV",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "60dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameNV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblHolderNameNV",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Daisy Davis",
                "top": "60dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountNameGroup.add(lblAccHoldName, lblHolderNameCV1, lblHolderNameNV1, lblHolderNameCV, lblHolderNameNV);
            var flxAccountNumberGroup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountNumberGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumberGroup.setDefaultUnit(kony.flex.DP);
            var lblAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Repayment Account Number",
                "top": "98dp",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberCV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblAccountNumberCV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberNV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblAccountNumberNV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberCV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAccountNumberCV",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "98dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberNV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAccountNumberNV",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "9281 8900 8192 1211",
                "top": "98dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountNumberGroup.add(lblAccountNumber, lblAccountNumberCV1, lblAccountNumberNV1, lblAccountNumberCV, lblAccountNumberNV);
            var flxSwiftGroup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftGroup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftGroup.setDefaultUnit(kony.flex.DP);
            var lblSwift = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSwift",
                "isVisible": false,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "BIC/SWIFT ",
                "top": "136dp",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftCV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblSwiftCV1",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftNV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblSwiftNV1",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftCV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSwiftCV",
                "isVisible": false,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "LB29NWBK60161331926819",
                "top": "136dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftNV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSwiftNV",
                "isVisible": false,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "MCRBRUMM000",
                "top": "136dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftGroup.add(lblSwift, lblSwiftCV1, lblSwiftNV1, lblSwiftCV, lblSwiftNV);
            var flxBankGroup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBankGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankGroup.setDefaultUnit(kony.flex.DP);
            var lblBankName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblBankName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Bank Name",
                "top": "136dp",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameCV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblBankNameCV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameNV1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "1dp",
                "id": "lblBankNameNV1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "top": "0dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameCV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblBankNameCV",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Lloyds Banking Group",
                "top": "136dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameNV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblBankNameNV",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Bank of Moscow",
                "top": "136dp",
                "width": "35%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankGroup.add(lblBankName, lblBankNameCV1, lblBankNameNV1, lblBankNameCV, lblBankNameNV);
            var lblSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeperator",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "183dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxCurrentACmb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxCurrentACmb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrentACmb.setDefaultUnit(kony.flex.DP);
            var flxHeadermb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxHeadermb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeadermb.setDefaultUnit(kony.flex.DP);
            var lblCurrentRepaymentAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblCurrentRepaymentAccount",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeadermb.add(lblCurrentRepaymentAccount);
            var flxContentCurrentmb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxContentCurrentmb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentCurrentmb.setDefaultUnit(kony.flex.DP);
            var lblAccountHolderNameCVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountHolderNameCVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberCVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountNumberCVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameCVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblBankNameCVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHolderNameValCV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountHolderNameValCV",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberValCVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountNumberValCVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameValCVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblBankNameValCVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentCurrentmb.add(lblAccountHolderNameCVmb, lblAccountNumberCVmb, lblBankNameCVmb, lblAccountHolderNameValCV, lblAccountNumberValCVmb, lblBankNameValCVmb);
            flxCurrentACmb.add(flxHeadermb, flxContentCurrentmb);
            var flxNewACmb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNewACmb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewACmb.setDefaultUnit(kony.flex.DP);
            var flxNewHeaderMb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNewHeaderMb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewHeaderMb.setDefaultUnit(kony.flex.DP);
            var lblNewRepaymentAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblNewRepaymentAccount",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewHeaderMb.add(lblNewRepaymentAccount);
            var flxContentNewmb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxContentNewmb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentNewmb.setDefaultUnit(kony.flex.DP);
            var lblAccountHolderNameNVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountHolderNameNVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberNVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountNumberNVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameNVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblBankNameNVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHolderNameValNV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountHolderNameValNV",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberValNVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAccountNumberValNVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameValNVmb = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblBankNameValNVmb",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentNewmb.add(lblAccountHolderNameNVmb, lblAccountNumberNVmb, lblBankNameNVmb, lblAccountHolderNameValNV, lblAccountNumberValNVmb, lblBankNameValNVmb);
            var flxSeparatorMb = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorMb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMb.setDefaultUnit(kony.flex.DP);
            flxSeparatorMb.add();
            var flxSeperatorMb1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperatorMb1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorMb1.setDefaultUnit(kony.flex.DP);
            flxSeperatorMb1.add();
            flxNewACmb.add(flxNewHeaderMb, flxContentNewmb, flxSeparatorMb, flxSeperatorMb1);
            flxAccountDetails.add(flxHeaderGroup, flxAccountNameGroup, flxAccountNumberGroup, flxSwiftGroup, flxBankGroup, lblSeperator, flxSeparator1, flxCurrentACmb, flxNewACmb);
            var flxAddress = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "170dp",
                "id": "flxAddress",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var lblExistingAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblExistingAddress",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Existing Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExistingAddressVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblExistingAddressVal1",
                "isVisible": true,
                "left": "358dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExistingAddressVal2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblExistingAddressVal2",
                "isVisible": true,
                "left": "358dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblNewAddress",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "New Address:",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddressVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblNewAddressVal1",
                "isVisible": true,
                "left": "358dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddressVal2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblNewAddressVal2",
                "isVisible": true,
                "left": "358dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsedFor = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblUsedFor",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Used For:",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "423dp",
                "src": "info_grey.png",
                "top": "136dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrimaryCommunication = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblPrimaryCommunication",
                "isVisible": true,
                "left": "448dp",
                "skin": "ICSknLb727272SSP11Px",
                "text": "Primary Communication",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Label"
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "183dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            flxAddress.add(lblExistingAddress, lblExistingAddressVal1, lblExistingAddressVal2, lblNewAddress, lblNewAddressVal1, lblNewAddressVal2, lblUsedFor, imgInfoIcon, lblPrimaryCommunication, lblSeparator1, flxSeparator3);
            flxLoanAccountsSegment.add(lblLoanDetails, flxSegLoanDetails, flxAccountDetails, flxAddress);
            var flxSupportingDocsMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocsMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocsMain.setDefaultUnit(kony.flex.DP);
            var flxSupportingDocsTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSupportingDocsTitle",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocsTitle.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSupportingDocTitle",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Supporting Documents",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            flxSupportingDocsTitle.add(lblSupportingDocTitle, flxSeparator4);
            var flxSupportingDocs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.setDefaultUnit(kony.flex.DP);
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Supporting Documents"
                        },
                        [{
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }, {
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }, {
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxDropDown": "flxDropDown",
                    "flxGap": "flxGap",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "flxTransfersFromListHeader": "flxTransfersFromListHeader",
                    "imgDoc": "imgDoc",
                    "imgDropDown": "imgDropDown",
                    "lblDocName": "lblDocName",
                    "lblSeparator": "lblSeparator",
                    "lblTopSeparator": "lblTopSeparator",
                    "lblTransactionHeader": "lblTransactionHeader"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.add(segSupportingDocs);
            var flxCheckBoxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxCheckBoxMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.setDefaultUnit(kony.flex.DP);
            var flxCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblCheckMsg",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "31dp",
                "isModalContainer": false,
                "top": 30,
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblCheckBox",
                "isVisible": true,
                "left": "0",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "D",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(lblCheckBox);
            var lblCheckMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblCheckMsg",
                "isVisible": true,
                "left": "65dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "I confirm that my co-borrower is aware of the change. ",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "69dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxCheckBoxMain.add(flxCheckBox, lblCheckMsg, flxSeparator2);
            flxSupportingDocsMain.add(flxSupportingDocsTitle, flxSupportingDocs, flxCheckBoxMain);
            flxLoanDetails.add(flxLoanAccountsSegment, flxSupportingDocsMain);
            flxContentMain.add(flxFacilityDetails, flxLoanDetails);
            formTemplate12.flxContentTCCenter.add(flxContentMain);
            var flxBackButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxBackButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "20dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackButton.setDefaultUnit(kony.flex.DP);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "text": "Back To Service Request",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackButton.add(btnBack);
            formTemplate12.flxPageFooter.add(flxBackButton);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "width": "100dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Download"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "40dp",
                "width": "40dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "0dp",
                "id": "lblDownload",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "D",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(lblDownload);
            var flxPrint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxPrint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "width": "40dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrint.setDefaultUnit(kony.flex.DP);
            var Image0ed490d1d437748 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "0dp",
                "height": "19dp",
                "id": "Image0ed490d1d437748",
                "isVisible": true,
                "left": "0",
                "right": "0dp",
                "src": "print_blue.png",
                "top": "0",
                "width": "21dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(Image0ed490d1d437748);
            flxButtons.add(flxDownload, flxPrint);
            formTemplate12.flxTCButtons.add(flxButtons);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "lblRequestDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "458dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "41"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "lblRequestType": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblRequestTypeVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "number",
                            "value": "33"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "72dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "88dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "127dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "143dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "182dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "237dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblOutstandingBalanceVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "292dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblMaturityDateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblStatus": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "347dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblStatusVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "362dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblComments": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "402dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblCommentsVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "417dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "flxSegLoanDetails": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "flxAccountDetails": {
                        "height": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "lblCurrAccount": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxHeaderGroup"]
                    },
                    "lblNewAccount": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxHeaderGroup"]
                    },
                    "lblAccHoldName": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameCV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameNV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameCV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameNV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblAccountNumber": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberCV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberNV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberCV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberNV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblBankName": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameCV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameNV1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameCV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameNV": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblSeperator": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "flxSeparator1": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "flxCurrentACmb": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "flxHeadermb": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "ICSknbgF9F9F9topbottomBorder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb"]
                    },
                    "lblCurrentRepaymentAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPBold42424213px",
                        "text": "Current Repayment Account ",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxHeadermb"]
                    },
                    "flxContentCurrentmb": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "176dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb"]
                    },
                    "lblAccountHolderNameCVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Account Holder Name:",
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "lblAccountNumberCVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "lblBankNameCVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "123dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "lblAccountHolderNameValCV": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "lblAccountNumberValCVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "lblBankNameValCVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxCurrentACmb", "flxContentCurrentmb"]
                    },
                    "flxNewACmb": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "flxNewHeaderMb": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "ICSknbgF9F9F9topbottomBorder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb"]
                    },
                    "lblNewRepaymentAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPBold42424213px",
                        "text": "New Repayment Account ",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxNewHeaderMb"]
                    },
                    "flxContentNewmb": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "176dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb"]
                    },
                    "lblAccountHolderNameNVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Repayment Account Holder Name:",
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "lblAccountNumberNVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "lblBankNameNVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272Lato13px",
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "123dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "lblAccountHolderNameValNV": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "lblAccountNumberValNVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "lblBankNameValNVmb": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb", "flxContentNewmb"]
                    },
                    "flxSeparatorMb": {
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb"]
                    },
                    "flxSeperatorMb1": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxNewACmb"]
                    },
                    "lblExistingAddress": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknSSPRegular42424213Px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal2": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknSSPRegular42424213Px",
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddress": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknSSPRegular42424213Px",
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal2": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknSSPRegular42424213Px",
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblUsedFor": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "imgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "153dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblPrimaryCommunication": {
                        "left": {
                            "type": "string",
                            "value": "118dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "157dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblSeparator1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "flxSeparator3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "flxSupportingDocsTitle": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain"]
                    },
                    "lblSupportingDocTitle": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain", "flxSupportingDocsTitle"]
                    },
                    "flxSeparator4": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "39dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain", "flxSupportingDocsTitle"]
                    },
                    "flxBackButton": {
                        "right": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxPageFooter"]
                    },
                    "btnBack": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxPageFooter", "flxBackButton"]
                    }
                },
                "1024": {
                    "lblRequestDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblRequestType": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblStatus": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails", "flxFacilityContent"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "flxAccountDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "lblCurrAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxHeaderGroup"]
                    },
                    "lblNewAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxHeaderGroup"]
                    },
                    "lblAccHoldName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameCV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameNV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblAccountNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberCV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberNV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblSwift": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxSwiftGroup"]
                    },
                    "lblSwiftCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxSwiftGroup"]
                    },
                    "lblSwiftNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxSwiftGroup"]
                    },
                    "lblSwiftCV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxSwiftGroup"]
                    },
                    "lblSwiftNV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxSwiftGroup"]
                    },
                    "lblBankName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameCV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblBankNameNV": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxBankGroup"]
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "flxAddress": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "lblExistingAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblUsedFor": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "imgInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblPrimaryCommunication": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxContentMain": {
                        "left": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxFacilityDetails": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "101.80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxFacilityHeader": {
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "flxFacilityContent": {
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "flxLoanDetails": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "101.80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxLoanAccountsSegment": {
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "flxAccountDetails": {
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment"]
                    },
                    "lblAccHoldName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblHolderNameNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNameGroup"]
                    },
                    "lblAccountNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberCV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblAccountNumberNV1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails", "flxAccountNumberGroup"]
                    },
                    "lblSeperator": {
                        "left": {
                            "type": "string",
                            "value": "-7dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100.20%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "lblExistingAddress": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddress": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblUsedFor": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "imgInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblPrimaryCommunication": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "flxSupportingDocsTitle": {
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain"]
                    },
                    "lblSupportingDocTitle": {
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain", "flxSupportingDocsTitle"]
                    },
                    "flxSeparator4": {
                        "top": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain", "flxSupportingDocsTitle"]
                    }
                },
                "1380": {
                    "flxContentMain": {
                        "left": {
                            "type": "number",
                            "value": "12"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxFacilityDetails": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxFacilityHeader": {
                        "left": {
                            "type": "number",
                            "value": "6"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "flxFacilityContent": {
                        "left": {
                            "type": "number",
                            "value": "6"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxFacilityDetails"]
                    },
                    "flxLoanDetails": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxLoanAccountsSegment": {
                        "left": {
                            "type": "number",
                            "value": "6"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblSeperator": {
                        "left": {
                            "type": "number",
                            "value": "-7"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "width": {
                            "type": "string",
                            "value": "100.20%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAccountDetails"]
                    },
                    "lblExistingAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblExistingAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblNewAddressVal2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblUsedFor": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "imgInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblPrimaryCommunication": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsSegment", "flxAddress"]
                    },
                    "flxSupportingDocsTitle": {
                        "left": {
                            "type": "number",
                            "value": "6"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxSupportingDocsMain"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmRepaymentDayRequest,
            "enabledForIdleTimeout": true,
            "id": "frmRepaymentDayRequest",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_abb0b7bfc76c4ff69bedff9d70ebf939,
            "preShow": function(eventobject) {
                controller.AS_Form_h239dcaeb637403cb80510e088b56499(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Repayment Day Request",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_fad3968bfb504505acbb0a531a90561a,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});