define("ArrangementsMA/AccountsUIModule/frmPrintTransaction", function() {
    return function(controller) {
        function addWidgetsfrmPrintTransaction() {
            this.setDefaultUnit(kony.flex.DP);
            var flxprintTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxprintTransactions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprintTransactions.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "70dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "18px",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "centerY": "50%",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "6.66%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgKony, lblKonyBank);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "< Back"
                },
                "focusSkin": "slButtonGlossRed",
                "id": "btnBack",
                "isVisible": false,
                "left": "6.07%",
                "skin": "Copysknbtnffffff",
                "text": "< Back",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var lblMyCheckingAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "id": "lblMyCheckingAccount",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCheckingAccountSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "200dp",
                "id": "flxCheckingAccountSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknflxBorder979797",
                "top": "20dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckingAccountSummary.setDefaultUnit(kony.flex.DP);
            var flxCheckingSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "51dp",
                "id": "flxCheckingSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-0.50%",
                "isModalContainer": false,
                "skin": "sknflxeeeeeeBorder979797",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckingSummaryHeader.setDefaultUnit(kony.flex.DP);
            var lblAccSummaryHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "ACCOUNT SUMMARY"
                },
                "id": "lblAccSummaryHeading",
                "isVisible": true,
                "left": "2.08%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.print.accountSummary\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckingSummaryHeader.add(lblAccSummaryHeading);
            var keyValueAccHolderName = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueAccHolderName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.enroll.accountHolderName\")"
                    },
                    "lblValue": {
                        "text": "John Bailey"
                    },
                    "printTransactionKeyValue": {
                        "top": "70dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValueAccNumber = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueAccNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")"
                    },
                    "lblValue": {
                        "text": "xxxx xxxx xxxx 3456"
                    },
                    "printTransactionKeyValue": {
                        "top": "100dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValueBank = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueBank",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "130dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CheckImages.Bank\")"
                    },
                    "lblValue": {
                        "text": "Kony Bank"
                    },
                    "printTransactionKeyValue": {
                        "top": "130dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValueBranch = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueBranch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "160dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "flxKey": {
                        "left": "5.08%",
                        "top": "0dp"
                    },
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.BRANCH\")"
                    },
                    "lblValue": {
                        "text": "Austin Downtown"
                    },
                    "printTransactionKeyValue": {
                        "top": "160dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValueAvailableBalance = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueAvailableBalance",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "text": "Available Balance:"
                    },
                    "lblValue": {
                        "text": "$328.00"
                    },
                    "printTransactionKeyValue": {
                        "left": "50%",
                        "top": "70dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValueCurrentBalance = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValueCurrentBalance",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "text": "Current Balance:"
                    },
                    "lblValue": {
                        "text": "$324.01"
                    },
                    "printTransactionKeyValue": {
                        "left": "50%",
                        "top": "100dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValuePendingDeposits = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValuePendingDeposits",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "130dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "text": "Pending Deposits:"
                    },
                    "lblValue": {
                        "text": "+$100.00"
                    },
                    "printTransactionKeyValue": {
                        "left": "50%",
                        "top": "130dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var keyValuePendingWithdrawal = new com.InfinityOLB.ArrangementsMA.printTransactionKeyValue({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "keyValuePendingWithdrawal",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "160dp",
                "width": "50%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "lblKey": {
                        "text": "Pending Withdrawals:"
                    },
                    "lblValue": {
                        "text": "-$100.00"
                    },
                    "printTransactionKeyValue": {
                        "left": "50%",
                        "top": "160dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxVerticalSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxVerticalSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "50dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator.add();
            flxCheckingAccountSummary.add(flxCheckingSummaryHeader, keyValueAccHolderName, keyValueAccNumber, keyValueBank, keyValueBranch, keyValueAvailableBalance, keyValueCurrentBalance, keyValuePendingDeposits, keyValuePendingWithdrawal, flxVerticalSeparator);
            var lblTransactionsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Transactions From: 04/30/2017 to 05/05/2017 "
                },
                "id": "lblTransactionsFrom",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbl424242bold17px",
                "text": "Transactions From: 04/30/2017 to 05/05/2017 ",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPendingTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPendingTransactions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknflxBorder979797",
                "top": "25dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingTransactions.setDefaultUnit(kony.flex.DP);
            var flxPendingTransactionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "51dp",
                "id": "flxPendingTransactionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-0.50%",
                "isModalContainer": false,
                "skin": "sknflxeeeeeeBorder979797",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingTransactionsHeader.setDefaultUnit(kony.flex.DP);
            var lblPendingTransactions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "PENDING TRANSACTIONS"
                },
                "centerY": "50%",
                "id": "lblPendingTransactions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknlbl424242bold15px",
                "text": "PENDING TRANSACTIONS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingTransactionsHeader.add(lblPendingTransactions);
            var flxhearlabels = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxhearlabels",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-0.50%",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "50dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxhearlabels.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Date"
                },
                "centerY": "50%",
                "id": "lblDate",
                "isVisible": true,
                "left": "2.95%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Date",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Description"
                },
                "centerY": "50%",
                "id": "lblDescription",
                "isVisible": true,
                "left": "13.65%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Description",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Type"
                },
                "centerY": "50%",
                "id": "lblType",
                "isVisible": true,
                "left": "53.41%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Type",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCategory = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Category"
                },
                "centerY": "50%",
                "id": "lblCategory",
                "isVisible": false,
                "left": "57.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Category",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount"
                },
                "centerY": "50%",
                "id": "lblAmount",
                "isVisible": true,
                "right": "21%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Amount",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Balance"
                },
                "centerY": "50%",
                "id": "lblBalance",
                "isVisible": true,
                "right": "5.48%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Balance",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxhearlabels.add(lblDate, lblDescription, lblType, lblCategory, lblAmount, lblBalance);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var segPendingTransaction = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segPendingTransaction",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxPrintTransaction"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "101dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPrintTransaction": "flxPrintTransaction",
                    "lblAmount": "lblAmount",
                    "lblBalance": "lblBalance",
                    "lblCategory": "lblCategory",
                    "lblDate": "lblDate",
                    "lblDescription": "lblDescription",
                    "lblSeparator": "lblSeparator",
                    "lblType": "lblType"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingTransactions.add(flxPendingTransactionsHeader, flxhearlabels, flxSeparator, segPendingTransaction);
            var flxPostedTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPostedTransactions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknflxBorder979797",
                "top": "25dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostedTransactions.setDefaultUnit(kony.flex.DP);
            var flxPostedTransactionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "51dp",
                "id": "flxPostedTransactionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-0.50%",
                "isModalContainer": false,
                "skin": "sknflxeeeeeeBorder979797",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostedTransactionsHeader.setDefaultUnit(kony.flex.DP);
            var CopylblPendingTransactions0a979ad50321149 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "POSTED TRANSACTIONS"
                },
                "id": "CopylblPendingTransactions0a979ad50321149",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknlbl424242bold15px",
                "text": "POSTED TRANSACTIONS",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPostedTransactionsHeader.add(CopylblPendingTransactions0a979ad50321149);
            var flxPostedTransactionsLabels = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxPostedTransactionsLabels",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-0.50%",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "50dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostedTransactionsLabels.setDefaultUnit(kony.flex.DP);
            var lblDate1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Date"
                },
                "centerY": "50%",
                "id": "lblDate1",
                "isVisible": true,
                "left": "2.95%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Date",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDescription1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Description"
                },
                "centerY": "50%",
                "id": "lblDescription1",
                "isVisible": true,
                "left": "13.65%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Description",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblType1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Type"
                },
                "centerY": "50%",
                "id": "lblType1",
                "isVisible": true,
                "left": "53.41%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Type",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCategory1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Category"
                },
                "centerY": "50%",
                "id": "lblCategory1",
                "isVisible": false,
                "left": "57.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Category",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Amount"
                },
                "centerY": "50%",
                "id": "lblAmount1",
                "isVisible": true,
                "right": "21%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Amount",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBalance1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Balance"
                },
                "centerY": "50%",
                "id": "lblBalance1",
                "isVisible": true,
                "right": "5.48%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Balance",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPostedTransactionsLabels.add(lblDate1, lblDescription1, lblType1, lblCategory1, lblAmount1, lblBalance1);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var segPostedTransactions = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segPostedTransactions",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxPrintTransaction"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "101dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPrintTransaction": "flxPrintTransaction",
                    "lblAmount": "lblAmount",
                    "lblBalance": "lblBalance",
                    "lblCategory": "lblCategory",
                    "lblDate": "lblDate",
                    "lblDescription": "lblDescription",
                    "lblSeparator": "lblSeparator",
                    "lblType": "lblType"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPostedTransactions.add(flxPostedTransactionsHeader, flxPostedTransactionsLabels, flxSeparator1, segPostedTransactions);
            var flxDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Border9797971pxRadius3px",
                "top": "5dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisclaimer.setDefaultUnit(kony.flex.DP);
            var rtxDisclaimer = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>"
                },
                "bottom": "2dp",
                "id": "rtxDisclaimer",
                "isVisible": true,
                "left": "1%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>",
                "top": "10px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisclaimer.add(rtxDisclaimer);
            var btnBackBottom = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Back"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50px",
                "id": "btnBackBottom",
                "isVisible": false,
                "left": "79dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "40dp",
                "width": "14.60%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Kony Bank Pvt. Ltd. Copyright 2017. All rightes reserved."
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Page 1 of 1"
                },
                "id": "lblPage",
                "isVisible": false,
                "right": "0%",
                "skin": "sknlbl424242bold15px",
                "text": "Page 1 of 1",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight, lblPage);
            flxprintTransactions.add(flxHeader, btnBack, lblMyCheckingAccount, flxCheckingAccountSummary, lblTransactionsFrom, flxPendingTransactions, flxPostedTransactions, flxDisclaimer, btnBackBottom, flxBottom);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxprintTransactions": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxprintTransactions": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxprintTransactions": {
                        "width": {
                            "type": "string",
                            "value": "1250px"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "keyValueAccHolderName.lblValue": {
                    "text": "John Bailey"
                },
                "keyValueAccHolderName": {
                    "top": "70dp",
                    "width": "50%"
                },
                "keyValueAccNumber.lblValue": {
                    "text": "xxxx xxxx xxxx 3456"
                },
                "keyValueAccNumber": {
                    "top": "100dp",
                    "width": "50%"
                },
                "keyValueBank.lblValue": {
                    "text": "Kony Bank"
                },
                "keyValueBank": {
                    "top": "130dp",
                    "width": "50%"
                },
                "keyValueBranch.flxKey": {
                    "left": "5.08%",
                    "top": "0dp"
                },
                "keyValueBranch.lblValue": {
                    "text": "Austin Downtown"
                },
                "keyValueBranch": {
                    "top": "160dp",
                    "width": "50%"
                },
                "keyValueAvailableBalance.lblKey": {
                    "text": "Available Balance:"
                },
                "keyValueAvailableBalance.lblValue": {
                    "text": "$328.00"
                },
                "keyValueAvailableBalance": {
                    "left": "50%",
                    "top": "70dp",
                    "width": "50%"
                },
                "keyValueCurrentBalance.lblKey": {
                    "text": "Current Balance:"
                },
                "keyValueCurrentBalance.lblValue": {
                    "text": "$324.01"
                },
                "keyValueCurrentBalance": {
                    "left": "50%",
                    "top": "100dp",
                    "width": "50%"
                },
                "keyValuePendingDeposits.lblKey": {
                    "text": "Pending Deposits:"
                },
                "keyValuePendingDeposits.lblValue": {
                    "text": "+$100.00"
                },
                "keyValuePendingDeposits": {
                    "left": "50%",
                    "top": "130dp",
                    "width": "50%"
                },
                "keyValuePendingWithdrawal.lblKey": {
                    "text": "Pending Withdrawals:"
                },
                "keyValuePendingWithdrawal.lblValue": {
                    "text": "-$100.00"
                },
                "keyValuePendingWithdrawal": {
                    "left": "50%",
                    "top": "160dp",
                    "width": "50%"
                }
            }
            this.add(flxprintTransactions);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintTransaction,
            "enabledForIdleTimeout": false,
            "id": "frmPrintTransaction",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_b73fe53964fc430490008be45ff22c8e,
            "preShow": function(eventobject) {
                controller.AS_Form_aa9408ee7696468a9ebd691556fcaf30(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});