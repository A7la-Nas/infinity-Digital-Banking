define("SBAdvisoryMA/AcIntelligenceDashboardUIModule/frmReceivablePayableProbability", function() {
    return function(controller) {
        function addWidgetsfrmReceivablePayableProbability() {
            this.setDefaultUnit(kony.flex.DP);
            var flxchart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "220dp",
                "id": "flxchart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "50%",
                "appName": "SBAdvisoryMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxchart.setDefaultUnit(kony.flex.DP);
            var MultiLineChart = new com.SBAdvisory.AID.MultiLineChart({
                "centerX": "50%",
                "height": "100%",
                "id": "MultiLineChart",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "SBAdvisoryMA",
                "viewType": "MultiLineChart",
                "overrides": {
                    "MultiLineChart": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var MultiLineChart_data = (appConfig.componentMetadata && appConfig.componentMetadata["SBAdvisoryMA"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmReceivablePayableProbability"] && appConfig.componentMetadata["SBAdvisoryMA"]["frmReceivablePayableProbability"]["MultiLineChart"]) || {};
            flxchart.add(MultiLineChart);
            this.compInstData = {
                "MultiLineChart": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                }
            }
            this.add(flxchart);
        };
        return [{
            "addWidgets": addWidgetsfrmReceivablePayableProbability,
            "enabledForIdleTimeout": false,
            "id": "frmReceivablePayableProbability",
            "init": controller.AS_Form_f51b2367e85446ca8c324b31f2bbf15d,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "SBAdvisoryMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});