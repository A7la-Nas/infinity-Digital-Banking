define("ConsentMgmtMA/DummyLogin/frmDummyLogin", function() {
    return function(controller) {
        function addWidgetsfrmDummyLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxLogin = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ConsentMgmtMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogin.setDefaultUnit(kony.flex.DP);
            var btnPSD2Consent = new kony.ui.Button({
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnPSD2Consent",
                "isVisible": true,
                "left": "0",
                "onClick": controller.AS_Button_c8681d058b174104bab2e86d025e24b4,
                "skin": "defBtnNormal",
                "text": "PSD2 Consent",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCDPConsent = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnCDPConsent",
                "isVisible": true,
                "left": "0",
                "onClick": controller.AS_Button_dc9f2a1b25574d19a464b42e5ce5784b,
                "skin": "defBtnNormal",
                "text": "CDP Consent",
                "top": "25%",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogin.add(btnPSD2Consent, btnCDPConsent);
            this.compInstData = {}
            this.add(flxLogin);
        };
        return [{
            "addWidgets": addWidgetsfrmDummyLogin,
            "enabledForIdleTimeout": false,
            "id": "frmDummyLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_h2d15769d3444974a6afecfe1223b127(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ConsentMgmtMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});