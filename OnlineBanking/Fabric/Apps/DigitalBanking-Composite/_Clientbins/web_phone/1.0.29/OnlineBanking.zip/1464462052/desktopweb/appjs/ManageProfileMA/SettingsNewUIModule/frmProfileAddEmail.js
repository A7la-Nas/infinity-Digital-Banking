define("ManageProfileMA/SettingsNewUIModule/frmProfileAddEmail", function() {
    return function(controller) {
        function addWidgetsfrmProfileAddEmail() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Settings",
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "We could not find an exact match. Please enter your payee information as it appears on your bill."
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Dropdown",
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    },
                    "profileMenu": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxProfile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxProfile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfile.setDefaultUnit(kony.flex.DP);
            var flxAddNewEmailWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddNewEmailWrapper",
                "isVisible": false,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddNewEmailWrapper.setDefaultUnit(kony.flex.DP);
            var flxAddNewEmailHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAddNewEmailHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewEmailHeader.setDefaultUnit(kony.flex.DP);
            var flxAddNewEmailSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAddNewEmailSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewEmailSeperator.setDefaultUnit(kony.flex.DP);
            flxAddNewEmailSeperator.add();
            var lblAddNewEmailHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAddNewEmailHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddNewEmailHeader.add(flxAddNewEmailSeperator, lblAddNewEmailHeading);
            var flxAddNewEmailContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "635dp",
                "id": "flxAddNewEmailContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewEmailContainer.setDefaultUnit(kony.flex.DP);
            var flxErrorAddNewEmail = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorAddNewEmail",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorAddNewEmail.setDefaultUnit(kony.flex.DP);
            var CopyimgError0b88b44e0c6bb47 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "CopyimgError0b88b44e0c6bb47",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblError0e8bfa78d5ffc48 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Page level/transaction level errors appear here.",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "CopylblError0e8bfa78d5ffc48",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "Page level/transaction level errors appear here.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorAddNewEmail.add(CopyimgError0b88b44e0c6bb47, CopylblError0e8bfa78d5ffc48);
            var flxNewEmailId = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNewEmailId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewEmailId.setDefaultUnit(kony.flex.DP);
            var FlexGroup0c602237726cd45 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexGroup0c602237726cd45",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 3,
                        "1366": 1,
                        "1380": 1
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0c602237726cd45.setDefaultUnit(kony.flex.DP);
            var rtxEmailId = new kony.ui.RichText({
                "id": "rtxEmailId",
                "isVisible": true,
                "left": "2.29%",
                "skin": "sknRtxSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profilemanagement.rtxEmailId\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexGroup0c602237726cd45.add(rtxEmailId);
            var FlexGroup0a97c8434184649 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "FlexGroup0a97c8434184649",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0a97c8434184649.setDefaultUnit(kony.flex.DP);
            var tbxEmailId = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "rtxEmailId",
                        "aria-required": true,
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEmailId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "19.72%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Profile.Enteremail\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "53.67%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "email"
            });
            FlexGroup0a97c8434184649.add(tbxEmailId);
            var flxMarkAsPrimaryEmail = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxMarkAsPrimaryEmail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "190dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarkAsPrimaryEmail.setDefaultUnit(kony.flex.DP);
            var flxMarkAsPrimaryEmailCheckbox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblMarkAsPrimaryEmail",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxMarkAsPrimaryEmailCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "19.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarkAsPrimaryEmailCheckbox.setDefaultUnit(kony.flex.DP);
            var lblMarkAsPrimaryEmailCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Checkbox"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblMarkAsPrimaryEmailCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "D",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMarkAsPrimaryEmailCheckbox.add(lblMarkAsPrimaryEmailCheckBox);
            var lblMarkAsPrimaryEmail = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMarkAsPrimaryEmail",
                "isVisible": true,
                "left": "24.25%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Mark for Alert Communication",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMarkAsPrimaryEmail.add(flxMarkAsPrimaryEmailCheckbox, lblMarkAsPrimaryEmail);
            var flxAnotherprimaryNumberExists = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAnotherprimaryNumberExists",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "19.70%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "120dp",
                "width": "600dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAnotherprimaryNumberExists.setDefaultUnit(kony.flex.DP);
            var imgPrimaryNumberexists = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "27dp",
                "id": "imgPrimaryNumberexists",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0px",
                "width": "27dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrimaryNumberexists = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblPrimaryNumberexists",
                "isVisible": true,
                "left": "8%",
                "skin": "sknLblSSP33333313px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.anotherEmail\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAnotherprimaryNumberExists.add(imgPrimaryNumberexists, lblPrimaryNumberexists);
            var flxAlertCommAddEmail = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxAlertCommAddEmail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "190dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommAddEmail.setDefaultUnit(kony.flex.DP);
            var flxMarkAsAlertCommEmailCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblMarkAsAlertCommEmailCheckBox",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxMarkAsAlertCommEmailCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "19.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarkAsAlertCommEmailCheckBox.setDefaultUnit(kony.flex.DP);
            var lblMarkAsAlertCommEmailCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Checkbox"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblMarkAsAlertCommEmailCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "D",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMarkAsAlertCommEmailCheckBox.add(lblMarkAsAlertCommEmailCheckBox);
            var lblMarkAsAlertCommEmail = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMarkAsAlertCommEmail",
                "isVisible": true,
                "left": "24.25%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Mark for Alert Communication",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertCommAddEmail.add(flxMarkAsAlertCommEmailCheckBox, lblMarkAsAlertCommEmail);
            flxNewEmailId.add(FlexGroup0c602237726cd45, FlexGroup0a97c8434184649, flxMarkAsPrimaryEmail, flxAnotherprimaryNumberExists, flxAlertCommAddEmail);
            var flxNewEmailIdButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80px",
                "id": "flxNewEmailIdButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "340dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewEmailIdButtons.setDefaultUnit(kony.flex.DP);
            var flxSeperator6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator6.setDefaultUnit(kony.flex.DP);
            flxSeperator6.add();
            var btnAddEmailIdAdd = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Add"
                },
                "height": "40dp",
                "id": "btnAddEmailIdAdd",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADD\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn3343a8Border3343a82pxRadius2pxhover"
            });
            var btnAddEmailIdCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel"
                },
                "height": "40dp",
                "id": "btnAddEmailIdCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxNewEmailIdButtons.add(flxSeperator6, btnAddEmailIdAdd, btnAddEmailIdCancel);
            flxAddNewEmailContainer.add(flxErrorAddNewEmail, flxNewEmailId, flxNewEmailIdButtons);
            flxAddNewEmailWrapper.add(flxAddNewEmailHeader, flxAddNewEmailContainer);
            flxProfile.add(flxAddNewEmailWrapper);
            flxRight.add(flxProfile);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Delete",
                    "tagName": "span"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Are you sure you want to Delete this Phone Number?",
                    "tagName": "span"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "No"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "No"
            });
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Yes"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Yes"
            });
            flxProfileDeleteButtons.add(btnDeletePopupNo, btnDeletePopupYes);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmProfileAddEmail": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "aria-expanded": false,
                                "role": "button",
                                "tabindex": 0
                            }
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.20%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailId": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEmailId": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmailCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsPrimaryEmail": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxAnotherprimaryNumberExists": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "imgPrimaryNumberexists": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "lblPrimaryNumberexists": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommAddEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMarkAsAlertCommEmailCheckBox": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsAlertCommEmail": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailIdButtons": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdAdd": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailId": {
                        "minHeight": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEmailId": {
                        "padding": [1, 0, 0, 0],
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "19.81%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90.19%"
                        },
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmailCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsPrimaryEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxAnotherprimaryNumberExists": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "imgPrimaryNumberexists": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "lblPrimaryNumberexists": {
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommAddEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsAlertCommEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailIdButtons": {
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailContainer": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailId": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "rtxEmailId": {
                        "i18n_text": "i18n.profilemanagement.rtxEmailId",
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "tbxEmailId": {
                        "padding": [1, 0, 0, 0],
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsPrimaryEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxAnotherprimaryNumberExists": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "imgPrimaryNumberexists": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "lblPrimaryNumberexists": {
                        "segmentProps": []
                    },
                    "flxAlertCommAddEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsAlertCommEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailIdButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdAdd": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdCancel": {
                        "right": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmProfileAddEmail": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewEmailContainer": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailId": {
                        "minHeight": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "rtxEmailId": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "tbxEmailId": {
                        "padding": [1, 0, 0, 0],
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "19.69%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "81.42%"
                        },
                        "segmentProps": []
                    },
                    "flxMarkAsPrimaryEmailCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsPrimaryEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAnotherprimaryNumberExists": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "imgPrimaryNumberexists": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "flxAlertCommAddEmail": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "segmentProps": []
                    },
                    "lblMarkAsAlertCommEmail": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewEmailIdButtons": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdAdd": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddEmailIdCancel": {
                        "right": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "profileMenu": {
                    "centerX": "",
                    "width": "100%"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmProfileAddEmail,
            "enabledForIdleTimeout": true,
            "id": "frmProfileAddEmail",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_e27b381be7714447bdbea877417db458(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewEmail\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});