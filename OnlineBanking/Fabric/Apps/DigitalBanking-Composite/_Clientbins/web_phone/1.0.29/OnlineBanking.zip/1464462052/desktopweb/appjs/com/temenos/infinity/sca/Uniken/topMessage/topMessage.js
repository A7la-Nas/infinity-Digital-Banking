define(function() {
    return function(controller) {
        var topMessage = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "topMessage",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0c5734eb3d47e47",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "topMessage"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "topMessage"), extendConfig({}, controller.args[2], "topMessage"));
        topMessage.setDefaultUnit(kony.flex.DP);
        var fontIconMsgType = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Close"
            },
            "id": "fontIconMsgType",
            "isVisible": true,
            "left": "20dp",
            "text": "J",
            "top": "15dp",
            "width": "50dp",
            "zIndex": 1
        }, controller.args[0], "fontIconMsgType"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "fontIconMsgType"), extendConfig({
            "toolTip": "Close"
        }, controller.args[2], "fontIconMsgType"));
        var flxMsgContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxMsgContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "90dp",
            "isModalContainer": false,
            "right": "55dp",
            "skin": "slFbox",
            "top": "0dp",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxMsgContainer"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxMsgContainer"), extendConfig({}, controller.args[2], "flxMsgContainer"));
        flxMsgContainer.setDefaultUnit(kony.flex.DP);
        var lblMsgHeader = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Page level/transaction level errors appear here."
            },
            "id": "lblMsgHeader",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknSSP42424224Px",
            "text": "Page level/transaction level errors appear here.",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblMsgHeader"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblMsgHeader"), extendConfig({}, controller.args[2], "lblMsgHeader"));
        var lblMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Page level/transaction level errors appear here."
            },
            "bottom": "20dp",
            "id": "lblMsg",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknSSP72727215Px",
            "text": "Page level/transaction level errors appear here.",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblMsg"), extendConfig({}, controller.args[2], "lblMsg"));
        flxMsgContainer.add(lblMsgHeader, lblMsg);
        var flxCloseMsg = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxCloseMsg",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": 20,
            "skin": "skncursor",
            "top": "20dp",
            "width": "20dp",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxCloseMsg"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxCloseMsg"), extendConfig({}, controller.args[2], "flxCloseMsg"));
        flxCloseMsg.setDefaultUnit(kony.flex.DP);
        var lblCloseMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "Close"
            },
            "id": "lblCloseMsg",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknOlbFonts0273e317px",
            "text": "g",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCloseMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCloseMsg"), extendConfig({
            "toolTip": "Close"
        }, controller.args[2], "lblCloseMsg"));
        flxCloseMsg.add(lblCloseMsg);
        topMessage.add(fontIconMsgType, flxMsgContainer, flxCloseMsg);
        topMessage.breakpointResetData = {};
        topMessage.breakpointData = {
            maxBreakpointWidth: 1366,
            "640": {
                "fontIconMsgType": {
                    "segmentProps": []
                },
                "lblCloseMsg": {
                    "segmentProps": []
                }
            },
            "1024": {
                "fontIconMsgType": {
                    "segmentProps": []
                },
                "lblCloseMsg": {
                    "segmentProps": []
                }
            }
        }
        topMessage.compInstData = {}
        return topMessage;
    }
})