define("ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmAddUsersVerifyController", ['CommonUtilities', 'FormControllerUtility', 'ViewConstants', 'OLBConstants', 'CampaignUtility'], function(CommonUtilities, FormControllerUtility, ViewConstants, OLBConstants, CampaignUtility) {
    var orientationHandler = new OrientationHandler();
    //Type your controller code here 
    return {
        preShow: function() {
            var scope = this;
            this.view.btnModifyRoles.onClick = function() {
                scope.navigateToAddUsers();
            }.bind(this);
            this.view.btnCancelRoles.onClick = function() {
                scope.navigateToAddUsers();
            }.bind(this);
            this.view.btnProceedRoles.onClick = function() {
                scope.navigateToAddUsersAck();
            }.bind(this);
            this.view.FilterSignatoryGroup.flxShowAllUsers.onClick = this.filterShow;
        },
        filterShow: function() {
            if (this.view.FilterSignatoryGroup.flxFilterGroup.isVisible) {
                this.view.FilterSignatoryGroup.flxFilterGroup.isVisible = false;
            } else {
                this.view.FilterSignatoryGroup.flxFilterGroup.isVisible = true;
            }
        },
        navigateToAddUsers: function() {
            applicationManager.getNavigationManager().navigateTo("frmAddUsers");
        },
        navigateToAddUsersAck: function() {
            applicationManager.getNavigationManager().navigateTo("frmViewManageSignatoryGroup");
        },
    };
});
define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAddUsersVerifyControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmAddUsersVerify **/
    AS_Form_ia0df1e544c64104ba50f52784235c56: function AS_Form_ia0df1e544c64104ba50f52784235c56(eventobject) {
        var self = this;
        return self.preShow.call(this);
    }
});
define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAddUsersVerifyController", ["ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmAddUsersVerifyController", "ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAddUsersVerifyControllerActions"], function() {
    var controller = require("ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmAddUsersVerifyController");
    var controllerActions = ["ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAddUsersVerifyControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
