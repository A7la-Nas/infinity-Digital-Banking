define("TradeFinanceMA/ExportLCUIModule/frmExportLCPendingAuth", function() {
    return function(controller) {
        function addWidgetsfrmExportLCPendingAuth() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "121dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003e75Bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "isVisible": true
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 85,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "141dp",
                "width": "1198dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblSubHeader = new kony.ui.Label({
                "id": "lblSubHeader",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Export LC - Drawing - D10011004",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "58.89%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1135dp",
                "isModalContainer": false,
                "right": 0,
                "top": "30dp",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var Dimage = new kony.ui.Image2({
                "height": "100%",
                "id": "Dimage",
                "isVisible": true,
                "left": "0dp",
                "right": 0,
                "src": "download_3x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(Dimage);
            var flxPrint = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "61.11%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPrint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1172dp",
                "isModalContainer": false,
                "right": "-9%",
                "top": "32dp",
                "width": "23dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrint.setDefaultUnit(kony.flex.DP);
            var imgPrint = new kony.ui.Image2({
                "height": "100%",
                "id": "imgPrint",
                "isVisible": true,
                "left": "0dp",
                "src": "print_blue.png",
                "top": 0,
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(imgPrint);
            flxSubHeader.add(lblSubHeader, flxDownload, flxPrint);
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "87.34%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummarylbl = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.setDefaultUnit(kony.flex.DP);
            var lcsummary = new kony.ui.Label({
                "id": "lcsummary",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.add(lcsummary);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var flxViewLCDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "75%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25%",
                "width": "23.95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetials = new kony.ui.Label({
                "height": "20dp",
                "id": "lblViewLCDetials",
                "isVisible": true,
                "left": "60%",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View LC Details",
                "top": "0dp",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.add(lblViewLCDetials);
            flxLCSummaryHeader.add(flxLCSummarylbl, flxBottomSeparator, flxViewLCDetails);
            var flxBodyContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "64.38%",
                "id": "flxBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32%",
                "width": "30.83%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContent.setDefaultUnit(kony.flex.DP);
            var flxContentLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "height": "18dp",
                "id": "lblApplicant",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "10px",
                "width": "374dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantName = new kony.ui.Label({
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "70dp",
                "skin": "ICSknLbl42424215PX",
                "text": " Katie Floyd",
                "top": "10px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel.add(lblApplicant, lblApplicantName);
            var flxContentLabel2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel2.setDefaultUnit(kony.flex.DP);
            var lblLCRefNo = new kony.ui.Label({
                "id": "lblLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Advising LC Ref No:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRightLCRefNo = new kony.ui.Label({
                "id": "lblRightLCRefNo",
                "isVisible": true,
                "left": "125dp",
                "skin": "ICSknLbl42424215PX",
                "text": "LC0000100001",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel2.add(lblLCRefNo, lblRightLCRefNo);
            var flxContentLabel3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel3.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeValue = new kony.ui.Label({
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknLbl42424215PX",
                "text": "sight",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel3.add(lblLCType, lblLCTypeValue);
            var flxContentLabel4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel4.setDefaultUnit(kony.flex.DP);
            var lblIssueBank = new kony.ui.Label({
                "id": "lblIssueBank",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.cardManage.issuingBank\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueBankValue = new kony.ui.Label({
                "id": "lblIssueBankValue",
                "isVisible": true,
                "left": "88dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Bank of America",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel4.add(lblIssueBank, lblIssueBankValue);
            flxBodyContent.add(flxContentLabel, flxContentLabel2, flxContentLabel3, flxContentLabel4);
            var flxBodyContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxBodyContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "421dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentRight.setDefaultUnit(kony.flex.DP);
            var flxContentRight1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight1.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCAmount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValue = new kony.ui.Label({
                "id": "lblLCAmountValue",
                "isVisible": true,
                "left": "76dp",
                "skin": "ICSknLbl42424215PX",
                "text": "$ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight1.add(lblLCAmount, lblLCAmountValue);
            var flxContentRight2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight2.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "id": "lblIssueDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.CM.issueDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateValue = new kony.ui.Label({
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "75dp",
                "skin": "ICSknLbl42424215PX",
                "text": "10/01/2021",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight2.add(lblIssueDate, lblIssueDateValue);
            var flxContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "76dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight.setDefaultUnit(kony.flex.DP);
            var lblIssueLCRefNo = new kony.ui.Label({
                "id": "lblIssueLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing LC Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingRefNoValue = new kony.ui.Label({
                "id": "lblIssuingRefNoValue",
                "isVisible": true,
                "left": "115dp",
                "skin": "ICSknLbl42424215PX",
                "text": "5678098765",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight.add(lblIssueLCRefNo, lblIssuingRefNoValue);
            flxBodyContentRight.add(flxContentRight1, flxContentRight2, flxContentRight);
            var flxBodyContentLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxBodyContentLast",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "816dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentLast.setDefaultUnit(kony.flex.DP);
            var flxContentLast1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast1.setDefaultUnit(kony.flex.DP);
            var lblLCUntilizedAmount = new kony.ui.Label({
                "id": "lblLCUntilizedAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Untilized Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCUntilizedAmountValue = new kony.ui.Label({
                "id": "lblLCUntilizedAmountValue",
                "isVisible": true,
                "left": "136dp",
                "skin": "ICSknLbl42424215PX",
                "text": " $ 2,567.87",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast1.add(lblLCUntilizedAmount, lblLCUntilizedAmountValue);
            var flxContentLast2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast2.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ExpiryDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "80dp",
                "skin": "ICSknLbl42424215PX",
                "text": "12/31/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast2.add(lblExpiryDate, lblExpiryDateValue);
            flxBodyContentLast.add(flxContentLast1, flxContentLast2);
            flxLCSummaryBody.add(flxLCSummaryHeader, flxBodyContent, flxBodyContentRight, flxBodyContentLast);
            var flxDrawingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "87.36%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxDrawingDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingDetails = new kony.ui.Label({
                "height": "33dp",
                "id": "lblDrawingDetails",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.DrawingDetails\")",
                "top": "0dp",
                "width": "102dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingDetailsDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxDrawingDetailsDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95.30%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDrawingDetailsDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.add(imgDrawingDetailsDropdown);
            flxDrawingDetailsHeader.add(lblDrawingDetails, flxDrawingDetailsDropdown);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "500dp",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDrawingStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.setDefaultUnit(kony.flex.DP);
            var labela = new kony.ui.Label({
                "id": "labela",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Drawing Status:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelb = new kony.ui.Label({
                "id": "labelb",
                "isVisible": true,
                "left": "300px",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Pending Cust Auth",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.add(labela, labelb);
            var flxDrawingRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingRef",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingRef.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefKey = new kony.ui.Label({
                "id": "lblDrawingRefKey",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Drawing Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefvalue = new kony.ui.Label({
                "id": "lblDrawingRefvalue",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "D10011004",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingRef.add(lblDrawingRefKey, lblDrawingRefvalue);
            var flxDrawingCreate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingCreate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingCreate.setDefaultUnit(kony.flex.DP);
            var labele = new kony.ui.Label({
                "id": "labele",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Drawing Created Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelf = new kony.ui.Label({
                "id": "labelf",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "05/05/2021",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingCreate.add(labele, labelf);
            var lblDrawingAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "lblDrawingAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            lblDrawingAmount.setDefaultUnit(kony.flex.DP);
            var labelg = new kony.ui.Label({
                "id": "labelg",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DrawingAmount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelh = new kony.ui.Label({
                "id": "labelh",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "$ 1,567.99",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            lblDrawingAmount.add(labelg, labelh);
            var Flex15 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex15",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "130px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex15.setDefaultUnit(kony.flex.DP);
            var labeli = new kony.ui.Label({
                "id": "labeli",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Amounttobedebitedfrom\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelj = new kony.ui.Label({
                "id": "labelj",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Assignment of Proceeds(Other beneficiary name or internal/external acc)",
                "top": "0",
                "width": "280dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex15.add(labeli, labelj);
            var Flex16 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex16",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "180px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex16.setDefaultUnit(kony.flex.DP);
            var labelk = new kony.ui.Label({
                "id": "labelk",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Finance us:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labell = new kony.ui.Label({
                "id": "labell",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Selected. Please Finance us for the draft amount by negotiation with full recourse to us.",
                "top": "0",
                "width": "260dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex16.add(labelk, labell);
            var Flex17 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex17",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "250px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex17.setDefaultUnit(kony.flex.DP);
            var labelm = new kony.ui.Label({
                "id": "labelm",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Uploaded Documents:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labeln = new kony.ui.Label({
                "id": "labeln",
                "isVisible": true,
                "left": "254%",
                "skin": "ICSknLbl42424215PX",
                "text": "Document1.zip",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelo = new kony.ui.Label({
                "id": "labelo",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Clearance Statement.pdf",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex17.add(labelm, labeln, labelo);
            var Flex18 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex18",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "300px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex18.setDefaultUnit(kony.flex.DP);
            var labelp = new kony.ui.Label({
                "id": "labelp",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Physical Document Details:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelr = new kony.ui.Label({
                "id": "labelr",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Bill of Lading  (Will not submit, Will not submit)",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelq = new kony.ui.Label({
                "id": "labelq",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Invoices   (2 Originals, 3 Copies)",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex18.add(labelp, labelr, labelq);
            var Flex19 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex19",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "360px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex19.setDefaultUnit(kony.flex.DP);
            var labels = new kony.ui.Label({
                "id": "labels",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Forward despite any discrepancies:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelT = new kony.ui.Label({
                "id": "labelT",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Selected(Kindly forward documents to issuing bank as presented despite any discrepancy(ies) noted)",
                "top": "0",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex19.add(labels, labelT);
            var Flex20 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex20",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "430px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex20.setDefaultUnit(kony.flex.DP);
            var labelU = new kony.ui.Label({
                "id": "labelU",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Charges Debit Account:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelV = new kony.ui.Label({
                "id": "labelV",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "Company’s Checking Acc…3241",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex20.add(labelU, labelV);
            var Flex21 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "Flex21",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "460px",
                "width": "10%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            Flex21.setDefaultUnit(kony.flex.DP);
            var labelW = new kony.ui.Label({
                "id": "labelW",
                "isVisible": true,
                "left": "20px",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBank\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var labelX = new kony.ui.Label({
                "id": "labelX",
                "isVisible": true,
                "left": "300px",
                "skin": "ICSknLbl42424215PX",
                "text": "First batch goods shipped, bills attached",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            Flex21.add(labelW, labelX);
            flxMain.add(flxDrawingStatus, flxDrawingRef, flxDrawingCreate, lblDrawingAmount, Flex15, Flex16, Flex17, Flex18, Flex19, Flex20, Flex21);
            flxDrawingDetails.add(flxDrawingDetailsHeader, flxSeparator, flxMain);
            var FlexApproval = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "550dp",
                "id": "FlexApproval",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7%",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow",
                "top": "30px",
                "width": "1202dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApproval.setDefaultUnit(kony.flex.DP);
            var ApprovalDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "ApprovalDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            ApprovalDetails.setDefaultUnit(kony.flex.DP);
            var FlexSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "FlexSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "35dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexSeperator.setDefaultUnit(kony.flex.DP);
            FlexSeperator.add();
            var flexright = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "19dp",
                "id": "flexright",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "130%",
                "width": "110dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flexright.setDefaultUnit(kony.flex.DP);
            var lblApprovalStatus = new kony.ui.Label({
                "id": "lblApprovalStatus",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ApprovalStatus\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApproved = new kony.ui.Label({
                "id": "lblApproved",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl727272SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "top": "230%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRejected = new kony.ui.Label({
                "id": "lblRejected",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Search.Rejected\")",
                "top": "430%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPending = new kony.ui.Label({
                "id": "lblPending",
                "isVisible": true,
                "left": "278dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Pending",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValue = new kony.ui.Label({
                "id": "lblValue",
                "isVisible": true,
                "left": "278dp",
                "skin": "sknLblSSPSB42424215Px",
                "text": "1",
                "top": "230%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblvalue0 = new kony.ui.Label({
                "id": "lblvalue0",
                "isVisible": true,
                "left": "278dp",
                "skin": "sknLblSSPSB42424215Px",
                "text": "0",
                "top": "430%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReject = new kony.ui.Label({
                "id": "lblReject",
                "isVisible": false,
                "left": "10px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblpackages = new kony.ui.Label({
                "id": "lblpackages",
                "isVisible": false,
                "left": "200%",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexright.add(lblApprovalStatus, lblApproved, lblRejected, lblPending, lblValue, lblvalue0, lblReject, lblpackages);
            var ApprovalInformation = new kony.ui.Label({
                "id": "ApprovalInformation",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Approval Information",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var BtnEdit = new kony.ui.Button({
                "height": "50dp",
                "id": "BtnEdit",
                "isVisible": false,
                "left": "1000px",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "Button",
                "top": "435px",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            ApprovalDetails.add(FlexSeperator, flexright, ApprovalInformation, BtnEdit);
            var Back = new kony.ui.Button({
                "height": "50dp",
                "id": "Back",
                "isVisible": true,
                "left": "640px",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Back",
                "top": "460px",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Approve = new kony.ui.Button({
                "height": "50dp",
                "id": "Approve",
                "isVisible": true,
                "left": "83%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "Back",
                "top": "460px",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var WithDraw = new kony.ui.Button({
                "height": "50dp",
                "id": "WithDraw",
                "isVisible": true,
                "left": "820px",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Button",
                "top": "460px",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Reject = new kony.ui.Button({
                "height": "50dp",
                "id": "Reject",
                "isVisible": true,
                "left": "820px",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Button",
                "top": "460px",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApproval = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxApproval",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "220px",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApproval.setDefaultUnit(kony.flex.DP);
            var FlxApprovalInformaton = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "FlxApprovalInformaton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxApprovalInformaton.setDefaultUnit(kony.flex.DP);
            var FlxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "FlxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxSeperator.setDefaultUnit(kony.flex.DP);
            FlxSeperator.add();
            var FlxApprovalAdvice = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48dp",
                "id": "FlxApprovalAdvice",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxApprovalAdvice.setDefaultUnit(kony.flex.DP);
            var FlexApprovalAdvice1 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "FlexApprovalAdvice1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "42dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "29dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice1.setDefaultUnit(kony.flex.DP);
            var lblNameUser = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNameUser",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "User",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice1.add(lblNameUser);
            var FlexApprovalAdvice2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "FlexApprovalAdvice2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "279dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "103dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice2.setDefaultUnit(kony.flex.DP);
            var lblSignatoryGroup = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblSignatoryGroup",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Signatory Group",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice2.add(lblSignatoryGroup);
            var FlexApprovalAdvice3 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "FlexApprovalAdvice3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "519dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice3.setDefaultUnit(kony.flex.DP);
            var lblStatus = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblStatus",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Status",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice3.add(lblStatus);
            var FlexApprovalAdvice4 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "FlexApprovalAdvice4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "716dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "77dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice4.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Date & Time",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice4.add(lblDate);
            var FlexApprovalAdvice5 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "18dp",
                "id": "FlexApprovalAdvice5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "941dp",
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "75dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice5.setDefaultUnit(kony.flex.DP);
            var lblComment = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblComment",
                "isVisible": true,
                "left": "0px",
                "skin": "ICSknLbl42424215PX",
                "text": "Comment",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApprovalAdvice5.add(lblComment);
            FlxApprovalAdvice.add(FlexApprovalAdvice1, FlexApprovalAdvice2, FlexApprovalAdvice3, FlexApprovalAdvice4, FlexApprovalAdvice5);
            var FlexBottomSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "FlexBottomSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexBottomSeperator1.setDefaultUnit(kony.flex.DP);
            FlexBottomSeperator1.add();
            FlxApprovalInformaton.add(FlxSeperator, FlxApprovalAdvice, FlexBottomSeperator1);
            var segApproval = new kony.ui.SegmentedUI2({
                "data": [{
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }, {
                    "lblUser1": "User",
                    "lblUser2": "Signatory Group",
                    "lblUser3": "Status",
                    "lblUser4": "Date & Time",
                    "lblUser5": "Comment  "
                }],
                "groupCells": false,
                "height": "120dp",
                "id": "segApproval",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxApprovalInformation"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "50dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "FlexMain": "FlexMain",
                    "flexSubDesign": "flexSubDesign",
                    "lblUser1": "lblUser1",
                    "lblUser2": "lblUser2",
                    "lblUser3": "lblUser3",
                    "lblUser4": "lblUser4",
                    "lblUser5": "lblUser5"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApproval.add(FlxApprovalInformaton, segApproval);
            var btnPending = new kony.ui.Button({
                "height": "50dp",
                "id": "btnPending",
                "isVisible": true,
                "left": "83%",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "Pending Approvers",
                "top": "90px",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexApproval.add(ApprovalDetails, Back, Approve, WithDraw, Reject, flxApproval, btnPending);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxFooterMenu": {
                        "left": "6.50%"
                    },
                    "lblCopyright": {
                        "left": "6.50%",
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxMainContainer.add(flxSubHeader, flxLCSummaryBody, flxDrawingDetails, FlexApproval, flxFooter);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.imgKonyHamburger": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Import LC",
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Dimage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lcsummary": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "FlexSeperator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "FlxApprovalInformaton": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "Dimage": {
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "segmentProps": []
                    },
                    "imgPrint": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "height": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "87.40%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetails": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23.95%"
                        },
                        "segmentProps": []
                    },
                    "lblViewLCDetials": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "30.38%"
                        },
                        "top": {
                            "type": "string",
                            "value": "12%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22.83%"
                        },
                        "segmentProps": []
                    },
                    "flxContentLabel": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblApplicant": {
                        "i18n_text": "i18n.ExportLC.Applicant",
                        "text": "Applicant:",
                        "segmentProps": []
                    },
                    "lblApplicantName": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxContentLabel2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "389dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCRefNo": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblRightLCRefNo": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxContentLabel3": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCType": {
                        "i18n_text": "i18n.ImportLC.LCType",
                        "segmentProps": []
                    },
                    "lblLCTypeValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "lblIssueBank": {
                        "i18n_text": "kony.mb.cardManage.issuingBank",
                        "segmentProps": []
                    },
                    "lblIssueBankValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxBodyContentRight": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentRight1": {
                        "left": {
                            "type": "string",
                            "value": "2px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "lblLCAmount": {
                        "i18n_text": "i18n.ExportLC.LCAmount",
                        "segmentProps": []
                    },
                    "lblLCAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxContentRight2": {
                        "left": {
                            "type": "string",
                            "value": "2px"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDate": {
                        "i18n_text": "kony.mb.CM.issueDate",
                        "segmentProps": []
                    },
                    "lblIssueDateValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxContentRight": {
                        "left": {
                            "type": "string",
                            "value": "2px"
                        },
                        "width": {
                            "type": "string",
                            "value": "374dp"
                        },
                        "segmentProps": []
                    },
                    "lblIssuingRefNoValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxBodyContentLast": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24%"
                        },
                        "segmentProps": []
                    },
                    "flxContentLast1": {
                        "left": {
                            "type": "string",
                            "value": "2px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "text": "LC Untilized Amount:",
                        "segmentProps": []
                    },
                    "lblLCUntilizedAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentLast2": {
                        "left": {
                            "type": "string",
                            "value": "2px"
                        },
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpiryDate": {
                        "i18n_text": "i18n.TradeFinance.ExpiryDate",
                        "segmentProps": []
                    },
                    "lblExpiryDateValue": {
                        "left": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "labele": {
                        "text": "Drawing Created Date:",
                        "segmentProps": []
                    },
                    "labelg": {
                        "i18n_text": "i18n.ImportDrawings.DrawingAmount",
                        "segmentProps": []
                    },
                    "labeli": {
                        "i18n_text": "i18n.TradeFinance.Amounttobedebitedfrom",
                        "segmentProps": []
                    },
                    "labell": {
                        "segmentProps": []
                    },
                    "labelm": {
                        "i18n_text": "kony.bb.user.Uploaded Documents:",
                        "text": "Uploaded Documents:",
                        "segmentProps": []
                    },
                    "labeln": {
                        "left": {
                            "type": "string",
                            "value": "340%"
                        },
                        "segmentProps": []
                    },
                    "labelp": {
                        "i18n_text": "konybb.user.Physical Document Details:",
                        "segmentProps": []
                    },
                    "labels": {
                        "i18n_text": "kony.bb.user.Forward despite any discrepancies:",
                        "segmentProps": []
                    },
                    "labelU": {
                        "i18n_text": "kony.bb.user.Charges Debit Account:",
                        "segmentProps": []
                    },
                    "labelW": {
                        "i18n_text": "i18n.TradeFinance.MessageToBank",
                        "segmentProps": []
                    },
                    "FlexApproval": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.30%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "i18n_text": "i18n.konybb.common.ApprovalStatus",
                        "segmentProps": []
                    },
                    "lblApproved": {
                        "i18n_text": "i18n.konybb.Common.Approved",
                        "segmentProps": []
                    },
                    "lblValue": {
                        "skin": "s34d3f1de57642eab0fb3e56b123451d",
                        "segmentProps": []
                    },
                    "lblvalue0": {
                        "skin": "s33673dceb2e4652bcc7ec6276b1209d",
                        "segmentProps": []
                    },
                    "lblReject": {
                        "skin": "ICSknSSPRegular727272op10015px",
                        "text": "Add all packing list",
                        "top": {
                            "type": "string",
                            "value": "120px"
                        },
                        "segmentProps": []
                    },
                    "lblpackages": {
                        "text": "Rejected Reason:",
                        "top": {
                            "type": "number",
                            "value": "120"
                        },
                        "segmentProps": []
                    },
                    "ApprovalInformation": {
                        "text": "Approval Information",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "BtnEdit": {
                        "isCustomLayout": false,
                        "text": "Edit & Re-submit",
                        "top": {
                            "type": "string",
                            "value": "451px"
                        },
                        "segmentProps": []
                    },
                    "Back": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF15Px",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Approve": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "text": "Approve",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "WithDraw": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Back",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Reject": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "text": "Reject",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxApproval": {
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNameUser": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice2": {
                        "left": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblSignatoryGroup": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice3": {
                        "left": {
                            "type": "string",
                            "value": "258dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice4": {
                        "left": {
                            "type": "string",
                            "value": "429dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "77dp"
                        },
                        "segmentProps": []
                    },
                    "lblDate": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice5": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "562dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "63dp"
                        },
                        "segmentProps": []
                    },
                    "lblComment": {
                        "segmentProps": []
                    },
                    "segApproval": {
                        "data": [{
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }, {
                            "lblUser1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "User"
                            },
                            "lblUser2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Signatory Group"
                            },
                            "lblUser3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Status"
                            },
                            "lblUser4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Date & Time"
                            },
                            "lblUser5": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Comment  "
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxApprovalTablet"
                        }),
                        "sectionHeaderTemplate": "",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "widgetDataMap": {
                            "flexSubDesign": "flexSubDesign",
                            "flxApprovalTablet": "flxApprovalTablet",
                            "lblUser1": "lblUser1",
                            "lblUser2": "lblUser2",
                            "lblUser3": "lblUser3",
                            "lblUser4": "lblUser4",
                            "lblUser5": "lblUser5"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "btnPending": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "text": "Pending Approvers",
                        "top": {
                            "type": "string",
                            "value": "90px"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "Dimage": {
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "segmentProps": []
                    },
                    "imgPrint": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "labell": {
                        "segmentProps": []
                    },
                    "labeln": {
                        "segmentProps": []
                    },
                    "labelo": {
                        "text": "Clearance Statement.pdf",
                        "segmentProps": []
                    },
                    "labelr": {
                        "segmentProps": []
                    },
                    "FlexApproval": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "FlexSeperator": {
                        "segmentProps": []
                    },
                    "lblPending": {
                        "segmentProps": []
                    },
                    "lblValue": {
                        "skin": "sa3717562eda4cb6a8308b8fb43334da",
                        "segmentProps": []
                    },
                    "lblvalue0": {
                        "skin": "s3a1d4e03b5f45f2aa976deee4c2f6ed",
                        "segmentProps": []
                    },
                    "lblReject": {
                        "skin": "sknSSPRegular727272op10015px",
                        "text": "Rejected Reason:",
                        "top": {
                            "type": "string",
                            "value": "110px"
                        },
                        "segmentProps": []
                    },
                    "lblpackages": {
                        "text": "Add all packing list",
                        "top": {
                            "type": "string",
                            "value": "110px"
                        },
                        "segmentProps": []
                    },
                    "BtnEdit": {
                        "text": "Edit & Re-submit",
                        "top": {
                            "type": "string",
                            "value": "453px"
                        },
                        "segmentProps": []
                    },
                    "Back": {
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Approve": {
                        "text": "Approve",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "WithDraw": {
                        "isVisible": false,
                        "skin": "s7fe42c9224c4167b38639cb70377071",
                        "text": "Withdraw",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Reject": {
                        "text": "Reject",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxApproval": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice1": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice2": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice3": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice4": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice5": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "Dimage": {
                        "segmentProps": []
                    },
                    "imgPrint": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "labell": {
                        "segmentProps": []
                    },
                    "labeln": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "FlexApproval": {
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblPending": {
                        "segmentProps": []
                    },
                    "lblValue": {
                        "skin": "s7f831faf99846a9a44d72829462f781",
                        "segmentProps": []
                    },
                    "lblvalue0": {
                        "skin": "s493e63c410a45d990a54489d38a0e23",
                        "segmentProps": []
                    },
                    "lblReject": {
                        "skin": "ICSknSSPRegular727272op10015px",
                        "text": "Rejected Reason:",
                        "top": {
                            "type": "string",
                            "value": "110px"
                        },
                        "segmentProps": []
                    },
                    "lblpackages": {
                        "text": "Add all packing list",
                        "top": {
                            "type": "string",
                            "value": "110px"
                        },
                        "width": {
                            "type": "string",
                            "value": "130px"
                        },
                        "segmentProps": []
                    },
                    "BtnEdit": {
                        "text": "Edit & Re-submit",
                        "top": {
                            "type": "string",
                            "value": "455px"
                        },
                        "segmentProps": []
                    },
                    "Back": {
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Approve": {
                        "text": "Approve",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "WithDraw": {
                        "isVisible": false,
                        "skin": "sfccf13adf604f5a8c55d3dc5280f186",
                        "text": "withdraw",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "Reject": {
                        "text": "Reject",
                        "top": {
                            "type": "string",
                            "value": "480px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxApproval": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice3": {
                        "segmentProps": []
                    },
                    "FlexApprovalAdvice4": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "customfooternew.flxFooterMenu": {
                    "left": "6.50%"
                },
                "customfooternew.lblCopyright": {
                    "left": "6.50%",
                    "top": "75dp"
                }
            }
            this.add(flxHeader, flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCPendingAuth,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCPendingAuth",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA",
            "preShow": function(eventobject) {
                controller.AS_Form_c81869a046db4c6fb6e4e71b3299755e(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});