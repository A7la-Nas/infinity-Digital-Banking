define("TradeFinanceMA/DashboardUIModule/frmDashboard", function() {
    return function(controller) {
        function addWidgetsfrmDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmDashboard"] && appConfig.componentMetadata["ResourcesMA"]["frmDashboard"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "Trade Finance Overview";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || {};
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "TradeFinance";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "Overview";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxReceivablePayablePopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxReceivablePayablePopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1500
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivablePayablePopup.setDefaultUnit(kony.flex.DP);
            var flxRPContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxRPContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "69%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPContainer.setDefaultUnit(kony.flex.DP);
            var flxRPHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxRPHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPHeader.setDefaultUnit(kony.flex.DP);
            var lblRPHeading = new kony.ui.Label({
                "id": "lblRPHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Receivables (USD $) ",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRPClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRPClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPClose.setDefaultUnit(kony.flex.DP);
            var lblRPClose = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblRPClose",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPClose.add(lblRPClose);
            flxRPHeader.add(lblRPHeading, flxRPClose);
            var flxSeparator9 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator9",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator9.setDefaultUnit(kony.flex.DP);
            flxSeparator9.add();
            var flxRPDateSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "78dp",
                "id": "flxRPDateSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "zIndex": 10,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPDateSummary.setDefaultUnit(kony.flex.DP);
            var flxRPCalendar = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRPCalendar",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "190dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPCalendar.setDefaultUnit(kony.flex.DP);
            var lblRPToday = new kony.ui.Label({
                "id": "lblRPToday",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Today\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calRPDate = new kony.ui.Calendar({
                "calendarIcon": "calender.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "height": "40dp",
                "hour": 0,
                "id": "calRPDate",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "placeholder": "MM/DD/YYYY",
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "25dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxRPCalendar.add(lblRPToday, calRPDate);
            var flxRPAmountSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRPAmountSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5.90%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "75%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPAmountSummary.setDefaultUnit(kony.flex.DP);
            var flxRPAmountSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRPAmountSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPAmountSummary1.setDefaultUnit(kony.flex.DP);
            var lblRPSummary1 = new kony.ui.Label({
                "id": "lblRPSummary1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.receivables\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPCount1 = new kony.ui.Label({
                "id": "lblRPCount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPAmount1 = new kony.ui.Label({
                "id": "lblRPAmount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPAmountSummary1.add(lblRPSummary1, lblRPCount1, lblRPAmount1);
            var flxHorizontalSeparator5 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHorizontalSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator5.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator5.add();
            var flxRPAmountSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRPAmountSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPAmountSummary2.setDefaultUnit(kony.flex.DP);
            var lblRPSummary2 = new kony.ui.Label({
                "id": "lblRPSummary2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Amount Received",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPCount2 = new kony.ui.Label({
                "id": "lblRPCount2",
                "isVisible": true,
                "left": "26%",
                "skin": "sknLbl04a615SSPReg20px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPAmount2 = new kony.ui.Label({
                "id": "lblRPAmount2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPAmountSummary2.add(lblRPSummary2, lblRPCount2, lblRPAmount2);
            flxRPAmountSummary.add(flxRPAmountSummary1, flxHorizontalSeparator5, flxRPAmountSummary2);
            flxRPDateSummary.add(flxRPCalendar, flxRPAmountSummary);
            var flxRPSearchAndFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRPSearchAndFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "96%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSearchAndFilter.setDefaultUnit(kony.flex.DP);
            var flxRPSearchAndFilterContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRPSearchAndFilterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSearchAndFilterContainer.setDefaultUnit(kony.flex.DP);
            var flxRPSearch = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSearch.setDefaultUnit(kony.flex.DP);
            var lblRPSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "25dp",
                "id": "lblRPSearchIcon",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "25dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRPSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "tbxRPSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "6%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.searchForTransactionRef\")",
                "right": "6%",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 10, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblRPSearchClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "lblRPSearchClearIcon",
                "isVisible": false,
                "right": "2%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSearch.add(lblRPSearchIcon, tbxRPSearch, lblRPSearchClearIcon);
            var flxRPFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRPFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPFilter.setDefaultUnit(kony.flex.DP);
            var lblRPView = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPView",
                "isVisible": true,
                "left": "6%",
                "skin": "bbSknLbl949494SSP15Px",
                "text": "View:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPSelectedFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSelectedFilter",
                "isVisible": true,
                "left": "25%",
                "skin": "ICSknLbl42424215PX",
                "text": "All",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPFilterDropdown = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblRPFilterDropdown",
                "isVisible": true,
                "right": "6%",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPFilter.add(lblRPView, lblRPSelectedFilter, lblRPFilterDropdown);
            var flxRPContextual = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRPContextual",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "1%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPContextual.setDefaultUnit(kony.flex.DP);
            var lblRPContextual = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblRPContextual",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPContextual.add(lblRPContextual);
            flxRPSearchAndFilterContainer.add(flxRPSearch, flxRPFilter, flxRPContextual);
            var flxRPFilterList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRPFilterList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "maxHeight": "480dp",
                "minHeight": "100dp",
                "isModalContainer": false,
                "right": "3%",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "40dp",
                "width": "37%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPFilterList.setDefaultUnit(kony.flex.DP);
            var flxRPFilters = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxRPFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "maxHeight": "480dp",
                "minHeight": "100dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxRPFilters.setDefaultUnit(kony.flex.DP);
            var segRPFilterList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segRPFilterList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxTempExportLCFilter1"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxGuaranteeReceivedDetailsHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPFilters.add(segRPFilterList);
            var flxRPFilterActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxRPFilterActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPFilterActions.setDefaultUnit(kony.flex.DP);
            var flxRPFilterSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxRPFilterSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPFilterSeparator.setDefaultUnit(kony.flex.DP);
            flxRPFilterSeparator.add();
            var btnRPFilterCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnRPFilterCancel",
                "isVisible": true,
                "left": "6%",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.tab.common.cancel\")",
                "width": "42%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnRPFilterApply = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnRPFilterApply",
                "isVisible": true,
                "right": "6%",
                "skin": "ICSknbtnEnabed003e7536px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")",
                "width": "42%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPFilterActions.add(flxRPFilterSeparator, btnRPFilterCancel, btnRPFilterApply);
            flxRPFilterList.add(flxRPFilters, flxRPFilterActions);
            var flxRPContextualList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "42dp",
                "id": "flxRPContextualList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "40dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPContextualList.setDefaultUnit(kony.flex.DP);
            var segRPContextualList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segRPContextualList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 15,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPContextualList.add(segRPContextualList);
            flxRPSearchAndFilter.add(flxRPSearchAndFilterContainer, flxRPFilterList, flxRPContextualList);
            var flxRPSortColumns = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRPSortColumns",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxbgf7f7f7op100Bordere3e3e3radius2px",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumns.setDefaultUnit(kony.flex.DP);
            var flxRPSortColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn1.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.product\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRPSortColumn1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn1",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn1.add(lblRPSortColumn1, imgRPSortColumn1);
            var flxRPSortColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn2.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Trans. Ref",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRPSortColumn2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn2",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn2.add(lblRPSortColumn2, imgRPSortColumn2);
            var flxRPSortColumn3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "13.5%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn3.setDefaultUnit(kony.flex.DP);
            var imgRPSortColumn3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn3",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPSortColumn3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn3.add(imgRPSortColumn3, lblRPSortColumn3);
            var flxRPSortColumn4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "11%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn4.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn4 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn4",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRPSortColumn4 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn4",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn4.add(lblRPSortColumn4, imgRPSortColumn4);
            var flxRPSortColumn5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "21%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn5.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn5 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn5",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.CreditAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRPSortColumn5 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn5",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn5.add(lblRPSortColumn5, imgRPSortColumn5);
            var flxRPSortColumn6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "12%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn6.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn6 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn6",
                "isVisible": true,
                "right": "18dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Avail Bal",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRPSortColumn6 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgRPSortColumn6",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "slImage",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn6.add(lblRPSortColumn6, imgRPSortColumn6);
            var flxRPSortColumn7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRPSortColumn7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "5.50%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPSortColumn7.setDefaultUnit(kony.flex.DP);
            var lblRPSortColumn7 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPSortColumn7",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Action\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPSortColumn7.add(lblRPSortColumn7);
            flxRPSortColumns.add(flxRPSortColumn1, flxRPSortColumn2, flxRPSortColumn3, flxRPSortColumn4, flxRPSortColumn5, flxRPSortColumn6, flxRPSortColumn7);
            var flxRPList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxRPList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPList.setDefaultUnit(kony.flex.DP);
            var segReceivablePayable = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segReceivablePayable",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxReceivablePayableList1"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPList.add(segReceivablePayable);
            var flxRPPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxRPPagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "160dp",
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPPagination.setDefaultUnit(kony.flex.DP);
            var RPPaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "RPPaginationContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRPPagination.add(RPPaginationContainer);
            var flxRPNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "flxRPNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRPNoRecords.setDefaultUnit(kony.flex.DP);
            var imgRPNoRecords = new kony.ui.Image2({
                "centerY": "50%",
                "height": "35dp",
                "id": "imgRPNoRecords",
                "isVisible": true,
                "left": "2%",
                "src": "info_grey.png",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRPNoRecords = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRPNoRecords",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.NoRecordErrMsg\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRPNoRecords.add(imgRPNoRecords, lblRPNoRecords);
            flxRPContainer.add(flxRPHeader, flxSeparator9, flxRPDateSummary, flxRPSearchAndFilter, flxRPSortColumns, flxRPList, flxRPPagination, flxRPNoRecords);
            flxReceivablePayablePopup.add(flxRPContainer);
            var flxNAListingPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxNAListingPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1500
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListingPopup.setDefaultUnit(kony.flex.DP);
            var flxNAListingContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNAListingContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "69%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListingContainer.setDefaultUnit(kony.flex.DP);
            var flxNAListingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxNAListingHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListingHeader.setDefaultUnit(kony.flex.DP);
            var lblNAListingHeading = new kony.ui.Label({
                "id": "lblNAListingHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Need Attention Value",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNAListingClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxNAListingClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListingClose.setDefaultUnit(kony.flex.DP);
            var lblNAListingClose = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblNAListingClose",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNAListingClose.add(lblNAListingClose);
            flxNAListingHeader.add(lblNAListingHeading, flxNAListingClose);
            var flxSeparator11 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator11",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator11.setDefaultUnit(kony.flex.DP);
            flxSeparator11.add();
            var flxNASearchAndFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxNASearchAndFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "96%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASearchAndFilter.setDefaultUnit(kony.flex.DP);
            var flxNASearchContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxNASearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASearchContainer.setDefaultUnit(kony.flex.DP);
            var flxNASearch = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "0dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASearch.setDefaultUnit(kony.flex.DP);
            var lblNASearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "25dp",
                "id": "lblNASearchIcon",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "25dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxNASearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "tbxNASearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "6%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.searchForTransactionRef\")",
                "right": "6%",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 10, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblNASearchClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "lblNASearchClearIcon",
                "isVisible": false,
                "right": "2%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNASearch.add(lblNASearchIcon, tbxNASearch, lblNASearchClearIcon);
            var flxNAListingContextual = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxNAListingContextual",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "width": "1%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListingContextual.setDefaultUnit(kony.flex.DP);
            var lblNAListingContextual = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblNAListingContextual",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNAListingContextual.add(lblNAListingContextual);
            flxNASearchContainer.add(flxNASearch, flxNAListingContextual);
            var flxNAContextualList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "42dp",
                "id": "flxNAContextualList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "40dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAContextualList.setDefaultUnit(kony.flex.DP);
            var segNAContextualList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segNAContextualList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 15,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNAContextualList.add(segNAContextualList);
            flxNASearchAndFilter.add(flxNASearchContainer, flxNAContextualList);
            var flxNASortColumns = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxNASortColumns",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxbgf7f7f7op100Bordere3e3e3radius2px",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumns.setDefaultUnit(kony.flex.DP);
            var flxNASortColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASortColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33.70%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumn1.setDefaultUnit(kony.flex.DP);
            var lblNASortColumn1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "05/30/2017"
                },
                "centerY": "50%",
                "id": "lblNASortColumn1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.product\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            var imgNASortColumn1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgNASortColumn1",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNASortColumn1.add(lblNASortColumn1, imgNASortColumn1);
            var flxNASortColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASortColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "19.20%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumn2.setDefaultUnit(kony.flex.DP);
            var lblNASortColumn2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "05/30/2017"
                },
                "centerY": "50%",
                "id": "lblNASortColumn2",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.transDotRef\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            var imgNASortColumn2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgNASortColumn2",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNASortColumn2.add(lblNASortColumn2, imgNASortColumn2);
            var flxNASortColumn3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASortColumn3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumn3.setDefaultUnit(kony.flex.DP);
            var lblNASortColumn3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "05/30/2017"
                },
                "centerY": "50%",
                "id": "lblNASortColumn3",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.updatedOn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            var imgNASortColumn3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgNASortColumn3",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNASortColumn3.add(lblNASortColumn3, imgNASortColumn3);
            var flxNASortColumn4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASortColumn4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "16%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumn4.setDefaultUnit(kony.flex.DP);
            var imgNASortColumn4 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "TransactionType sorting"
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgNASortColumn4",
                "imageWhenFailed": "sorting_next.png",
                "imageWhileDownloading": "sorting_next.png",
                "isVisible": true,
                "left": "5dp",
                "src": "sortingfinal.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNASortColumn4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "05/30/2017"
                },
                "centerY": "50%",
                "id": "lblNASortColumn4",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            flxNASortColumn4.add(imgNASortColumn4, lblNASortColumn4);
            var flxNASortColumn5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNASortColumn5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10.70%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNASortColumn5.setDefaultUnit(kony.flex.DP);
            var lblNASortColumn5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "05/30/2017"
                },
                "centerY": "50%",
                "id": "lblNASortColumn5",
                "isVisible": true,
                "right": "15%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Action\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            flxNASortColumn5.add(lblNASortColumn5);
            flxNASortColumns.add(flxNASortColumn1, flxNASortColumn2, flxNASortColumn3, flxNASortColumn4, flxNASortColumn5);
            var flxNAListing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxNAListing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAListing.setDefaultUnit(kony.flex.DP);
            var segNAListing = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segNAListing",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxNeedAttentionListing"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNAListing.add(segNAListing);
            var flxNAPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxNAPagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "20dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNAPagination.setDefaultUnit(kony.flex.DP);
            var NAPaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NAPaginationContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxNAPagination.add(NAPaginationContainer);
            var flxNANoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "flxNANoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNANoRecords.setDefaultUnit(kony.flex.DP);
            var imgNANoRecords = new kony.ui.Image2({
                "centerY": "50%",
                "height": "35dp",
                "id": "imgNANoRecords",
                "isVisible": true,
                "left": "2%",
                "src": "info_grey.png",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNANoRecords = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNANoRecords",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.NoRecordErrMsg\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNANoRecords.add(imgNANoRecords, lblNANoRecords);
            flxNAListingContainer.add(flxNAListingHeader, flxSeparator11, flxNASearchAndFilter, flxNASortColumns, flxNAListing, flxNAPagination, flxNANoRecords);
            flxNAListingPopup.add(flxNAListingContainer);
            formTemplate12.flxContentPopup.add(flxReceivablePayablePopup, flxNAListingPopup);
            var flxDashboardHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDashboardHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboardHeader.setDefaultUnit(kony.flex.DP);
            var flxWidgetsCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxWidgetsCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWidgetsCurrency.setDefaultUnit(kony.flex.DP);
            var lblWidgetCurrencyHeading = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblWidgetCurrencyHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.allWidgetsAreRepresentFor\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "120dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrency.setDefaultUnit(kony.flex.DP);
            var flxCurrencyDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCurrencyDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Border",
                "top": "0dp",
                "width": "46.40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyDropdown.setDefaultUnit(kony.flex.DP);
            var lblSelectedCurrency = new kony.ui.Label({
                "id": "lblSelectedCurrency",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": 9,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrencyDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCurrencyDropdownIcon",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "top": "0",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrencyDropdown.add(lblSelectedCurrency, lblCurrencyDropdownIcon);
            var flxCurrencyList = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxCurrencyList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "40dp",
                "verticalScrollIndicator": true,
                "width": "46.40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyList.setDefaultUnit(kony.flex.DP);
            var segCurrency = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segCurrency",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrencyList.add(segCurrency);
            flxCurrency.add(flxCurrencyDropdown, flxCurrencyList);
            flxWidgetsCurrency.add(lblWidgetCurrencyHeading, flxCurrency);
            var flxRefreshAndQuickLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRefreshAndQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRefreshAndQuickLinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinks.setDefaultUnit(kony.flex.DP);
            var lblQuickLinksDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblQuickLinksDropdownIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblQuickLinks = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblQuickLinks",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.quickLinks\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLinks.add(lblQuickLinksDropdownIcon, lblQuickLinks);
            var flxRefresh = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRefresh",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRefresh.setDefaultUnit(kony.flex.DP);
            var lblRefreshIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblRefreshIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "skn0273e320pxolbfonticons",
                "text": "W",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRefreshedTime = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRefreshedTime",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRefresh.add(lblRefreshIcon, lblRefreshedTime);
            flxRefreshAndQuickLinks.add(flxQuickLinks, flxRefresh);
            var flxQuickLinksContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxQuickLinksContent",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "35dp",
                "width": "24%",
                "zIndex": 15,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksContent.setDefaultUnit(kony.flex.DP);
            var flxSegQuickLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegQuickLinks.setDefaultUnit(kony.flex.DP);
            var segQuickLinks = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segQuickLinks",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxClausesDescription"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegQuickLinks.add(segQuickLinks);
            var flxSeparator15 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator15",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator15.setDefaultUnit(kony.flex.DP);
            flxSeparator15.add();
            var flxQLAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxQLAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQLAction.setDefaultUnit(kony.flex.DP);
            var btnEditLinks = new kony.ui.Button({
                "centerY": "50%",
                "height": "20dp",
                "id": "btnEditLinks",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.editLinks\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Edit Links"
            });
            flxQLAction.add(btnEditLinks);
            flxQuickLinksContent.add(flxSegQuickLinks, flxSeparator15, flxQLAction);
            var flxContextualQL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContextualQL",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "35dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualQL.setDefaultUnit(kony.flex.DP);
            var flxContextualHeaderQL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxContextualHeaderQL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualHeaderQL.setDefaultUnit(kony.flex.DP);
            var lblChooseLink = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblChooseLink",
                "isVisible": true,
                "left": "5%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.chooseYourPreferredLinks\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnResetQL = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnResetQL",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.reset\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Reset"
            });
            flxContextualHeaderQL.add(lblChooseLink, btnResetQL);
            var flxSegContextualQL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegContextualQL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegContextualQL.setDefaultUnit(kony.flex.DP);
            var segContextualQL = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segContextualQL",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxTempExportLCFilter1"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxGuaranteeReceivedDetailsHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegContextualQL.add(segContextualQL);
            var flxSeparator13 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator13",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator13.setDefaultUnit(kony.flex.DP);
            flxSeparator13.add();
            var flxContextualActionsQL = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxContextualActionsQL",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualActionsQL.setDefaultUnit(kony.flex.DP);
            var btnApplyQL = new kony.ui.Button({
                "centerY": "50%",
                "height": "50%",
                "id": "btnApplyQL",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.datePicker.apply\")",
                "top": "0dp",
                "width": "42%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Apply"
            });
            var btnCancelQL = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnCancelQL",
                "isVisible": true,
                "right": "18%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.nuo.Cancel\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxContextualActionsQL.add(btnApplyQL, btnCancelQL);
            flxContextualQL.add(flxContextualHeaderQL, flxSegContextualQL, flxSeparator13, flxContextualActionsQL);
            flxDashboardHeader.add(flxWidgetsCurrency, flxRefreshAndQuickLinks, flxQuickLinksContent, flxContextualQL);
            var flxDashboardData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDashboardData",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboardData.setDefaultUnit(kony.flex.DP);
            var flxAmountReceivables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "425dp",
                "id": "flxAmountReceivables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "66.25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountReceivables.setDefaultUnit(kony.flex.DP);
            var flxLoadingReceivables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingReceivables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingReceivables.setDefaultUnit(kony.flex.DP);
            var imgLoadingReceivables = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingReceivables",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingReceivables.add(imgLoadingReceivables);
            var flxReceivables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivables",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivables.setDefaultUnit(kony.flex.DP);
            var flxAmountReceivablesHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAmountReceivablesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountReceivablesHeader.setDefaultUnit(kony.flex.DP);
            var flxAmountReceivablesHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountReceivablesHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountReceivablesHeading.setDefaultUnit(kony.flex.DP);
            var lblAmountReceivablesHeading = new kony.ui.Label({
                "id": "lblAmountReceivablesHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.amountReceivables\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountReceivablesHeading.add(lblAmountReceivablesHeading);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxViewReceivables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewReceivables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewReceivables.setDefaultUnit(kony.flex.DP);
            var btnViewReceivables = new kony.ui.Button({
                "id": "btnViewReceivables",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.viewReceivables\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View Receivables"
            });
            flxViewReceivables.add(btnViewReceivables);
            flxAmountReceivablesHeader.add(flxAmountReceivablesHeading, flxSeparator1, flxViewReceivables);
            var flxAmountReceivablesSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "78dp",
                "id": "flxAmountReceivablesSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountReceivablesSummary.setDefaultUnit(kony.flex.DP);
            var flxReceivableSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableSummary1.setDefaultUnit(kony.flex.DP);
            var lblReceivableSummary1 = new kony.ui.Label({
                "id": "lblReceivableSummary1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.todaysReceivables\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableCount1 = new kony.ui.Label({
                "id": "lblReceivableCount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableAmount1 = new kony.ui.Label({
                "id": "lblReceivableAmount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableSummary1.add(lblReceivableSummary1, lblReceivableCount1, lblReceivableAmount1);
            var flxHorizontalSeparator1 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHorizontalSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator1.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator1.add();
            var flxReceivableSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableSummary2.setDefaultUnit(kony.flex.DP);
            var lblReceivableSummary2 = new kony.ui.Label({
                "id": "lblReceivableSummary2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AmountReceived\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableCount2 = new kony.ui.Label({
                "id": "lblReceivableCount2",
                "isVisible": true,
                "left": "26%",
                "skin": "sknLbl04a615SSPReg20px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableAmount2 = new kony.ui.Label({
                "id": "lblReceivableAmount2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableSummary2.add(lblReceivableSummary2, lblReceivableCount2, lblReceivableAmount2);
            var flxHorizontalSeparator2 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHorizontalSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator2.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator2.add();
            var flxReceivableSummary3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableSummary3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableSummary3.setDefaultUnit(kony.flex.DP);
            var lblReceivableSummary3 = new kony.ui.Label({
                "id": "lblReceivableSummary3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.overdues\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableCount3 = new kony.ui.Label({
                "id": "lblReceivableCount3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknLblFF000020px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableAmount3 = new kony.ui.Label({
                "id": "lblReceivableAmount3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableSummary3.add(lblReceivableSummary3, lblReceivableCount3, lblReceivableAmount3);
            flxAmountReceivablesSummary.add(flxReceivableSummary1, flxHorizontalSeparator1, flxReceivableSummary2, flxHorizontalSeparator2, flxReceivableSummary3);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxReceivableGraphHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxReceivableGraphHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableGraphHeader.setDefaultUnit(kony.flex.DP);
            var flxReceivableTypes = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableTypes.setDefaultUnit(kony.flex.DP);
            var flxReceivableType1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableType1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableType1.setDefaultUnit(kony.flex.DP);
            var lblReceivableType1Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblReceivableType1Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblc6d6e4OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableType1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblReceivableType1",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Drawings\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableType1.add(lblReceivableType1Icon, lblReceivableType1);
            var flxReceivableType2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableType2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableType2.setDefaultUnit(kony.flex.DP);
            var lblReceivableType2Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblReceivableType2Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl83a6c4OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableType2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblReceivableType2",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.collections\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableType2.add(lblReceivableType2Icon, lblReceivableType2);
            var flxReceivableType3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableType3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableType3.setDefaultUnit(kony.flex.DP);
            var lblReceivableType3Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblReceivableType3Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl4176a4OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReceivableType3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblReceivableType3",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.claims\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableType3.add(lblReceivableType3Icon, lblReceivableType3);
            flxReceivableTypes.add(flxReceivableType1, flxReceivableType2, flxReceivableType3);
            var flxReceivableGraphFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableGraphFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "160dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableGraphFilter.setDefaultUnit(kony.flex.DP);
            var flxReceivableGraphFilterDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxReceivableGraphFilterDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "130dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableGraphFilterDropdown.setDefaultUnit(kony.flex.DP);
            var lblReceivableGraphFilterDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblReceivableGraphFilterDropdownIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedReceivableGraphFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectedReceivableGraphFilter",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "Expiry in 7 Days",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableGraphFilterDropdown.add(lblReceivableGraphFilterDropdownIcon, lblSelectedReceivableGraphFilter);
            var flxReceivableGraphFilterList = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxReceivableGraphFilterList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "25dp",
                "verticalScrollIndicator": true,
                "width": "46.40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivableGraphFilterList.setDefaultUnit(kony.flex.DP);
            var segReceivableGraphFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segReceivableGraphFilter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReceivableGraphFilterList.add(segReceivableGraphFilter);
            flxReceivableGraphFilter.add(flxReceivableGraphFilterDropdown, flxReceivableGraphFilterList);
            flxReceivableGraphHeader.add(flxReceivableTypes, flxReceivableGraphFilter);
            var flxReceivablesGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "200dp",
                "id": "flxReceivablesGraph",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReceivablesGraph.setDefaultUnit(kony.flex.DP);
            flxReceivablesGraph.add();
            flxReceivables.add(flxAmountReceivablesHeader, flxAmountReceivablesSummary, flxSeparator2, flxReceivableGraphHeader, flxReceivablesGraph);
            flxAmountReceivables.add(flxLoadingReceivables, flxReceivables);
            var flxAmountPayables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "425dp",
                "id": "flxAmountPayables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "445dp",
                "width": "66.25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountPayables.setDefaultUnit(kony.flex.DP);
            var flxLoadingPayables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingPayables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingPayables.setDefaultUnit(kony.flex.DP);
            var imgLoadingPayables = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingPayables",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingPayables.add(imgLoadingPayables);
            var flxPayables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayables",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayables.setDefaultUnit(kony.flex.DP);
            var flxAmountPayablesHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAmountPayablesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountPayablesHeader.setDefaultUnit(kony.flex.DP);
            var flxAmountPayablesHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountPayablesHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountPayablesHeading.setDefaultUnit(kony.flex.DP);
            var lblAmountPayablesHeading = new kony.ui.Label({
                "id": "lblAmountPayablesHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.amountPayables\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountPayablesHeading.add(lblAmountPayablesHeading);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxViewPayables = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewPayables",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewPayables.setDefaultUnit(kony.flex.DP);
            var btnViewPayables = new kony.ui.Button({
                "id": "btnViewPayables",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnSSP0273e315px",
                "text": "View Payables",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View Payables"
            });
            flxViewPayables.add(btnViewPayables);
            flxAmountPayablesHeader.add(flxAmountPayablesHeading, flxSeparator4, flxViewPayables);
            var flxAmountPayablesSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "78dp",
                "id": "flxAmountPayablesSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountPayablesSummary.setDefaultUnit(kony.flex.DP);
            var flxPayableSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableSummary1.setDefaultUnit(kony.flex.DP);
            var lblPayableSummary1 = new kony.ui.Label({
                "id": "lblPayableSummary1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Today’s Payables",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableCount1 = new kony.ui.Label({
                "id": "lblPayableCount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableAmount1 = new kony.ui.Label({
                "id": "lblPayableAmount1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableSummary1.add(lblPayableSummary1, lblPayableCount1, lblPayableAmount1);
            var flxHorizontalSeparator3 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHorizontalSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator3.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator3.add();
            var flxPayableSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableSummary2.setDefaultUnit(kony.flex.DP);
            var lblPayableSummary2 = new kony.ui.Label({
                "id": "lblPayableSummary2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.amountPaid\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableCount2 = new kony.ui.Label({
                "id": "lblPayableCount2",
                "isVisible": true,
                "left": "26%",
                "skin": "sknLbl04a615SSPReg20px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableAmount2 = new kony.ui.Label({
                "id": "lblPayableAmount2",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableSummary2.add(lblPayableSummary2, lblPayableCount2, lblPayableAmount2);
            var flxHorizontalSeparator4 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHorizontalSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "1dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalSeparator4.setDefaultUnit(kony.flex.DP);
            flxHorizontalSeparator4.add();
            var flxPayableSummary3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableSummary3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableSummary3.setDefaultUnit(kony.flex.DP);
            var lblPayableSummary3 = new kony.ui.Label({
                "id": "lblPayableSummary3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.overdues\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableCount3 = new kony.ui.Label({
                "id": "lblPayableCount3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknLblFF000020px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableAmount3 = new kony.ui.Label({
                "id": "lblPayableAmount3",
                "isVisible": true,
                "left": "26%",
                "skin": "ICSknSSP42424220Px",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableSummary3.add(lblPayableSummary3, lblPayableCount3, lblPayableAmount3);
            flxAmountPayablesSummary.add(flxPayableSummary1, flxHorizontalSeparator3, flxPayableSummary2, flxHorizontalSeparator4, flxPayableSummary3);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var flxPayableGraphHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPayableGraphHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableGraphHeader.setDefaultUnit(kony.flex.DP);
            var flxPayableTypes = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableTypes.setDefaultUnit(kony.flex.DP);
            var flxPayableType1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableType1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableType1.setDefaultUnit(kony.flex.DP);
            var lblPayableType1Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblPayableType1Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblffdbb2OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableType1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayableType1",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.Drawings\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableType1.add(lblPayableType1Icon, lblPayableType1);
            var flxPayableType2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableType2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableType2.setDefaultUnit(kony.flex.DP);
            var lblPayableType2Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblPayableType2Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblffb059OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableType2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayableType2",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.collections\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableType2.add(lblPayableType2Icon, lblPayableType2);
            var flxPayableType3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableType3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableType3.setDefaultUnit(kony.flex.DP);
            var lblPayableType3Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblPayableType3Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblff8600OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayableType3 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayableType3",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.claims\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableType3.add(lblPayableType3Icon, lblPayableType3);
            flxPayableTypes.add(flxPayableType1, flxPayableType2, flxPayableType3);
            var flxPayableGraphFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableGraphFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "160dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableGraphFilter.setDefaultUnit(kony.flex.DP);
            var flxPayableGraphFilterDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayableGraphFilterDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "130dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableGraphFilterDropdown.setDefaultUnit(kony.flex.DP);
            var lblPayableGraphFilterDropdownIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "15dp",
                "id": "lblPayableGraphFilterDropdownIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff14pxOther",
                "text": "O",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedPayableGraphFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSelectedPayableGraphFilter",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "Expiry in 7 Days",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableGraphFilterDropdown.add(lblPayableGraphFilterDropdownIcon, lblSelectedPayableGraphFilter);
            var flxPayableGraphFilterList = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": false,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxPayableGraphFilterList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCRoundedbebebe3Px",
                "top": "25dp",
                "verticalScrollIndicator": true,
                "width": "46.40%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxPayableGraphFilterList.setDefaultUnit(kony.flex.DP);
            var segPayableGraphFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segPayableGraphFilter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayableGraphFilterList.add(segPayableGraphFilter);
            flxPayableGraphFilter.add(flxPayableGraphFilterDropdown, flxPayableGraphFilterList);
            flxPayableGraphHeader.add(flxPayableTypes, flxPayableGraphFilter);
            var flxPayablesGraph = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "200dp",
                "id": "flxPayablesGraph",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayablesGraph.setDefaultUnit(kony.flex.DP);
            flxPayablesGraph.add();
            flxPayables.add(flxAmountPayablesHeader, flxAmountPayablesSummary, flxSeparator5, flxPayableGraphHeader, flxPayablesGraph);
            flxAmountPayables.add(flxLoadingPayables, flxPayables);
            var flxLimits = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "390dp",
                "id": "flxLimits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "890dp",
                "width": "66.25%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimits.setDefaultUnit(kony.flex.DP);
            var flxLoadingLimits = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingLimits",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingLimits.setDefaultUnit(kony.flex.DP);
            var imgLoadingLimits = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingLimits",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingLimits.add(imgLoadingLimits);
            var flxLimitsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLimitsContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsContainer.setDefaultUnit(kony.flex.DP);
            var flxLimitsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLimitsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsHeader.setDefaultUnit(kony.flex.DP);
            var flxLimitsHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLimitsHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsHeading.setDefaultUnit(kony.flex.DP);
            var lblLimitsHeading = new kony.ui.Label({
                "id": "lblLimitsHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.limits\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitsHeading.add(lblLimitsHeading);
            var flxSeparator6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator6.setDefaultUnit(kony.flex.DP);
            flxSeparator6.add();
            var flxViewAllLimits = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewAllLimits",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewAllLimits.setDefaultUnit(kony.flex.DP);
            var btnViewAllLimits = new kony.ui.Button({
                "id": "btnViewAllLimits",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.viewAll\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All"
            });
            flxViewAllLimits.add(btnViewAllLimits);
            flxLimitsHeader.add(flxLimitsHeading, flxSeparator6, flxViewAllLimits);
            var flxLimitsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLimitsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsBody.setDefaultUnit(kony.flex.DP);
            var flxLimitsType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLimitsType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "250dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsType.setDefaultUnit(kony.flex.DP);
            var flxLimitsType1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLimitsType1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsType1.setDefaultUnit(kony.flex.DP);
            var lblLimitType1Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblLimitType1Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblc8e9ebOLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLimitType1 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLimitType1",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.available\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitsType1.add(lblLimitType1Icon, lblLimitType1);
            var flxLimitsType2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxLimitsType2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsType2.setDefaultUnit(kony.flex.DP);
            var lblLimitType2Icon = new kony.ui.Label({
                "centerY": "50%",
                "height": "12dp",
                "id": "lblLimitType2Icon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl23a8b1OLBFontIcons12px",
                "text": "F",
                "width": "13dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLimitType2 = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLimitType2",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.utilized\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLimitsType2.add(lblLimitType2Icon, lblLimitType2);
            flxLimitsType.add(flxLimitsType1, flxLimitsType2);
            var flxLimitsChartArea = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "300dp",
                "id": "flxLimitsChartArea",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLimitsChartArea.setDefaultUnit(kony.flex.DP);
            flxLimitsChartArea.add();
            flxLimitsBody.add(flxLimitsType, flxLimitsChartArea);
            flxLimitsContainer.add(flxLimitsHeader, flxLimitsBody);
            flxLimits.add(flxLoadingLimits, flxLimitsContainer);
            var flxNeedAttention = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "275dp",
                "id": "flxNeedAttention",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "32.50%",
                "zIndex": 10,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttention.setDefaultUnit(kony.flex.DP);
            var flxLoadingNA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingNA",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingNA.setDefaultUnit(kony.flex.DP);
            var imgLoadingNA = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingNA",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingNA.add(imgLoadingNA);
            var flxNeedAttentionContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxNeedAttentionContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttentionContainer.setDefaultUnit(kony.flex.DP);
            var flxNeedAttentionHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxNeedAttentionHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttentionHeader.setDefaultUnit(kony.flex.DP);
            var flxNeedAttentionHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxNeedAttentionHeading",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttentionHeading.setDefaultUnit(kony.flex.DP);
            var imgNeedAttention = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgNeedAttention",
                "isVisible": true,
                "left": "0dp",
                "src": "alert.png",
                "top": "0dp",
                "width": "22dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNeedAttentionHeading = new kony.ui.Label({
                "id": "lblNeedAttentionHeading",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.needAttention\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNeedAttentionHeading.add(imgNeedAttention, lblNeedAttentionHeading);
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxNeedAttentionContextual = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNeedAttentionContextual",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttentionContextual.setDefaultUnit(kony.flex.DP);
            var lblNeedAttentionContextualIcon = new kony.ui.Label({
                "id": "lblNeedAttentionContextualIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNeedAttentionContextual.add(lblNeedAttentionContextualIcon);
            var flxContextualNA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContextualNA",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualNA.setDefaultUnit(kony.flex.DP);
            var flxContextualHeaderNA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxContextualHeaderNA",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualHeaderNA.setDefaultUnit(kony.flex.DP);
            var lblChooseList = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblChooseList",
                "isVisible": true,
                "left": "5%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.chooseYourPreferredList\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnResetNA = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnResetNA",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.reset\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Reset"
            });
            flxContextualHeaderNA.add(lblChooseList, btnResetNA);
            var flxSegContextualNA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegContextualNA",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegContextualNA.setDefaultUnit(kony.flex.DP);
            var segContextualNA = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segContextualNA",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxTempExportLCFilter1"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxGuaranteeReceivedDetailsHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegContextualNA.add(segContextualNA);
            var flxSeparator12 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator12",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator12.setDefaultUnit(kony.flex.DP);
            flxSeparator12.add();
            var flxContextualActionsNA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxContextualActionsNA",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualActionsNA.setDefaultUnit(kony.flex.DP);
            var btnApplyNA = new kony.ui.Button({
                "centerY": "50%",
                "height": "50%",
                "id": "btnApplyNA",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.datePicker.apply\")",
                "top": "0dp",
                "width": "42%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Apply"
            });
            var btnCancelNA = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnCancelNA",
                "isVisible": true,
                "right": "18%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.nuo.Cancel\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxContextualActionsNA.add(btnApplyNA, btnCancelNA);
            flxContextualNA.add(flxContextualHeaderNA, flxSegContextualNA, flxSeparator12, flxContextualActionsNA);
            flxNeedAttentionHeader.add(flxNeedAttentionHeading, flxSeparator3, flxNeedAttentionContextual, flxContextualNA);
            var flxNeedAttentionData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "223dp",
                "id": "flxNeedAttentionData",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNeedAttentionData.setDefaultUnit(kony.flex.DP);
            var segNeedAttention = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segNeedAttention",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxNeedAttention"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNeedAttentionData.add(segNeedAttention);
            flxNeedAttentionContainer.add(flxNeedAttentionHeader, flxNeedAttentionData);
            flxNeedAttention.add(flxLoadingNA, flxNeedAttentionContainer);
            var flxAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "507dp",
                "id": "flxAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "295dp",
                "width": "32.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccounts.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountsHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "70%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeading.setDefaultUnit(kony.flex.DP);
            var lblAccountsHeading = new kony.ui.Label({
                "id": "lblAccountsHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsHeading.add(lblAccountsHeading);
            var flxSeparator7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator7.setDefaultUnit(kony.flex.DP);
            flxSeparator7.add();
            var flxViewAllAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewAllAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewAllAccounts.setDefaultUnit(kony.flex.DP);
            var btnViewAllAccounts = new kony.ui.Button({
                "id": "btnViewAllAccounts",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.viewAll\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All"
            });
            flxViewAllAccounts.add(btnViewAllAccounts);
            flxAccountsHeader.add(flxAccountsHeading, flxSeparator7, flxViewAllAccounts);
            var flxAccountsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "95dp",
                "id": "flxAccountsBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsBody.setDefaultUnit(kony.flex.DP);
            var lblAvailableBalance = new kony.ui.Label({
                "id": "lblAvailableBalance",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.totalAccountsAvailableBalance\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAvailableAmount = new kony.ui.Label({
                "id": "lblAvailableAmount",
                "isVisible": true,
                "left": "80dp",
                "skin": "sknlbl424242SSPReg24px",
                "top": "47dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator10 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator10",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "95%",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator10.setDefaultUnit(kony.flex.DP);
            flxSeparator10.add();
            var flxIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf9f9f9Rounded15pxTab",
                "top": "20dp",
                "width": "40dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIcon.setDefaultUnit(kony.flex.DP);
            var lblIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblIcon",
                "isVisible": true,
                "skin": "sknLblFontTypeTradeFinance",
                "text": "C",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIcon.add(lblIcon);
            flxAccountsBody.add(lblAvailableBalance, lblAvailableAmount, flxSeparator10, flxIcon);
            var flxAccountsListing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountsListing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsListing.setDefaultUnit(kony.flex.DP);
            var segAccountsListing = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAccountsListing",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxRecentlyUpdatedAcc"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsListing.add(segAccountsListing);
            var flxLoadingAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingAccounts.setDefaultUnit(kony.flex.DP);
            var imgLoadingAccounts = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingAccounts",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingAccounts.add(imgLoadingAccounts);
            flxAccounts.add(flxAccountsHeader, flxAccountsBody, flxAccountsListing, flxLoadingAccounts);
            var flxExchangeRates = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxExchangeRates",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "822dp",
                "width": "32.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRates.setDefaultUnit(kony.flex.DP);
            var flxLoadingER = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoadingER",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingER.setDefaultUnit(kony.flex.DP);
            var imgLoadingER = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgLoadingER",
                "isVisible": true,
                "src": "rb_4_0_ad_loading_indicator.gif",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingER.add(imgLoadingER);
            var flxExchangeRatesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxExchangeRatesContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRatesContainer.setDefaultUnit(kony.flex.DP);
            var flxExchangeRatesHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxExchangeRatesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 4,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRatesHeader.setDefaultUnit(kony.flex.DP);
            var flxExchangeRatesHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExchangeRatesHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRatesHeading.setDefaultUnit(kony.flex.DP);
            var lblExchangeRatesHeading = new kony.ui.Label({
                "id": "lblExchangeRatesHeading",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Hamburger.exchangeRates\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeRatesHeading.add(lblExchangeRatesHeading);
            var flxSeparator8 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator8",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator8.setDefaultUnit(kony.flex.DP);
            flxSeparator8.add();
            var flxRefreshExchangeRates = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRefreshExchangeRates",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "10%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRefreshExchangeRates.setDefaultUnit(kony.flex.DP);
            var lblRefreshExchangeRatesIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblRefreshExchangeRatesIcon",
                "isVisible": true,
                "right": "0dp",
                "skin": "skn0273e320pxolbfonticons",
                "text": "W",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExchangeRatesRefreshedTime = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExchangeRatesRefreshedTime",
                "isVisible": true,
                "right": "10dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRefreshExchangeRates.add(lblRefreshExchangeRatesIcon, lblExchangeRatesRefreshedTime);
            var flxExchangeRatesContextual = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExchangeRatesContextual",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRatesContextual.setDefaultUnit(kony.flex.DP);
            var lblExchangeRatesContextual = new kony.ui.Label({
                "id": "lblExchangeRatesContextual",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeRatesContextual.add(lblExchangeRatesContextual);
            var flxCurrencyContexualDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCurrencyContexualDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyContexualDropdown.setDefaultUnit(kony.flex.DP);
            var flxChooseCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxChooseCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChooseCurrency.setDefaultUnit(kony.flex.DP);
            var lblChooseCurrency = new kony.ui.Label({
                "id": "lblChooseCurrency",
                "isVisible": true,
                "left": "5%",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.chooseYourPreferredCurrency\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnResetAction = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnResetAction",
                "isVisible": true,
                "right": "5%",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.reset\")",
                "width": "40dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChooseCurrency.add(lblChooseCurrency, btnResetAction);
            var flxFilters = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilters.setDefaultUnit(kony.flex.DP);
            var flxSelectedCurrencies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSelectedCurrencies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedCurrencies.setDefaultUnit(kony.flex.DP);
            var flxSelectedHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSelectedHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedHeader.setDefaultUnit(kony.flex.DP);
            var lblSelected = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Accounts"
                },
                "id": "lblSelected",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSP72727215px",
                "text": "Selected (Max. 5)",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Accounts"
            });
            var flxSelectedSeparator = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSelectedSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedSeparator.setDefaultUnit(kony.flex.DP);
            flxSelectedSeparator.add();
            var flxSelectedDropdownImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxSelectedDropdownImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d3a44c95e0844f8b91e7d195da058b94,
                "right": "5%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxSelectedDropdownImage.setDefaultUnit(kony.flex.DP);
            var lblSelectedDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Accounts"
                },
                "id": "lblSelectedDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbldropdown",
                "text": "P",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Accounts"
            });
            flxSelectedDropdownImage.add(lblSelectedDropdown);
            flxSelectedHeader.add(lblSelected, flxSelectedSeparator, flxSelectedDropdownImage);
            var segSelectedCurrenciesList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segSelectedCurrenciesList",
                "isVisible": true,
                "left": "5%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCTypeOfAccountsList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "95%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSelectedSeparator2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSelectedSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedSeparator2.setDefaultUnit(kony.flex.DP);
            flxSelectedSeparator2.add();
            flxSelectedCurrencies.add(flxSelectedHeader, segSelectedCurrenciesList, flxSelectedSeparator2);
            var flxAvailableCurrencies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAvailableCurrencies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "maxHeight": "200dp",
                "minHeight": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableCurrencies.setDefaultUnit(kony.flex.DP);
            var flxAvailableHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAvailableHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableHeader.setDefaultUnit(kony.flex.DP);
            var lblAvailableHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Accounts"
                },
                "centerY": "50%",
                "id": "lblAvailableHeader",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.available\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Accounts"
            });
            var flxAvailableHeadingSeparator = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAvailableHeadingSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableHeadingSeparator.setDefaultUnit(kony.flex.DP);
            flxAvailableHeadingSeparator.add();
            var flxAvailableDropdownImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxAvailableDropdownImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d3a44c95e0844f8b91e7d195da058b94,
                "right": "5%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxAvailableDropdownImage.setDefaultUnit(kony.flex.DP);
            var lblAvailableDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Accounts"
                },
                "id": "lblAvailableDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbldropdown",
                "text": "P",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Accounts"
            });
            flxAvailableDropdownImage.add(lblAvailableDropdown);
            flxAvailableHeader.add(lblAvailableHeader, flxAvailableHeadingSeparator, flxAvailableDropdownImage);
            var flxSearchAvailableCurrencies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearchAvailableCurrencies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "10dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchAvailableCurrencies.setDefaultUnit(kony.flex.DP);
            var lblAvailableSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "18dp",
                "id": "lblAvailableSearchIcon",
                "isVisible": true,
                "left": "3%",
                "skin": "ICSknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "18dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearchAvailable = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "txtSearchAvailable",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Wealth.SearchCurrency\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "75%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 10, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "18dp",
                "id": "lblClearIcon",
                "isVisible": false,
                "left": "1.50%",
                "skin": "ICSknLblClearFontIcona0a0a016px",
                "text": "J",
                "width": "18dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchAvailableCurrencies.add(lblAvailableSearchIcon, txtSearchAvailable, lblClearIcon);
            var segAvailableCurrenciesList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAvailableCurrenciesList",
                "isVisible": true,
                "left": "5%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCStatusType"
                }),
                "sectionHeaderSkin": "seg2Normal2",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "95%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAvailableBottomSeparator = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAvailableBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxAvailableBottomSeparator.add();
            flxAvailableCurrencies.add(flxAvailableHeader, flxSearchAvailableCurrencies, segAvailableCurrenciesList, flxAvailableBottomSeparator);
            flxFilters.add(flxSelectedCurrencies, flxAvailableCurrencies);
            var flxERContextualActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxERContextualActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxERContextualActions.setDefaultUnit(kony.flex.DP);
            var flxSeparator14 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "centerX": "50%",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator14",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator14.setDefaultUnit(kony.flex.DP);
            flxSeparator14.add();
            var btnCancelCurrency = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancelCurrency",
                "isVisible": true,
                "left": "6%",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "42%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnApplyCurrency = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnApplyCurrency",
                "isVisible": true,
                "right": "6%",
                "skin": "ICSknbtnEnabed003e7536px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.datePicker.apply\")",
                "width": "42%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Apply"
            });
            flxERContextualActions.add(flxSeparator14, btnCancelCurrency, btnApplyCurrency);
            flxCurrencyContexualDropdown.add(flxChooseCurrency, flxFilters, flxERContextualActions);
            flxExchangeRatesHeader.add(flxExchangeRatesHeading, flxSeparator8, flxRefreshExchangeRates, flxExchangeRatesContextual, flxCurrencyContexualDropdown);
            var flxCurrencyConversion = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "105dp",
                "id": "flxCurrencyConversion",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyConversion.setDefaultUnit(kony.flex.DP);
            var lblFromCurrency = new kony.ui.Label({
                "id": "lblFromCurrency",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.from1Unit\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToCurrency = new kony.ui.Label({
                "id": "lblToCurrency",
                "isVisible": true,
                "left": "53%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.equalsTo\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtFromCurrency = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtFromCurrency",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Wealth.SearchCurrency\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "45dp",
                "width": "42%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var txtToCurrency = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtToCurrency",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "53%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Wealth.SearchCurrency\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "45dp",
                "width": "42%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var flxCurrencyListDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "420dp",
                "id": "flxCurrencyListDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "21dp",
                "isModalContainer": false,
                "right": 30,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "45dp",
                "width": "73%",
                "zIndex": 100,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyListDropdown.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.50%",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "10dp",
                "width": "93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var lblSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "18dp",
                "id": "lblSearchIcon",
                "isVisible": true,
                "left": "3%",
                "skin": "ICSknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "18dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntbxSSP42424215pxnoborder",
                "height": "100%",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Wealth.SearchCurrency\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "75%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 10, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727215px"
            });
            var lblClear = new kony.ui.Label({
                "centerY": "50%",
                "height": "18dp",
                "id": "lblClear",
                "isVisible": true,
                "left": "1.50%",
                "skin": "ICSknLblClearFontIcona0a0a016px",
                "text": "J",
                "width": "18dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearch.add(lblSearchIcon, txtSearch, lblClear);
            var flxRecentlyUsed = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxRecentlyUsed",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3.50%",
                "maxHeight": "120dp",
                "minHeight": "40dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "10dp",
                "verticalScrollIndicator": true,
                "width": "93%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxRecentlyUsed.setDefaultUnit(kony.flex.DP);
            var lblRecentlyUsed = new kony.ui.Label({
                "id": "lblRecentlyUsed",
                "isVisible": true,
                "left": "4%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mob.ForeignExchange.Recentlyused\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segRecentlyUsed = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segRecentlyUsed",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRecentlyUsed.add(lblRecentlyUsed, segRecentlyUsed);
            var flxAllCurrencies = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxAllCurrencies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3.50%",
                "maxHeight": "230dp",
                "minHeight": "40dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "93%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxAllCurrencies.setDefaultUnit(kony.flex.DP);
            var lblAllCurrency = new kony.ui.Label({
                "id": "lblAllCurrency",
                "isVisible": true,
                "left": "4%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.All\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segAllCurrency = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAllCurrency",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAllCurrencies.add(lblAllCurrency, segAllCurrency);
            flxCurrencyListDropdown.add(flxSearch, flxRecentlyUsed, flxAllCurrencies);
            flxCurrencyConversion.add(lblFromCurrency, lblToCurrency, txtFromCurrency, txtToCurrency, flxCurrencyListDropdown);
            var flxERSegmentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxERSegmentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxbgf7f7f7op100Bordere3e3e3radius2pxTopBottom",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxERSegmentHeader.setDefaultUnit(kony.flex.DP);
            var lblERCurrencyHeading = new kony.ui.Label({
                "id": "lblERCurrencyHeading",
                "isVisible": true,
                "left": "5%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Currency\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblERBuyHeading = new kony.ui.Label({
                "id": "lblERBuyHeading",
                "isVisible": true,
                "right": "28%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ForeignExchange.Buy\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblERSellHeader = new kony.ui.Label({
                "id": "lblERSellHeader",
                "isVisible": true,
                "right": "5%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ForeignExchange.Sell\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxERSegmentHeader.add(lblERCurrencyHeading, lblERBuyHeading, lblERSellHeader);
            var flxExchangeSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "204dp",
                "id": "flxExchangeSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeSegment.setDefaultUnit(kony.flex.DP);
            var segExchangeRates = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "100%",
                "id": "segExchangeRates",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExchangeRatesRow"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeSegment.add(segExchangeRates);
            flxExchangeRatesContainer.add(flxExchangeRatesHeader, flxCurrencyConversion, flxERSegmentHeader, flxExchangeSegment);
            flxExchangeRates.add(flxLoadingER, flxExchangeRatesContainer);
            flxDashboardData.add(flxAmountReceivables, flxAmountPayables, flxLimits, flxNeedAttention, flxAccounts, flxExchangeRates);
            formTemplate12.flxContentTCCenter.add(flxDashboardHeader, flxDashboardData);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxReceivablePayablePopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "flxRPClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPHeader"]
                    },
                    "flxSeparator9": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "lblRPToday": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPCalendar"]
                    },
                    "flxRPAmountSummary": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary"]
                    },
                    "lblRPSummary1": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary1"]
                    },
                    "flxHorizontalSeparator5": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary"]
                    },
                    "lblRPSummary2": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary2"]
                    },
                    "flxRPSearchAndFilterContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "tbxRPSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPSearch"]
                    },
                    "flxRPFilter": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "lblRPView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "lblRPSelectedFilter": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "flxRPFilterList": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPFilters": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "segRPFilterList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilters"]
                    },
                    "flxRPFilterActions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "flxRPFilterSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilterActions"]
                    },
                    "flxRPPagination": {
                        "centerX": {
                            "type": "string",
                            "value": "51.50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "imgRPNoRecords": {
                        "segmentProps": []
                    },
                    "lblRPNoRecords": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxNAListingPopup": {
                        "segmentProps": []
                    },
                    "flxNAListingClose": {
                        "segmentProps": []
                    },
                    "flxSeparator11": {
                        "segmentProps": []
                    },
                    "flxNASearchContainer": {
                        "segmentProps": []
                    },
                    "flxNASearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxNASearch": {
                        "segmentProps": []
                    },
                    "flxNAPagination": {
                        "centerX": {
                            "type": "string",
                            "value": "51.50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgNANoRecords": {
                        "segmentProps": []
                    },
                    "lblNANoRecords": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency"]
                    },
                    "flxCurrencyDropdown": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "lblSelectedCurrency": {
                        "skin": "ICSknLbl424242SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyDropdown"]
                    },
                    "flxCurrencyList": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "segCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyList"]
                    },
                    "lblQuickLinks": {
                        "skin": "ICSknLbl424242SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxQuickLinks"]
                    },
                    "lblRefreshedTime": {
                        "skin": "ICSknLbl424242SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxRefresh"]
                    },
                    "flxSeparator15": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxQuickLinksContent"]
                    },
                    "flxSeparator13": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxContextualQL"]
                    },
                    "flxAmountReceivablesHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables"]
                    },
                    "flxAmountReceivablesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader"]
                    },
                    "lblAmountReceivablesHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader", "flxAmountReceivablesHeading"]
                    },
                    "flxSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader"]
                    },
                    "flxAmountReceivablesSummary": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables"]
                    },
                    "lblReceivableSummary1": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary2": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary3": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary3"]
                    },
                    "flxSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables"]
                    },
                    "lblSelectedReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterDropdown"]
                    },
                    "flxReceivableGraphFilterList": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter"]
                    },
                    "segReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterList"]
                    },
                    "flxAmountPayablesHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables"]
                    },
                    "flxAmountPayablesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader"]
                    },
                    "lblAmountPayablesHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader", "flxAmountPayablesHeading"]
                    },
                    "flxSeparator4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader"]
                    },
                    "flxAmountPayablesSummary": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables"]
                    },
                    "lblPayableSummary1": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary1"]
                    },
                    "flxHorizontalSeparator3": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary2": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary2"]
                    },
                    "flxHorizontalSeparator4": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary3": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary3"]
                    },
                    "flxSeparator5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables"]
                    },
                    "lblSelectedPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterDropdown"]
                    },
                    "flxPayableGraphFilterList": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter"]
                    },
                    "segPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterList"]
                    },
                    "flxLimitsHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer"]
                    },
                    "flxLimitsHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader"]
                    },
                    "lblLimitsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader", "flxLimitsHeading"]
                    },
                    "flxSeparator6": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader"]
                    },
                    "flxNeedAttentionHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer"]
                    },
                    "flxNeedAttentionHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "lblNeedAttentionHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader", "flxNeedAttentionHeading"]
                    },
                    "flxSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "flxSeparator12": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader", "flxContextualNA"]
                    },
                    "flxAccountsHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts"]
                    },
                    "flxAccountsHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "lblAccountsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader", "flxAccountsHeading"]
                    },
                    "flxSeparator7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "flxExchangeRatesHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer"]
                    },
                    "flxExchangeRatesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "lblExchangeRatesHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxExchangeRatesHeading"]
                    },
                    "flxSeparator8": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "lblExchangeRatesRefreshedTime": {
                        "skin": "ICSknLbl424242SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxRefreshExchangeRates"]
                    },
                    "flxCurrencyContexualDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "flxSelectedSeparator": {
                        "height": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "segSelectedCurrenciesList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "flxSelectedSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "flxAvailableHeadingSeparator": {
                        "height": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "txtSearchAvailable": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxSearchAvailableCurrencies"]
                    },
                    "flxAvailableBottomSeparator": {
                        "height": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies"]
                    },
                    "flxERContextualActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "flxCurrencyListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion", "flxCurrencyListDropdown", "flxSearch"]
                    }
                },
                "1024": {
                    "flxReceivablePayablePopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "flxRPContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup"]
                    },
                    "lblRPToday": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPCalendar"]
                    },
                    "lblRPSummary1": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary1"]
                    },
                    "flxHorizontalSeparator5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary"]
                    },
                    "lblRPSummary2": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary2"]
                    },
                    "flxRPSearchAndFilterContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPSearch": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "tbxRPSearch": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPSearch"]
                    },
                    "flxRPFilter": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "lblRPView": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "lblRPSelectedFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "flxRPFilterList": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPFilters": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "segRPFilterList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilters"]
                    },
                    "flxRPFilterActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "flxRPFilterSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilterActions"]
                    },
                    "flxRPContextualList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPSortColumn1": {
                        "left": {
                            "type": "string",
                            "value": "8.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn2": {
                        "width": {
                            "type": "string",
                            "value": "17.50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn3": {
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn4": {
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn5": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn6": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPSortColumn7": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "segReceivablePayable": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPList"]
                    },
                    "flxRPPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "imgRPNoRecords": {
                        "segmentProps": []
                    },
                    "lblRPNoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxNAListingPopup": {
                        "segmentProps": []
                    },
                    "flxNAListingContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxNASearchContainer": {
                        "segmentProps": []
                    },
                    "flxNASearch": {
                        "segmentProps": []
                    },
                    "tbxNASearch": {
                        "segmentProps": []
                    },
                    "flxNAContextualList": {
                        "segmentProps": []
                    },
                    "segNAListing": {
                        "segmentProps": []
                    },
                    "flxNAPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgNANoRecords": {
                        "segmentProps": []
                    },
                    "lblNANoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency"]
                    },
                    "flxCurrencyDropdown": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "lblSelectedCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyDropdown"]
                    },
                    "flxCurrencyList": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "segCurrency": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyList"]
                    },
                    "lblQuickLinks": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxQuickLinks"]
                    },
                    "lblRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxRefresh"]
                    },
                    "flxQuickLinksContent": {
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader"]
                    },
                    "flxSeparator15": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxQuickLinksContent"]
                    },
                    "flxContextualQL": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader"]
                    },
                    "flxSeparator13": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxContextualQL"]
                    },
                    "flxAmountReceivables": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxReceivables": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables"]
                    },
                    "flxAmountReceivablesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader"]
                    },
                    "flxSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader"]
                    },
                    "lblReceivableSummary1": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary2": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary3": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary3"]
                    },
                    "flxSeparator2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables"]
                    },
                    "lblSelectedReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterDropdown"]
                    },
                    "flxReceivableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter"]
                    },
                    "segReceivableGraphFilter": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterList"]
                    },
                    "flxAmountPayables": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxPayables": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables"]
                    },
                    "flxAmountPayablesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader"]
                    },
                    "flxSeparator4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader"]
                    },
                    "lblPayableSummary1": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary1"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary2": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary2"]
                    },
                    "flxHorizontalSeparator4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary3": {
                        "skin": "sknLblSSP72727217px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary3"]
                    },
                    "flxSeparator5": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables"]
                    },
                    "lblSelectedPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterDropdown"]
                    },
                    "flxPayableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter"]
                    },
                    "segPayableGraphFilter": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterList"]
                    },
                    "flxLimits": {
                        "top": {
                            "type": "string",
                            "value": "1837dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxLimitsHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader"]
                    },
                    "flxSeparator6": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader"]
                    },
                    "flxNeedAttention": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxNeedAttentionHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "flxSeparator3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "flxContextualNA": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "flxSeparator12": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader", "flxContextualNA"]
                    },
                    "flxAccounts": {
                        "top": {
                            "type": "string",
                            "value": "1310dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxAccountsHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "flxSeparator7": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "flxViewAllAccounts": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "flxExchangeRates": {
                        "top": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData"]
                    },
                    "flxExchangeRatesHeading": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "flxSeparator8": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "lblExchangeRatesRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxRefreshExchangeRates"]
                    },
                    "flxCurrencyContexualDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "flxChooseCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "lblChooseCurrency": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxChooseCurrency"]
                    },
                    "flxSelectedHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "lblSelected": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "flxSelectedSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "flxSelectedDropdownImage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "lblSelectedDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader", "flxSelectedDropdownImage"]
                    },
                    "segSelectedCurrenciesList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "flxAvailableHeadingSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "lblAvailableDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader", "flxAvailableDropdownImage"]
                    },
                    "txtSearchAvailable": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxSearchAvailableCurrencies"]
                    },
                    "flxERContextualActions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "lblToCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtFromCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtToCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "flxCurrencyListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtSearch": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion", "flxCurrencyListDropdown", "flxSearch"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxReceivablePayablePopup": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "flxSeparator9": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "flxHorizontalSeparator5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary"]
                    },
                    "flxRPSearchAndFilterContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPSearch": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "tbxRPSearch": {
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPSearch"]
                    },
                    "flxRPFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer"]
                    },
                    "lblRPView": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "lblRPSelectedFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPSearchAndFilterContainer", "flxRPFilter"]
                    },
                    "flxRPFilterList": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isCustomLayout": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPFilters": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "segRPFilterList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilters"]
                    },
                    "flxRPFilterActions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList"]
                    },
                    "flxRPFilterSeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilterActions"]
                    },
                    "btnRPFilterCancel": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilterActions"]
                    },
                    "btnRPFilterApply": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter", "flxRPFilterList", "flxRPFilterActions"]
                    },
                    "flxRPContextualList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSearchAndFilter"]
                    },
                    "flxRPSortColumns": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "flxRPSortColumn1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn1": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn1"]
                    },
                    "flxRPSortColumn2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn2": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn2"]
                    },
                    "flxRPSortColumn3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn3": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn3"]
                    },
                    "flxRPSortColumn4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn4": {
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn4"]
                    },
                    "flxRPSortColumn5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn5": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn5"]
                    },
                    "flxRPSortColumn6": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "imgRPSortColumn6": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "sortingfinal.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns", "flxRPSortColumn6"]
                    },
                    "flxRPSortColumn7": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPSortColumns"]
                    },
                    "flxRPPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "imgRPNoRecords": {
                        "segmentProps": []
                    },
                    "lblRPNoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxNAListingPopup": {
                        "segmentProps": []
                    },
                    "flxSeparator11": {
                        "segmentProps": []
                    },
                    "flxNASearchContainer": {
                        "segmentProps": []
                    },
                    "flxNASearch": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxNASearch": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxNAContextualList": {
                        "segmentProps": []
                    },
                    "flxNAPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgNANoRecords": {
                        "segmentProps": []
                    },
                    "lblNANoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency"]
                    },
                    "flxCurrencyDropdown": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "lblSelectedCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyDropdown"]
                    },
                    "flxCurrencyList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "segCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyList"]
                    },
                    "lblQuickLinks": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxQuickLinks"]
                    },
                    "lblRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxRefresh"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblSelectedReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterDropdown"]
                    },
                    "flxReceivableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter"]
                    },
                    "segReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterList"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "flxHorizontalSeparator4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblSelectedPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterDropdown"]
                    },
                    "flxPayableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter"]
                    },
                    "segPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterList"]
                    },
                    "lblExchangeRatesRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxRefreshExchangeRates"]
                    },
                    "flxCurrencyContexualDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "flxChooseCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "lblChooseCurrency": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxChooseCurrency"]
                    },
                    "flxSelectedHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "lblSelected": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "flxSelectedSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "flxSelectedDropdownImage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "lblSelectedDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader", "flxSelectedDropdownImage"]
                    },
                    "segSelectedCurrenciesList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "flxSelectedSeparator2": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "lblAvailableHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "flxAvailableHeadingSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "flxAvailableDropdownImage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "lblAvailableDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader", "flxAvailableDropdownImage"]
                    },
                    "txtSearchAvailable": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxSearchAvailableCurrencies"]
                    },
                    "segAvailableCurrenciesList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies"]
                    },
                    "flxAvailableBottomSeparator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies"]
                    },
                    "flxERContextualActions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "btnCancelCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxERContextualActions"]
                    },
                    "btnApplyCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxERContextualActions"]
                    },
                    "txtFromCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtToCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "flxCurrencyListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    },
                    "txtSearch": {
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion", "flxCurrencyListDropdown", "flxSearch"]
                    }
                },
                "1380": {
                    "lblRPToday": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPCalendar"]
                    },
                    "lblRPSummary1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary1"]
                    },
                    "flxHorizontalSeparator5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary"]
                    },
                    "lblRPSummary2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer", "flxRPDateSummary", "flxRPAmountSummary", "flxRPAmountSummary2"]
                    },
                    "flxRPPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxReceivablePayablePopup", "flxRPContainer"]
                    },
                    "imgRPNoRecords": {
                        "segmentProps": []
                    },
                    "lblRPNoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxNAPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgNANoRecords": {
                        "segmentProps": []
                    },
                    "lblNANoRecords": {
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "zindex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency"]
                    },
                    "flxCurrencyDropdown": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "lblSelectedCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyDropdown"]
                    },
                    "flxCurrencyList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency"]
                    },
                    "segCurrency": {
                        "left": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxWidgetsCurrency", "flxCurrency", "flxCurrencyList"]
                    },
                    "lblQuickLinks": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxQuickLinks"]
                    },
                    "lblRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardHeader", "flxRefreshAndQuickLinks", "flxRefresh"]
                    },
                    "flxAmountReceivablesHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader"]
                    },
                    "lblAmountReceivablesHeading": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesHeader", "flxAmountReceivablesHeading"]
                    },
                    "lblReceivableSummary1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary1"]
                    },
                    "flxHorizontalSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary2"]
                    },
                    "flxHorizontalSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary"]
                    },
                    "lblReceivableSummary3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxAmountReceivablesSummary", "flxReceivableSummary3"]
                    },
                    "lblSelectedReceivableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterDropdown"]
                    },
                    "flxReceivableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter"]
                    },
                    "segReceivableGraphFilter": {
                        "left": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountReceivables", "flxReceivables", "flxReceivableGraphHeader", "flxReceivableGraphFilter", "flxReceivableGraphFilterList"]
                    },
                    "flxAmountPayablesHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader"]
                    },
                    "lblAmountPayablesHeading": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesHeader", "flxAmountPayablesHeading"]
                    },
                    "lblPayableSummary1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary1"]
                    },
                    "flxHorizontalSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary2"]
                    },
                    "flxHorizontalSeparator4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary"]
                    },
                    "lblPayableSummary3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxAmountPayablesSummary", "flxPayableSummary3"]
                    },
                    "lblSelectedPayableGraphFilter": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterDropdown"]
                    },
                    "flxPayableGraphFilterList": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter"]
                    },
                    "segPayableGraphFilter": {
                        "left": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAmountPayables", "flxPayables", "flxPayableGraphHeader", "flxPayableGraphFilter", "flxPayableGraphFilterList"]
                    },
                    "flxLimitsHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader"]
                    },
                    "lblLimitsHeading": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxLimits", "flxLimitsContainer", "flxLimitsHeader", "flxLimitsHeading"]
                    },
                    "flxNeedAttentionHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader"]
                    },
                    "lblNeedAttentionHeading": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxNeedAttention", "flxNeedAttentionContainer", "flxNeedAttentionHeader", "flxNeedAttentionHeading"]
                    },
                    "flxAccountsHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader"]
                    },
                    "lblAccountsHeading": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxAccounts", "flxAccountsHeader", "flxAccountsHeading"]
                    },
                    "flxExchangeRatesHeading": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "lblExchangeRatesHeading": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxExchangeRatesHeading"]
                    },
                    "lblExchangeRatesRefreshedTime": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxRefreshExchangeRates"]
                    },
                    "flxCurrencyContexualDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader"]
                    },
                    "lblSelected": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "flxSelectedSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader"]
                    },
                    "lblSelectedDropdown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies", "flxSelectedHeader", "flxSelectedDropdownImage"]
                    },
                    "segSelectedCurrenciesList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "flxSelectedSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxSelectedCurrencies"]
                    },
                    "lblAvailableHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "flxAvailableHeadingSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader"]
                    },
                    "lblAvailableDropdown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies", "flxAvailableHeader", "flxAvailableDropdownImage"]
                    },
                    "segAvailableCurrenciesList": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies"]
                    },
                    "flxAvailableBottomSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxFilters", "flxAvailableCurrencies"]
                    },
                    "flxERContextualActions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown"]
                    },
                    "btnCancelCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxERContextualActions"]
                    },
                    "btnApplyCurrency": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxExchangeRatesHeader", "flxCurrencyContexualDropdown", "flxERContextualActions"]
                    },
                    "flxCurrencyListDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxDashboardData", "flxExchangeRates", "flxExchangeRatesContainer", "flxCurrencyConversion"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmDashboard,
            "enabledForIdleTimeout": true,
            "id": "frmDashboard",
            "init": controller.AS_Form_jca483d654b14e629057aab068e75ea0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});