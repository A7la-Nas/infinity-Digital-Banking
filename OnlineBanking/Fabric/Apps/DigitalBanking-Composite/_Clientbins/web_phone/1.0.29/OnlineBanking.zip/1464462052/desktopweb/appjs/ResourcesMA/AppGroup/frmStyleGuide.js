define("ResourcesMA/AppGroup/frmStyleGuide", function() {
    return function(controller) {
        function addWidgetsfrmStyleGuide() {
            this.setDefaultUnit(kony.flex.DP);
            var flxSample1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "550dp",
                "id": "flxSample1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 70,
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow",
                "top": 30,
                "width": "30%",
                "appName": "ResourcesMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSample1.setDefaultUnit(kony.flex.DP);
            var btnSample1 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample1",
                "isVisible": true,
                "left": "50dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "sknBtnNormalSSPFFFFFF15Px",
                "top": "25dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSample2 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample2",
                "isVisible": true,
                "left": "50dp",
                "skin": "ICSknbtnDisablede2e9f036px",
                "text": "ICSknbtnDisablede2e9f036px",
                "top": "110dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSample3 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample3",
                "isVisible": true,
                "left": "50dp",
                "skin": "bbSknBtn0e73d8SSP15Px",
                "text": "bbSknBtn0e73d8SSP15Px",
                "top": "200dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSample4 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample4",
                "isVisible": true,
                "left": "50dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "text": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "top": "290dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSample5 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample5",
                "isVisible": true,
                "left": "50dp",
                "skin": "ICSknbtnPrimaryHover",
                "text": "ICSknbtnPrimaryHover",
                "top": "380dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSample6 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSample6",
                "isVisible": true,
                "left": "50dp",
                "skin": "ICSknbtnSecondaryHover",
                "text": "ICSknbtnSecondaryHover",
                "top": "460dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSample1.add(btnSample1, btnSample2, btnSample3, btnSample4, btnSample5, btnSample6);
            var flxSample2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "550dp",
                "id": "flxSample2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 600,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": 30,
                "width": "25%",
                "appName": "ResourcesMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSample2.setDefaultUnit(kony.flex.DP);
            var lblSample1 = new kony.ui.Label({
                "id": "lblSample1",
                "isVisible": true,
                "left": "70dp",
                "skin": "bbSknLbl0e73d8SSP15Px",
                "text": "bbSknLbl0e73d8SSP15Px",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample2 = new kony.ui.Label({
                "id": "lblSample2",
                "isVisible": true,
                "left": "72dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "bbSknLbl424242SSP15Px",
                "top": "70dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample3 = new kony.ui.Label({
                "id": "lblSample3",
                "isVisible": true,
                "left": "70dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "ICSknSSPRegular727272op10015px",
                "top": "110dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample4 = new kony.ui.Label({
                "id": "lblSample4",
                "isVisible": true,
                "left": "52dp",
                "skin": "sknLabel003e7524px",
                "text": "sknLabel003e7524px",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample5 = new kony.ui.Label({
                "id": "lblSample5",
                "isVisible": true,
                "left": "72dp",
                "skin": "sknLblFFFFFF9PxBg003E75Circle",
                "text": "skbLblOLBFontIcons003E7511PxNoBorder",
                "top": "190dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample6 = new kony.ui.Label({
                "id": "lblSample6",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknSSP003e757px",
                "text": "sknLblNotification003e75FontIcon",
                "top": "230dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample7 = new kony.ui.Label({
                "id": "lblSample7",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "sknlbl424242SSP15pxSemibold",
                "top": "260dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample8 = new kony.ui.Label({
                "id": "lblSample8",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknSSPBold42424220Px",
                "text": "sknSSPBold42424220Px",
                "top": "377dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample9 = new kony.ui.Label({
                "id": "lblSample9",
                "isVisible": true,
                "left": "88dp",
                "skin": "bbSknLbl000000font",
                "text": "bbSknLbl000000font",
                "top": "340dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample10 = new kony.ui.Label({
                "id": "lblSample10",
                "isVisible": true,
                "left": "98dp",
                "skin": "bbSknLabelBold",
                "text": "bbSknLabelBold",
                "top": "300dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample11 = new kony.ui.Label({
                "id": "lblSample11",
                "isVisible": true,
                "left": "77dp",
                "skin": "bbSknLblFF001FLatoBold15Px",
                "text": "bbSknLblFF001FLatoBold15Px",
                "top": "420dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample12 = new kony.ui.Label({
                "id": "lblSample12",
                "isVisible": true,
                "left": "110dp",
                "skin": "sknlblff000015px",
                "text": "sknlblff000015px",
                "top": "448dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample13 = new kony.ui.Label({
                "id": "lblSample13",
                "isVisible": true,
                "left": "52dp",
                "skin": "ICSkn3343a8labelSSPRegular15px",
                "text": "ICSkn3343a8labelSSPRegular15px",
                "top": "480dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSample14 = new kony.ui.Label({
                "id": "lblSample14",
                "isVisible": true,
                "left": "52dp",
                "skin": "ICSknBBLabelSSP42424220px",
                "text": "ICSknBBLabelSSP42424220px",
                "top": "512dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSample2.add(lblSample1, lblSample2, lblSample3, lblSample4, lblSample5, lblSample6, lblSample7, lblSample8, lblSample9, lblSample10, lblSample11, lblSample12, lblSample13, lblSample14);
            var tbxSample1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxSample1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1000dp",
                "placeholder": "ICSknTxtBoxPlaceholderSSP94949415px",
                "secureTextEntry": false,
                "skin": "ICSknTextBoxSSPR42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "100dp",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            var calSample1 = new kony.ui.Calendar({
                "calendarIcon": "calbtn.png",
                "dateComponents": [12, 8, 2021, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 12,
                "formattedDate": "12/08/2021",
                "height": "40dp",
                "hour": 0,
                "id": "calSample1",
                "isVisible": true,
                "left": "1000dp",
                "minutes": 0,
                "month": 8,
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "200dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "300dp",
                "year": 2021
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var calSample2 = new kony.ui.Calendar({
                "calendarIcon": "calbtn.png",
                "dateComponents": [12, 8, 2021, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 12,
                "formattedDate": "12/08/2021",
                "height": "40dp",
                "hour": 0,
                "id": "calSample2",
                "isVisible": true,
                "left": "1000dp",
                "minutes": 0,
                "month": 8,
                "seconds": 0,
                "skin": "sknCalTransactions",
                "top": "305dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "300dp",
                "year": 2021
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            this.compInstData = {}
            this.add(flxSample1, flxSample2, tbxSample1, calSample1, calSample2);
        };
        return [{
            "addWidgets": addWidgetsfrmStyleGuide,
            "enabledForIdleTimeout": false,
            "id": "frmStyleGuide",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ResourcesMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});