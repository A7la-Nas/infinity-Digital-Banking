define("ArrangementsMA/AccountServicesUIModule/frmConfirmClosure", function() {
    return function(controller) {
        function addWidgetsfrmConfirmClosure() {
            this.setDefaultUnit(kony.flex.DP);
            var formAccountClosure = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formAccountClosure",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formAccountClosure",
                "overrides": {
                    "flxContentPopup": {
                        "isVisible": false
                    },
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formAccountClosure_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmClosure"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmClosure"]["formAccountClosure"]) || {};
            formAccountClosure.serviceParameters = formAccountClosure_data.serviceParameters || {};
            formAccountClosure.customPopupData = formAccountClosure_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formAccountClosure.dataFormatting = formAccountClosure_data.dataFormatting || {};
            formAccountClosure.dataMapping = formAccountClosure_data.dataMapping || {};
            formAccountClosure.conditionalMappingKey = formAccountClosure_data.conditionalMappingKey || "";
            formAccountClosure.conditionalMapping = formAccountClosure_data.conditionalMapping || {};
            formAccountClosure.pageTitle = formAccountClosure_data.pageTitle || "Confirm Account Closure";
            formAccountClosure.pageTitlei18n = formAccountClosure_data.pageTitlei18n || "";
            formAccountClosure.primaryLinks = formAccountClosure_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formAccountClosure.flxMainWrapperzIndex = formAccountClosure_data.flxMainWrapperzIndex || 2;
            formAccountClosure.secondaryLinks = formAccountClosure_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formAccountClosure.supplementaryLinks = formAccountClosure_data.supplementaryLinks || [];
            formAccountClosure.pageTitleVisibility = formAccountClosure_data.pageTitleVisibility || true;
            formAccountClosure.logoConfig = formAccountClosure_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formAccountClosure.accountText = formAccountClosure_data.accountText || "";
            formAccountClosure.logoutConfig = formAccountClosure_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formAccountClosure.profileConfig = formAccountClosure_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formAccountClosure.activeMenuID = formAccountClosure_data.activeMenuID || "";
            formAccountClosure.activeSubMenuID = formAccountClosure_data.activeSubMenuID || "";
            formAccountClosure.backFlag = formAccountClosure_data.backFlag || false;
            formAccountClosure.hamburgerConfig = formAccountClosure_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formAccountClosure.backProperties = formAccountClosure_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formAccountClosure.breadCrumbProperties = formAccountClosure_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formAccountClosure.genricMessage = formAccountClosure_data.genricMessage || {};
            formAccountClosure.sessionTimeOutData = formAccountClosure_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formAccountClosure.footerProperties = formAccountClosure_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formAccountClosure.copyRight = formAccountClosure_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxTermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0",
                "width": "100%",
                "zIndex": 15,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "405dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "640dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "Button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this popup"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "btnClose",
                "top": "0",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, btnClose, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(rtxTC);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "85%",
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "CopyslFbox0e7e706a6ed2544",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "95%",
                "horizontalScrollIndicator": true,
                "id": "brwScroll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            brwScroll.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            brwScroll.add(brwBodyTnC);
            flxBody.add(brwScroll);
            var flxSpacing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(flxDummy, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditions.add(flxTC);
            formAccountClosure.flxContentPopup.add(flxTermsAndConditions);
            var flxAccountClosure = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountClosure",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0px",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountClosure.setDefaultUnit(kony.flex.DP);
            var flxAccountDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblAccountDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblAccountDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.accountDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "49dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountDetailsHeader.add(lblAccountDetails, lblSeparator1);
            var flxAlert = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxAlert",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlert.setDefaultUnit(kony.flex.DP);
            var flxAlertMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAlertMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "Copysknbbborderbox",
                "top": "10dp",
                "width": "95%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertMain.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgWarning",
                "isVisible": true,
                "left": "10dp",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxReasonsMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": false,
                "id": "flxReasonsMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReasonsMain.setDefaultUnit(kony.flex.DP);
            var segAlerts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblDot": "F",
                    "lblReason": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.accountFinalOpen\")"
                }],
                "groupCells": false,
                "id": "segAlerts",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAcClosure"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAcClosure": "flxAcClosure",
                    "lblDot": "lblDot",
                    "lblReason": "lblReason"
                },
                "width": "70%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReasonsMain.add(segAlerts);
            var lblAlertHeading = new kony.ui.Label({
                "id": "lblAlertHeading",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.noteTheFollowingDetails\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertMain.add(imgWarning, flxReasonsMain, lblAlertHeading);
            flxAlert.add(flxAlertMain);
            var flxCont = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCont",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCont.setDefaultUnit(kony.flex.DP);
            var lblAccountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.accountName\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValAccountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValAccountName",
                "isVisible": true,
                "left": "266dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumWithColon\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValAccountNumber",
                "isVisible": true,
                "left": "266dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountType",
                "isVisible": true,
                "left": "608dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountType\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValAccountType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValAccountType",
                "isVisible": true,
                "left": "818dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCurrentBalance",
                "isVisible": true,
                "left": "608dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.currentBalance\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValCurrentBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValCurrentBalance",
                "isVisible": true,
                "left": "818dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator2 = new kony.ui.Label({
                "height": "1px",
                "id": "lblSeparator2",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "top": "10dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCont.add(lblAccountName, lblValAccountName, lblAccountNumber, lblValAccountNumber, lblAccountType, lblValAccountType, lblCurrentBalance, lblValCurrentBalance, lblSeparator2);
            var flxSelectRepaymentDay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSelectRepaymentDay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectRepaymentDay.setDefaultUnit(kony.flex.DP);
            var lblReasonForClosing = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReasonForClosing",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.accountClosingReason\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClosingDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxClosingDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius2px",
                "top": "49dp",
                "width": "360dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClosingDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblDropdown",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.select\")",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "317dp",
                "isModalContainer": false,
                "top": "8dp",
                "width": "25dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblDropdownIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(lblDropdownIcon);
            flxClosingDropdown.add(lblDropdown, flxDropdown);
            var flxDropDownMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDropDownMenu",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "90dp",
                "width": "360dp",
                "zIndex": 100,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "onKeyPress": controller.AS_FlexContainer_jd88ab09927747a7b20ef26c7cc6ef2d
            });
            flxDropDownMenu.setDefaultUnit(kony.flex.DP);
            var segReasons = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblSeparator": "-",
                    "lblUsers": "Unhappy with our services."
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Dissatisfied with our product offering."
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Minmum/balance or charges are on higher side."
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Other"
                }],
                "groupCells": false,
                "id": "segReasons",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAccountTypes"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountTypes": "flxAccountTypes",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "onKeyPress": controller.AS_Segment_cb4ec61ada8d4880a9a710785c099959
            });
            flxDropDownMenu.add(segReasons);
            var flxGroupImageDoc = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGroupImageDoc",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "109dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupImageDoc.setDefaultUnit(kony.flex.DP);
            var lblSupportingDoc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSupportingDoc",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.supportingDocumentsOptional\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImageInfo1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about attaching supporting doc"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "15dp",
                "id": "flxImageInfo1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "2dp",
                "width": "15dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageInfo1.setDefaultUnit(kony.flex.DP);
            var imgInfo1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgInfo1",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey_2.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageInfo1.add(imgInfo1);
            flxGroupImageDoc.add(lblSupportingDoc, flxImageInfo1);
            var flxDocumentComponent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentComponent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "138dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentComponent.setDefaultUnit(kony.flex.DP);
            var uploadFiles3 = new com.InfinityOLB.ArrangementsMA.uploadFiles3({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "uploadFiles3",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "viewType": "uploadFiles3",
                "overrides": {
                    "uploadFiles3": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var uploadFiles3_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmConfirmClosure"] && appConfig.componentMetadata["ArrangementsMA"]["frmConfirmClosure"]["uploadFiles3"]) || {};
            uploadFiles3.inErrorState = uploadFiles3_data.inErrorState || false;
            uploadFiles3.maxFilesCount = uploadFiles3_data.maxFilesCount || 5;
            uploadFiles3.aaa = uploadFiles3_data.aaa || true;
            var lblSeparatorLine2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Label"
                },
                "height": "1dp",
                "id": "lblSeparatorLine2",
                "isVisible": true,
                "left": "0dp",
                "right": "30dp",
                "skin": "sknLabelD8D8D8",
                "text": "Label",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtons = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "71dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxCheckBoxMain = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "70%",
                "id": "flxCheckBoxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "40%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.setDefaultUnit(kony.flex.DP);
            var flxCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "checkbox",
                        "tabindex": 0
                    },
                    "a11yLabel": "I accept the Terms and Conditions"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": 30,
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCheckBox",
                "isVisible": true,
                "left": "0",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "D",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(lblCheckBox);
            var lblCheckMsg = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCheckMsg",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingspot.Iaccept\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTAndC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxTAndC",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTAndC.setDefaultUnit(kony.flex.DP);
            var lblTAndC = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblTAndC",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLblSSP4176A415Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.AddExternalAccountsTermsAndConditions.Title\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTAndC.add(lblTAndC);
            flxCheckBoxMain.add(flxCheckBox, lblCheckMsg, flxTAndC);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Confirm account closure details"
                },
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.tab.Confirm\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel account closure"
                },
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "175dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Cancel\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(flxCheckBoxMain, btnContinue, btnCancel);
            flxDocumentComponent.add(uploadFiles3, lblSeparatorLine2, flxButtons);
            var lblSuppDocWarning = new kony.ui.Label({
                "id": "lblSuppDocWarning",
                "isVisible": false,
                "left": "0",
                "skin": "sknlblee0005LatoReg15px",
                "text": "Label",
                "top": "305dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSuppDocInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "124dp",
                "id": "flxSuppDocInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "255dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "287dp",
                "width": "300dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.setDefaultUnit(kony.flex.DP);
            var lblAttachmentRules = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "height": "18dp",
                "id": "lblAttachmentRules",
                "isVisible": true,
                "left": 15,
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.attachmentRules\")",
                "top": 7,
                "width": "112dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop-up."
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxClose1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "7dp",
                "width": "25dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose1.setDefaultUnit(kony.flex.DP);
            var lblClose1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "lblClose1",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": "0dp",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose1.add(lblClose1);
            var lblSuppDocInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "54dp",
                "id": "lblSuppDocInfo",
                "isVisible": true,
                "left": 15,
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FileAttachmentErrorMessage\")",
                "top": 42,
                "width": "268dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.add(lblAttachmentRules, flxClose1, lblSuppDocInfo);
            flxSelectRepaymentDay.add(lblReasonForClosing, flxClosingDropdown, flxDropDownMenu, flxGroupImageDoc, flxDocumentComponent, lblSuppDocWarning, flxSuppDocInfo);
            flxAccountClosure.add(flxAccountDetailsHeader, flxAlert, flxCont, flxSelectRepaymentDay);
            formAccountClosure.flxContentTCCenter.add(flxAccountClosure);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formAccountClosure": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions"]
                    },
                    "flxClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxTermsAndConditionsHeader"]
                    },
                    "flxTCContents": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC"]
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC"]
                    },
                    "flxDummy": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails"]
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails"]
                    },
                    "brwScroll": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails", "flxBody"]
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails", "flxBody", "brwScroll"]
                    },
                    "flxAccountClosure": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter"]
                    },
                    "flxAccountDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "52px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "skn4B4B4BSemiBold13px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "flxCont": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "117dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "134dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountType": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountType": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblCurrentBalance": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValCurrentBalance": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblSeparator2": {
                        "skin": "sknSeparatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblReasonForClosing": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "flxClosingDropdown": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "lblDropdown": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown"]
                    },
                    "flxDropdown": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "92%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown"]
                    },
                    "lblDropdownIcon": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown", "flxDropdown"]
                    },
                    "flxDropDownMenu": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc"]
                    },
                    "imgInfo1": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc", "flxImageInfo1"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxDocumentComponent"]
                    },
                    "lblSeparatorLine2": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCheckBoxMain": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxCheckBox": {
                        "segmentProps": []
                    },
                    "lblCheckMsg": {
                        "segmentProps": []
                    },
                    "lblTAndC": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblff000013px",
                        "text": "The file size exceeds the maximum limit. Please make sure that the file you are uploading doesn’t exceed 2MB.",
                        "top": {
                            "type": "string",
                            "value": "291dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "269dp"
                        },
                        "segmentProps": []
                    },
                    "flxSuppDocInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxTC": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions"]
                    },
                    "rtxTC": {
                        "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Disabling e-Banking Access Agreements and Disclosures</b>\n<br/>\nCONSENT TO ELECTRONIC DELIVERY – You specifically agree to receive electronically your periodic Infinity account statement, credit card loan statement, notices, and any other disclosures or communications regarding your relationship with Temenos. You may still receive correspondence and notices via postal service. When statements, notices, and/or disclosures are available, you will receive an e-mail message, along with instructions on how to access them. A notice to any account owner will be considered a notice to all account owners. Any owner of this Infinity account has the right to establish an eStatement service for an account.\n<br/>\n<b>By giving us your phone number and submitting this application, you acknowledge that:</b>\n<br/>\n1. You've reviewed any special disclosure that applies in your state: ME, CA, NY, RI, OH, VT and WI residents\n2. All information you've submitted is true and correct and is given to obtain credit from us\nmay still receive correspondence and notices via postal service. \n3. When statements, notices, and/or disclosures are available, you will receive an e-mail message, along with instructions on how to access them\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxTCContents"]
                    },
                    "flxScrollDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC"]
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails"]
                    },
                    "brwScroll": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails", "flxBody"]
                    },
                    "brwBodyTnC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentPopup", "flxTermsAndConditions", "flxTC", "flxScrollDetails", "flxBody", "brwScroll"]
                    },
                    "flxAccountClosure": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter"]
                    },
                    "flxAccountDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "196dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountNumber": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountNumber": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "196dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountType": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "395dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountType": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "561dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblCurrentBalance": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "395dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValCurrentBalance": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "580dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblReasonForClosing": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "flxClosingDropdown": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "359dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "flxDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "333dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown"]
                    },
                    "flxDropDownMenu": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc"]
                    },
                    "imgInfo1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc", "flxImageInfo1"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "flxCheckBox": {
                        "segmentProps": []
                    },
                    "lblCheckMsg": {
                        "segmentProps": []
                    },
                    "lblTAndC": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "text": "Label",
                        "segmentProps": []
                    },
                    "flxSuppDocInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocInfo": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1366": {
                    "formAccountClosure": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxAccountClosure": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter"]
                    },
                    "flxAccountDetailsHeader": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountDetails": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "flxAlert": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountName": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountName": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountNumber": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountNumber": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblAccountType": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValAccountType": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblCurrentBalance": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblValCurrentBalance": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "lblSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblReasonForClosing": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "flxClosingDropdown": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "lblDropdown": {
                        "skin": "bbsknLbl94949415px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown"]
                    },
                    "flxDropdown": {
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxClosingDropdown"]
                    },
                    "flxDropDownMenu": {
                        "skin": "sknFlxffffffShadowd464545",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "segReasons": {
                        "rowSkin": "seg2Normal2",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxDropDownMenu"]
                    },
                    "lblSupportingDoc": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSuppDocWarning": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "sknlblee0005LatoReg15px",
                        "text": "The file size exceeds the maximum limit. Please make sure that the file you are uploading doesn’t exceed 2MB.",
                        "top": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSuppDocInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblAttachmentRules": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblClose1": {
                        "bottom": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "segmentProps": []
                    },
                    "lblSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxAccountClosure": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter"]
                    },
                    "flxAccountDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblAccountDetails": {
                        "skin": "sknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxAccountDetailsHeader"]
                    },
                    "flxCont": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxCont"]
                    },
                    "flxSelectRepaymentDay": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure"]
                    },
                    "lblReasonForClosing": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay"]
                    },
                    "lblSupportingDoc": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formAccountClosure", "flxContentTCCenter", "flxAccountClosure", "flxSelectRepaymentDay", "flxGroupImageDoc"]
                    },
                    "lblSeparatorLine2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCheckMsg": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSuppDocInfo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblAttachmentRules": {
                        "segmentProps": []
                    },
                    "lblSuppDocInfo": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formAccountClosure": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formAccountClosure.flxContentTCCenter.flxAccountClosure.flxSelectRepaymentDay.flxDocumentComponent.uploadFiles3": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formAccountClosure);
        };
        return [{
            "addWidgets": addWidgetsfrmConfirmClosure,
            "enabledForIdleTimeout": true,
            "id": "frmConfirmClosure",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_b57c9ab060e94e48aea5cd382de88e7b(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Account Closure - Confirmation",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});