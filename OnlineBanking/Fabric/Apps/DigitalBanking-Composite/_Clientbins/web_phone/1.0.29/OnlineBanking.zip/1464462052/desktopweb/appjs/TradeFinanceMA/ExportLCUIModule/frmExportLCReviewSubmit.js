define("TradeFinanceMA/ExportLCUIModule/frmExportLCReviewSubmit", function() {
    return function(controller) {
        function addWidgetsfrmExportLCReviewSubmit() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003e75Bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKonyHamburger": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblExportLCReviewSubmit = new kony.ui.Label({
                "id": "lblExportLCReviewSubmit",
                "isVisible": true,
                "left": "82dp",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Export LC - Drawing - Review & Submit",
                "top": "144dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSubHeader.add(lblExportLCReviewSubmit);
            var flxDrawingSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "201dp",
                "id": "flxDrawingSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummary.setDefaultUnit(kony.flex.DP);
            var flxDrawingSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDrawingSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxDrawingSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDrawingSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblDrawingSummary = new kony.ui.Label({
                "id": "lblDrawingSummary",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingSummarylbl.add(lblDrawingSummary);
            var flxBottomSeparatorDrawing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparatorDrawing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparatorDrawing.setDefaultUnit(kony.flex.DP);
            flxBottomSeparatorDrawing.add();
            flxDrawingSummaryHeader.add(flxDrawingSummarylbl, flxBottomSeparatorDrawing);
            var flxBodyContentSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "67dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary1.setDefaultUnit(kony.flex.DP);
            var lblDrawingStatus = new kony.ui.Label({
                "id": "lblDrawingStatus",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingStatus\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingStatusValue = new kony.ui.Label({
                "id": "lblDrawingStatusValue",
                "isVisible": true,
                "left": "280dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary1.add(lblDrawingStatus, lblDrawingStatusValue);
            var flxBodyContentSummary2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "105dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary2.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefNo = new kony.ui.Label({
                "id": "lblDrawingRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingRefNo\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefNoValue = new kony.ui.Label({
                "id": "lblDrawingRefNoValue",
                "isVisible": true,
                "left": "280dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary2.add(lblDrawingRefNo, lblDrawingRefNoValue);
            var flxBodyContentSummary3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "31dp",
                "id": "flxBodyContentSummary3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "140dp",
                "width": "425dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary3.setDefaultUnit(kony.flex.DP);
            var lblDrawingDate = new kony.ui.Label({
                "id": "lblDrawingDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingCreatedDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingDateValue = new kony.ui.Label({
                "id": "lblDrawingDateValue",
                "isVisible": true,
                "left": "280dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBodyContentSummary3.add(lblDrawingDate, lblDrawingDateValue);
            flxDrawingSummary.add(flxDrawingSummaryHeader, flxBodyContentSummary1, flxBodyContentSummary2, flxBodyContentSummary3);
            var flxLCSummaryTablet = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryTablet",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryTablet.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader02 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader02.setDefaultUnit(kony.flex.DP);
            var flxSummaryTopSeparatorLC02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSummaryTopSeparatorLC02",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryTopSeparatorLC02.setDefaultUnit(kony.flex.DP);
            flxSummaryTopSeparatorLC02.add();
            var flxLCSummayTablet02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummayTablet02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummayTablet02.setDefaultUnit(kony.flex.DP);
            var lblLCSummaryTablet02 = new kony.ui.Label({
                "id": "lblLCSummaryTablet02",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummayTablet02.add(lblLCSummaryTablet02);
            var flxViewLCDetails02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1.46%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "8.93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails02.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetailsTablet02 = new kony.ui.Label({
                "id": "lblViewLCDetailsTablet02",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View LC Details"
            });
            flxViewLCDetails02.add(lblViewLCDetailsTablet02);
            var flxSummaryBottomSeparator02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSummaryBottomSeparator02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryBottomSeparator02.setDefaultUnit(kony.flex.DP);
            flxSummaryBottomSeparator02.add();
            flxLCSummaryHeader02.add(flxSummaryTopSeparatorLC02, flxLCSummayTablet02, flxViewLCDetails02, flxSummaryBottomSeparator02);
            var segLCSummaryContent = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "32dp",
                "data": [{
                    "lblReview": "Other Additional Conditions (Optional):",
                    "lblReviewValue1": "$2789.89"
                }],
                "groupCells": false,
                "id": "segLCSummaryContent",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingsRowTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingsRowTemplate": "flxDrawingsRowTemplate",
                    "flxReviewRight": "flxReviewRight",
                    "flxReviewValues": "flxReviewValues",
                    "flxreviewRows": "flxreviewRows",
                    "lblReview": "lblReview",
                    "lblReviewValue1": "lblReviewValue1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummaryTablet.add(flxLCSummaryHeader02, segLCSummaryContent);
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "88%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.add(lblLCSummary);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var flxViewLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "75%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25%",
                "width": "23.95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetials = new kony.ui.Label({
                "height": "30dp",
                "id": "lblViewLCDetials",
                "isVisible": true,
                "left": "60%",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0dp",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.add(lblViewLCDetials);
            flxLCSummaryHeader.add(flxLCSummarylbl, flxBottomSeparator, flxViewLCDetails);
            var flxBodyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64.38%",
                "id": "flxBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32%",
                "width": "30.83%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContent.setDefaultUnit(kony.flex.DP);
            var flxContentLabel1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel1.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "height": "18dp",
                "id": "lblApplicant",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "0",
                "width": "364dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantName = new kony.ui.Label({
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "70dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel1.add(lblApplicant, lblApplicantName);
            var flxContentLabel2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel2.setDefaultUnit(kony.flex.DP);
            var lblLCRefNo = new kony.ui.Label({
                "id": "lblLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AdvisingLCRefNo\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRightLCRefNo = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRightLCRefNo",
                "isVisible": true,
                "left": "125dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel2.add(lblLCRefNo, lblRightLCRefNo);
            var flxContentLabel3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel3.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeValue = new kony.ui.Label({
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel3.add(lblLCType, lblLCTypeValue);
            var flxContentLabel4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel4.setDefaultUnit(kony.flex.DP);
            var lblIssueBank = new kony.ui.Label({
                "id": "lblIssueBank",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssuingBank\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueBankValue = new kony.ui.Label({
                "id": "lblIssueBankValue",
                "isVisible": true,
                "left": "88dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel4.add(lblIssueBank, lblIssueBankValue);
            flxBodyContent.add(flxContentLabel1, flxContentLabel2, flxContentLabel3, flxContentLabel4);
            var flxBodyContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxBodyContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "421dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "105dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentRight.setDefaultUnit(kony.flex.DP);
            var flxContentRight1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight1.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCAmount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValue = new kony.ui.Label({
                "id": "lblLCAmountValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight1.add(lblLCAmount, lblLCAmountValue);
            var flxContentRight2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight2.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "id": "lblIssueDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssueDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateValue = new kony.ui.Label({
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "75dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight2.add(lblIssueDate, lblIssueDateValue);
            var flxContentRight3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "76dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight3.setDefaultUnit(kony.flex.DP);
            var lblIssueLCRefNo = new kony.ui.Label({
                "id": "lblIssueLCRefNo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.IssuingLCRefNo\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingRefNoValue = new kony.ui.Label({
                "id": "lblIssuingRefNoValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight3.add(lblIssueLCRefNo, lblIssuingRefNoValue);
            flxBodyContentRight.add(flxContentRight1, flxContentRight2, flxContentRight3);
            var flxBodyContentLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxBodyContentLast",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "816dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "105dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentLast.setDefaultUnit(kony.flex.DP);
            var flxContentLast1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast1.setDefaultUnit(kony.flex.DP);
            var lblLCUntilizedAmount = new kony.ui.Label({
                "id": "lblLCUntilizedAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCUntilizedAmount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCUntilizedAmountValue = new kony.ui.Label({
                "id": "lblLCUntilizedAmountValue",
                "isVisible": true,
                "left": "136dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast1.add(lblLCUntilizedAmount, lblLCUntilizedAmountValue);
            var flxContentLast2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast2.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.ExpiryDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "80dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast2.add(lblExpiryDate, lblExpiryDateValue);
            flxBodyContentLast.add(flxContentLast1, flxContentLast2);
            flxLCSummaryBody.add(flxLCSummaryHeader, flxBodyContent, flxBodyContentRight, flxBodyContentLast);
            var flxDiscrepanciesandResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesandResponse",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponse.setDefaultUnit(kony.flex.DP);
            var flxDiscrepanciesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDiscrepanciesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxDiscrepanciesandResponseLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDiscrepanciesandResponseLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.setDefaultUnit(kony.flex.DP);
            var DiscrepanciesandResponseValue = new kony.ui.Label({
                "id": "DiscrepanciesandResponseValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DiscrepanciesandResponse\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.add(DiscrepanciesandResponseValue);
            var flxBottomSeparater = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparater",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparater.setDefaultUnit(kony.flex.DP);
            flxBottomSeparater.add();
            var flxDiscrepancyDropdown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "31dp",
                "id": "flxDiscrepancyDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95.96%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyDropdown.setDefaultUnit(kony.flex.DP);
            var imgDiscrepancyDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDiscrepancyDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyDropdown.add(imgDiscrepancyDropdown);
            flxDiscrepanciesHeader.add(flxTopSeperator, flxDiscrepanciesandResponseLabel, flxBottomSeparater, flxDiscrepancyDropdown);
            var flxDiscrepanciesMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesMain.setDefaultUnit(kony.flex.DP);
            var flxTotalDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocuments.setDefaultUnit(kony.flex.DP);
            var lblTotalDocuments = new kony.ui.Label({
                "id": "lblTotalDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TotalDocuments\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxtotoalDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxtotoalDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalDocumentsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalDocumentsValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.add(lblTotalDocumentsValue);
            flxTotalDocumentsValue.add(flxtotoalDocumentsValueContainer);
            flxTotalDocuments.add(lblTotalDocuments, flxTotalDocumentsValue);
            var flxDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocuments.setDefaultUnit(kony.flex.DP);
            var lblDocuments = new kony.ui.Label({
                "id": "lblDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Documents\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var segDocumentsValueContainer = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblHeading": "Clearance Statement.pdf"
                }, {
                    "lblHeading": "Statement1.pdf"
                }, {
                    "lblHeading": "Invoices.pdf"
                }, {
                    "lblHeading": "Statement2.pdf"
                }],
                "groupCells": false,
                "id": "segDocumentsValueContainer",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSectionHeaderTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSectionHeaderTemplate": "flxSectionHeaderTemplate",
                    "lblHeading": "lblHeading"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.add(segDocumentsValueContainer);
            flxDocumentsValue.add(flxDocumentsValueContainer);
            flxDocuments.add(lblDocuments, flxDocumentsValue);
            var flxDocStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatus.setDefaultUnit(kony.flex.DP);
            var lblDocStatus = new kony.ui.Label({
                "id": "lblDocStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DocumentStatus\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValue.setDefaultUnit(kony.flex.DP);
            var flxDocStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblDocStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblDocStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Discrepant",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.add(lblDocStatusValue);
            flxDocStatusValue.add(flxDocStatusValueContainer);
            flxDocStatus.add(lblDocStatus, flxDocStatusValue);
            var flxDiscrepancyResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancyResponse",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.setDefaultUnit(kony.flex.DP);
            var segDiscrepancyResponse = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReasonforReturn\")",
                    "lblRight1": "Check the Packing list and Shipping advise and clear this",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Discrepancy1\")",
                    "lblRight1": "Packing list not signed",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D1UserResponse\")",
                    "lblRight1": "I Accept this discrepancy, I will submit a revised document",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Discrepancy2\")",
                    "lblRight1": "Shipping Advise stamop is missing",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D2UserResponse\")",
                    "lblRight1": "I Accept this discrepancy, Please proceed with the existing documnet",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.D2UserComment\")",
                    "lblRight1": "Shipping has startewd",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }, {
                    "lblLeft1": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ReturnMessagetoBank\")",
                    "lblRight1": "Kindly forward this with revised Packing list",
                    "lblRight2": "Label",
                    "lblRight3": "Label",
                    "lblRight4": "Label"
                }],
                "groupCells": false,
                "id": "segDiscrepancyResponse",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingDetailsExport"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                    "flxRight1": "flxRight1",
                    "lblLeft1": "lblLeft1",
                    "lblRight1": "lblRight1",
                    "lblRight2": "lblRight2",
                    "lblRight3": "lblRight3",
                    "lblRight4": "lblRight4"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.add(segDiscrepancyResponse);
            flxDiscrepanciesMain.add(flxTotalDocuments, flxDocuments, flxDocStatus, flxDiscrepancyResponse);
            flxDiscrepanciesandResponse.add(flxDiscrepanciesHeader, flxDiscrepanciesMain);
            var flxDrawingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxDrawingDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "99.42%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingDetails = new kony.ui.Label({
                "id": "lblDrawingDetails",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.RevisetheDrawing\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingDetailsDropdown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "29dp",
                "id": "flxDrawingDetailsDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "96%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "29dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown = new kony.ui.Image2({
                "height": "29dp",
                "id": "imgDrawingDetailsDropdown",
                "isVisible": false,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "29dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.add(imgDrawingDetailsDropdown);
            flxDrawingDetailsHeader.add(lblDrawingDetails, flxDrawingDetailsDropdown);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxDrawingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingContent.setDefaultUnit(kony.flex.DP);
            var flxDrawingRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingRef.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingRefKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DrawingAmount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefValue = new kony.ui.Label({
                "id": "lblDrawingRefValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingRef.add(lblDrawingRefKey, lblDrawingRefValue);
            var flxAmountCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCredited",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCredited.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblAmountCreditedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmounttobeCreditedto\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountCrediredValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCrediredValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedValue = new kony.ui.Label({
                "id": "lblAmountCreditedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountCreditedValueInfo = new kony.ui.Label({
                "id": "lblAmountCreditedValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.OtherBeneficiaryName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.add(lblAmountCreditedValue, lblAmountCreditedValueInfo);
            flxAmountCredited.add(lblAmountCreditedKey, flxAmountCrediredValue);
            var flxFinanceUS = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUS",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUS.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblFinanceUSKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Financeus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFinanceUSValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUSValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSValue = new kony.ui.Label({
                "id": "lblFinanceUSValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFinanceUSInfo = new kony.ui.Label({
                "id": "lblFinanceUSInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PleaseFinanceUs\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.add(lblFinanceUSValue, lblFinanceUSInfo);
            flxFinanceUS.add(lblFinanceUSKey, flxFinanceUSValue);
            var flxUploadDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocs.setDefaultUnit(kony.flex.DP);
            var lblUploadDocsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblUploadDocsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.UploadDocuments\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadDocsValue = new kony.ui.Label({
                "id": "lblUploadDocsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segUploadDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}],
                "groupCells": false,
                "id": "segUploadDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValue"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDocs.add(lblUploadDocsKey, lblUploadDocsValue, segUploadDocuments);
            var flxPhysicalDocDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalDocDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocDetailsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPhysicalDocDetailsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PhysicalDocumentDetails\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhysicalDocDetailsValue = new kony.ui.Label({
                "id": "lblPhysicalDocDetailsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segPhysicalDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}],
                "groupCells": false,
                "id": "segPhysicalDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDropdownValue"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.add(lblPhysicalDocDetailsKey, lblPhysicalDocDetailsValue, segPhysicalDocuments);
            var flxDiscrepancies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancies.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDiscrepanciesKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Forwarddespiteanydiscrepancies\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDiscrepanciesValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesValue = new kony.ui.Label({
                "id": "lblDiscrepanciesValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDiscrepanciesValueInfo = new kony.ui.Label({
                "id": "lblDiscrepanciesValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.KindlyForwardDoc\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.add(lblDiscrepanciesValue, lblDiscrepanciesValueInfo);
            flxDiscrepancies.add(lblDiscrepanciesKey, flxDiscrepanciesValue);
            var flxChargesDebit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChargesDebit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesDebit.setDefaultUnit(kony.flex.DP);
            var lblChargesDebitKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblChargesDebitKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ChargesDebitAccount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChargesDebitValue = new kony.ui.Label({
                "id": "lblChargesDebitValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChargesDebit.add(lblChargesDebitKey, lblChargesDebitValue);
            var flxMsgToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMsgToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsgToBank.setDefaultUnit(kony.flex.DP);
            var lblMsgToBankKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblMsgToBankKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBank\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMsgToBankValue = new kony.ui.Label({
                "id": "lblMsgToBankValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.CommonWarning\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsgToBank.add(lblMsgToBankKey, lblMsgToBankValue);
            flxDrawingContent.add(flxDrawingRef, flxAmountCredited, flxFinanceUS, flxUploadDocs, flxPhysicalDocDetails, flxDiscrepancies, flxChargesDebit, flxMsgToBank);
            var flxSeparatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "30dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom.add();
            var flxReviewSubmitButtons = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxReviewSubmitButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "top": "25dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReviewSubmitButtons.setDefaultUnit(kony.flex.DP);
            var btnSubmitReview = new kony.ui.Button({
                "height": "40dp",
                "id": "btnSubmitReview",
                "isVisible": true,
                "right": "3%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Submit\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackReview = new kony.ui.Button({
                "height": "40dp",
                "id": "btnBackReview",
                "isVisible": true,
                "right": "2%",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCloseReview = new kony.ui.Button({
                "height": "40dp",
                "id": "btnCloseReview",
                "isVisible": true,
                "right": "2%",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReviewSubmitButtons.add(btnSubmitReview, btnBackReview, btnCloseReview);
            flxDrawingDetails.add(flxDrawingDetailsHeader, flxSeparator, flxDrawingContent, flxSeparatorBottom, flxReviewSubmitButtons);
            flxMain.add(flxSubHeader, flxDrawingSummary, flxLCSummaryTablet, flxLCSummaryBody, flxDiscrepanciesandResponse, flxDrawingDetails);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxFooterMenu": {
                        "left": "7%"
                    },
                    "lblCopyright": {
                        "left": "7%",
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "215dp",
                "clipBounds": false,
                "height": "268dp",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxViewLCDetailsPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewLCDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "630dp",
                "horizontalScrollIndicator": true,
                "id": "flxLCDetailsPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknNoBorder",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "50%"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxLCDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblLCDetailsHeader = new kony.ui.Label({
                "id": "lblLCDetailsHeader",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "View LC Details",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "12dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCross",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var flxSeparator02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "49dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator02.setDefaultUnit(kony.flex.DP);
            flxSeparator02.add();
            flxLCDetailsHeader.add(lblLCDetailsHeader, flxCross, flxSeparator02);
            var flxLCDetailsData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetailsData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsData.setDefaultUnit(kony.flex.DP);
            var flxLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetails.setDefaultUnit(kony.flex.DP);
            var lblLcDetails = new kony.ui.Label({
                "id": "lblLcDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCDetails\")",
                "top": "10dp",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "93.07%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop.add();
            var flxLCSummaryBody02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryBody02",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "565dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody02.setDefaultUnit(kony.flex.DP);
            var flxLeftLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoKey = new kony.ui.Label({
                "id": "lblLCRefNoKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCReferenceNumber\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeKey = new kony.ui.Label({
                "id": "lblLCTypeKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantKey = new kony.ui.Label({
                "id": "lblApplicantKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantAddressKey = new kony.ui.Label({
                "id": "lblApplicantAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Applicant Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankKey = new kony.ui.Label({
                "id": "lblIssuingBankKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankAddressKey = new kony.ui.Label({
                "id": "lblIssuingBankAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateKey = new kony.ui.Label({
                "id": "lblIssueDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Issue Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpireDateKey = new kony.ui.Label({
                "id": "lblExpireDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountKey = new kony.ui.Label({
                "id": "lblLCAmountKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Amount: ",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.add(lblLCRefNoKey, lblLCTypeKey, lblApplicantKey, lblApplicantAddressKey, lblIssuingBankKey, lblIssuingBankAddressKey, lblIssueDateKey, lblExpireDateKey, lblLCAmountKey);
            var flxRightLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "85dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoValue = new kony.ui.Label({
                "id": "lblLCRefNoValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeeValue = new kony.ui.Label({
                "id": "lblLCTypeeValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantValue = new kony.ui.Label({
                "id": "lblLCApplicantValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantAddValue = new kony.ui.Label({
                "id": "lblLCApplicantAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankalue = new kony.ui.Label({
                "id": "lblLCIssueBankalue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankAddValue = new kony.ui.Label({
                "id": "lblLCIssueBankAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueDateValue = new kony.ui.Label({
                "id": "lblLCIssueDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCExpireDateValue = new kony.ui.Label({
                "id": "lblLCExpireDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValuee = new kony.ui.Label({
                "id": "lblLCAmountValuee",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.add(lblLCRefNoValue, lblLCTypeeValue, lblLCApplicantValue, lblLCApplicantAddValue, lblLCIssueBankalue, lblLCIssueBankAddValue, lblLCIssueDateValue, lblLCExpireDateValue, lblLCAmountValuee);
            flxLCSummaryBody02.add(flxLeftLCSummary, flxRightLCSummary);
            var flxSeparatorTop02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorTop02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "97.71%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop02.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop02.add();
            flxLCDetails.add(lblLcDetails, flxSeparatorTop, flxLCSummaryBody02, flxSeparatorTop02);
            var flxBeneficiaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryDetails.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryDetails = new kony.ui.Label({
                "id": "lblBeneficiaryDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Beneficiary Details",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorMid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorMid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "40dp",
                "width": "93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMid.setDefaultUnit(kony.flex.DP);
            flxSeparatorMid.add();
            var flxBeneficiaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "60dp",
                "width": "440dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryBody.setDefaultUnit(kony.flex.DP);
            var flxBenLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenLeft.setDefaultUnit(kony.flex.DP);
            var lblBenName = new kony.ui.Label({
                "id": "lblBenName",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddress = new kony.ui.Label({
                "id": "lblBenAddress",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenLeft.add(lblBenName, lblBenAddress);
            var flxBenRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "140dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenRight.setDefaultUnit(kony.flex.DP);
            var lblBenNameValue = new kony.ui.Label({
                "id": "lblBenNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddValue = new kony.ui.Label({
                "id": "lblBenAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenRight.add(lblBenNameValue, lblBenAddValue);
            flxBeneficiaryBody.add(flxBenLeft, flxBenRight);
            var flxSeparatorBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "140dp",
                "width": "98.72%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBen.setDefaultUnit(kony.flex.DP);
            flxSeparatorBen.add();
            flxBeneficiaryDetails.add(lblBeneficiaryDetails, flxSeparatorMid, flxBeneficiaryBody, flxSeparatorBen);
            var flxGoodShipment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipment.setDefaultUnit(kony.flex.DP);
            var lblGoodShipment = new kony.ui.Label({
                "id": "lblGoodShipment",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Good & Shipment Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorGoods = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorGoods",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "45dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorGoods.setDefaultUnit(kony.flex.DP);
            flxSeparatorGoods.add();
            var flxGoodShipmentBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipmentBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipmentBody.setDefaultUnit(kony.flex.DP);
            var flxGoodsLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.setDefaultUnit(kony.flex.DP);
            var lblGoodsDescription = new kony.ui.Label({
                "id": "lblGoodsDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Goods Description:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdditionalCon = new kony.ui.Label({
                "id": "lblAdditionalCon",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Additional Conditions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirm = new kony.ui.Label({
                "id": "lblConfirm",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Confirm Instructions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentDate = new kony.ui.Label({
                "id": "lblShipmentDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Latest Shipment Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.add(lblGoodsDescription, lblAdditionalCon, lblConfirm, lblShipmentDate);
            var flxGoodsRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsRight.setDefaultUnit(kony.flex.DP);
            var lblDescriptionValue = new kony.ui.Label({
                "id": "lblDescriptionValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddValue = new kony.ui.Label({
                "id": "lblAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirmValue = new kony.ui.Label({
                "id": "lblConfirmValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentValue = new kony.ui.Label({
                "id": "lblShipmentValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsRight.add(lblDescriptionValue, lblAddValue, lblConfirmValue, lblShipmentValue);
            flxGoodShipmentBody.add(flxGoodsLeft, flxGoodsRight);
            var flxSeparatorBottom01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "200dp",
                "width": "98%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom01.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom01.add();
            flxGoodShipment.add(lblGoodShipment, flxSeparatorGoods, flxGoodShipmentBody, flxSeparatorBottom01);
            var flxDocumentTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTerms.setDefaultUnit(kony.flex.DP);
            var lblDocumentTerms = new kony.ui.Label({
                "id": "lblDocumentTerms",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Documents and Terms",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument02.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument02.add();
            var flxDocumentTermsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTermsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTermsBody.setDefaultUnit(kony.flex.DP);
            var flxLeftContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContent.setDefaultUnit(kony.flex.DP);
            var lblDocumentName = new kony.ui.Label({
                "id": "lblDocumentName",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Document Name:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadedFiles = new kony.ui.Label({
                "id": "lblUploadedFiles",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Uploaded Files:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftContent.add(lblDocumentName, lblUploadedFiles);
            var flxRightContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContent.setDefaultUnit(kony.flex.DP);
            var lblDocNameValue = new kony.ui.Label({
                "id": "lblDocNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadedDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.setDefaultUnit(kony.flex.DP);
            var segUploadedDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUploadedDocs",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportLCUploadDocPopup"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocContent": "flxDocContent",
                    "flxDocumentName": "flxDocumentName",
                    "flxExportLCUploadDocPopup": "flxExportLCUploadDocPopup",
                    "flxMain": "flxMain",
                    "flxPDFImage": "flxPDFImage",
                    "imgPDF": "imgPDF",
                    "lblDocumentName": "lblDocumentName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedDocs.add(segUploadedDocs);
            flxRightContent.add(lblDocNameValue, flxUploadedDocs);
            flxDocumentTermsBody.add(flxLeftContent, flxRightContent);
            var flxSeparatorBottomDoc = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorBottomDoc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottomDoc.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottomDoc.add();
            flxDocumentTerms.add(lblDocumentTerms, flxSeparatorDocument02, flxDocumentTermsBody, flxSeparatorBottomDoc);
            var flxSwiftMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "97.32%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessage.setDefaultUnit(kony.flex.DP);
            var lblSwiftMessage = new kony.ui.Label({
                "id": "lblSwiftMessage",
                "isVisible": true,
                "left": 10,
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "SWIFT Message and Advises Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "35dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument.add();
            var flxSwiftMessageBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxSwiftMessageBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageBody.setDefaultUnit(kony.flex.DP);
            var flxSwiftMessageLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessageLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.setDefaultUnit(kony.flex.DP);
            var lblMessageType = new kony.ui.Label({
                "id": "lblMessageType",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Type:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDelivered = new kony.ui.Label({
                "id": "lblDelivered",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Delivered To/From:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDate = new kony.ui.Label({
                "id": "lblSwiftDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategory = new kony.ui.Label({
                "id": "lblMessageCategory",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Category:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.add(lblMessageType, lblDelivered, lblSwiftDate, lblMessageCategory);
            var flxSwiftMessagesRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessagesRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "103dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.setDefaultUnit(kony.flex.DP);
            var lblMessageTypeValue = new kony.ui.Label({
                "id": "lblMessageTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliveredValue = new kony.ui.Label({
                "id": "lblDeliveredValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDateValue = new kony.ui.Label({
                "id": "lblSwiftDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoryValue = new kony.ui.Label({
                "id": "lblMessageCategoryValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.add(lblMessageTypeValue, lblDeliveredValue, lblSwiftDateValue, lblMessageCategoryValue);
            flxSwiftMessageBody.add(flxSwiftMessageLeft, flxSwiftMessagesRight);
            flxSwiftMessage.add(lblSwiftMessage, flxSeparatorDocument, flxSwiftMessageBody);
            flxLCDetailsData.add(flxLCDetails, flxBeneficiaryDetails, flxGoodShipment, flxDocumentTerms, flxSwiftMessage);
            flxLCDetailsPopup.add(flxLCDetailsHeader, flxLCDetailsData);
            flxViewLCDetailsPopup.add(flxLCDetailsPopup);
            flxDialogs.add(flxLogout, flxViewLCDetailsPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.imgKonyHamburger": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Import LC",
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "skin": "s8b9c3471e9f4cdcb3133f2cb3fec6fa",
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDrawing": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader02": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummayTablet02": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCSummaryTablet02": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxViewLCDetails02": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator02": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segLCSummaryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "DiscrepanciesandResponseValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": []
                    },
                    "flxBottomSeparater": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepancyDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDiscrepancyDropdown": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxtotoalDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewSubmitButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknFlxBordere3e3e3Radius3Px",
                        "segmentProps": []
                    },
                    "btnSubmitReview": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackReview": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnCloseReview": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody02": {
                        "segmentProps": []
                    },
                    "lblLCRefNoKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCRefNoValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeeValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankalue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "Default": {
                            "contentAlignment": 4
                        },
                        "accessibilityConfig": {},
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "text": "User entered message will appear here in two lines with truncation in the en..",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "segmentProps": []
                    },
                    "lblExportLCReviewSubmit": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingSummary": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparatorDrawing": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "lblDrawingStatusValue": {
                        "segmentProps": []
                    },
                    "lblDrawingRefNoValue": {
                        "segmentProps": []
                    },
                    "lblDrawingDateValue": {
                        "segmentProps": []
                    },
                    "flxLCSummaryTablet": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummayTablet02": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetails02": {
                        "right": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblViewLCDetailsTablet02": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator02": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "segLCSummaryContent": {
                        "data": [{
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Applicant:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Katie Floyd"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising LC Ref No:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC0000100001"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Amount:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 2,567.87"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Untilized Amount:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 2,567.87"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Type:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Sight"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issue Date:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "10/11/2021"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Expiry Date:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12/31/2022"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issuing Bank:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Bank of America"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issuing LC Ref No:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "5678098765"
                            }
                        }],
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingsRowTemplate"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingsRowTemplate": "flxDrawingsRowTemplate",
                            "flxReviewRight": "flxReviewRight",
                            "flxReviewValues": "flxReviewValues",
                            "flxreviewRows": "flxreviewRows",
                            "lblReview": "lblReview",
                            "lblReviewValue1": "lblReviewValue1"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxLCSummaryBody": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparater": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepancyDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.82%"
                        },
                        "segmentProps": []
                    },
                    "imgDiscrepancyDropdown": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "307dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnSubmitReview": {
                        "segmentProps": []
                    },
                    "btnBackReview": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnCloseReview": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "zIndex": 5000,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50.06%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "text": "Export LC - LC0000100001",
                        "segmentProps": []
                    },
                    "flxCross": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsData": {
                        "segmentProps": []
                    },
                    "flxLCDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody02": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTop02": {
                        "segmentProps": []
                    },
                    "flxBeneficiaryDetails": {
                        "segmentProps": []
                    },
                    "flxSeparatorMid": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBen": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipment": {
                        "segmentProps": []
                    },
                    "flxSeparatorGoods": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipmentBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdditionalCon": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirm": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodsRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "lblAddValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom01": {
                        "top": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentTerms": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument02": {
                        "segmentProps": []
                    },
                    "flxDocumentTermsBody": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottomDoc": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument": {
                        "segmentProps": []
                    },
                    "flxSwiftMessageBody": {
                        "segmentProps": []
                    },
                    "lblDelivered": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategory": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSwiftMessagesRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDeliveredValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDateValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoryValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "segmentProps": []
                    },
                    "flxReviewSubmitButtons": {
                        "segmentProps": []
                    },
                    "btnCloseReview": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxSubHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountCreditedValueInfo": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblFinanceUSInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesValueInfo": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewSubmitButtons": {
                        "segmentProps": []
                    },
                    "btnSubmitReview": {
                        "segmentProps": []
                    },
                    "btnBackReview": {
                        "segmentProps": []
                    },
                    "btnCloseReview": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody02": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customfooternew.flxFooterMenu": {
                    "left": "7%"
                },
                "customfooternew.lblCopyright": {
                    "left": "7%",
                    "top": "75dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCReviewSubmit,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCReviewSubmit",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_fa98595712384e65843af7605633d718,
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});