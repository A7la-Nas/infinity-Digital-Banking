define("ApprovalRequestMA/ApprovalsReqUIModule/frmApprovalViewDetailsNew", function() {
    return function(controller) {
        function addWidgetsfrmApprovalViewDetailsNew() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "headermenu": {
                        "height": "70dp",
                        "right": "6%",
                        "top": "0dp",
                        "width": "94%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "maxWidth": "1366dp",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxContentHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "96dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "11.20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "height": "25dp",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlblUserName",
                "text": "Request 1",
                "top": "20dp",
                "width": "86dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBackToPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBackToPending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "185dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackToPending.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "height": "19dp",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_left.png",
                "top": "10dp",
                "width": "5dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackToPending = new kony.ui.Label({
                "id": "lblBackToPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP4176a415px",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackToPending.add(imgBack, lblBackToPending);
            flxContentHeader.add(lblContentHeader, flxBackToPending);
            var flxContentContainerRight = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxContentContainerRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "98dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainerRight.setDefaultUnit(kony.flex.DP);
            var ApprovalRoadMapElement = new com.InfinityOLB.Resources.ApprovalRoadMapElement({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ApprovalRoadMapElement",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "ApprovalRoadMapElement": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxApprovalRoadMapElementMobile": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false
                    },
                    "flxApprovalRoadMapElementTablet": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "top": "0"
                    },
                    "flxDropDownHeaderTablet": {
                        "height": "85dp",
                        "width": "100%"
                    },
                    "flxDropDownIconTablet": {
                        "right": "30dp"
                    },
                    "flxHeaderLabelWrapperTablet": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "left": "30dp",
                        "top": "viz.val_cleared"
                    },
                    "lblRoadMapHeaderTablet": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxContentContainerRight.add(ApprovalRoadMapElement);
            var flxContentContainerLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentContainerLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "11.20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "101dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainerLeft.setDefaultUnit(kony.flex.DP);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "bottom": "30dp",
                "clipBounds": false,
                "height": "110dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalViewDetailsNew"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalViewDetailsNew"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "115dp"
                    },
                    "flxAcknowledgementNew": {
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "isVisible": false
                    },
                    "flxTickImage": {
                        "height": "50dp"
                    },
                    "imgDownload": {
                        "src": "bbdownloadicon.png"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "imgTick": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    }
                }
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slfBoxffffffB1R5",
                "id": "flxTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var flxACHFileUploadDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "200dp",
                "id": "flxACHFileUploadDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFileUploadDetails.setDefaultUnit(kony.flex.DP);
            var lblACHfileDetails = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblACHfileDetails",
                "isVisible": true,
                "left": "2.60%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.YourACHFileDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "49.80%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "94.60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            var imgTopSeparatorEmpty = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgTopSeparatorEmpty",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopSeparator.add(imgTopSeparatorEmpty);
            var flxFomatType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "49.80%",
                "clipBounds": true,
                "id": "flxFomatType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": 20,
                "width": "94.60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFomatType.setDefaultUnit(kony.flex.DP);
            var lblFomatTypeAck = new kony.ui.Label({
                "id": "lblFomatTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.FormatTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFormatTypeValue = new kony.ui.Label({
                "id": "lblFormatTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Nacha",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFomatType.add(lblFomatTypeAck, lblFormatTypeValue);
            var flxFileUploadRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "49.90%",
                "clipBounds": true,
                "id": "flxFileUploadRequest",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "94.60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadRequest.setDefaultUnit(kony.flex.DP);
            var lblRequestTypeAck = new kony.ui.Label({
                "id": "lblRequestTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.RequestTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestTypeValue = new kony.ui.Label({
                "id": "lblRequestTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "PPD",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileUploadRequest.add(lblRequestTypeAck, lblRequestTypeValue);
            var flxFileUploadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "49.90%",
                "clipBounds": true,
                "id": "flxFileUploadAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "94.60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadAck.setDefaultUnit(kony.flex.DP);
            var lblUploadedFile = new kony.ui.Label({
                "id": "lblUploadedFile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.UploadedFileColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedFileAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxUploadedFileAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "270dp",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": 330,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileAck.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImageAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImageAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImageAck.setDefaultUnit(kony.flex.DP);
            var imgFileTypeAck = new kony.ui.Image2({
                "height": "100%",
                "id": "imgFileTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_image.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileTypeImageAck.add(imgFileTypeAck);
            var lblFileNameAck = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFileNameAck",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknBBLato0273e315px",
                "text": "FileName.Nacha",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgdownloadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgdownloadAck",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "width": "20dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.setDefaultUnit(kony.flex.DP);
            var imgDownloadFIleAck = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgDownloadFIleAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.add(imgDownloadFIleAck);
            flxUploadedFileAck.add(flxFileTypeImageAck, lblFileNameAck, flxImgdownloadAck);
            flxFileUploadAck.add(lblUploadedFile, flxUploadedFileAck);
            flxACHFileUploadDetails.add(lblACHfileDetails, flxTopSeparator, flxFomatType, flxFileUploadRequest, flxFileUploadAck);
            var NonEditableDetailsforApprovals = new com.InfinityOLB.ApprovalRequestMA.NonEditableDetailsforApprovals({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableDetailsforApprovals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "8dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxTemplateRecordHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "115dp",
                "id": "flxTemplateRecordHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordHeader.setDefaultUnit(kony.flex.DP);
            var lblRecordHeader1 = new kony.ui.Label({
                "id": "lblRecordHeader1",
                "isVisible": true,
                "left": "2.60%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CreditorDestinationAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRecordHeader2 = new kony.ui.Label({
                "id": "lblRecordHeader2",
                "isVisible": true,
                "left": "2.60%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.accountInfo\")",
                "top": "70dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "49.89%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 50,
                "width": "94.66%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.setDefaultUnit(kony.flex.DP);
            var lblSampleHeader = new kony.ui.Label({
                "id": "lblSampleHeader",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.add(lblSampleHeader);
            flxTemplateRecordHeader.add(lblRecordHeader1, lblRecordHeader2, flxSeperatorHeader);
            var TemplateRecordsNew = new com.InfinityOLB.ApprovalRequestMA.TemplateRecordsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TemplateRecordsNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransactionDetails.add(flxErrorMessage, flxACHFileUploadDetails, NonEditableDetailsforApprovals, flxTemplateRecordHeader, TemplateRecordsNew);
            var flxRequestCreateEditUpdateEditDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxRequestCreateEditUpdateEditDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestCreateEditUpdateEditDetails.setDefaultUnit(kony.flex.DP);
            var flxTabs = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTabs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabs.setDefaultUnit(kony.flex.DP);
            var btnTab1 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnTab1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBtnAccountSummaryUnselected",
                "text": "Updated Details",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var btnTab2 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnTab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBtnAccountSummaryUnselected",
                "text": "Existing Details",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            flxTabs.add(btnTab1, btnTab2);
            var flxRequestDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRequestDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestDetails.setDefaultUnit(kony.flex.DP);
            var lblCreatedDetails = new kony.ui.Label({
                "bottom": "15dp",
                "centerY": "27dp",
                "id": "lblCreatedDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Created Details",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCreateRequestInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "25dp",
                "clipBounds": true,
                "id": "flxCreateRequestInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateRequestInfo.setDefaultUnit(kony.flex.DP);
            var flxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var lblRecipientInforation = new kony.ui.Label({
                "id": "lblRecipientInforation",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var SegmentRecipientInfoDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "ImgIsUpdatedStatus": "",
                    "lblColon": "",
                    "lblIsUpdatedStatus": "",
                    "lblKey": "",
                    "lblValue": ""
                }],
                "groupCells": false,
                "id": "SegmentRecipientInfoDetails",
                "isVisible": true,
                "left": "20dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxNonEditableRecipientanditsbankDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "ImgIsUpdatedStatus": "ImgIsUpdatedStatus",
                    "flxFlag": "flxFlag",
                    "flxKey": "flxKey",
                    "flxMain": "flxMain",
                    "flxNonEditableRecipientanditsbankDetails": "flxNonEditableRecipientanditsbankDetails",
                    "flxValue": "flxValue",
                    "lblColon": "lblColon",
                    "lblIsUpdatedStatus": "lblIsUpdatedStatus",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue"
                },
                "width": "96.50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperatorBankDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBankDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBankDetails.setDefaultUnit(kony.flex.DP);
            flxSeperatorBankDetails.add();
            var lblRecipientBankInfo = new kony.ui.Label({
                "id": "lblRecipientBankInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Recipient's Bank Information",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var SegmentRecipientBankDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "ImgIsUpdatedStatus": "",
                    "lblColon": "",
                    "lblIsUpdatedStatus": "",
                    "lblKey": "",
                    "lblValue": ""
                }],
                "groupCells": false,
                "id": "SegmentRecipientBankDetails",
                "isVisible": true,
                "left": "20dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxNonEditableRecipientanditsbankDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "ImgIsUpdatedStatus": "ImgIsUpdatedStatus",
                    "flxFlag": "flxFlag",
                    "flxKey": "flxKey",
                    "flxMain": "flxMain",
                    "flxNonEditableRecipientanditsbankDetails": "flxNonEditableRecipientanditsbankDetails",
                    "flxValue": "flxValue",
                    "lblColon": "lblColon",
                    "lblIsUpdatedStatus": "lblIsUpdatedStatus",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue"
                },
                "width": "96.50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRecipientsLinkedWith = new kony.ui.Label({
                "id": "lblRecipientsLinkedWith",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Recipient Linked With",
                "top": 10,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var contractListRecipient = new com.InfinityOLB.Approvals.contractListRecipient({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "contractListRecipient",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "flxCol1": {
                        "centerX": "viz.val_cleared",
                        "left": "0dp"
                    },
                    "flxCol2": {
                        "centerX": "viz.val_cleared",
                        "left": "0%",
                        "width": "22%"
                    },
                    "flxCol3": {
                        "centerX": "viz.val_cleared",
                        "isVisible": true,
                        "left": "0%"
                    },
                    "flxCol4": {
                        "centerX": "viz.val_cleared",
                        "left": "0%"
                    },
                    "flxContract": {
                        "width": "87.50%"
                    },
                    "flxContractsHeader": {
                        "isVisible": true
                    },
                    "flxRow": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "imgCol1": {
                        "src": "sorting_next.png"
                    },
                    "imgCol2": {
                        "src": "sorting.png"
                    },
                    "imgCol3": {
                        "isVisible": false,
                        "src": "sorting.png"
                    },
                    "lblCol3": {
                        "isVisible": false,
                        "text": "Identity Number"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCreateRequestInfo.add(flxSeperator, lblRecipientInforation, SegmentRecipientInfoDetails, flxSeperatorBankDetails, lblRecipientBankInfo, SegmentRecipientBankDetails, lblRecipientsLinkedWith, contractListRecipient);
            flxRequestDetails.add(lblCreatedDetails, flxCreateRequestInfo);
            flxRequestCreateEditUpdateEditDetails.add(flxTabs, flxRequestDetails);
            var flxApprovalHistorySection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalHistorySection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": 10,
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistorySection.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalsHistoryInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryInformation.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxApprovalsHistoryErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgApprovalHistoryError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgApprovalHistoryError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalHistoryError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApprovalHistoryError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxErrorSeperator.add();
            flxApprovalsHistoryErrorMessage.add(imgApprovalHistoryError, lblApprovalHistoryError, flxErrorSeperator);
            var flxApprovalHistoryContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalHistoryContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.setDefaultUnit(kony.flex.DP);
            var flxApprovalHistoryHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalHistoryHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryHeading.setDefaultUnit(kony.flex.DP);
            var lblApprovalHistoryInformation = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalHistoryInformation",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.achtransationdetail.ApprovalHistoryInformation\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalHistoryCollapseArrow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxApprovalHistoryCollapseArrow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "17dp",
                "width": "20dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryCollapseArrow.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "height": "100%",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblDelete20px",
                "text": "O",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryCollapseArrow.add(lblDropdown);
            flxApprovalHistoryHeading.add(lblApprovalHistoryInformation, flxApprovalHistoryCollapseArrow);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxApprovalStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "25dp",
                "clipBounds": true,
                "id": "flxApprovalStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.setDefaultUnit(kony.flex.DP);
            var flxApprovalStatusGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalStatusGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatusGroup.setDefaultUnit(kony.flex.DP);
            var flxApprovalDetailsStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalDetailsStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsStatus.setDefaultUnit(kony.flex.DP);
            var lblApprovalStatus = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatus",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ApprovalStatus\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var lblApprovalStatusValue = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatusValue",
                "isVisible": true,
                "left": "150dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            flxApprovalDetailsStatus.add(lblApprovalStatus, lblApprovalStatusValue);
            var flxApprovedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovedCountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblApproveCount = new kony.ui.Label({
                "id": "lblApproveCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.approvedWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApproveCountVal = new kony.ui.Label({
                "id": "lblApproveCountVal",
                "isVisible": true,
                "left": "185dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "2",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.add(lblApproveCount, lblApproveCountVal);
            var flxRejectedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRejectedCountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblRejectCount = new kony.ui.Label({
                "id": "lblRejectCount",
                "isVisible": true,
                "left": 20,
                "skin": "sknlbla0a0a015px",
                "text": "Rejected:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRejectCountVal = new kony.ui.Label({
                "id": "lblRejectCountVal",
                "isVisible": true,
                "left": "190dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.add(lblRejectCount, lblRejectCountVal);
            flxApprovalStatusGroup.add(flxApprovalDetailsStatus, flxApprovedCountDetails, flxRejectedCountDetails);
            var btnPendingAprrovers = new kony.ui.Button({
                "height": "40dp",
                "id": "btnPendingAprrovers",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.pendingApprovers\")",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.add(flxApprovalStatusGroup, btnPendingAprrovers);
            var flxSeparatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom.add();
            var segApprovalDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segApprovalDetails",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsRowTemplate"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsACKHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxApprovalDetailsACKHeader": "flxApprovalDetailsACKHeader",
                    "flxApprovalDetailsRowTemplate": "flxApprovalDetailsRowTemplate",
                    "flxApproveDetails": "flxApproveDetails",
                    "flxHeaderValues": "flxHeaderValues",
                    "flxNoRecords": "flxNoRecords",
                    "flxTopSeperator": "flxTopSeperator",
                    "flxTopSeperator2": "flxTopSeperator2",
                    "imgFlxTopSeparator": "imgFlxTopSeparator",
                    "imgFlxTopSeparator2": "imgFlxTopSeparator2",
                    "lblAction": "lblAction",
                    "lblActionKey": "lblActionKey",
                    "lblComments": "lblComments",
                    "lblCommentsKey": "lblCommentsKey",
                    "lblDateAndTime": "lblDateAndTime",
                    "lblDateAndTimeKey": "lblDateAndTimeKey",
                    "lblNoRecords": "lblNoRecords",
                    "lblSignatoryGroup": "lblSignatoryGroup",
                    "lblSignatoryGroupKey": "lblSignatoryGroupKey",
                    "lblUserID": "lblUserID",
                    "lblUserIDKey": "lblUserIDKey"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.add(flxApprovalHistoryHeading, flxTopSeperator, flxApprovalStatus, flxSeparatorBottom, segApprovalDetails);
            flxApprovalsHistoryInformation.add(flxApprovalsHistoryErrorMessage, flxApprovalHistoryContent);
            flxApprovalHistorySection.add(flxApprovalsHistoryInformation);
            var flxApprovalFormActions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxApprovalFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalFormActions.setDefaultUnit(kony.flex.DP);
            var flxButtonSeparator = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxButtonSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonSeparator.setDefaultUnit(kony.flex.DP);
            flxButtonSeparator.add();
            var ApprovalFormActions = new com.InfinityOLB.ApprovalRequestsMA.ApprovalFormActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "ApprovalFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "ApprovalFormActions": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "btnBack": {
                        "right": "1.50%",
                        "top": "10dp",
                        "width": "97%"
                    },
                    "btnCancel": {
                        "right": "1.50%",
                        "top": "10dp",
                        "width": "97%"
                    },
                    "btnNext": {
                        "right": "1.50%",
                        "width": "97%"
                    },
                    "btnOption": {
                        "right": "1.50%",
                        "top": "10dp",
                        "width": "97%"
                    },
                    "flxMain": {
                        "height": "111dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxApprovalFormActions.add(flxButtonSeparator, ApprovalFormActions);
            var flxAuthenticator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "4dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthenticator.setDefaultUnit(kony.flex.DP);
            var OTPAuthenticator = new com.InfinityOLB.ApprovalRequestMA.OTPAuthenticator({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadowBlur8Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "OTPCode.imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "OTPCode.imgWarning": {
                        "src": "error_yellow.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAuthenticator.add(OTPAuthenticator);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainerLeft.add(flxDisplayErrorMessage, flxAcknowledgementContainer, flxTransactionDetails, flxRequestCreateEditUpdateEditDetails, flxApprovalHistorySection, flxApprovalFormActions, flxAuthenticator, flxTerms);
            flxMain.add(flxMainWrapper, flxContentHeader, flxContentContainerRight, flxContentContainerLeft);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "100dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "100dp",
                        "left": "0%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "top": "26.60%",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "23dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "22dp",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder3343a81pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSave = new kony.ui.Button({
                "bottom": 20,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 6000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxClose": {
                        "isVisible": true,
                        "right": "0dp"
                    },
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "280dp"
                    },
                    "flxPopupNew": {
                        "isVisible": false,
                        "zIndex": 6000
                    },
                    "flxSeperatorBottom": {
                        "isVisible": true
                    },
                    "formActionsNew.btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "formActionsNew.btnNext": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "width": "150dp"
                    },
                    "imgClose": {
                        "right": "20dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblCommnets": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Comments\")"
                    },
                    "trComments": {
                        "left": "30dp",
                        "right": "viz.val_cleared",
                        "top": "12dp",
                        "width": "88.70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxOverlay = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxOverlay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverlay.setDefaultUnit(kony.flex.DP);
            flxOverlay.add();
            var flxPendingApprovers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "600dp",
                "id": "flxPendingApprovers",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "ICsknFlxffffff",
                "top": "0dp",
                "width": "50%",
                "zIndex": 7000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApprovers.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxPendingApproversDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversDetails.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxPendingApproversHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.setDefaultUnit(kony.flex.DP);
            var lblApprovalDetails = new kony.ui.Label({
                "id": "lblApprovalDetails",
                "isVisible": true,
                "left": "23dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendinApprovers.PendingApprovalDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPopupclose = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgPopupclose",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.add(lblApprovalDetails, imgPopupclose);
            var flxSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxGroupDetails = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "70%",
                "horizontalScrollIndicator": true,
                "id": "flxGroupDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupDetails.setDefaultUnit(kony.flex.DP);
            var flxApprovalLimitHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalLimitHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalLimitHeader.setDefaultUnit(kony.flex.DP);
            var flxPerTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "190dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransaction.setDefaultUnit(kony.flex.DP);
            var lblPerTransaction = new kony.ui.Label({
                "id": "lblPerTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.PerTransactionApprovals\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPerTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxPerTransactionSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxPerTransactionSelected.add();
            flxPerTransaction.add(lblPerTransaction, flxPerTransactionSelected);
            var flxDailyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "240dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "125dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransaction.setDefaultUnit(kony.flex.DP);
            var lblDailyTransaction = new kony.ui.Label({
                "id": "lblDailyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.dailyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxDailyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxDailyTransactionSelected.add();
            flxDailyTransaction.add(lblDailyTransaction, flxDailyTransactionSelected);
            var flxWeekelyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeekelyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "395dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "145dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeekelyTransaction.setDefaultUnit(kony.flex.DP);
            var lblWeekelyTransaction = new kony.ui.Label({
                "id": "lblWeekelyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.weeklyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxWeeklyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "30dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxWeeklyTransactionSelected.add();
            flxWeekelyTransaction.add(lblWeekelyTransaction, flxWeeklyTransactionSelected);
            flxApprovalLimitHeader.add(flxPerTransaction, flxDailyTransaction, flxWeekelyTransaction);
            var flxNoteMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoteMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoteMessage.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Note: The transaction can be approved by any 2 of the sernior managers (or) any 1 of the admin.",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoteMessage.add(imgInfoIcon, lblInfo);
            var flxMultiContractMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMultiContractMsg",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMultiContractMsg.setDefaultUnit(kony.flex.DP);
            var lblMultiContractMsg = new kony.ui.Label({
                "id": "lblMultiContractMsg",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequest.ApprovalRequiredFromMultipleContracts\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMultiContractMsg.add(lblMultiContractMsg);
            var flxApproverList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApproverList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApproverList.setDefaultUnit(kony.flex.DP);
            flxApproverList.add();
            flxGroupDetails.add(flxApprovalLimitHeader, flxNoteMessage, flxMultiContractMsg, flxApproverList);
            var flxNoPendingData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxNoPendingData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPendingData.setDefaultUnit(kony.flex.DP);
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon2",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoPendingApprovals = new kony.ui.Label({
                "id": "lblNoPendingApprovals",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.noPendingApprovals\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfoIcon2, lblNoPendingApprovals);
            flxNoPendingData.add(flxInfo);
            var flxPopupBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "130dp",
                "id": "flxPopupBottom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 500,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBottom.setDefaultUnit(kony.flex.DP);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var btnClose = new kony.ui.Button({
                "bottom": "30dp",
                "height": "50dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupBottom.add(flxBottomSeparator, btnClose);
            flxPendingApproversDetails.add(flxPendingApproversHeader, flxSeparator, flxGroupDetails, flxNoPendingData, flxPopupBottom);
            flxPendingApprovers.add(flxPendingApproversDetails);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "instanceId": "ApprovalRoadMapElement"
                    },
                    "ApprovalRoadMapElement.flxApprovalRoadMapElementMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement.flxApprovalRoadMapElementTablet": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green.png",
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "70px"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnTab1": {
                        "skin": "ICSknBtnAccountSummarySelected13px",
                        "segmentProps": []
                    },
                    "btnTab2": {
                        "skin": "ICSknBtnAccountSummaryUnselected13px",
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknLblSSP42424215pxBold",
                        "text": "Recipient Information",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "SegmentRecipientInfoDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "skin": "sknLblSSP42424215pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknLblSSP42424215pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "contractListRecipient": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "contractListRecipient"
                    },
                    "contractListRecipient.flxCol1": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol2": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol3": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol4": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContractsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxApprovalStatus": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxApprovedCountDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblApproveCountVal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxRejectedCountDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblRejectCountVal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnProceed": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.lblSecureAccessCode": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.flxOTPContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnSave": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxClose": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement.flxApprovalRoadMapElementTablet": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement.flxDropDownHeaderTablet": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement.flxDropDownIconTablet": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalRoadMapElement.flxHeaderLabelWrapperTablet": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxAckContainer": {
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "10.50%"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxRequestCreateEditUpdateEditDetails": {
                        "segmentProps": []
                    },
                    "flxTabs": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "text": "Created Details",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBankDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "segmentProps": []
                    },
                    "SegmentRecipientBankDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.40%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryInformation": {
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": true,
                        "text": "Approval History Information",
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "163dp"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCount": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCountVal": {
                        "left": {
                            "type": "string",
                            "value": "202dp"
                        },
                        "segmentProps": []
                    },
                    "lblRejectCount": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblRejectCountVal": {
                        "left": {
                            "type": "string",
                            "value": "207dp"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxButtonSeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "sknflxe9ebee",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ApprovalFormActions"
                    },
                    "ApprovalFormActions.btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxOverlay": {
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalDetails": {
                        "segmentProps": []
                    },
                    "imgPopupclose": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerTransaction": {
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyTransaction": {
                        "left": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxWeekelyTransaction": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "segmentProps": []
                    },
                    "flxRequestCreateEditUpdateEditDetails": {
                        "segmentProps": []
                    },
                    "flxTabs": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnTab1": {
                        "segmentProps": []
                    },
                    "btnTab2": {
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "text": "Recipient Information",
                        "segmentProps": []
                    },
                    "SegmentRecipientInfoDetails": {
                        "segmentProps": []
                    },
                    "flxSeperatorBankDetails": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "segmentProps": []
                    },
                    "SegmentRecipientBankDetails": {
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.lblCol3": {
                        "text": "Updated",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "text": "Recipient Information",
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol2": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol3": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxCol4": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContractsHeader": {
                        "segmentProps": []
                    },
                    "contractListRecipient.lblCol3": {
                        "text": "Updated",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICsknFlxffffff",
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "flxNoteMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxMultiContractMsg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxApproverList": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon2": {
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    },
                    "btnClose": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu": {
                    "height": "70dp",
                    "right": "6%",
                    "top": "0dp",
                    "width": "94%"
                },
                "ApprovalRoadMapElement.flxApprovalRoadMapElementTablet": {
                    "top": "0"
                },
                "ApprovalRoadMapElement.flxDropDownHeaderTablet": {
                    "height": "85dp",
                    "width": "100%"
                },
                "ApprovalRoadMapElement.flxDropDownIconTablet": {
                    "right": "30dp"
                },
                "ApprovalRoadMapElement.flxHeaderLabelWrapperTablet": {
                    "bottom": "",
                    "centerX": "",
                    "left": "30dp",
                    "top": ""
                },
                "ApprovalRoadMapElement.lblRoadMapHeaderTablet": {
                    "top": "0dp"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "115dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxTickImage": {
                    "height": "50dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "src": "bbdownloadicon.png"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png",
                    "width": "100%"
                },
                "contractListRecipient.flxCol1": {
                    "centerX": "",
                    "left": "0dp"
                },
                "contractListRecipient.flxCol2": {
                    "centerX": "",
                    "left": "0%",
                    "width": "22%"
                },
                "contractListRecipient.flxCol3": {
                    "centerX": "",
                    "left": "0%"
                },
                "contractListRecipient.flxCol4": {
                    "centerX": "",
                    "left": "0%"
                },
                "contractListRecipient.flxContract": {
                    "width": "87.50%"
                },
                "contractListRecipient.flxRow": {
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "contractListRecipient.imgCol1": {
                    "src": "sorting_next.png"
                },
                "contractListRecipient.imgCol2": {
                    "src": "sorting.png"
                },
                "contractListRecipient.imgCol3": {
                    "src": "sorting.png"
                },
                "contractListRecipient.lblCol3": {
                    "text": "Identity Number"
                },
                "ApprovalFormActions": {
                    "centerY": "",
                    "top": "0dp"
                },
                "ApprovalFormActions.btnBack": {
                    "right": "1.50%",
                    "top": "10dp",
                    "width": "97%"
                },
                "ApprovalFormActions.btnCancel": {
                    "right": "1.50%",
                    "top": "10dp",
                    "width": "97%"
                },
                "ApprovalFormActions.btnNext": {
                    "right": "1.50%",
                    "width": "97%"
                },
                "ApprovalFormActions.btnOption": {
                    "right": "1.50%",
                    "top": "10dp",
                    "width": "97%"
                },
                "ApprovalFormActions.flxMain": {
                    "height": "111dp"
                },
                "OTPAuthenticator.OTPCode.imgViewCVVCode": {
                    "src": "view.png"
                },
                "OTPAuthenticator.OTPCode.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "100dp",
                    "left": "0%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "top": "26.60%",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "flxPopup.flxClose": {
                    "right": "0dp"
                },
                "flxPopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopup.flxPopupContainer": {
                    "centerY": "",
                    "left": "",
                    "right": "",
                    "top": "280dp"
                },
                "flxPopup": {
                    "zIndex": 6000
                },
                "flxPopup.formActionsNew.btnCancel": {
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "flxPopup.formActionsNew.btnNext": {
                    "left": "",
                    "right": "",
                    "width": "150dp"
                },
                "flxPopup.imgClose": {
                    "right": "20dp",
                    "src": "bbcloseicon.png"
                },
                "flxPopup.trComments": {
                    "left": "30dp",
                    "right": "",
                    "top": "12dp",
                    "width": "88.70%"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxTermsAndConditions, flxLogout, flxLoading, flxPopup, flxOverlay, flxPendingApprovers);
        };
        return [{
            "addWidgets": addWidgetsfrmApprovalViewDetailsNew,
            "enabledForIdleTimeout": true,
            "id": "frmApprovalViewDetailsNew",
            "init": controller.AS_Form_g9c15edc5dc64ecba9f2bdf7767d7380,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_d958675c91ea4833be75cfdb3e9d5267,
            "postShow": controller.AS_Form_i9d69d3e9d10407c8fe5a2b2bd6587f5,
            "preShow": function(eventobject) {
                controller.AS_Form_ca78558231dc4682934473626a85fcda(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalRequestMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_f687f95e76df47e9ad56c2ff8a5ebc5a,
            "retainScrollPosition": true
        }]
    }
});