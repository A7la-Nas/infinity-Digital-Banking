define("TradeFinanceMA/ExportLCUIModule/frmExportLCViewDetailsReturned", function() {
    return function(controller) {
        function addWidgetsfrmExportLCViewDetailsReturned() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003e75Bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "isVisible": true
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 85,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "141dp",
                "width": "1198dp",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblSubHeader = new kony.ui.Label({
                "id": "lblSubHeader",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Export LC - Drawing - D10011004",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisBodyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "5.80%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBodyContent.setDefaultUnit(kony.flex.DP);
            var flxVerticalEllipsisBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxVerticalEllipsisBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "6.50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisBody.setDefaultUnit(kony.flex.DP);
            var lblVerticalEllipsis = new kony.ui.Label({
                "centerX": "50%",
                "height": "100%",
                "id": "lblVerticalEllipsis",
                "isVisible": true,
                "skin": "ICsknOlbFonts0273e317px",
                "text": "O",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVerticalEllipsisDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxVerticalEllipsisDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "-8dp",
                "skin": "slfBoxffffffB1R5",
                "top": "32dp",
                "width": "250dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.setDefaultUnit(kony.flex.DP);
            var segVerticalDropdownEllipsis = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segVerticalDropdownEllipsis",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxLCTypeOfAccountsList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListRow": "flxAccountListRow",
                    "flxLCAccountType": "flxLCAccountType",
                    "flxLCType": "flxLCType",
                    "flxLCTypeOfAccountsList": "flxLCTypeOfAccountsList",
                    "imgLCCheckbox": "imgLCCheckbox",
                    "lblLCAccountType": "lblLCAccountType",
                    "lblLCCheckbox": "lblLCCheckbox"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVerticalEllipsisDropdown.add(segVerticalDropdownEllipsis);
            flxVerticalEllipsisBody.add(lblVerticalEllipsis, flxVerticalEllipsisDropdown);
            flxVerticalEllipsisBodyContent.add(flxVerticalEllipsisBody);
            flxSubHeader.add(lblSubHeader, flxVerticalEllipsisBodyContent);
            var flxLCSummaryTablet = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryTablet",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryTablet.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader02 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader02.setDefaultUnit(kony.flex.DP);
            var flxSummaryTopSeparatorLC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSummaryTopSeparatorLC",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryTopSeparatorLC.setDefaultUnit(kony.flex.DP);
            flxSummaryTopSeparatorLC.add();
            var flxLCSummayTablet = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummayTablet",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummayTablet.setDefaultUnit(kony.flex.DP);
            var lblLCSummaryTablet = new kony.ui.Label({
                "id": "lblLCSummaryTablet",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummayTablet.add(lblLCSummaryTablet);
            var flxViewLCDetailsTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetailsTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1.46%",
                "skin": "slFbox",
                "top": "15dp",
                "width": "8.93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsTop.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetailsTablet = new kony.ui.Label({
                "id": "lblViewLCDetailsTablet",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View LC Details"
            });
            flxViewLCDetailsTop.add(lblViewLCDetailsTablet);
            var flxSummaryBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSummaryBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxSummaryBottomSeparator.add();
            flxLCSummaryHeader02.add(flxSummaryTopSeparatorLC, flxLCSummayTablet, flxViewLCDetailsTop, flxSummaryBottomSeparator);
            var segLCSummaryContent = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "32dp",
                "data": [{
                    "lblReview": "Other Additional Conditions (Optional):",
                    "lblReviewValue1": "$2789.89"
                }],
                "groupCells": false,
                "id": "segLCSummaryContent",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingsRowTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDrawingsRowTemplate": "flxDrawingsRowTemplate",
                    "flxReviewRight": "flxReviewRight",
                    "flxReviewValues": "flxReviewValues",
                    "flxreviewRows": "flxreviewRows",
                    "lblReview": "lblReview",
                    "lblReviewValue1": "lblReviewValue1"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummaryTablet.add(flxLCSummaryHeader02, segLCSummaryContent);
            var flxLCSummaryBody = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLCSummaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "20dp",
                "width": "87.34%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody.setDefaultUnit(kony.flex.DP);
            var flxLCSummaryHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLCSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryHeader.setDefaultUnit(kony.flex.DP);
            var flxLCSummarylbl = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLCSummarylbl",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.setDefaultUnit(kony.flex.DP);
            var lblLCSummary = new kony.ui.Label({
                "id": "lblLCSummary",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.LCSummary\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLCSummarylbl.add(lblLCSummary);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var flxViewLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "75%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25%",
                "width": "23.95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetials = new kony.ui.Label({
                "height": "20dp",
                "id": "lblViewLCDetials",
                "isVisible": true,
                "left": "60%",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ViewLCDetails\")",
                "top": "0dp",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewLCDetails.add(lblViewLCDetials);
            flxLCSummaryHeader.add(flxLCSummarylbl, flxBottomSeparator, flxViewLCDetails);
            var flxBodyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64.38%",
                "id": "flxBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32%",
                "width": "30.83%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContent.setDefaultUnit(kony.flex.DP);
            var flxContentLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel.setDefaultUnit(kony.flex.DP);
            var lblApplicant = new kony.ui.Label({
                "height": "18dp",
                "id": "lblApplicant",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Applicant:",
                "top": "0",
                "width": "364dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantName = new kony.ui.Label({
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "70dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel.add(lblApplicant, lblApplicantName);
            var flxContentLabel2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "22dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel2.setDefaultUnit(kony.flex.DP);
            var lblLCRefNo = new kony.ui.Label({
                "id": "lblLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Advising LC Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRightLCRefNo = new kony.ui.Label({
                "id": "lblRightLCRefNo",
                "isVisible": true,
                "left": "125dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel2.add(lblLCRefNo, lblRightLCRefNo);
            var flxContentLabel3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel3.setDefaultUnit(kony.flex.DP);
            var lblLCType = new kony.ui.Label({
                "id": "lblLCType",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Type:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeValue = new kony.ui.Label({
                "id": "lblLCTypeValue",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel3.add(lblLCType, lblLCTypeValue);
            var flxContentLabel4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLabel4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLabel4.setDefaultUnit(kony.flex.DP);
            var lblIssueBank = new kony.ui.Label({
                "id": "lblIssueBank",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueBankValue = new kony.ui.Label({
                "id": "lblIssueBankValue",
                "isVisible": true,
                "left": "88dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLabel4.add(lblIssueBank, lblIssueBankValue);
            flxBodyContent.add(flxContentLabel, flxContentLabel2, flxContentLabel3, flxContentLabel4);
            var flxBodyContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxBodyContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "421dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentRight.setDefaultUnit(kony.flex.DP);
            var flxContentRight1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight1.setDefaultUnit(kony.flex.DP);
            var lblLCAmount = new kony.ui.Label({
                "id": "lblLCAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValue = new kony.ui.Label({
                "id": "lblLCAmountValue",
                "isVisible": true,
                "left": "76dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight1.add(lblLCAmount, lblLCAmountValue);
            var flxContentRight2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "363dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight2.setDefaultUnit(kony.flex.DP);
            var lblIssueDate = new kony.ui.Label({
                "id": "lblIssueDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issue Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateValue = new kony.ui.Label({
                "id": "lblIssueDateValue",
                "isVisible": true,
                "left": "75dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight2.add(lblIssueDate, lblIssueDateValue);
            var flxContentRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "76dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentRight.setDefaultUnit(kony.flex.DP);
            var lblIssueLCRefNo = new kony.ui.Label({
                "id": "lblIssueLCRefNo",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing LC Ref No:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingRefNoValue = new kony.ui.Label({
                "id": "lblIssuingRefNoValue",
                "isVisible": true,
                "left": "115dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentRight.add(lblIssueLCRefNo, lblIssuingRefNoValue);
            flxBodyContentRight.add(flxContentRight1, flxContentRight2, flxContentRight);
            var flxBodyContentLast = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxBodyContentLast",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "816dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyContentLast.setDefaultUnit(kony.flex.DP);
            var flxContentLast1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast1.setDefaultUnit(kony.flex.DP);
            var lblLCUntilizedAmount = new kony.ui.Label({
                "id": "lblLCUntilizedAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Untilized Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCUntilizedAmountValue = new kony.ui.Label({
                "id": "lblLCUntilizedAmountValue",
                "isVisible": true,
                "left": "136dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast1.add(lblLCUntilizedAmount, lblLCUntilizedAmountValue);
            var flxContentLast2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxContentLast2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "364dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentLast2.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "80dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentLast2.add(lblExpiryDate, lblExpiryDateValue);
            flxBodyContentLast.add(flxContentLast1, flxContentLast2);
            flxLCSummaryBody.add(flxLCSummaryHeader, flxBodyContent, flxBodyContentRight, flxBodyContentLast);
            var flxDrawingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox1",
                "top": "30dp",
                "width": "87.30%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetails.setDefaultUnit(kony.flex.DP);
            var flxDrawingDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDrawingDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblDrawingDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDrawingDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.DrawingDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDrawingDetailsDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30dp",
                "id": "flxDrawingDetailsDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.setDefaultUnit(kony.flex.DP);
            var imgDrawingDetailsDropdown = new kony.ui.Image2({
                "height": "33dp",
                "id": "imgDrawingDetailsDropdown",
                "isVisible": true,
                "left": "0.50%",
                "src": "arrowup_sm.png",
                "top": "0dp",
                "width": "37dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingDetailsDropdown.add(imgDrawingDetailsDropdown);
            var flxViewLCDetailsNew = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewLCDetailsNew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "85%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35%",
                "width": "23.95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsNew.setDefaultUnit(kony.flex.DP);
            var lblViewLCDetialsNew = new kony.ui.Label({
                "height": "20dp",
                "id": "lblViewLCDetialsNew",
                "isVisible": true,
                "left": "60%",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View LC Details",
                "top": "0dp",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsNew.add(lblViewLCDetialsNew);
            flxDrawingDetailsHeader.add(lblDrawingDetails, flxDrawingDetailsDropdown, flxViewLCDetailsNew);
            var flxDrawingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingContent.setDefaultUnit(kony.flex.DP);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxDrawingStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.setDefaultUnit(kony.flex.DP);
            var lblDrawingStatusKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingStatusKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingStatus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingStatusValue = new kony.ui.Label({
                "id": "lblDrawingStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingStatus.add(lblDrawingStatusKey, lblDrawingStatusValue);
            var flxDrawingRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingRef.setDefaultUnit(kony.flex.DP);
            var lblDrawingRefKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingRefKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingRefNo\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingRefValue = new kony.ui.Label({
                "id": "lblDrawingRefValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingRef.add(lblDrawingRefKey, lblDrawingRefValue);
            var flxDrawingCreated = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingCreated",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingCreated.setDefaultUnit(kony.flex.DP);
            var lblDrawingCreatedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingCreatedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.DrawingCreatedDate\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingCreatedValue = new kony.ui.Label({
                "id": "lblDrawingCreatedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingCreated.add(lblDrawingCreatedKey, lblDrawingCreatedValue);
            var flxDrawingAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDrawingAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDrawingAmount.setDefaultUnit(kony.flex.DP);
            var lblDrawingAmountKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDrawingAmountKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportDrawings.DrawingAmount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDrawingAmountValue = new kony.ui.Label({
                "id": "lblDrawingAmountValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrawingAmount.add(lblDrawingAmountKey, lblDrawingAmountValue);
            var flxAmountCredited = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCredited",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCredited.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblAmountCreditedKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.AmounttobeCreditto\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountCrediredValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmountCrediredValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.setDefaultUnit(kony.flex.DP);
            var lblAmountCreditedValue = new kony.ui.Label({
                "id": "lblAmountCreditedValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountCreditedValueInfo = new kony.ui.Label({
                "id": "lblAmountCreditedValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.OtherBeneficiaryName\")",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountCrediredValue.add(lblAmountCreditedValue, lblAmountCreditedValueInfo);
            flxAmountCredited.add(lblAmountCreditedKey, flxAmountCrediredValue);
            var flxFinanceUS = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUS",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUS.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblFinanceUSKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Financeus\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFinanceUSValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinanceUSValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.setDefaultUnit(kony.flex.DP);
            var lblFinanceUSValue = new kony.ui.Label({
                "id": "lblFinanceUSValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFinanceUSInfo = new kony.ui.Label({
                "id": "lblFinanceUSInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "(Please Finance us for the draft amount by negotiation with full recourse to us)",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFinanceUSValue.add(lblFinanceUSValue, lblFinanceUSInfo);
            flxFinanceUS.add(lblFinanceUSKey, flxFinanceUSValue);
            var flxUploadDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadDocs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadDocs.setDefaultUnit(kony.flex.DP);
            var lblUploadDocsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblUploadDocsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.UploadDocuments\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadDocsValue = new kony.ui.Label({
                "id": "lblUploadDocsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segUploadDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "id": "segUploadDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxFrmExportLCViewDetailsReturnedDoc"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFrmExportLCViewDetailsReturnedDoc": "flxFrmExportLCViewDetailsReturnedDoc",
                    "lblListValue": "lblListValue"
                },
                "width": "65%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadDocs.add(lblUploadDocsKey, lblUploadDocsValue, segUploadDocuments);
            var flxPhysicalDocDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalDocDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.setDefaultUnit(kony.flex.DP);
            var lblPhysicalDocDetailsKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPhysicalDocDetailsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PhysicalDocumentDetails\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhysicalDocDetailsValue = new kony.ui.Label({
                "id": "lblPhysicalDocDetailsValue",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segPhysicalDocuments = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": "Label"
                }],
                "groupCells": false,
                "id": "segPhysicalDocuments",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxFrmExportLCViewDetailsReturnedDoc"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFrmExportLCViewDetailsReturnedDoc": "flxFrmExportLCViewDetailsReturnedDoc",
                    "lblListValue": "lblListValue"
                },
                "width": "65%",
                "zIndex": 26,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalDocDetails.add(lblPhysicalDocDetailsKey, lblPhysicalDocDetailsValue, segPhysicalDocuments);
            var flxDiscrepancies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancies.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblDiscrepanciesKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.Forwarddespiteanydiscrepancies\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDiscrepanciesValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesValue = new kony.ui.Label({
                "id": "lblDiscrepanciesValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDiscrepanciesValueInfo = new kony.ui.Label({
                "id": "lblDiscrepanciesValueInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "(Kindly forward documents to issuing bank as presented despite any discrepancy noted)",
                "top": "0dp",
                "width": "60%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesValue.add(lblDiscrepanciesValue, lblDiscrepanciesValueInfo);
            flxDiscrepancies.add(lblDiscrepanciesKey, flxDiscrepanciesValue);
            var flxChargesDebit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChargesDebit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChargesDebit.setDefaultUnit(kony.flex.DP);
            var lblChargesDebitKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblChargesDebitKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ChargesDebitAccount\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChargesDebitValue = new kony.ui.Label({
                "id": "lblChargesDebitValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChargesDebit.add(lblChargesDebitKey, lblChargesDebitValue);
            var flxMsgToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": false,
                "id": "flxMsgToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.50%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "95%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsgToBank.setDefaultUnit(kony.flex.DP);
            var lblMsgToBankKey = new kony.ui.Label({
                "height": "18dp",
                "id": "lblMsgToBankKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.MessageToBankDrawings\")",
                "top": "0",
                "width": "285dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMsgToBankValue = new kony.ui.Label({
                "id": "lblMsgToBankValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsgToBank.add(lblMsgToBankKey, lblMsgToBankValue);
            flxDrawingContent.add(flxSeparator, flxDrawingStatus, flxDrawingRef, flxDrawingCreated, flxDrawingAmount, flxAmountCredited, flxFinanceUS, flxUploadDocs, flxPhysicalDocDetails, flxDiscrepancies, flxChargesDebit, flxMsgToBank);
            flxDrawingDetails.add(flxDrawingDetailsHeader, flxDrawingContent);
            var flxDiscrepanciesandResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesandResponse",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "87.34%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponse.setDefaultUnit(kony.flex.DP);
            var flxDiscrepanciesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDiscrepanciesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxDiscrepanciesandResponseLabel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxDiscrepanciesandResponseLabel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.setDefaultUnit(kony.flex.DP);
            var lblDiscrepanciesandResponseValue = new kony.ui.Label({
                "id": "lblDiscrepanciesandResponseValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Discrepancies and Response",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesandResponseLabel.add(lblDiscrepanciesandResponseValue);
            var flxViewReturnedByBankHistory = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxViewReturnedByBankHistory",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1.46%",
                "skin": "slFbox",
                "top": "25dp",
                "width": "8.93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewReturnedByBankHistory.setDefaultUnit(kony.flex.DP);
            var lblViewReturnedByBankHistory = new kony.ui.Label({
                "id": "lblViewReturnedByBankHistory",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLabelSSPRegular4176A415px",
                "text": "View Returned by Bank History (4)",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View LC Details"
            });
            flxViewReturnedByBankHistory.add(lblViewReturnedByBankHistory);
            var flxBottomSeparater02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxBottomSeparater02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparater02.setDefaultUnit(kony.flex.DP);
            flxBottomSeparater02.add();
            flxDiscrepanciesHeader.add(flxTopSeperator, flxDiscrepanciesandResponseLabel, flxViewReturnedByBankHistory, flxBottomSeparater02);
            var flxDiscrepanciesMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepanciesMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepanciesMain.setDefaultUnit(kony.flex.DP);
            var flxTotalDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocuments.setDefaultUnit(kony.flex.DP);
            var lblTotalDocuments = new kony.ui.Label({
                "id": "lblTotalDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TotalDocuments\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTotalDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTotalDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxtotoalDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxtotoalDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var lblTotalDocumentsValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblTotalDocumentsValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "2",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtotoalDocumentsValueContainer.add(lblTotalDocumentsValue);
            flxTotalDocumentsValue.add(flxtotoalDocumentsValueContainer);
            flxTotalDocuments.add(lblTotalDocuments, flxTotalDocumentsValue);
            var flxDocuments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocuments.setDefaultUnit(kony.flex.DP);
            var lblDocuments = new kony.ui.Label({
                "id": "lblDocuments",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Documents:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocumentsValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValue.setDefaultUnit(kony.flex.DP);
            var flxDocumentsValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.setDefaultUnit(kony.flex.DP);
            var segDocumentsValueContainer = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}],
                "groupCells": false,
                "id": "segDocumentsValueContainer",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxSectionHeaderTemplate"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocumentsValueContainer.add(segDocumentsValueContainer);
            flxDocumentsValue.add(flxDocumentsValueContainer);
            flxDocuments.add(lblDocuments, flxDocumentsValue);
            var flxDocStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatus.setDefaultUnit(kony.flex.DP);
            var lblDocStatus = new kony.ui.Label({
                "id": "lblDocStatus",
                "isVisible": true,
                "left": "1.54%",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Document Status:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDocStatusValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "310dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValue.setDefaultUnit(kony.flex.DP);
            var flxDocStatusValueContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocStatusValueContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.setDefaultUnit(kony.flex.DP);
            var lblDocStatusValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Registered Email Address"
                },
                "id": "lblDocStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Discrepant",
                "top": "0",
                "width": "46.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDocStatusValueContainer.add(lblDocStatusValue);
            flxDocStatusValue.add(flxDocStatusValueContainer);
            flxDocStatus.add(lblDocStatus, flxDocStatusValue);
            var flxDiscrepancyResponse = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiscrepancyResponse",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.setDefaultUnit(kony.flex.DP);
            var segDiscrepancyResponse = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segDiscrepancyResponse",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxDrawingDetailsExport"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiscrepancyResponse.add(segDiscrepancyResponse);
            flxDiscrepanciesMain.add(flxTotalDocuments, flxDocuments, flxDocStatus, flxDiscrepancyResponse);
            flxDiscrepanciesandResponse.add(flxDiscrepanciesHeader, flxDiscrepanciesMain);
            var flxResponseDiscrepancy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxResponseDiscrepancy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "ICSknShadowfffffBdr4Blur10px",
                "top": "30dp",
                "width": "87.33%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancy.setDefaultUnit(kony.flex.DP);
            var flxResponseDiscrepancyHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxResponseDiscrepancyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "98%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancyHeader.setDefaultUnit(kony.flex.DP);
            var lblResponseDiscrepancyHeader = new kony.ui.Label({
                "id": "lblResponseDiscrepancyHeader",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ResponsetoDiscrepancies\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancyHeader.add(lblResponseDiscrepancyHeader);
            var flxSeparatorDiscrepancyTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorDiscrepancyTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDiscrepancyTop.setDefaultUnit(kony.flex.DP);
            flxSeparatorDiscrepancyTop.add();
            var segResponseDiscrepant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDropdown": "",
                    "lblAddComment": "",
                    "lblDiscrepancy1": "",
                    "lblDiscrepancyReason": "",
                    "lblDiscrepancyReason1": "",
                    "lblDiscrepancyReason2": "",
                    "lblDiscrepancyReason3": "",
                    "lblEnterCommentHere": "",
                    "lblRemoveComment": "",
                    "lblSearchHere": "",
                    "txtAreaComment": ""
                }],
                "groupCells": false,
                "id": "segResponseDiscrepant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxResponseToDiscrepancy"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDiscrepancy1lbl": "flxDiscrepancy1lbl",
                    "flxDiscrepancyComment": "flxDiscrepancyComment",
                    "flxDiscrepancyExtraComment": "flxDiscrepancyExtraComment",
                    "flxDropdown": "flxDropdown",
                    "flxDropdownimg": "flxDropdownimg",
                    "flxEnterComment": "flxEnterComment",
                    "flxRemoveComment": "flxRemoveComment",
                    "flxResponseToDiscrepancy": "flxResponseToDiscrepancy",
                    "flxSearchHere": "flxSearchHere",
                    "imgDropdown": "imgDropdown",
                    "lblAddComment": "lblAddComment",
                    "lblDiscrepancy1": "lblDiscrepancy1",
                    "lblDiscrepancyReason": "lblDiscrepancyReason",
                    "lblEnterCommentHere": "lblEnterCommentHere",
                    "lblRemoveComment": "lblRemoveComment",
                    "lblSearchHere": "lblSearchHere"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxReturnMessageToBank = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReturnMessageToBank",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReturnMessageToBank.setDefaultUnit(kony.flex.DP);
            var lblReturnMessageToBank = new kony.ui.Label({
                "id": "lblReturnMessageToBank",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl424242SSPRegular15px",
                "text": "Return Message to Bank (Optional)",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxReturnMessageToBankContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReturnMessageToBankContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "64.49%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReturnMessageToBankContent.setDefaultUnit(kony.flex.DP);
            var flxReturnMessageToBankValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReturnMessageToBankValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "40.40%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReturnMessageToBankValue.setDefaultUnit(kony.flex.DP);
            var txtReturnMessageToBankValue = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "75dp",
                "id": "txtReturnMessageToBankValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "maxTextLength": 50,
                "numberOfVisibleLines": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "skin": "ICSknTxtAreaE3E3E3Border1px424242SSPRegular13px",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [3, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTextAreaPlaceholder727272SSPR36px"
            });
            flxReturnMessageToBankValue.add(txtReturnMessageToBankValue);
            flxReturnMessageToBankContent.add(flxReturnMessageToBankValue);
            flxReturnMessageToBank.add(lblReturnMessageToBank, flxReturnMessageToBankContent);
            var flxSummaryBottomSeparator02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSummaryBottomSeparator02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "97%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryBottomSeparator02.setDefaultUnit(kony.flex.DP);
            flxSummaryBottomSeparator02.add();
            var flxResponseDiscrepancyButtonActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxResponseDiscrepancyButtonActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancyButtonActions.setDefaultUnit(kony.flex.DP);
            var flxResponseDiscrepancyButton = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxResponseDiscrepancyButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancyButton.setDefaultUnit(kony.flex.DP);
            var btnContinueRevise = new kony.ui.Button({
                "height": "40dp",
                "id": "btnContinueRevise",
                "isVisible": true,
                "left": "0dp",
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.ContinuetoReviseDrawing\")",
                "top": "0dp",
                "width": "240dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnWithoutRevise = new kony.ui.Button({
                "height": "40dp",
                "id": "btnWithoutRevise",
                "isVisible": true,
                "left": "0dp",
                "right": "20dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.SubmitwithoutReviseDrawing\")",
                "top": "0dp",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackResponse = new kony.ui.Button({
                "height": "40dp",
                "id": "btnBackResponse",
                "isVisible": true,
                "left": "0dp",
                "right": "20dp",
                "skin": "ICSknsknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.transaction.back\")",
                "top": "0dp",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResponseDiscrepancyButton.add(btnContinueRevise, btnWithoutRevise, btnBackResponse);
            flxResponseDiscrepancyButtonActions.add(flxResponseDiscrepancyButton);
            flxResponseDiscrepancy.add(flxResponseDiscrepancyHeader, flxSeparatorDiscrepancyTop, segResponseDiscrepant, flxReturnMessageToBank, flxSummaryBottomSeparator02, flxResponseDiscrepancyButtonActions);
            flxMain.add(flxSubHeader, flxLCSummaryTablet, flxLCSummaryBody, flxDrawingDetails, flxDiscrepanciesandResponse, flxResponseDiscrepancy);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "1999dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxFooterMenu": {
                        "left": "6.50%"
                    },
                    "lblCopyright": {
                        "left": "6.50%",
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "215dp",
                "clipBounds": false,
                "height": "268dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 1500,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxViewLCDetailsPopup = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewLCDetailsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "630dp",
                "horizontalScrollIndicator": true,
                "id": "flxLCDetailsPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknNoBorder",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "50%"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsPopup.setDefaultUnit(kony.flex.DP);
            var flxLCDetailsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxLCDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblLCDetailsHeader = new kony.ui.Label({
                "id": "lblLCDetailsHeader",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "View LC Details",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2.50%",
                "skin": "slFbox",
                "top": "12dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCross",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var flxSeparator02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "49dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator02.setDefaultUnit(kony.flex.DP);
            flxSeparator02.add();
            flxLCDetailsHeader.add(lblLCDetailsHeader, flxCross, flxSeparator02);
            var flxLCDetailsData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetailsData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetailsData.setDefaultUnit(kony.flex.DP);
            var flxLCDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCDetails.setDefaultUnit(kony.flex.DP);
            var lblLcDetails = new kony.ui.Label({
                "id": "lblLcDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCDetails\")",
                "top": "10dp",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "93.07%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop.add();
            var flxLCSummaryBody01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLCSummaryBody01",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "565dp",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLCSummaryBody01.setDefaultUnit(kony.flex.DP);
            var flxLeftLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoKey = new kony.ui.Label({
                "id": "lblLCRefNoKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.LCReferenceNumber\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeKey = new kony.ui.Label({
                "id": "lblLCTypeKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ImportLC.LCType\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantKey = new kony.ui.Label({
                "id": "lblApplicantKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ExportLC.Applicant\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantAddressKey = new kony.ui.Label({
                "id": "lblApplicantAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Applicant Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankKey = new kony.ui.Label({
                "id": "lblIssuingBankKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssuingBankAddressKey = new kony.ui.Label({
                "id": "lblIssuingBankAddressKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Issuing Bank Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIssueDateKey = new kony.ui.Label({
                "id": "lblIssueDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Issue Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpireDateKey = new kony.ui.Label({
                "id": "lblExpireDateKey",
                "isVisible": true,
                "left": "0",
                "text": "Expiry Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountKey = new kony.ui.Label({
                "id": "lblLCAmountKey",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "LC Amount: ",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftLCSummary.add(lblLCRefNoKey, lblLCTypeKey, lblApplicantKey, lblApplicantAddressKey, lblIssuingBankKey, lblIssuingBankAddressKey, lblIssueDateKey, lblExpireDateKey, lblLCAmountKey);
            var flxRightLCSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightLCSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.setDefaultUnit(kony.flex.DP);
            var lblLCRefNoValue = new kony.ui.Label({
                "id": "lblLCRefNoValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCTypeeValue = new kony.ui.Label({
                "id": "lblLCTypeeValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantValue = new kony.ui.Label({
                "id": "lblLCApplicantValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCApplicantAddValue = new kony.ui.Label({
                "id": "lblLCApplicantAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankalue = new kony.ui.Label({
                "id": "lblLCIssueBankalue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueBankAddValue = new kony.ui.Label({
                "id": "lblLCIssueBankAddValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCIssueDateValue = new kony.ui.Label({
                "id": "lblLCIssueDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCExpireDateValue = new kony.ui.Label({
                "id": "lblLCExpireDateValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLCAmountValuee = new kony.ui.Label({
                "id": "lblLCAmountValuee",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightLCSummary.add(lblLCRefNoValue, lblLCTypeeValue, lblLCApplicantValue, lblLCApplicantAddValue, lblLCIssueBankalue, lblLCIssueBankAddValue, lblLCIssueDateValue, lblLCExpireDateValue, lblLCAmountValuee);
            flxLCSummaryBody01.add(flxLeftLCSummary, flxRightLCSummary);
            var flxSeparatorTop02 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorTop02",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "97.71%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTop02.setDefaultUnit(kony.flex.DP);
            flxSeparatorTop02.add();
            flxLCDetails.add(lblLcDetails, flxSeparatorTop, flxLCSummaryBody01, flxSeparatorTop02);
            var flxBeneficiaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryDetails.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryDetails = new kony.ui.Label({
                "id": "lblBeneficiaryDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Beneficiary Details",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorMid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorMid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "40dp",
                "width": "93%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMid.setDefaultUnit(kony.flex.DP);
            flxSeparatorMid.add();
            var flxBeneficiaryBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeneficiaryBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "60dp",
                "width": "440dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryBody.setDefaultUnit(kony.flex.DP);
            var flxBenLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenLeft.setDefaultUnit(kony.flex.DP);
            var lblBenName = new kony.ui.Label({
                "id": "lblBenName",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddress = new kony.ui.Label({
                "id": "lblBenAddress",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenLeft.add(lblBenName, lblBenAddress);
            var flxBenRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBenRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "136dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenRight.setDefaultUnit(kony.flex.DP);
            var lblBenNameValue = new kony.ui.Label({
                "id": "lblBenNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBenAddValue = new kony.ui.Label({
                "id": "lblBenAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenRight.add(lblBenNameValue, lblBenAddValue);
            flxBeneficiaryBody.add(flxBenLeft, flxBenRight);
            var flxSeparatorBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "140dp",
                "width": "98.72%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBen.setDefaultUnit(kony.flex.DP);
            flxSeparatorBen.add();
            flxBeneficiaryDetails.add(lblBeneficiaryDetails, flxSeparatorMid, flxBeneficiaryBody, flxSeparatorBen);
            var flxGoodShipment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipment.setDefaultUnit(kony.flex.DP);
            var lblGoodShipment = new kony.ui.Label({
                "id": "lblGoodShipment",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Good & Shipment Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorGoods = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorGoods",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "45dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorGoods.setDefaultUnit(kony.flex.DP);
            flxSeparatorGoods.add();
            var flxGoodShipmentBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodShipmentBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodShipmentBody.setDefaultUnit(kony.flex.DP);
            var flxGoodsLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.setDefaultUnit(kony.flex.DP);
            var lblGoodsDescription = new kony.ui.Label({
                "id": "lblGoodsDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Goods Description:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAdditionalCon = new kony.ui.Label({
                "id": "lblAdditionalCon",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Additional Conditions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirm = new kony.ui.Label({
                "id": "lblConfirm",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Confirm Instructions:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentDate = new kony.ui.Label({
                "id": "lblShipmentDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Latest Shipment Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsLeft.add(lblGoodsDescription, lblAdditionalCon, lblConfirm, lblShipmentDate);
            var flxGoodsRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGoodsRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "106px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoodsRight.setDefaultUnit(kony.flex.DP);
            var lblDescriptionValue = new kony.ui.Label({
                "id": "lblDescriptionValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddValue = new kony.ui.Label({
                "id": "lblAddValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirmValue = new kony.ui.Label({
                "id": "lblConfirmValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShipmentValue = new kony.ui.Label({
                "id": "lblShipmentValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGoodsRight.add(lblDescriptionValue, lblAddValue, lblConfirmValue, lblShipmentValue);
            flxGoodShipmentBody.add(flxGoodsLeft, flxGoodsRight);
            var flxSeparatorBottom01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorBottom01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "200dp",
                "width": "97.63%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom01.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom01.add();
            flxGoodShipment.add(lblGoodShipment, flxSeparatorGoods, flxGoodShipmentBody, flxSeparatorBottom01);
            var flxDocumentTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTerms.setDefaultUnit(kony.flex.DP);
            var lblDocumentTerms = new kony.ui.Label({
                "id": "lblDocumentTerms",
                "isVisible": true,
                "left": "15dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Documents and Terms",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "10dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument.add();
            var flxDocumentTermsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentTermsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentTermsBody.setDefaultUnit(kony.flex.DP);
            var flxLeftContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContent.setDefaultUnit(kony.flex.DP);
            var lblDocumentName = new kony.ui.Label({
                "id": "lblDocumentName",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Document Name:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadedFiles = new kony.ui.Label({
                "id": "lblUploadedFiles",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Uploaded Files:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftContent.add(lblDocumentName, lblUploadedFiles);
            var flxRightContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "110dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContent.setDefaultUnit(kony.flex.DP);
            var lblDocNameValue = new kony.ui.Label({
                "id": "lblDocNameValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSegUploadDoc = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegUploadDoc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "85%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegUploadDoc.setDefaultUnit(kony.flex.DP);
            var segUploadedDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUploadedDocs",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxExportLCUploadDocPopup"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDocContent": "flxDocContent",
                    "flxDocumentName": "flxDocumentName",
                    "flxExportLCUploadDocPopup": "flxExportLCUploadDocPopup",
                    "flxMain": "flxMain",
                    "flxPDFImage": "flxPDFImage",
                    "imgPDF": "imgPDF",
                    "lblDocumentName": "lblDocumentName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegUploadDoc.add(segUploadedDocs);
            flxRightContent.add(lblDocNameValue, flxSegUploadDoc);
            flxDocumentTermsBody.add(flxLeftContent, flxRightContent);
            var flxSeparatorDocument03 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument03",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument03.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument03.add();
            flxDocumentTerms.add(lblDocumentTerms, flxSeparatorDocument, flxDocumentTermsBody, flxSeparatorDocument03);
            var flxSwiftMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "97.32%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessage.setDefaultUnit(kony.flex.DP);
            var lblSwiftMessage = new kony.ui.Label({
                "id": "lblSwiftMessage",
                "isVisible": true,
                "left": 10,
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "SWIFT Message and Advises Details",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorDocument01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "2dp",
                "id": "flxSeparatorDocument01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "35dp",
                "width": "95.35%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDocument01.setDefaultUnit(kony.flex.DP);
            flxSeparatorDocument01.add();
            var flxSwiftMessageBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxSwiftMessageBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageBody.setDefaultUnit(kony.flex.DP);
            var flxSwiftMessageLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessageLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.setDefaultUnit(kony.flex.DP);
            var lblMessageType = new kony.ui.Label({
                "id": "lblMessageType",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Type:",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDelivered = new kony.ui.Label({
                "id": "lblDelivered",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Delivered To/From:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDate = new kony.ui.Label({
                "id": "lblSwiftDate",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Date:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategory = new kony.ui.Label({
                "id": "lblMessageCategory",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular727272op10015px",
                "text": "Message Category:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessageLeft.add(lblMessageType, lblDelivered, lblSwiftDate, lblMessageCategory);
            var flxSwiftMessagesRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSwiftMessagesRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "101dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.setDefaultUnit(kony.flex.DP);
            var lblMessageTypeValue = new kony.ui.Label({
                "id": "lblMessageTypeValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliveredValue = new kony.ui.Label({
                "id": "lblDeliveredValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftDateValue = new kony.ui.Label({
                "id": "lblSwiftDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageCategoryValue = new kony.ui.Label({
                "id": "lblMessageCategoryValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": "Label",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwiftMessagesRight.add(lblMessageTypeValue, lblDeliveredValue, lblSwiftDateValue, lblMessageCategoryValue);
            flxSwiftMessageBody.add(flxSwiftMessageLeft, flxSwiftMessagesRight);
            flxSwiftMessage.add(lblSwiftMessage, flxSeparatorDocument01, flxSwiftMessageBody);
            flxLCDetailsData.add(flxLCDetails, flxBeneficiaryDetails, flxGoodShipment, flxDocumentTerms, flxSwiftMessage);
            flxLCDetailsPopup.add(flxLCDetailsHeader, flxLCDetailsData);
            flxViewLCDetailsPopup.add(flxLCDetailsPopup);
            var flxMainReturnBankPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxMainReturnBankPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "1290dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainReturnBankPopup.setDefaultUnit(kony.flex.DP);
            var flxMainReturnPopup = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "550dp",
                "id": "flxMainReturnPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "150dp",
                "width": "610dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainReturnPopup.setDefaultUnit(kony.flex.DP);
            var flxReturnByBankPopup = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "655dp",
                "id": "flxReturnByBankPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "84dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffOuterShadowdddcdc",
                "top": "210dp",
                "width": "700dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReturnByBankPopup.setDefaultUnit(kony.flex.DP);
            var flxPopupHeaderTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPopupHeaderTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupHeaderTop.setDefaultUnit(kony.flex.DP);
            var lblReturnByBank = new kony.ui.Label({
                "id": "lblReturnByBank",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Return by Bank History (3)",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearchClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28dp",
                "id": "flxSearchClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchClose.setDefaultUnit(kony.flex.DP);
            var imgSearchClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearchClose",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchClose.add(imgSearchClose);
            flxPopupHeaderTop.add(lblReturnByBank, flxSearchClose);
            var flxSeparatorReturnTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorReturnTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "46dp",
                "width": "87%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorReturnTop.setDefaultUnit(kony.flex.DP);
            flxSeparatorReturnTop.add();
            flxReturnByBankPopup.add(flxPopupHeaderTop, flxSeparatorReturnTop);
            var flxMainBodyContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "480dp",
                "id": "flxMainBodyContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "84dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffNoShadow",
                "top": "255dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainBodyContainer.setDefaultUnit(kony.flex.DP);
            var segReturnByBank01 = new kony.ui.SegmentedUI2({
                "data": [{
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }, {
                    "lblReasonReturn": "Label",
                    "lblReasonReturn02": "Label",
                    "lblReasonReturn03": "Label",
                    "lblReturnBank": "Returned by Bank (3rd)",
                    "lblReturnDate": "03/04/2021",
                    "lblRightValue": "Label",
                    "lblRightValue02": "Label",
                    "lblRightValue03": "Label"
                }],
                "groupCells": false,
                "height": "480dp",
                "id": "segReturnByBank01",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TradeFinanceMA",
                    "friendlyName": "flxReturnedByBank"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxReturnByBankInner": "flxReturnByBankInner",
                    "flxReturnByBankOuter": "flxReturnByBankOuter",
                    "flxReturnedByBank": "flxReturnedByBank",
                    "flxReturnedByBankBodyContent": "flxReturnedByBankBodyContent",
                    "flxReturnedByBankBodyContent02": "flxReturnedByBankBodyContent02",
                    "flxReturnedByBankBodyContent03": "flxReturnedByBankBodyContent03",
                    "flxSeparatorReturnTop03": "flxSeparatorReturnTop03",
                    "flxSeparatorTopReturnBank": "flxSeparatorTopReturnBank",
                    "lblReasonReturn": "lblReasonReturn",
                    "lblReasonReturn02": "lblReasonReturn02",
                    "lblReasonReturn03": "lblReasonReturn03",
                    "lblReturnBank": "lblReturnBank",
                    "lblReturnDate": "lblReturnDate",
                    "lblRightValue": "lblRightValue",
                    "lblRightValue02": "lblRightValue02",
                    "lblRightValue03": "lblRightValue03"
                },
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMainBodyContainer.add(segReturnByBank01);
            flxMainReturnPopup.add(flxReturnByBankPopup, flxMainBodyContainer);
            flxMainReturnBankPopup.add(flxMainReturnPopup);
            var flxMainSubmit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxMainSubmit",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "minHeight": "1290dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainSubmit.setDefaultUnit(kony.flex.DP);
            var flxPopupRevisedSubmit = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "656dp",
                "id": "flxPopupRevisedSubmit",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "386dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffNoShadow",
                "top": "389dp",
                "width": "596dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupRevisedSubmit.setDefaultUnit(kony.flex.DP);
            var flxPopupHeaderSubmit = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPopupHeaderSubmit",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupHeaderSubmit.setDefaultUnit(kony.flex.DP);
            var lblRevisedSubmit = new kony.ui.Label({
                "id": "lblRevisedSubmit",
                "isVisible": true,
                "left": "1.46%",
                "skin": "ICSknLabelSSPRegular42424215px",
                "text": "Copy Details",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearch01 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "28dp",
                "id": "flxSearch01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "550dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "28dp",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch01.setDefaultUnit(kony.flex.DP);
            var imgSearch01 = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearch01",
                "isVisible": true,
                "left": "0",
                "src": "blue_close_icon.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearch01.add(imgSearch01);
            flxPopupHeaderSubmit.add(lblRevisedSubmit, flxSearch01);
            var flxSeparator01 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator01",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "44dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator01.setDefaultUnit(kony.flex.DP);
            flxSeparator01.add();
            var flxPopupBodyContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxPopupBodyContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBodyContent.setDefaultUnit(kony.flex.DP);
            var lblBodyContent = new kony.ui.Label({
                "id": "lblBodyContent",
                "isVisible": true,
                "left": "0",
                "text": "Are you sure you want to submit this without revise the drawing?",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMessageContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxMessageContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var lblMessageOptional = new kony.ui.Label({
                "id": "lblMessageOptional",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTextArea = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "txtTextArea",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Kindly",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxMessageContainer.add(lblMessageOptional, txtTextArea);
            flxPopupBodyContent.add(lblBodyContent, flxMessageContainer);
            var flxSeparator0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "576dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator0.setDefaultUnit(kony.flex.DP);
            flxSeparator0.add();
            var flxButtonsBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButtonsBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "595dp",
                "width": "100%",
                "appName": "TradeFinanceMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonsBottom.setDefaultUnit(kony.flex.DP);
            var btnNo = new kony.ui.Button({
                "height": "40dp",
                "id": "btnNo",
                "isVisible": true,
                "left": "246dp",
                "skin": "ICSknBtnSSPRegular003E7515Px",
                "text": "Close",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnYes = new kony.ui.Button({
                "height": "40dp",
                "id": "btnYes",
                "isVisible": true,
                "left": "416dp",
                "skin": "sknBtnBg003e75Rad3pxFont15pxFFF",
                "text": "Copy Details",
                "top": "0",
                "width": "160dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtonsBottom.add(btnNo, btnYes);
            flxPopupRevisedSubmit.add(flxPopupHeaderSubmit, flxSeparator01, flxPopupBodyContent, flxSeparator0, flxButtonsBottom);
            flxMainSubmit.add(flxPopupRevisedSubmit);
            flxDialogs.add(flxLogout, flxViewLCDetailsPopup, flxMainReturnBankPopup, flxMainSubmit);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.imgKonyHamburger": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Import LC",
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader02": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummayTablet": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCSummaryTablet": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxViewLCDetailsTop": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segLCSummaryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryHeader": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "LC Summary",
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgDrawingDetailsDropdown": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblDiscrepanciesandResponseValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "segmentProps": []
                    },
                    "flxViewReturnedByBankHistory": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBottomSeparater02": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxtotoalDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValueContainer": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknSSP42424213Px",
                        "segmentProps": []
                    },
                    "flxSeparatorDiscrepancyTop": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxReturnMessageToBank": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnMessageToBank": {
                        "skin": "ICSknLblSSP72727213px",
                        "segmentProps": []
                    },
                    "flxReturnMessageToBankContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxReturnMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "txtReturnMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator02": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxResponseDiscrepancyButton": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknFlxBordere3e3e3Radius3Px",
                        "segmentProps": []
                    },
                    "btnContinueRevise": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnWithoutRevise": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBackResponse": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody01": {
                        "segmentProps": []
                    },
                    "lblLCRefNoKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblApplicantAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssuingBankAddressKey": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCRefNoValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCTypeeValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCApplicantAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankalue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueBankAddValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "Default": {
                            "contentAlignment": 4
                        },
                        "accessibilityConfig": {},
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "text": "User entered message will appear here in two lines with truncation in the en..",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnBankPopup": {
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchClose": {
                        "right": {
                            "type": "string",
                            "value": "5.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainSubmit": {
                        "segmentProps": []
                    },
                    "flxPopupRevisedSubmit": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "605dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "lblRevisedSubmit": {
                        "left": {
                            "type": "string",
                            "value": "4.6%"
                        },
                        "segmentProps": []
                    },
                    "flxSearch01": {
                        "left": {
                            "type": "string",
                            "value": "88.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": "5.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator0": {
                        "top": {
                            "type": "string",
                            "value": "536dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsBottom": {
                        "top": {
                            "type": "string",
                            "value": "545dp"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "left": {
                            "type": "string",
                            "value": "6.60%"
                        },
                        "skin": "ICSknBtnSSPRegular003E7513Px",
                        "text": "Close",
                        "width": {
                            "type": "string",
                            "value": "42.85%"
                        },
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": "53.30%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6.60%"
                        },
                        "skin": "ICSknBtnSSPffffff13pxBg003e75",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.85%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxSubHeader": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxVerticalEllipsisDropdown": {
                        "segmentProps": []
                    },
                    "flxLCSummaryTablet": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummayTablet": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsTop": {
                        "right": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblViewLCDetailsTablet": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "segLCSummaryContent": {
                        "data": [{
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Applicant:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Katie Floyd"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Advising LC Ref No:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC0000100001"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Amount:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$ 2,567.87"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Untilized Amount:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": " $ 2,567.87"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "LC Type:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Sight"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issue Date:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "10/11/2021"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Expiry Date:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "12/31/2022"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issuing Bank:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Bank of America"
                            }
                        }, {
                            "lblReview": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Issuing LC Ref No:"
                            },
                            "lblReviewValue1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "5678098765"
                            }
                        }],
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingsRowTemplate"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingsRowTemplate": "flxDrawingsRowTemplate",
                            "flxReviewRight": "flxReviewRight",
                            "flxReviewValues": "flxReviewValues",
                            "flxreviewRows": "flxreviewRows",
                            "lblReview": "lblReview",
                            "lblReviewValue1": "lblReviewValue1"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxLCSummaryBody": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLCSummarylbl": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsNew": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "75.04%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblViewLCDetialsNew": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "47%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponseLabel": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxViewReturnedByBankHistory": {
                        "segmentProps": []
                    },
                    "lblViewReturnedByBankHistory": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparater02": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalDocumentsValue": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDocumentsValue": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentsValue": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDocStatusValue": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblDocStatusValue": {
                        "segmentProps": []
                    },
                    "flxResponseDiscrepancy": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "segResponseDiscrepant": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "rowSkin": "sknSegScrollHide",
                        "segmentProps": []
                    },
                    "flxReturnMessageToBank": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblReturnMessageToBank": {
                        "skin": "ICSknLabelSSPRegular72727215px",
                        "segmentProps": []
                    },
                    "flxReturnMessageToBankContent": {
                        "segmentProps": []
                    },
                    "flxReturnMessageToBankValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryBottomSeparator02": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxResponseDiscrepancyButton": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnContinueRevise": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    },
                    "btnWithoutRevise": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "234dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackResponse": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "zIndex": 5000,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50.06%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "text": "Export LC - LC0000100001",
                        "segmentProps": []
                    },
                    "flxCross": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsData": {
                        "segmentProps": []
                    },
                    "flxLCDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody01": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTop02": {
                        "segmentProps": []
                    },
                    "flxBeneficiaryDetails": {
                        "segmentProps": []
                    },
                    "flxSeparatorMid": {
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBen": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipment": {
                        "segmentProps": []
                    },
                    "flxSeparatorGoods": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodShipmentBody": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdditionalCon": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirm": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodsRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAddValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblShipmentValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom01": {
                        "top": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocumentTerms": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument": {
                        "segmentProps": []
                    },
                    "flxDocumentTermsBody": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument03": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument01": {
                        "segmentProps": []
                    },
                    "flxSwiftMessageBody": {
                        "segmentProps": []
                    },
                    "lblDelivered": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDate": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategory": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxSwiftMessagesRight": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDeliveredValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftDateValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageCategoryValue": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnBankPopup": {
                        "minHeight": {
                            "type": "string",
                            "value": "1270dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchClose": {
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "segReturnByBank01": {
                        "segmentProps": []
                    },
                    "flxMainSubmit": {
                        "segmentProps": []
                    },
                    "flxPopupRevisedSubmit": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "height": {
                            "type": "string",
                            "value": "247dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "134dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "lblRevisedSubmit": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "text": "Submit without Revise Drawing",
                        "segmentProps": []
                    },
                    "flxSearch01": {
                        "left": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopupBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "458dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator0": {
                        "top": {
                            "type": "string",
                            "value": "166dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsBottom": {
                        "top": {
                            "type": "string",
                            "value": "186dp"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "left": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "text": "No",
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblLCSummaryTablet": {
                        "i18n_text": "i18n.TradeFinance.LCSummary",
                        "segmentProps": []
                    },
                    "lblViewLCDetailsTablet": {
                        "i18n_text": "i18n.TradeFinance.ViewLCDetails",
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "lblLCSummary": {
                        "i18n_text": "i18n.TradeFinance.LCSummary",
                        "segmentProps": []
                    },
                    "lblViewLCDetials": {
                        "i18n_text": "i18n.TradeFinance.ViewLCDetails",
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingDetailsDropdown": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsNew": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingStatus": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingRef": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingCreated": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingAmount": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountCredited": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFinanceUS": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxUploadDocs": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "segUploadDocuments": {
                        "segmentProps": []
                    },
                    "flxPhysicalDocDetails": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "segPhysicalDocuments": {
                        "segmentProps": []
                    },
                    "flxDiscrepancies": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxChargesDebit": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxMsgToBank": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblDiscrepanciesandResponseValue": {
                        "text": "Discrepancies - Returned by Bank",
                        "segmentProps": []
                    },
                    "flxViewReturnedByBankHistory": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18.33%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "flxTotalDocuments": {
                        "segmentProps": []
                    },
                    "lblTotalDocuments": {
                        "segmentProps": []
                    },
                    "flxDocuments": {
                        "segmentProps": []
                    },
                    "lblDocuments": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "data": [{
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Clearance Statement.pdf"
                            }
                        }, {
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Invoices.pdf"
                            }
                        }, {
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Statement1.pdf"
                            }
                        }, {
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Statement2.pdf"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxSectionHeaderTemplate"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxSectionHeaderTemplate": "flxSectionHeaderTemplate",
                            "lblHeading": "lblHeading"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "flxDocStatus": {
                        "segmentProps": []
                    },
                    "lblDocStatus": {
                        "segmentProps": []
                    },
                    "segDiscrepancyResponse": {
                        "data": [{
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Reason for Return:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Check the Packing list and Shipping advise and clear this"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Discrepancy 1:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Packing list not signed"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D1 User Response:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "i Accept this discrepanct, I will submit a revised document"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Discrepancy 2:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Shipping Advise stamp is missing"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D2 User Response:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I Accept this discrepancty, Please proceed with the existing document"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "D2 User Comment:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Shipping has started"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "lblLeft1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Return Message to Bank:"
                            },
                            "lblRight1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Kindly forward this with revised packing list"
                            },
                            "lblRight2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblRight4": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TradeFinanceMA",
                            "friendlyName": "flxDrawingDetailsExport"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDrawingDetailsExport": "flxDrawingDetailsExport",
                            "flxRight1": "flxRight1",
                            "lblLeft1": "lblLeft1",
                            "lblRight1": "lblRight1",
                            "lblRight2": "lblRight2",
                            "lblRight3": "lblRight3",
                            "lblRight4": "lblRight4"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TradeFinanceMA"
                    },
                    "lblResponseDiscrepancyHeader": {
                        "i18n_text": "i18n.TradeFinance.ResponsetoDiscrepancies",
                        "segmentProps": []
                    },
                    "flxSeparatorDiscrepancyTop": {
                        "segmentProps": []
                    },
                    "segResponseDiscrepant": {
                        "rowSkin": "sknSegScrollHide",
                        "segmentProps": []
                    },
                    "lblReturnMessageToBank": {
                        "skin": "ICSknLabelSSPRegular72727215px",
                        "segmentProps": []
                    },
                    "flxReturnMessageToBankValue": {
                        "width": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "segmentProps": []
                    },
                    "flxResponseDiscrepancyButton": {
                        "segmentProps": []
                    },
                    "btnContinueRevise": {
                        "i18n_text": "i18n.TradeFinance.ContinuetoReviseDrawing",
                        "segmentProps": []
                    },
                    "btnWithoutRevise": {
                        "i18n_text": "i18n.TradeFinance.SubmitwithoutReviseDrawing",
                        "segmentProps": []
                    },
                    "btnBackResponse": {
                        "i18n_text": "kony.mb.transaction.back",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "text": "Export LC - LC0000100001",
                        "segmentProps": []
                    },
                    "flxLCDetailsData": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTop": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightLCSummary": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxGoodsRight": {
                        "segmentProps": []
                    },
                    "flxDocumentTerms": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxLeftContent": {
                        "segmentProps": []
                    },
                    "flxSeparatorDocument03": {
                        "segmentProps": []
                    },
                    "flxSwiftMessage": {
                        "segmentProps": []
                    },
                    "flxMainReturnBankPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "segReturnByBank01": {
                        "segmentProps": []
                    },
                    "flxMainSubmit": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopupRevisedSubmit": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "303dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "433dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopupHeaderSubmit": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblRevisedSubmit": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Submit without any revised Documents",
                        "segmentProps": []
                    },
                    "flxSearch01": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "463dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator01": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "flxPopupBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "179dp"
                        },
                        "skin": "sdb4293bb6e54e81a5ccbffe6df8f488",
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "lblBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "458dp"
                        },
                        "segmentProps": []
                    },
                    "flxMessageContainer": {
                        "height": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "367dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageOptional": {
                        "height": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Message to Bank (Optional)",
                        "width": {
                            "type": "string",
                            "value": "214dp"
                        },
                        "segmentProps": []
                    },
                    "txtTextArea": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "placeholder": "Kindly forward the documents to issuing bank",
                        "placeholderSkin": "sknTxtReplyMessageffffffTab",
                        "skin": "ICSknTxtAreaE3E3E3Border1px424242SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "367dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator0": {
                        "skin": "sknflxe9ebee",
                        "top": {
                            "type": "string",
                            "value": "224dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsBottom": {
                        "top": {
                            "type": "string",
                            "value": "243dp"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "text": "Yes",
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxLCSummaryBody": {
                        "segmentProps": []
                    },
                    "flxDrawingDetails": {
                        "skin": "ICSknShadowfffffBdr4Blur10px",
                        "segmentProps": []
                    },
                    "flxDrawingDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsNew": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingStatus": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingRef": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingCreated": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDrawingAmount": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountCredited": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxFinanceUS": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxUploadDocs": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxPhysicalDocDetails": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepancies": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxChargesDebit": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxMsgToBank": {
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "segmentProps": []
                    },
                    "flxDiscrepanciesandResponse": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDiscrepanciesMain": {
                        "segmentProps": []
                    },
                    "segDocumentsValueContainer": {
                        "segmentProps": []
                    },
                    "btnContinueRevise": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewLCDetailsPopup": {
                        "segmentProps": []
                    },
                    "flxLCDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblLCDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxLCSummaryBody01": {
                        "segmentProps": []
                    },
                    "lblIssueDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExpireDateKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCIssueDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblLCExpireDateValue": {
                        "skin": "ICSknLbl42424215PX",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainReturnBankPopup": {
                        "segmentProps": []
                    },
                    "flxMainReturnPopup": {
                        "skin": "ICSknFlxffffffNoShadow",
                        "segmentProps": []
                    },
                    "flxReturnByBankPopup": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblReturnByBank": {
                        "left": {
                            "type": "string",
                            "value": "2.48%"
                        },
                        "segmentProps": []
                    },
                    "flxMainBodyContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "CopyCopyslFbox1",
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "segReturnByBank01": {
                        "segmentProps": []
                    },
                    "flxMainSubmit": {
                        "segmentProps": []
                    },
                    "flxPopupRevisedSubmit": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "303dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "433dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopupHeaderSubmit": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblRevisedSubmit": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424215px",
                        "text": "Submit without any revised Documents",
                        "segmentProps": []
                    },
                    "flxSearch01": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "463dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator01": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "flxPopupBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "179dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "lblBodyContent": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424215px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "458dp"
                        },
                        "segmentProps": []
                    },
                    "flxMessageContainer": {
                        "height": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "367dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageOptional": {
                        "height": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Message to Bank (Optional)",
                        "width": {
                            "type": "string",
                            "value": "214dp"
                        },
                        "segmentProps": []
                    },
                    "txtTextArea": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "placeholder": "Kindly forward the documents to issuing bank",
                        "skin": "ICSknTxtAreaE3E3E3Border1px424242SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "367dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator0": {
                        "skin": "sknflxe9ebee",
                        "top": {
                            "type": "string",
                            "value": "224dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsBottom": {
                        "top": {
                            "type": "string",
                            "value": "243dp"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "text": "No",
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "text": "Yes",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "customfooternew.flxFooterMenu": {
                    "left": "6.50%"
                },
                "customfooternew.lblCopyright": {
                    "left": "6.50%",
                    "top": "75dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmExportLCViewDetailsReturned,
            "enabledForIdleTimeout": true,
            "id": "frmExportLCViewDetailsReturned",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_e1440abdc9f84174a6adfe17808cafae,
            "appName": "TradeFinanceMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});