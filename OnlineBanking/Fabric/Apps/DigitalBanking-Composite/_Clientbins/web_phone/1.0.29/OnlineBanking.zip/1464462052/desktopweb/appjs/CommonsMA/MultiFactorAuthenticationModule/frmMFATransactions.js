define("CommonsMA/MultiFactorAuthenticationModule/frmMFATransactions", function() {
    return function(controller) {
        function addWidgetsfrmMFATransactions() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknRtx424242SSP17Px",
                "text": "There is some error in the server.\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var lblLetsAuthenticate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Lets authenticate!"
                },
                "centerX": "50%",
                "id": "lblLetsAuthenticate",
                "isVisible": true,
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.LetsAuthenticate\")",
                "top": "25dp",
                "width": "1200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxLetsAuthenticateModule = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLetsAuthenticateModule",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "70dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLetsAuthenticateModule.setDefaultUnit(kony.flex.DP);
            var lblHeaderText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Lets authenticate!"
                },
                "id": "lblHeaderText",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mfa.recievingAccessCode\")",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Lets authenticate!"
                },
                "centerX": "50%",
                "height": "1dp",
                "id": "lblSeparator",
                "isVisible": true,
                "left": 20,
                "skin": "sknlblBge3e3e3op100",
                "top": "15dp",
                "width": "1160dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorderE8E9EB",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxWarning",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mfa,wrongAnswer\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(imgWarning, rtxWarning);
            var flxAnswerSecurityQuestions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAnswerSecurityQuestions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAnswerSecurityQuestions.setDefaultUnit(kony.flex.DP);
            var securityQuestions = new com.InfinityOLB.Resources.mfaold.securityQuestions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "securityQuestions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "30dp",
                "top": "0dp",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var securityQuestionsComponent = new com.InfinityOLB.Resources.mfa.securityQuestions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "securityQuestionsComponent",
                "isVisible": false,
                "left": 0,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ResourcesMA",
                "viewType": "securityQuestionsComponent",
                "overrides": {
                    "securityQuestions": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var securityQuestionsComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"]["securityQuestionsComponent"]) || {};
            securityQuestionsComponent.primaryBtnEnableSkin = securityQuestionsComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            securityQuestionsComponent.objectService = securityQuestionsComponent_data.objectService || "RBObjects";
            securityQuestionsComponent.serviceKey = securityQuestionsComponent_data.serviceKey || "";
            securityQuestionsComponent.checkboxUnSelected = securityQuestionsComponent_data.checkboxUnSelected || "D";
            securityQuestionsComponent.primaryBtnDisableSkin = securityQuestionsComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSP0273e315px\", \"hoverSkin\":\"sknBtnBlockedSSP0273e315px\", \"focusSkin\":\"sknBtnBlockedSSP0273e315px\"}";
            securityQuestionsComponent.dataModel = securityQuestionsComponent_data.dataModel || "Users_2";
            securityQuestionsComponent.checkboxSelected = securityQuestionsComponent_data.checkboxSelected || "C";
            securityQuestionsComponent.isPostLogin = securityQuestionsComponent_data.isPostLogin || true;
            securityQuestionsComponent.serviceId = securityQuestionsComponent_data.serviceId || "SERVICE_ID_67";
            securityQuestionsComponent.operationName = securityQuestionsComponent_data.operationName || "verifyLoginMFASecurityQuestions";
            securityQuestionsComponent.action = securityQuestionsComponent_data.action || "";
            flxAnswerSecurityQuestions.add(securityQuestions, securityQuestionsComponent);
            var flxTwoStepVerification = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTwoStepVerification",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTwoStepVerification.setDefaultUnit(kony.flex.DP);
            var flxOTP = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOTP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTP.setDefaultUnit(kony.flex.DP);
            var OTPPostLogin = new com.InfinityOLB.Resources.mfa.OTPPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    },
                    "btnProceed": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "right": "30dp"
                    },
                    "btnResendCode": {
                        "height": "40dp",
                        "isVisible": true,
                        "left": "58dp",
                        "top": "26dp"
                    },
                    "flxActions": {
                        "centerX": "viz.val_cleared",
                        "top": "15dp"
                    },
                    "flxDescription": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "left": "0"
                    },
                    "flxEnterOTPCode": {
                        "isVisible": true,
                        "left": "88dp",
                        "top": "30px"
                    },
                    "flxExtendedNotes": {
                        "bottom": "viz.val_cleared",
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxImgTxt": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxOTPHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxSeparator2": {
                        "top": "20dp"
                    },
                    "imgViewOTPCode": {
                        "src": "view.png"
                    },
                    "lblHeader": {
                        "text": "Select any one or both mode of contact to get a secure  code",
                        "width": "80%"
                    },
                    "lblHeaderOTP": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "lblNote": {
                        "bottom": "viz.val_cleared",
                        "left": "30dp",
                        "top": "50dp"
                    },
                    "lblOTP": {
                        "left": "0dp"
                    },
                    "lblResendMessage": {
                        "top": "3dp"
                    },
                    "lblSecureAccessCodeNotes": {
                        "left": "30dp"
                    },
                    "lblWrongOTP": {
                        "isVisible": false
                    },
                    "rtxHeaderOTP": {
                        "width": "85%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var OTPComponent = new com.InfinityOLB.Resources.mfa.OTPModule({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPComponent",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "OTPComponent",
                "overrides": {
                    "OTPModule": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var OTPComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"]["OTPComponent"]) || {};
            OTPComponent.primaryBtnEnableSkin = OTPComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            OTPComponent.displayAll = OTPComponent_data.displayAll || "DISPLAY_ALL";
            OTPComponent.serviceKey = OTPComponent_data.serviceKey || "";
            OTPComponent.objectService = OTPComponent_data.objectService || "Login";
            OTPComponent.primaryBtnDisableSkin = OTPComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSP0273e315px\", \"hoverSkin\":\"sknBtnBlockedSSP0273e315px\", \"focusSkin\":\"sknBtnBlockedSSP0273e315px\"}";
            OTPComponent.displayPrimary = OTPComponent_data.displayPrimary || "DISPLAY_PRIMARY";
            OTPComponent.dataModel = OTPComponent_data.dataModel || "Users_2";
            OTPComponent.isPostLogin = OTPComponent_data.isPostLogin || true;
            OTPComponent.verifyOTPOperationName = OTPComponent_data.verifyOTPOperationName || "verifyLoginMFAOTP";
            OTPComponent.displayNoValue = OTPComponent_data.displayNoValue || "DISPLAY_NO_VALUE";
            OTPComponent.errorFlexSkin = OTPComponent_data.errorFlexSkin || "sknborderff0000error";
            OTPComponent.serviceName = OTPComponent_data.serviceName || "SERVICE_ID_67";
            OTPComponent.requestOTPOperationName = OTPComponent_data.requestOTPOperationName || "requestLoginMFAOTP";
            OTPComponent.normalFlexSkin = OTPComponent_data.normalFlexSkin || "sknBorderE3E3E3";
            OTPComponent.resendOTPOperationName = OTPComponent_data.resendOTPOperationName || "requestLoginMFAOTP";
            OTPComponent.communicationType = OTPComponent_data.communicationType || "";
            OTPComponent.checkboxSelectedSkin = OTPComponent_data.checkboxSelectedSkin || "sknFontIconCheckBoxSelected";
            OTPComponent.action = OTPComponent_data.action || "";
            OTPComponent.checkboxSelected = OTPComponent_data.checkboxSelected || "C";
            OTPComponent.checkboxUnSelectedSkin = OTPComponent_data.checkboxUnSelectedSkin || "skn0273e320pxolbfonticons";
            OTPComponent.checkboxUnSelected = OTPComponent_data.checkboxUnSelected || "D";
            flxOTP.add(OTPPostLogin, OTPComponent);
            flxTwoStepVerification.add(flxOTP);
            var flxSCAComponent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSCAComponent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSCAComponent.setDefaultUnit(kony.flex.DP);
            var SCAComponent = new com.temenos.infinity.sca.transactions.SCAComponent({
                "height": "220dp",
                "id": "SCAComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "SCAComponent",
                "overrides": {
                    "SCAComponent": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var SCAComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"]["SCAComponent"]) || {};
            SCAComponent.serviceKey = SCAComponent_data.serviceKey || "";
            SCAComponent.flowType = SCAComponent_data.flowType || "";
            flxSCAComponent.add(SCAComponent);
            var flxSCAComponentUniken = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSCAComponentUniken",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSCAComponentUniken.setDefaultUnit(kony.flex.DP);
            var SCAUnikenComponent = new com.temenos.infinity.sca.transactions.uniken.SCAComponent({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "SCAUnikenComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "SCAUnikenComponent",
                "overrides": {
                    "SCAComponent": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var SCAUnikenComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"] && appConfig.componentMetadata["ResourcesMA"]["frmMFATransactions"]["SCAUnikenComponent"]) || {};
            SCAUnikenComponent.serviceKey = SCAUnikenComponent_data.serviceKey || "";
            SCAUnikenComponent.flowType = SCAUnikenComponent_data.flowType || "";
            flxSCAComponentUniken.add(SCAUnikenComponent);
            flxLetsAuthenticateModule.add(lblHeaderText, lblSeparator, flxWarning, flxAnswerSecurityQuestions, flxTwoStepVerification, flxSCAComponent, flxSCAComponentUniken);
            flxMainWrapper.add(lblLetsAuthenticate, flxLetsAuthenticateModule);
            flxMain.add(flxDowntimeWarning, flxMainWrapper);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooter({
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "viz.val_cleared",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var Copyflxleftcontainer0c2717d3a13cb45 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "Copyflxleftcontainer0c2717d3a13cb45",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            Copyflxleftcontainer0c2717d3a13cb45.setDefaultUnit(kony.flex.DP);
            Copyflxleftcontainer0c2717d3a13cb45.add();
            var Copyflxrightcontainer0c249a43c08314b = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "75%",
                "clipBounds": false,
                "height": "150dp",
                "id": "Copyflxrightcontainer0c249a43c08314b",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "CommonsMA"
            }, {
                "paddingInPixel": false
            }, {});
            Copyflxrightcontainer0c249a43c08314b.setDefaultUnit(kony.flex.DP);
            Copyflxrightcontainer0c249a43c08314b.add();
            flxFooter.add(CustomFooterMain, Copyflxleftcontainer0c2717d3a13cb45, Copyflxrightcontainer0c249a43c08314b);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "MFA Transactions",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderText": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "s962c52e36b64a828288abfc542c8d47",
                        "segmentProps": []
                    },
                    "lblSeparator": {
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "rtxWarning": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "segmentProps": []
                    },
                    "flxTwoStepVerification": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProfileSettings": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnResendCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxActions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterOTPCode": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxExtendedNotes": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxImgTxt": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxOTPHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxSeparator2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblHeader": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredPhone": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblResendMessage": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblWrongOTP": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "segmentProps": []
                    },
                    "flxSCAComponent": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderText": {
                        "segmentProps": []
                    },
                    "lblSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "segmentProps": []
                    },
                    "flxTwoStepVerification": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": "",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": "",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnResendCode": {
                        "left": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "left": {
                            "type": "number",
                            "value": "2"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "750dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterOTPCode": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxImgTxt": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "segmentProps": []
                    },
                    "flxSCAComponent": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderText": {
                        "segmentProps": []
                    },
                    "lblSeparator": {
                        "width": {
                            "type": "string",
                            "value": "96.70%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTwoStepVerification": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": "",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": "",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnResendCode": {
                        "left": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "left": {
                            "type": "number",
                            "value": "2"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterOTPCode": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxImgTxt": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.70%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblResendMessage": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxSCAComponent": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblLetsAuthenticate": {
                        "segmentProps": []
                    },
                    "flxLetsAuthenticateModule": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "flxAnswerSecurityQuestions": {
                        "segmentProps": []
                    },
                    "flxTwoStepVerification": {
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnCancel": {
                        "centerX": "",
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnProceed": {
                        "centerX": "",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.btnResendCode": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxDescription": {
                        "left": {
                            "type": "number",
                            "value": "2"
                        },
                        "width": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterOTPCode": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxEnterSecureAccessCode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxImgTxt": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96.70%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblOTP": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblResendMessage": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lblSecureAccessCodeNotes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxEmail": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.lbxPhone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "OTPPostLogin.rtxHeaderOTP": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSCAComponent": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "securityQuestionsComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "OTPPostLogin.btnCancel": {
                    "centerX": "",
                    "centerY": ""
                },
                "OTPPostLogin.btnProceed": {
                    "centerX": "",
                    "centerY": "",
                    "right": "30dp"
                },
                "OTPPostLogin.btnResendCode": {
                    "height": "40dp",
                    "left": "58dp",
                    "top": "26dp"
                },
                "OTPPostLogin.flxActions": {
                    "centerX": "",
                    "top": "15dp"
                },
                "OTPPostLogin.flxDescription": {
                    "left": "0"
                },
                "OTPPostLogin.flxEnterOTPCode": {
                    "left": "88dp",
                    "top": "30px"
                },
                "OTPPostLogin.flxExtendedNotes": {
                    "bottom": "",
                    "left": "0dp",
                    "top": "0dp"
                },
                "OTPPostLogin.flxSeparator2": {
                    "top": "20dp"
                },
                "OTPPostLogin.imgViewOTPCode": {
                    "src": "view.png"
                },
                "OTPPostLogin.lblHeader": {
                    "text": "Select any one or both mode of contact to get a secure  code",
                    "width": "80%"
                },
                "OTPPostLogin.lblHeaderOTP": {
                    "width": "100%"
                },
                "OTPPostLogin.lblNote": {
                    "bottom": "",
                    "left": "30dp",
                    "top": "50dp"
                },
                "OTPPostLogin.lblOTP": {
                    "left": "0dp"
                },
                "OTPPostLogin.lblResendMessage": {
                    "top": "3dp"
                },
                "OTPPostLogin.lblSecureAccessCodeNotes": {
                    "left": "30dp"
                },
                "OTPPostLogin.rtxHeaderOTP": {
                    "width": "85%"
                },
                "OTPComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "SCAComponent": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "SCAUnikenComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp"
                },
                "CustomFooterMain": {
                    "centerX": "",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                }
            }
            this.add(flxHeader, flxMain, flxLoading, flxLogout, flxFooter);
        };
        return [{
            "addWidgets": addWidgetsfrmMFATransactions,
            "enabledForIdleTimeout": true,
            "id": "frmMFATransactions",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_iaf82dc815a5431a84e1756b94d0e2f4,
            "postShow": controller.AS_Form_cea3905467b6471eba8bfacbaedff280,
            "preShow": function(eventobject) {
                controller.AS_Form_a7d12781782e419cad031377fb00858c(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "CommonsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_d81d44becfe2428b91d50b991cf71931,
            "retainScrollPosition": false
        }]
    }
});