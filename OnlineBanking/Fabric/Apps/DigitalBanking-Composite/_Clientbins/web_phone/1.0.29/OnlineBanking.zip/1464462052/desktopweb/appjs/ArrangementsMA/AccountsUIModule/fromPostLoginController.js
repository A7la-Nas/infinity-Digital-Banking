define("ArrangementsMA/AccountsUIModule/userfromPostLoginController", {
    //Type your controller code here 
});
define("ArrangementsMA/AccountsUIModule/fromPostLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ArrangementsMA/AccountsUIModule/fromPostLoginController", ["ArrangementsMA/AccountsUIModule/userfromPostLoginController", "ArrangementsMA/AccountsUIModule/fromPostLoginControllerActions"], function() {
    var controller = require("ArrangementsMA/AccountsUIModule/userfromPostLoginController");
    var controllerActions = ["ArrangementsMA/AccountsUIModule/fromPostLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
