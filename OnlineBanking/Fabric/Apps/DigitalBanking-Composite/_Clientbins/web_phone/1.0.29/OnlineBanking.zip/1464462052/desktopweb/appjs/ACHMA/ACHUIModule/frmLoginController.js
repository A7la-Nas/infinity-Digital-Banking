define("ACHMA/ACHUIModule/userfrmLoginController", {
    //Type your controller code here 
});
define("ACHMA/ACHUIModule/frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ACHMA/ACHUIModule/frmLoginController", ["ACHMA/ACHUIModule/userfrmLoginController", "ACHMA/ACHUIModule/frmLoginControllerActions"], function() {
    var controller = require("ACHMA/ACHUIModule/userfrmLoginController");
    var controllerActions = ["ACHMA/ACHUIModule/frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
