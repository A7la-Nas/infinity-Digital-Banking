define("com/temenos/infinity/sca/uniken/rememberMe/userrememberMeController", function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            let scopeObj = this;
            scopeObj.CHECBOX_SELECTED = "C";
            scopeObj.CHECBOX_UNSELECTED = "D";
            scopeObj.CHECKBOX_UNSELECTED_SKIN = 'skn0273e320pxolbfonticons';
            scopeObj.CHECKBOX_SELECTED_SKIN = 'sknFontIconCheckBoxSelected';
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        preshow: function() {
            let scopeObj = this;
            scopeObj.setFlowActions();
            scopeObj.view.lblFavoriteEmailCheckBox.text = scopeObj.CHECBOX_SELECTED;
            scopeObj.view.lblFavoriteEmailCheckBox.skin = scopeObj.CHECKBOX_SELECTED_SKIN;
        },
        setFlowActions: function() {
            let scopeObj = this;
            scopeObj.view.flexcheckuncheck.onClick = function() {
                let isSelected = scopeObj.isRememberMe();
                scopeObj.view.lblFavoriteEmailCheckBox.text = isSelected ? scopeObj.CHECBOX_UNSELECTED : scopeObj.CHECBOX_SELECTED;
                scopeObj.view.lblFavoriteEmailCheckBox.skin = isSelected ? scopeObj.CHECKBOX_UNSELECTED_SKIN : scopeObj.CHECKBOX_SELECTED_SKIN;
            };
            scopeObj.view.btnForgotPassword.onClick = function() {
                scopeObj.cantSignIn();
            };
        },
        isRememberMe: function() {
            let scopeObj = this;
            return scopeObj.view.lblFavoriteEmailCheckBox.text === scopeObj.CHECBOX_SELECTED;
        }
    };
});
define("com/temenos/infinity/sca/uniken/rememberMe/rememberMeControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for rememberMe **/
    AS_FlexContainer_b8412af146464514be1c58b56c159ba3: function AS_FlexContainer_b8412af146464514be1c58b56c159ba3(eventobject) {
        var self = this;
        return self.preshow.call(this);
    }
});
define("com/temenos/infinity/sca/uniken/rememberMe/rememberMeController", ["com/temenos/infinity/sca/uniken/rememberMe/userrememberMeController", "com/temenos/infinity/sca/uniken/rememberMe/rememberMeControllerActions"], function() {
    var controller = require("com/temenos/infinity/sca/uniken/rememberMe/userrememberMeController");
    var actions = require("com/temenos/infinity/sca/uniken/rememberMe/rememberMeControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});
