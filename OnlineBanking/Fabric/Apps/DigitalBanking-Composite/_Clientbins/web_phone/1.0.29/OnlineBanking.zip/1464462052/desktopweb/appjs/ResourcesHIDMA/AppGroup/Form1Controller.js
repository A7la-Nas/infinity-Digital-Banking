define("ResourcesHIDMA/AppGroup/userForm1Controller", {
    //Type your controller code here 
});
define("ResourcesHIDMA/AppGroup/Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ResourcesHIDMA/AppGroup/Form1Controller", ["ResourcesHIDMA/AppGroup/userForm1Controller", "ResourcesHIDMA/AppGroup/Form1ControllerActions"], function() {
    var controller = require("ResourcesHIDMA/AppGroup/userForm1Controller");
    var controllerActions = ["ResourcesHIDMA/AppGroup/Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
